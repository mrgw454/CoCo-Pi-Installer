cd /home/pi/pyDriveWire
./pyDriveWire --daemon

sleep 3s


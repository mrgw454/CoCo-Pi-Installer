    clear
    RETVAL=$(whiptail --title "$(cat $HOME/x68000pi-release.txt) $(cat $HOME/rpi-model.txt)" \
    --menu "\nPlease select from the following:" 18 70 10 \
    "1" "X68000 Attract Mode Floppy Disks (random)" \
    "2" "X68000 Attract Mode SASI HDD (random)" \
    "3" "Return to Main Menu" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) attract-mode-random-x68000.sh /media/share1/X68000/nfggames.com/X68000_Craig && X68000-menu-Attract.sh;;
        2) attract-mode-random-x68000.sh /media/share1/X68000/nfggames.com/HDD-Games && X68000-menu-Attract.sh;;
        3) X68000-menu.sh;;
        *) echo "Quitting...";;
    esac

    clear
    RETVAL=$(whiptail --title "$(cat $HOME/ti99pi-release.txt) $(cat $HOME/rpi-model.txt)" \
    --menu "\nPlease select from the following:" 18 70 10 \
    "1" "TI-99/4a MAME   Attract Mode (loop through all)" \
    "2" "TI-99/4a MAME   Attract Mode (random)" \
    "3" "TI-99/4a MAME   Attract Mode (random) ti99sim" \
    "4" "Return to Main Menu" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) attract-mode-ti99.sh && TI99Pi-menu-Attract.sh;;
        2) attract-mode-random-ti99.sh && TI99Pi-menu-Attract.sh;;
        3) attract-mode-random-ti99sim.sh && TI99Pi-menu-Attract.sh;;
        4) TI99Pi-menu.sh;;
        *) echo "Quitting...";;
    esac

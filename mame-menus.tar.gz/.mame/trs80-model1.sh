clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_trs80.txt`
export MAMEPARMS=$MAMEPARMSFILE

if [ -e $HOME/.mame/.override_ini_files ]
then

    echo Using existing ini file.
    echo

else

    echo

fi

if [ -e $HOME/.mame/.mame_cassette ]
then
    floppy=`cat $HOME/.mame/.mame_cassette`

    if [ -e "$cassette" ]
    then

        echo "Cassette save file found - automounting [$cassette]"
        echo
        read -p  "Press any key to continue." -n1 -s
        echo

	mame trs80 -ramsize 48k -cass1 "$cassette" $MAMEPARMS

    else

	echo "Cassette tape image [$cassette] not found in cassette save file.  Aborting."
        echo
        echo "Please run \"Clear all saved mount files\" on Utilities Menu."
        echo
        read -p  "Press any key to continue." -n1 -s
        echo

    fi

else

    mame trs80 -ramsize 48k -cass1 "$1" $MAMEPARMS

fi

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
TRS80pi-menu.sh

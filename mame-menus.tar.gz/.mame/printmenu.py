#!/usr/bin/python3

import re
import subprocess
import os
import json

menus = {}
scripts = {}

DEBUG = 0

defaultDir = "/home/pi/.mame"
def prMenu(shFile, indent, visited):
    # print('%s%s' % (' '*indent, shFile))
    if shFile in menus and shFile not in visited:
        visited += [shFile]
        indent += 3
        data = menus[shFile]
        for d in data['items']:
            print('%s%s - %s' % (' '*indent, d['tag'], d['action']))
            prMenu(d['action'], indent, visited)

with open('menu.json') as f:
    t = json.load(f)
menus = t['menus']
menus = t['menus']
prMenu('menu', 0, [])

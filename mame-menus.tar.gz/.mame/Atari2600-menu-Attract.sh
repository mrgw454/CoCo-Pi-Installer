    clear
    RETVAL=$(whiptail --title "$(cat $HOME/a2600pi-release.txt)" \
    --menu "\nPlease select from the following:" 18 70 10 \
    "1" "Atari 2600 MAME   Attract Mode (loop through all)" \
    "2" "Atari 2600 MAME   Attract Mode (random)" \
    "3" "Return to Main Menu" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) attract-mode-atari2600.sh /media/share1/atari/2600 && Atari2600-menu-Attract.sh;;
        2) attract-mode-random-atari2600.sh /media/share1/atari/2600 && Atari2600-menu-Attract.sh;;
        3) Atari2600-menu.sh;;
        *) echo "Quitting...";;
    esac

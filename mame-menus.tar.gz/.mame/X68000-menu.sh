cd $HOME/.mame

export NEWT_COLORS='
root=black,black
border=black,black
window=black,black
shadow=black,black
title=brightgreen,black
button=white,black
actbutton=black,white
checkbox=back,black
actcheckbox=black,black
entry=green,black
label=white,black
listbox=green,black
actlistbox=black,green
textbox=white,black
acttextbox=black,white
helpline=black
roottext=black
disentry=black,black
compactbutton=black,black
actsellistbox=black,green
sellistbox=green,black
'

    clear
    RETVAL=$(whiptail --title "$(cat $HOME/x68000pi-release.txt) $(cat $HOME/rpi-model.txt)" \
    --menu "\nPlease select from the following:" 18 65 10 \
    "1" "X68000 w/6MB RAM and 9000MB SCSI HDD E: (Games)" \
    "2" "Attract (Kiosk) Mode Menu" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) x68000-scsihdd.sh;;
        2) X68000-menu-Attract.sh;;
        *) echo "Quitting...";;
    esac

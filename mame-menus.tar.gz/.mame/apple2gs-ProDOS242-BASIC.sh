clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_apple2gs.txt`
export MAMEPARMS=$MAMEPARMSFILE

if [ -e $HOME/.mame/.override_ini_files ]
then

    echo Using existing ini file.
    echo

else

    # placeholder
    echo Using copied ini file

fi

if [ -e $HOME/.mame/.mame_floppy ]
then
    floppy=`cat $HOME/.mame/.mame_floppy`

    if [ -e "$floppy" ]
    then

        echo "Floppy save file found - automounting [$floppy]"
        echo
        read -p  "Press any key to continue." -n1 -s
        echo

        # apple IIgs
        mame apple2gsr1 -ramsize 8M -gameio joy -flop1 "$floppy" -flop2 "/media/share1/apple/source/BASIC/bench/AHLS/BENCH.DSK" $MAMEPARMS



    else

	echo "Floppy disk image [$floppy] not found in floppy save file.  Aborting."
        echo
        echo "Please run \"Clear all saved mount files\" on Utilities Menu."
        echo
        read -p  "Press any key to continue." -n1 -s
        echo

    fi

else

    # apple IIgs
    mame apple2gsr1 -ramsize 8M -gameio joy -flop1 "/media/share1/apple/DOS/ProDOS_2_4_2.dsk" -flop2 "/media/share1/apple/source/BASIC/BENCH/AHLS/BENCH.DSK" $MAMEPARMS

fi

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
ApplePi-menu.sh

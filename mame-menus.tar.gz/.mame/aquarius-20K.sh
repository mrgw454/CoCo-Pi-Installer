clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_aquarius.txt`
export MAMEPARMS=$MAMEPARMSFILE

if [ -e $HOME/.mame/.override_ini_files ]
then

    echo Using existing ini file.
    echo

else

    echo placeholder

fi


mame aquarius -ramsize 20k $MAMEPARMS

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
AQUARIUS-menu.sh

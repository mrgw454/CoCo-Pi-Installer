    clear
    RETVAL=$(whiptail --title "$(cat $HOME/applepi-release.txt) $(cat $HOME/rpi-model.txt)" \
    --menu "\nPlease select from the following:" 18 70 10 \
    "1" "Apple IIgs MAME Attract Mode (random)" \
    "2" "Return to Main Menu" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) attract-mode-random-apple2gs.sh /media/share1/apple/games/collections && ApplePi-menu-Attract.sh;;
        2) ApplePi-menu.sh;;
        *) echo "Quitting...";;
    esac

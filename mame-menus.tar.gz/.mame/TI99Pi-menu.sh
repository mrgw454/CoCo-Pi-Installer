cd $HOME/.mame

export NEWT_COLORS='
root=black,black
border=black,black
window=black,black
shadow=black,black
title=brightgreen,black
button=white,black
actbutton=black,white
checkbox=back,black
actcheckbox=black,black
entry=green,black
label=white,black
listbox=green,black
actlistbox=black,green
textbox=white,black
acttextbox=black,white
helpline=black
roottext=black
disentry=black,black
compactbutton=black,black
actsellistbox=black,green
sellistbox=green,black
'

    clear
    RETVAL=$(whiptail --title "$(cat $HOME/ti99pi-release.txt) $(cat $HOME/rpi-model.txt)" \
    --menu "\nPlease select from the following:" 18 65 10 \
    "1" "TI-99/4a w/loaded PEB 1MB RAM (Extended Basic 2.5)" \
    "2" "TI-99/4a w/loaded PEB 1MB RAM (Disk Manager)" \
    "3" "TI-99/4a w/loaded PEB 1MB RAM (Editor Assembler)" \
    "4" "TI-99/4a w/loaded PEB 1MB RAM (32K memtest)" \
    "5" "TI-99/4a w/loaded PEB 1MB RAM (Terminal Emulator)" \
    "6" "TI-99/4a w/loaded PEB 1MB RAM (Realms of Antiquity)" \
    "7" "TI-99/4a w/BASIC & Cassette (Hell's Halls)" \
    "8" "TI-99/4a w/TIPI   PEB 1MB RAM" \
    "9" "Attract (Kiosk) Mode Menu" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) ti994a_exbas25.sh;;
        2) ti994a_diskman.sh;;
        3) ti994a_editass.sh;;
        4) ti994a_32memtest.sh;;
        5) ti994a_rs232.sh;;
        6) ti994a_ROA.sh;;
        7) ti994a_HALLS.sh;;
        8) ti994a_TIPI.sh;;
        9) TI99Pi-menu-Attract.sh;;
        *) echo "Quitting...";;
    esac

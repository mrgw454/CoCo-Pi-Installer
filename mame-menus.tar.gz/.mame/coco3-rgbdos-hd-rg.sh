clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters.txt`
export MAMEPARMS=$MAMEPARMSFILE

if [ -e $HOME/.mame/.override_ini_files ]
then

    echo Using existing ini file.
    echo

else

    # disable Becker port
    cp $HOME/.mame/cfg/coco3.cfg.beckerport-disabled $HOME/.mame/cfg/coco3.cfg

fi

#mame coco3 -ramsize 512k -cart1 /media/share1/roms/RGBDOS2HD.ROM -hard1 /media/share1/EMU/VHD/VCCEmuDisk.vhd -ext fdc $MAMEPARMS
mame coco3 -ramsize 512k -ext multi -ext:multi:slot4 fdc -cart5 /media/share1/roms/RGBDOS2HD.ROM -hard1 /media/share1/EMU/VHD/VCCEmuDisk.vhd $MAMEPARMS

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
CoCoPi-menu-Coco3.sh

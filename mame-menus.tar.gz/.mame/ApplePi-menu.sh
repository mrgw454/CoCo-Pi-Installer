cd $HOME/.mame

export NEWT_COLORS='
root=black,black
border=black,black
window=black,black
shadow=black,black
title=brightgreen,black
button=white,black
actbutton=black,white
checkbox=back,black
actcheckbox=black,black
entry=green,black
label=white,black
listbox=green,black
actlistbox=black,green
textbox=white,black
acttextbox=black,white
helpline=black
roottext=black
disentry=black,black
compactbutton=black,black
actsellistbox=black,green
sellistbox=green,black
'

    clear
    RETVAL=$(whiptail --title "$(cat $HOME/applepi-release.txt) $(cat $HOME/rpi-model.txt)" \
    --menu "\nPlease select from the following:" 18 65 10 \
    "1" "Apple IIgs @ 16Mhz w/8MB, HDD and GS OS 6.0.4" \
    "2" "Apple IIgs @ 16Mhz w/8MB, ProDOS 16 & HDD" \
    "3" "Apple IIgs @ 16Mhz w/8MB, HDD, GS OS 6.0.4 & COMM" \
    "4" "Apple IIgs w/8MB ProDOS 2.4.2 & BASIC.SYSTEM" \
    "5" "Attract (Kiosk) Mode Menu" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) apple2gs-GSOS6-HD.sh;;
        2) apple2gs-CFFA2-HD.sh "$HOME/.gsplus/disks/myIISgs/h32mb.2mg";;
        3) apple2gs-Communications-HD.sh;;
        4) apple2gs-ProDOS242-BASIC.sh;;
        5) ApplePi-menu-Attract.sh;;
        *) echo "Quitting...";;
    esac

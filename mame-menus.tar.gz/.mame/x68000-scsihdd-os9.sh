clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_x68000.txt`
export MAMEPARMS=$MAMEPARMSFILE

# use SWITCH.X program to configure machine options

# SCSI HDD is drive letter E:
# Use LHES on E: to browse file system

# scsi hdd
#mame x68000 -ram 6MB -exp1 cz6bs1 -hard1 /media/share1/X68000/OS9/os9_x68000_2.4_pwin_hd/os9_x68000_2.4_pwin.hdf $MAMEPARMS
mame x68000 -ram 6MB -exp1 cz6bs1 -hard1 /media/share1/X68000/OS9/os9_x68000_2.4_text_hd/os9_x68000_2.4_text.hdf $MAMEPARMS

# sasi hdd
#mame x68000 -ram 6MB -sasihd /media/share1/X68000/OS9/os9_x68000_2.4_pwin_hd/os9_x68000_2.4_pwin.hdf $MAMEPARMS
#mame x68000 -ram 6MB -sasihd /media/share1/X68000/OS9/os9_x68000_2.4_text_hd/os9_x68000_2.4_text.hdf $MAMEPARMS


# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
	echo
else
	echo
	echo "Please make note of message above when requesting help."
	echo
	read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame


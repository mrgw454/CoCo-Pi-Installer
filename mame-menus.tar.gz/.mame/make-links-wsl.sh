#!/bin/bash

rm -r -f artwork
rm -r -f ctrlr
rm -r -f dats
rm -r -f folders
rm -r -f samples
rm -r -f videosnaps
rm -r -f videosnaps_SL
rm -r -f chds
rm -r -f roms
rm -r -f software

ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/artwork" artwork
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/ctrlr" ctrlr
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/dats" dats

#ln -s "/mnt/e/torrents/MAME 0.260 EXTRAs/folders" folders

ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/samples" samples
ln -s "/mnt/e/torrents/MAME 0.262 VideoSnaps/videosnaps" videosnaps
ln -s "/mnt/e/torrents/MAME 0.262 VideoSnaps/videosnaps_SL" videosnaps_SL
ln -s "/mnt/e/torrents/MAME 0.262 CHDs (merged)" chds
ln -s "/mnt/e/torrents/MAME 0.262 ROMs (non-merged)" roms
ln -s "/mnt/e/torrents/MAME 0.262 Software List ROMs (merged)" software

ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/artpreview.zip" artpreview.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/bosses.zip" bosses.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/cabinets.zip" cabinets.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/cheat.7z" cheat.7z
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/covers_SL.zip" covers_SL.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/cpanel.zip" cpanel.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/devices.zip" devices.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/ends.zip" ends.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/flyers.zip" flyers.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/gameover.zip" gameover.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/howto.zip" howto.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/icons.zip" icons.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/logo.zip" logo.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/manuals.zip" manuals.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/manuals_SL.zip" manuals_SL.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/marquees.zip" marquees.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/pcb.zip" pcb.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/scores.zip" scores.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/select.zip" select.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/snap.zip" snap.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/snap_SL.zip" snap_SL.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/titles.zip" titles.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/titles_SL.zip" titles_SL.zip
ln -s "/mnt/e/torrents/MAME 0.261 EXTRAs/versus.zip" versus.zip

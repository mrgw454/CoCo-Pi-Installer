clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_adam.txt`
export MAMEPARMS=$MAMEPARMSFILE

if [ -e $HOME/.mame/.override_ini_files ]
then

    echo Using existing ini file.
    echo

else

    # placeholder
    echo Using copied ini file

fi

mame adam -slot1 adamlink -slot2 ide -slot2:ide:ata:0 hdd -slot2:ide:ata:1 hdd -hard1 "/media/share1/coleco/IDE/CF/20250227/SanDisk-256MB-1of2.img" -hard2 "/media/share1/coleco/IDE/CF/20250227/SanDisk-256MB-2of2.img" -slot3 ram -ramsize 1024K -flop1 "$1" -cass1 "/media/share1/coleco/IDE/IDE Boot DDP.ddp" $MAMEPARMS

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
Adam-menu.sh

#!/usr/bin/python3

import dialog
import re
import subprocess
import os
import json
from string import Template
import atexit
import pexpect


DEBUG = 0

patWhip = re.compile('whiptail --title "([^"]+)"')
patChoice = re.compile('"(\w+)" +"([^"]+)"')
patAction= re.compile('(\w+)\) +([^;]+);;')
START = 1
WHIPTAIL = 2
ENTRIES = 3
ACTIONS = 4
END = 5

with open('menu.json') as f:
    objects = json.load(f)

def exit1():
    subprocess.run('clear')
atexit.register(exit1)

cmd = 'echo "$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)"'
title = subprocess.getoutput(cmd) + '\n\nPlease select from the following:'

def myExec(directory, cmd):
    p = pexpect.spawn('bash', [cmd], cwd=directory, env=os.environ)
    p.interact()
    p.terminate()

def parseSh(shFile):
    choices = []
    actions = {}
    item = objects['menus'].get(shFile, None)
    if item is None:
        item = objects['scripts'].get(shFile, None)
    if item['type'] == 'menu':
        for entry in item['items']:
            choices.append((entry['tag'], entry['desc']))
            actions[entry['tag']] = entry['action']
        if DEBUG:
            msg = """
            choices: %s
            actions: %s
            """ % (choices, actions)
            d = dialog.Dialog(autowidgetsize=True)
            d.msgbox(msg)
        d = dialog.Dialog(autowidgetsize=True)
        code, tag = d.menu(title, choices=choices)
        if code == 'ok':
            r = actions[tag]
        else:
            r = None
    elif item['type'] == 'script':
        pwd = os.getcwd()
        directory = Template(item['dir']).substitute(os.environ)
        os.chdir(directory)

        # shFile = shFile.split('&&')[0].strip()
        code = 'ok'
        d = dialog.Dialog(autowidgetsize=True)
        if DEBUG:
            code = d.yesno('Run: %s' % shFile)
        if code == 'ok':
            subprocess.run('clear')
            print(item)
            env = os.environ
            env['SHELL'] = '/bin/bash'
            # r = subprocess.run(item['cmd'], shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
            cmd = Template(item['cmd']).substitute(os.environ)
            if item.get('interactive') == True:
                #os.system(cmd)
                myExec(directory, cmd)
            else:
                print("Running: %s" % cmd)
                r = subprocess.run(['/bin/bash', cmd], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
                if r.returncode != 0:
                    msg = """
RC: %s
Stdout: %s
Stderr: %s
                    """ % (r.returncode, r.stdout, r.stderr)
                    code = d.msgbox(msg)
        os.chdir(pwd)
        r = '_back_'
    return r

g=open('log.txt', 'w')
mc = []
r = 'menu'
while r is not None:
    if r not in mc:
        mc.append(r)
    if DEBUG:
        d = dialog.Dialog(autowidgetsize=True)
        d.msgbox('r=%s, mc=%s' % (r,str(mc))) 
    r = parseSh(r)
    if r == '_back_':
        mc.pop()
        r = mc[-1]
    elif r in mc:
        i = mc.index(r)
        mc = mc[:i+1]

#    RETVAL=$(whiptail --title "$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)" \
#    --menu "\nPlease select from the following:" 18 65 10 \


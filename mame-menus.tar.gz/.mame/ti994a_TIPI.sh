clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_ti99.txt`
export MAMEPARMS=$MAMEPARMSFILE

/opt/google/chrome/chrome "http://192.168.0.26:9900/" &

# ccdcc FDC controller
mame ti99_4a -gromport single -ioport peb -ioport:peb:slot2 tipi,bios=2023 -conn rpi.192.168.0.26 -ioport:peb:slot3 speech -ioport:peb:slot4 samsmem -ioport:peb:slot5 tirs232 -ioport:peb:slot6 "" -ioport:peb:slot7 ccdcc -ioport:peb:slot7:ccdcc:0 525dd -ioport:peb:slot7:ccdcc:1 525dd -ioport:peb:slot7:ccdcc:2 "" -ioport:peb:slot7:ccdcc:3 "" -ioport:peb:slot8 "" -joyport twinjoy $MAMEPARMS

# bwg FDC controller
#mame ti99_4a -gromport single -ioport peb -ioport:peb:slot2 tipi,bios=2023 -conn rpi.192.168.0.26 -ioport:peb:slot3 speech -ioport:peb:slot4 samsmem -ioport:peb:slot5 tirs232 -ioport:peb:slot6 "" -ioport:peb:slot7 bwg -ioport:peb:slot7:bwg:0 525dd -ioport:peb:slot7:bwg:1 525dd -ioport:peb:slot7:bwg:2 "" -ioport:peb:slot7:bwg:3 "" -ioport:peb:slot8 "" -joyport twinjoy -cart exbasic $MAMEPARMS 

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
TI99Pi-menu.sh




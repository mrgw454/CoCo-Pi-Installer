cd $HOME/.mame

export NEWT_COLORS='
root=black,black
border=black,black
window=black,black
shadow=black,black
title=brightgreen,black
button=white,black
actbutton=black,white
checkbox=back,black
actcheckbox=black,black
entry=green,black
label=white,black
listbox=green,black
actlistbox=black,green
textbox=white,black
acttextbox=black,white
helpline=black
roottext=black
disentry=black,black
compactbutton=black,black
actsellistbox=black,green
sellistbox=green,black
'

    clear
    RETVAL=$(whiptail --title "$(cat $HOME/commodorepi-release.txt) $(cat $HOME/rpi-model.txt)" \
    --menu "\nPlease select from the following:" 18 65 10 \
    "1" "C64 w/64K & BASIC" \
    "2" "C128 w/128K & BASIC" \
    "3" "C64 Attract (random)" \
    "4" "C128 Attract (random)" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) c64-BASIC.sh;;
        2) c128-BASIC.sh;;
        3) attract-mode-random-c64.sh /media/share1/C64/itch.io;;
        4) attract-mode-random-c128.sh /media/share1/C128/demos;;
        *) echo "Quitting...";;
    esac

clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_nabupc.txt`
export MAMEPARMS=$MAMEPARMSFILE


#mame nabupc -window -kbd nabu_hle -bios ver14 -option1 fdc -flop1 /media/share1/nabu/disks/leo1.img -flop2 /media/share1/nabu/disks/leo2.img $MAMEPARMS
#mame nabupc -window -kbd nabu_hle -bios ver14 -option1 fdc -flop1 /media/share1/nabu/disks/zork.dsk $MAMEPARMS
mame nabupc -window -kbd nabu_hle -bios ver14 -option1 fdc $MAMEPARMS

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
	echo
else
	echo
	echo "Please make note of message above when requesting help."
	echo
	read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame


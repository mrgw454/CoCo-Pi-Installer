clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters.txt`
export MAMEPARMS=$MAMEPARMSFILE


if [ -e $HOME/.mame/.override_ini_files ]
then

    echo Using existing ini file.
    echo

else

    # disable Becker port
    cp $HOME/.mame/cfg/coco2b.cfg.beckerport-disabled $HOME/.mame/cfg/coco2b.cfg

fi

    mame coco2b -ramsize 64k -ext multi -flop1 "/media/share1/SDC/SHOEMAKE/DCPLAY.DSK" -flop2 "/media/share1/SDC/SHOEMAKE/DCMAP.DSK" -autoboot_delay 2 -autoboot_command 'RUN "RUNME.BAS"\n' $MAMEPARMS > /dev/null


# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
	echo
else
	echo
	echo "Please make note of message above when requesting help."
	echo
	read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
[ -n "$COCOPI_MENU_CALLER" ] && "$COCOPI_MENU_CALLER"

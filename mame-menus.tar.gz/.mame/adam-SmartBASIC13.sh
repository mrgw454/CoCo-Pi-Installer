clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_adam.txt`
export MAMEPARMS=$MAMEPARMSFILE

if [ -e $HOME/.mame/.override_ini_files ]
then

    echo Using existing ini file.
    echo

else

    # placeholder
    echo Using copied ini file

fi

	mame adam -slot3 ram -flop1 "/media/share1/coleco/BASIC/SmartBASIC+ v1.3 (198x) (Unknown).dsk" -flop2 "$1" $MAMEPARMS

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
Adam-menu.sh

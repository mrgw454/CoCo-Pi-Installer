clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_apple2gs.txt`
export MAMEPARMS=$MAMEPARMSFILE

if [ -e $HOME/.mame/.override_ini_files ]
then

    echo Using existing ini file.
    echo

else

    # placeholder
    echo Using copied ini file

fi

if [ -e $HOME/.mame/.mame_floppy ]
then
    floppy=`cat $HOME/.mame/.mame_floppy`

    if [ -e "$floppy" ]
    then

        echo "Floppy save file found - automounting [$floppy]"
        echo
        read -p  "Press any key to continue." -n1 -s
        echo

        # ROM 03, 16Mhz, Uthernet board in SLOT 3 and built-in serial port
        #mame apple2gs -ramsize 8M -gameio joy -modem null_modem -bitb socket.localhost:2023 -sl4 uthernet -flop3 "$floppy" -sl7 cffa2 -noautosave -hard1 "$1" -hard2 "$2" $MAMEPARMS
        #mame apple2gs -ramsize 8M -gameio joy -modem null_modem -bitb socket.localhost:2023 -sl4 uthernet -flop1 "$floppy" -sl7 cffa2 -noautosave -hard1 "$1" -hard2 "$2" $MAMEPARMS

        # ROM 01, 16Mhz, Uthernet board in SLOT 3 and built-in serial port
        #mame apple2gsr1 -ramsize 8M -gameio joy -modem null_modem -bitb socket.localhost:2023 -sl4 uthernet -flop3 "$floppy" -sl7 cffa2 -noautosave -hard1 "$1" -hard2 "$2" $MAMEPARMS
        mame apple2gsr1 -ramsize 8M -gameio joy -modem null_modem -bitb socket.localhost:2023 -sl4 uthernet -flop1 "$floppy" -sl7 cffa2 -noautosave -hard1 "$1" -hard2 "$2" $MAMEPARMS




    else

	echo "Floppy disk image [$floppy] not found in floppy save file.  Aborting."
        echo
        echo "Please run \"Clear all saved mount files\" on Utilities Menu."
        echo
        read -p  "Press any key to continue." -n1 -s
        echo

    fi

else

    # ROM 03, 16Mhz, Uthernet board in SLOT 3 and built-in serial port
    #mame apple2gs -ramsize 8M -gameio joy -modem null_modem -bitb socket.localhost:2023 -sl4 uthernet -sl7 cffa2 -noautosave -hard1 "$1" -hard2 "$2" $MAMEPARMS
    #mame apple2gs -ramsize 8M -gameio joy -modem null_modem -bitb socket.localhost:2023 -sl4 uthernet -sl7 cffa2 -noautosave -hard1 "$1" -hard2 "$2" $MAMEPARMS

    # ROM 01, 16Mhz, Uthernet board in SLOT 3 and built-in serial port
    #mame apple2gsr1 -ramsize 8M -gameio joy -modem null_modem -bitb socket.localhost:2023 -sl4 uthernet -sl7 cffa2 -noautosave -hard1 "$1" -hard2 "$2" $MAMEPARMS
    mame apple2gsr1 -ramsize 8M -gameio joy -modem null_modem -bitb socket.localhost:2023 -sl4 uthernet -sl7 cffa2 -noautosave -hard1 "$1" -hard2 "$2" $MAMEPARMS


fi

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
ApplePi-menu.sh

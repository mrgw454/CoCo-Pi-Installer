clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_msx2.txt`
export MAMEPARMS=$MAMEPARMSFILE

mame fsa1 -cart1 "$1" $MAMEPARMS


# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame

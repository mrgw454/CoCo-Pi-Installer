clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_nabupc.txt`
export MAMEPARMS=$MAMEPARMSFILE

mame nabupc -window -kbd nabu_hle -bios ver14 -option1 hdd -hard /media/share1/nabu/disks/hdd-mbasic.chd $MAMEPARMS

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
	echo
else
	echo
	echo "Please make note of message above when requesting help."
	echo
	read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame


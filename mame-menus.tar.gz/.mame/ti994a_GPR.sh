clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_ti99.txt`
export MAMEPARMS=$MAMEPARMSFILE

mame ti99_4a -video gdi -autoframeskip -natural -ioport peb -ioport:peb:slot2 32kmem -ioport:peb:slot3 tirs232 -ioport:peb:slot4 pcode -ioport:peb:slot8 tifdc -ioport:peb:slot8:tifdc:2 525dd -flop1 /media/share1/ti/GPR/GPR.dsk $MAMEPARMS

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
TI99Pi-menu.sh




clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters.txt`
export MAMEPARMS=$MAMEPARMSFILE

if [ -e $HOME/.mame/.override_ini_files ]
then

    echo Using existing ini file.
    echo

else

    # disable Becker port
    cp $HOME/.mame/cfg/coco3.cfg.beckerport-disabled $HOME/.mame/cfg/coco3.cfg

fi

if [ -e $HOME/.mame/.mame_rom ]
then
    rom=`cat $HOME/.mame/.mame_rom`

    if [ -e "$rom" ]
    then

        echo "ROM save file found - automounting [$rom]"
        echo
        read -p  "Press any key to continue." -n1 -s
        echo

	mame coco3 -ext gmc -cart "$rom" $MAMEPARMS

    else

        echo "ROM image [$rom] not found in ROM save file.  Aborting."
        echo
        echo "Please run \"Clear all saved mount files\" on Utilities Menu."
        echo
        read -p  "Press any key to continue." -n1 -s
        echo

    fi

else

	mame coco3 -ext gmc -cart /media/share1/roms/cocofest.rom $MAMEPARMS

fi

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
[ -n "$COCOPI_MENU_CALLER" ] && "$COCOPI_MENU_CALLER"

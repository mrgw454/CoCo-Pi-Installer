clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_x68000.txt`
export MAMEPARMS=$MAMEPARMSFILE

# use SWITCH.X program to configure machine options

# mame-0.252 is known to work
# SCSI HDD is drive letter E:
# Use LHES on E: to browse file system

mame x68000 -ram 12MB -flop1 /media/share1/X68000/work/MasterDisk_V2.xdf -exp1 cz6bs1 -hard1 /media/share1/X68000/work/X68000_V4.HDS $MAMEPARMS

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
	echo
else
	echo
	echo "Please make note of message above when requesting help."
	echo
	read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame


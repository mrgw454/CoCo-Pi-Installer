clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_apple2gs.txt`
export MAMEPARMS=$MAMEPARMSFILE

if [ -e $HOME/.mame/.override_ini_files ]
then

    echo Using existing ini file.
    echo

else

    # placeholder
    echo Using copied ini file

fi

    # apple IIgs
    mame apple2gsr1 -ramsize 8M -gameio joy -sl7 cffa2 -noautosave -hard1 "/media/share1/apple/Nox Archaist/Nox Archaist Lord of Storms HDV (v137).HDV" $MAMEPARMS

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
ApplePi-menu.sh

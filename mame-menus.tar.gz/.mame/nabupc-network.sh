clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_nabupc.txt`
export MAMEPARMS=$MAMEPARMSFILE

# use with nabud network emulator
#mame nabupc -window -kbd nabu_hle -hcca null_modem -bitb socket.127.0.0.1:5019 $MAMEPARMS

# use with NABUIA network emulator - make sure baud rates are set to 115200K
#mame nabupc -window -kbd nabu_hle -hcca null_modem -bitb socket.127.0.0.1:5816 $MAMEPARMS
mame nabupc -window -hcca null_modem -bitb socket.127.0.0.1:5816 $MAMEPARMS

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
	echo
else
	echo
	echo "Please make note of message above when requesting help."
	echo
	read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame


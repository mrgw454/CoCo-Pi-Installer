clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters.txt`
export MAMEPARMS=$MAMEPARMSFILE

cd $HOME/.mame

if [ -e $HOME/.mame/.override_ini_files ]
then

    echo Using existing ini file.
    echo

else

    # enable Becker port
    cp $HOME/.mame/cfg/coco3.cfg.beckerport-enabled $HOME/.mame/cfg/coco3.cfg

fi

# hdbdos method
mame coco3 -ramsize 2048k -ext multi -ext:multi:slot4 fdc -cart5 /media/share1/roms/hdbdw3bc3.rom -autoboot_delay 2 -autoboot_command '2' $MAMEPARMS

# yados method
#mame coco3 -ramsize 2048k -cart /media/share1/roms/yados.rom -ext fdc -autoboot_delay 2 -autoboot_command '2' $MAMEPARMS

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
[ -n "$COCOPI_MENU_CALLER" ] && "$COCOPI_MENU_CALLER"

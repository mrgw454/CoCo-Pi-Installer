cd $HOME/.mame

export NEWT_COLORS='
root=black,black
border=black,black
window=black,black
shadow=black,black
title=brightgreen,black
button=white,black
actbutton=black,white
checkbox=back,black
actcheckbox=black,black
entry=green,black
label=white,black
listbox=green,black
actlistbox=black,green
textbox=white,black
acttextbox=black,white
helpline=black
roottext=black
disentry=black,black
compactbutton=black,black
actsellistbox=black,green
sellistbox=green,black
'

    clear
    RETVAL=$(whiptail --title "$(cat $HOME/nabupi-release.txt) $(cat $HOME/rpi-model.txt)" \
    --menu "\nPlease select from the following:" 18 65 10 \
    "1" "NABU Network Boot" \
    "2" "NABU Floppy Boot" \
    "3" "NABU HDD Boot" \
    "4" "NABU HDD MBASIC Boot" \
    "5" "Start NABU Network Emulator (nabud)" \
    "6" "View  NABU Network Emulator Log File (nabud)" \
    "7" "Stop  NABU Network Emulator (nabud)" \
    "8" "Start NABU Network Emulator (NABUIA)" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) nabupc-network.sh;;
        2) nabupc-floppy.sh;;
        3) nabupc-hdd.sh;;
        4) nabupc-hdd-mbasic.sh;;
        5) $HOME/nabud/sbin/nabud -l $HOME/nabud/logs/nabud.log ; NABU-menu.sh;;
        6) less $HOME/nabud/logs/nabud.log ; NABU-menu.sh;;
        7) kill $(ps aux | grep 'nabud' | awk '{print $2}') ; NABU-menu.sh;;
        8) $HOME/NABUIA/NABU-Internet-Adapter-84;;
        *) echo "Quitting...";;
    esac

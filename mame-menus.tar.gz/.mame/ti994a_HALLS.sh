clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_ti99.txt`
export MAMEPARMS=$MAMEPARMSFILE

#mame ti99_4a -autoboot_delay 1 -autoboot_command '\n1\n\n\n\nOLD CS1\n\n' -cass1 /media/share1/ti/PixelPendant/HALLS-2Q.wav $MAMEPARMS
mame ti99_4a -cass1 /media/share1/ti/PixelPendant/HALLS-2Q.wav $MAMEPARMS

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
TI99Pi-menu.sh




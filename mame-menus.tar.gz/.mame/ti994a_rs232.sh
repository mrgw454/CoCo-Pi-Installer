clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_ti99.txt`
export MAMEPARMS=$MAMEPARMSFILE

mame ti99_4a -cart exbas25 -ioport peb -ioport:peb:slot4 samsmem -ioport:peb:slot5 tirs232 -serl1 socket.localhost:10000 -ioport:peb:slot7 hfdc -flop1 /media/share1/TI99/TERM80/term80.dsk $MAMEPARMS
#mame ti99_4a -cart /media/share1/TI99/roms/fastterm32k8.bin -ioport peb -ioport:peb:slot4 samsmem -ioport:peb:slot5 tirs232 -serl1 socket.localhost:10000 -ioport:peb:slot7 hfdc -flop1 /media/share1/TI99/TERM80/term80.dsk $MAMEPARMSFILE
#mame ti99_4a -cart /media/share1/TI99/roms/fast_term_113pc.rpk -ioport peb -ioport:peb:slot4 samsmem -ioport:peb:slot5 tirs232 -serl1 socket.localhost:10000 -ioport:peb:slot7 hfdc -flop1 /media/share1/TI99/TERM80/term80.dsk $MAMEPARMSFILE
#mame ti99_4a -cart exbas25 -ioport peb -ioport:peb:slot4 samsmem -ioport:peb:slot5 tirs232 -serl1 socket.localhost:10000 -ioport:peb:slot7 hfdc -flop1 /media/share1/TI99/TERM80/TELCO.DSK $MAMEPARMSFILE

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
TI99Pi-menu.sh

    clear
    RETVAL=$(whiptail --title "$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)" \
    --menu "\nPlease select from the following:" 18 70 10 \
    "1" "TRS-80 Color Computer 2 DECB" \
    "2" "TRS-80 Color Computer 2 DECB w/6309" \
    "3" "TRS-80 Color Computer 2 DECB w/SSC & MPI" \
    "4" "TRS-80 Color Computer 2 DECB w/GMC & MPI" \
    "5" "TRS-80 Color Computer 2 ECB  w/GMC" \
    "6" "TRS-80 Color Computer 2 DECB w/6309,SSFM & MPI" \
    "7" "TRS-80 Color Computer 2 HDB-DOS" \
    "8" "TRS-80 Color Computer 2 HDB-DOS w/6309" \
    "9" "TRS-80 Color Computer 2 HDB-DOS w/PLATO" \
    "10" "TRS-80 Color Computer 2 YA-DOS w/HDD" \
    "11" "TRS-80 Color Computer 2 YA-DOS w/6309 & HDD" \
    "12" "TRS-80 Color Computer 2 ECB w/64KB" \
    "13" "TRS-80 Color Computer 2 w/FLEX" \
    "14" "TRS-80 Deluxe Color Computer ACB w/64KB" \
    "15" "Return to Main Menu" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) coco2-decb.sh;;
        2) coco2-decb-6309.sh;;
        3) coco2-decb-ssc-mpi.sh;;
        4) coco2-decb-gmc-mpi.sh;;
        5) coco2-ecb-gamemaster.sh;;
	6) coco2-decb-SSFM-mpi-6309.sh;;
        7) coco2-hdbdos.sh;;
        8) coco2-hdbdos-6309.sh;;
        9) coco2-hdbdos-pyDW-PLATO.sh;;
       10) coco2-yados-HD-mpi.sh;;
       11) coco2-yados-HD-6309-mpi.sh;;
       12) coco2-ecb.sh;;
       13) coco2-flex.sh;;
       14) deluxecoco-decb.sh;;
       15) menu;;
        *) echo "Quitting...";;
    esac

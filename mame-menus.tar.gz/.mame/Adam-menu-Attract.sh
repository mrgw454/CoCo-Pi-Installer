    clear
    RETVAL=$(whiptail --title "$(cat $HOME/adampi-release.txt) $(cat $HOME/rpi-model.txt)" \
    --menu "\nPlease select from the following:" 18 70 10 \
    "1" "Coleco Adam MAME Attract Mode Carts (random)" \
    "2" "Coleco Adam MAME Attract Mode DDP's (random)" \
    "3" "Coleco Adam MAME Attract Mode Disks (random)" \
    "4" "Return to Main Menu" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) attract-mode-random-adam.sh /media/share1/coleco/games && Adam-menu-Attract.sh;;
        2) attract-mode-random-adam.sh /media/share1/coleco/DataPacks && Adam-menu-Attract.sh;;
        3) attract-mode-random-adam.sh /media/share1/coleco/Disks && Adam-menu-Attract.sh;;
        4) Adam-menu.sh;;
        *) echo "Quitting...";;
    esac

#!/bin/bash

# launch this is another window
#ssniffer /dev/tnt0 0 color

# tnt0 is used for fujinet-pc
# tnt1 is used for MAME
# set device speed (115200 for CoCo 3, 57600 for CoCo 2)
#stty -F /dev/tnt0 57600
#stty -F /dev/tnt1 57600
stty -F /dev/tnt0 115200
stty -F /dev/tnt1 115200

# show settings
stty -F /dev/tnt0 speed
stty -F /dev/tnt1 speed

echo
echo "hi" > /dev/tnt1; cat /dev/tnt0
echo

# Make sure Becker port is enabled using the UI (Machine Configuration)
# Make sure to match the baud rate in MAME using the UI (Machine Configuration)

# non Becker port HDB-DOS ROMs
#mame coco2b -ramsize 64k -rs232 null_modem -bitb /dev/tnt1 -cart /home/ron/source/toolshed-code/hdbdos/hdbdw3cc2.rom -ui_active -skip_gameinfo
#mame coco3 -ramsize 512k -rs232 null_modem -bitb /dev/tnt1 -cart /home/ron/source/toolshed-code/hdbdos/hdbdw3cc3.rom -ui_active -skip_gameinfo

# Becker port ROM usage
#mame coco2b -ramsize 64k -ext fdc,bios=hdbk12 -rs232 null_modem -bitb /dev/tnt1 -ui_active -skip_gameinfo
mame coco3 -ramsize 512k -ext fdc,bios=hdbk12 -rs232 null_modem -bitb /dev/tnt1 -ui_active -skip_gameinfo

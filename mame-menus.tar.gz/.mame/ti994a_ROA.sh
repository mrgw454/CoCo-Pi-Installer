clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_ti99.txt`
export MAMEPARMS=$MAMEPARMSFILE

#mame ti99_4a -cart exbasic -ioport peb -ioport:peb:slot4 samsmem -ioport:peb:slot5 tirs232 -ioport:peb:slot7 tifdc -flop1 /media/share1/ti/ROA/ROAGAME.dsk -flop2 /media/share1/ti/ROA/ROAWORLD12.dsk -ui_active -skip_gameinfo -window -nomax -resolution 1280x960
#mame ti99_4a -ioport peb -ioport:peb:slot3 speech -ioport:peb:slot2 samsmem -ioport:peb:slot8 ccfdc -ioport:peb:slot8:ccfdc:2 525dd -cart exbasic -flop1 /media/share1/ti/ROA/ROAGAME.dsk -flop2 /media/share1/ti/ROA/ROAWORLD12.dsk -flop3 /media/share1/ti/ROA/ROAWORLD34.dsk -ui_active -skip_gameinfo -window -nomax -resolution 1280x960
#mame ti99_4a -cart exbasic -ioport peb -ioport:peb:slot4 samsmem -ioport:peb:slot5 tirs232 -ioport:peb:slot7 bwg -flop1 /media/share1/ti/ROA/ROAGAME.dsk -flop2 /media/share1/ti/ROA/ROAWORLD12.dsk -ui_active -skip_gameinfo -window -nomax -resolution 1280x960
mame ti99_4a -ioport peb -ioport:peb:slot3 speech -ioport:peb:slot2 samsmem -ioport:peb:slot8 bwg -ioport:peb:slot8:bwg:2 525dd -cart exbasic -flop1 /media/share1/ti/ROA/ROAGAME.dsk -flop2 /media/share1/ti/ROA/ROAWORLD12.dsk -flop3 /media/share1/ti/ROA/ROAWORLD34.dsk $MAMEPARMS

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
TI99Pi-menu.sh




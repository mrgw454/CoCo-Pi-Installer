#!/bin/bash

rm -r -f artwork
rm -r -f ctrlr
rm -r -f dats
rm -r -f folders
rm -r -f samples
rm -r -f videosnaps
rm -r -f videosnaps_SL
rm -r -f chds
rm -r -f roms
rm -r -f software

ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/artwork" artwork
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/ctrlr" ctrlr
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/dats" dats

#ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/folders" folders

ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/samples" samples
ln -s "/media/ron/DATA/torrents/MAME 0.261 VideoSnaps/videosnaps" videosnaps
ln -s "/media/ron/DATA/torrents/MAME 0.261 VideoSnaps/videosnaps_SL" videosnaps_SL
ln -s "/media/ron/DATA/torrents/MAME 0.261 CHDs (merged)" chds
ln -s "/media/ron/DATA/torrents/MAME 0.261 ROMs (non-merged)" roms
ln -s "/media/ron/DATA/torrents/MAME 0.261 Software List ROMs (merged)" software

ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/artpreview.zip" artpreview.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/bosses.zip" bosses.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/cabinets.zip" cabinets.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/cheat.7z" cheat.7z
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/covers_SL.zip" covers_SL.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/cpanel.zip" cpanel.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/devices.zip" devices.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/ends.zip" ends.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/flyers.zip" flyers.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/gameover.zip" gameover.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/howto.zip" howto.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/icons.zip" icons.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/logo.zip" logo.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/manuals.zip" manuals.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/manuals_SL.zip" manuals_SL.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/marquees.zip" marquees.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/pcb.zip" pcb.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/scores.zip" scores.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/select.zip" select.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/snap.zip" snap.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/snap_SL.zip" snap_SL.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/titles.zip" titles.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/titles_SL.zip" titles_SL.zip
ln -s "/media/ron/DATA/torrents/MAME 0.260 EXTRAs/versus.zip" versus.zip

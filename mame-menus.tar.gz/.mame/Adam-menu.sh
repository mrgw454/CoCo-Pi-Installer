cd $HOME/.mame

export NEWT_COLORS='
root=black,black
border=black,black
window=black,black
shadow=black,black
title=brightgreen,black
button=white,black
actbutton=black,white
checkbox=back,black
actcheckbox=black,black
entry=green,black
label=white,black
listbox=green,black
actlistbox=black,green
textbox=white,black
acttextbox=black,white
helpline=black
roottext=black
disentry=black,black
compactbutton=black,black
actsellistbox=black,green
sellistbox=green,black
'

    clear
    RETVAL=$(whiptail --title "$(cat $HOME/adampi-release.txt) $(cat $HOME/rpi-model.txt)" \
    --menu "\nPlease select from the following:" 18 65 10 \
    "1" "Coleco Adam Typewriter" \
    "2" "Coleco Adam BASIC" \
    "3" "Coleco Adam SmartBASIC 1.0" \
    "4" "Coleco Adam SmartBASIC 1.1 (ROM)" \
    "5" "Coleco Adam SmartBASIC 1.3" \
    "6" "Coleco Adam SmartBASIC 2.0" \
    "7" "Coleco Adam SmartBASIC 2.1" \
    "8" "Coleco Adam w/EXT RAM and IDE HDD" \
    "9" "Attract (Kiosk) Mode Menu" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) adam-typewriter.sh;;
        2) adam-BASIC.sh;;
        3) adam-SmartBASIC10.sh;;
        4) adam-SmartBASIC11.sh;;
        5) adam-SmartBASIC13.sh;;
        6) adam-SmartBASIC20.sh;;
        7) adam-SmartBASIC21.sh;;
        8) adam-TDOS-IDE.sh;;
        9) Adam-menu-Attract.sh;;
        *) echo "Quitting...";;
    esac

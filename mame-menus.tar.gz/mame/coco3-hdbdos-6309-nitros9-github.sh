clear

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters.txt`
export MAMEPARMS=$MAMEPARMSFILE

if [ -e $HOME/.mame/.override_ini_files ]
then

    echo Using existing ini file.
    echo

else

    # enable Becker port
    cp $HOME/.mame/cfg/coco3h.cfg.beckerport-enabled $HOME/.mame/cfg/coco3h.cfg

fi

#mame coco3h -ramsize 2048k -ext multi -ext:multi:slot4 fdc -cart5 /media/share1/roms/hdbdw3bc3.rom -flop1 $HOME/source/nitros9/dsks/NOS9_6309_L2_v030300_coco3_40d_1.dsk -flop2 $HOME/source/nitros9/dsks/NOS9_6309_L2_v030300_coco3_40d_2.dsk -hard1 $HOME/source/nitros9/dsks/NOS9_6309_L2_v030300_coco3_cocosdc.dsk -autoboot_delay 2 -autoboot_command 'DRIVE OFF\nDOS\n' $MAMEPARMS

mame coco3h -ramsize 2M -ext multi -ext:multi:slot4 fdc,bios=ados380 -flop1 $HOME/source/nitros9/dsks/NOS9_6309_L2_v030300_coco3_40d_1.dsk

# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
CoCoPi-menu-Coco3.sh

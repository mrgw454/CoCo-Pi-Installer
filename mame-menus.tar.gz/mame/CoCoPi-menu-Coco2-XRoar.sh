    clear
    RETVAL=$(whiptail --title "$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)" \
    --menu "\nPlease select from the following:" 18 65 10 \
    "1" "TRS-80 Color Computer 2 DECB" \
    "2" "TRS-80 Color Computer 2 w/6309 DECB" \
    "3" "TRS-80 Color Computer 2 HDB-DOS" \
    "4" "TRS-80 Color Computer 2 YA-DOS w/HDD" \
    "5" "TRS-80 Color Computer 2 YA-DOS w/6309 & HDD" \
    "6" "TRS-80 Color Computer 2 w/512K MOOH" \
    "7" "TRS-80 Color Computer 2 w/GMC & CASSETTE image" \
    "8" "TRS-80 Color Computer 2 w/GMC & BIN image" \
    "9" "TRS-80 Color Computer 2 w/GMC & ROM image" \
    "10" "TRS-80 Color Computer 2 w/GMC & DSK image" \
    "11" "TRS-80 Color Computer 2 HDB-DOS w/PLATO" \
    "12" "TRS-80 Color Computer 2 w/FLEX" \
    "13" "TRS-80 Deluxe Color Computer ACB w/64KB" \
    "14" "Return to Main Menu" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) $HOME/.xroar/coco2-decb-xroar.sh;;
        2) $HOME/.xroar/coco2-decb-6309-xroar.sh;;
        3) $HOME/.xroar/coco2-hdbdos-xroar.sh;;
        4) $HOME/.xroar/coco2-yados-HD-xroar.sh;;
        5) $HOME/.xroar/coco2-yados-HD-6309-xroar.sh;;
        6) $HOME/.xroar/coco2-MOOH-xroar-Becker.sh;;
        7) $HOME/.xroar/coco2-GMC-CAS-xroar.sh;;
        8) $HOME/.xroar/coco2-GMC-BIN-xroar.sh;;
        9) $HOME/.xroar/coco2-GMC-ROM-xroar.sh;;
       10) $HOME/.xroar/coco2-GMC-FLOPPY-xroar.sh;;
       11) $HOME/.xroar/coco2-hdbdos-pyDW-PLATO-xroar.sh;;
       12) $HOME/.xroar/coco2-flex-xroar.sh;;
       13) $HOME/.xroar/deluxecoco-acb-xroar.sh;;
       14) menu;;
        *) echo "Quitting...";;
    esac

# ssniffer /dev/tnt0 0 color

# stty -F /dev/tnt1 57600
# stty -F /dev/tnt1 speed

# echo "hi" > /dev/tnt1; cat /dev/tnt0

# Use this for a Coco 2 using a bit-banger port at 1200 baud.  Make sure to match the baud rate in MAME using the UI (Machine Configuration)
#mame coco2b -rs232 null_modem -bitb socket.localhost:6551 -flop1 /media/share1/SDC/COMM/GETERM25.DSK -autoboot_delay 2 -autoboot_command 'LOADM"GETERM.BIN":EXEC\n' -ui_active -skip_gameinfo
mame coco2b -cart /media/share1/roms/hdbdw3bck.rom
#mame coco2b -rs232 null_modem -bitb socket.localhost:6551 -cart /media/share1/roms/hdbdw3bck.rom


# Use this for a Coco 2 using a Deluxe RS-232 Pak and MultiPak Interface at 1200 baud.  Make sure to match the baud rate in MAME using the UI (Machine Configuration)
#mame coco2b -ramsize 64K -ext multi -ext:multi:slot1 rs232 -ext:multi:slot1:rs232:port null_modem -bitb socket.localhost:6551 -flop1 /media/share1/SDC/COMM/GETERM25.DSK -ui_active -skip_gameinfo
#mame coco2b -ramsize 64k -ext multi -ext:multi:slot4 fdc -cart5 /media/share1/roms/hdbdw3bck.rom $MAMEPARMS

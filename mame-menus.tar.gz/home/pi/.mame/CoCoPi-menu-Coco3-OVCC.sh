    clear
    RETVAL=$(whiptail --title "$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)" \
    --menu "\nPlease select from the following:" 18 75 10 \
    "1" "Tandy Color Computer 3 DECB" \
    "2" "Tandy Color Computer 3 DECB w/6309,2MB" \
    "3" "Tandy Color Computer 3 DECB w/6309 & ORCH90" \
    "4" "Tandy Color Computer 3 HDB-DOS" \
    "5" "Tandy Color Computer 3 HDB-DOS w/6309,2MB & NitrOS9 EOU" \
    "6" "Tandy Color Computer 3 HDB-DOS w/6309,2MB,Fuzix & pyDW" \
    "7" "Tandy Color Computer 3 HDB-DOS w/6309,2MB,Fuzix & lwwire" \
    "8" "Tandy Color Computer 3 HDB-DOS w/PLATO" \
    "9" "Tandy Color Computer 3 YA-DOS w/6309,2MB & HDD" \
    "10" "Return to Main Menu" \
    3>&1 1>&2 2>&3)

    # Below you can enter the corresponding commands

    case $RETVAL in
        1) $HOME/.ovcc/coco3-decb-OVCC.sh;;
        2) $HOME/.ovcc/coco3-decb-6309-2MB-OVCC.sh;;
	3) $HOME/.ovcc/coco3-decb-6309-ORCH90-OVCC.sh;;
        4) $HOME/.ovcc/coco3-hdbdos-OVCC.sh;;
        5) $HOME/.ovcc/coco3-hdbdos-6309-nitros9-OVCC.sh;;
        6) $HOME/.ovcc/coco3-Fuzix-pyDW-OVCC.sh;;
        7) $HOME/.ovcc/coco3-Fuzix-lwwire-OVCC.sh;;
        8) $HOME/.ovcc/coco3-hdbdos-pyDW-PLATO-OVCC.sh;;
        9) $HOME/.ovcc/coco3-yados-HD-6309-mpi-OVCC.sh;;
       10) menu;;
        *) echo "Quitting...";;
    esac

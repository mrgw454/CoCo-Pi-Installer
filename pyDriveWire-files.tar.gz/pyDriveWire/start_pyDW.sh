#!/bin/bash

# for troubleshooting, use this
# sudo tcpdump -w /tmp/pyDriveWire.tcpdump -i lo port 65504

rm /tmp/pyDriveWire.pid > /dev/null 2>&1
rm /tmp/pyDriveWire.log > /dev/null 2>&1

cd $HOME/pyDriveWire
./pyDriveWire --daemon

sleep 3s

cd $HOME/.mame


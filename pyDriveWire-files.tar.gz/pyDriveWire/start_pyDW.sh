#!/bin/bash
PIDFILE="/tmp/pyDriveWire.pid"
SRCDIR="$HOME/pyDriveWire"
PYTHON="/home/ron/.pyenv/versions/3.11.2/bin/python3"

echo "Starting pyDriveWire..."
rm -f "$PIDFILE" /tmp/pyDriveWire.log

cd "$SRCDIR"
$PYTHON pyDriveWire.py --daemon

sleep 2

if [ -f "$PIDFILE" ]; then
    PID=$(cat "$PIDFILE")
    if ps -p "$PID" >/dev/null 2>&1; then
        echo "pyDriveWire started (PID $PID)"
    else
        echo "PID file exists but process is not running."
    fi
else
    echo "pyDriveWire did not create a PID file."
fi

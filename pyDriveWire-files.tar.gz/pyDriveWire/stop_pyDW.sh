#!/bin/bash

echo "Stopping pyDriveWire server..."
echo ""

cd $HOME/pyDriveWire
./pyDriveWire --stop

rm /tmp/pyDriveWire.pid > /dev/null 2>&1

cd $HOME/.mame


#!/bin/bash
PIDFILE="/tmp/pyDriveWire.pid"
SRCDIR="$HOME/pyDriveWire"
PYTHON="/home/ron/.pyenv/versions/3.11.2/bin/python3"

echo "Stopping pyDriveWire..."

if [ ! -f "$PIDFILE" ]; then
    echo "pyDriveWire is not running."
    exit 1
fi

PID=$(cat "$PIDFILE")

cd "$SRCDIR"
$PYTHON pyDriveWire.py --stop

sleep 1

if ps -p "$PID" >/dev/null 2>&1; then
    echo "Force killing pyDriveWire..."
    kill -9 "$PID"
fi

rm -f "$PIDFILE"
echo "pyDriveWire stopped."

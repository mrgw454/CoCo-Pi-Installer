import urllib.request
import re
import traceback
import sys

if len(sys.argv) < 2:
    print("Usage: pyDwCli <url> [<cmd>]")
    sys.exit(1)

url = sys.argv[1]
cmd = None
if len(sys.argv) > 2:
    cmd = " ".join(sys.argv[2:])

while True:
    try:
        if cmd:
            wdata = cmd
        else:
            print("pyDriveWire>", end=" ")
            wdata = input()
    except EOFError:
        print()
        print("Bye!")
        break

    # Exit conditions
    if wdata.startswith(chr(4)) or wdata.lower() in ["exit", "quit"]:
        print("Bye!")
        break

    try:
        # Clean up backspace and delete characters
        wdata = re.subn('.\b', '', wdata)[0]
        wdata = re.subn('.\x7f', '', wdata)[0]

        # Encode and send request
        data = wdata.encode('latin-1')
        req = urllib.request.Request(url, data=data)
        req.add_header('Content-Type', 'application/x-www-form-urlencoded')

        with urllib.request.urlopen(req) as conn:
            result = conn.read().decode('latin-1')
            print(result)

        if cmd:
            break
    except Exception as ex:
        print("ERROR:: %s" % str(ex))
        traceback.print_exc()

cd $HOME/pyDriveWire
./pyDwCli http://localhost:6800

sleep 3s

cd $HOME/.mame


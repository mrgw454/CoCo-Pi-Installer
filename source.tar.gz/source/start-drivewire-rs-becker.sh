#!/usr/bin/env bash

set -euo pipefail

DW_BIN="${HOME}/source/drivewire-rs/target/release/dw"

if [[ $# -ne 1 ]]; then
    echo "Usage: $0 /path/to/disk.dsk" >&2
    exit 1
fi

if [[ ! -x "${DW_BIN}" ]]; then
    echo "drivewire-rs binary not found at ${DW_BIN}" >&2
    exit 1
fi

exec "${DW_BIN}" serve \
    --tcp 127.0.0.1:65504 \
    --disk0 "$1"

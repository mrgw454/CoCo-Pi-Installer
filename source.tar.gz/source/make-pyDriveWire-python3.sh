#!/bin/bash

# pyDriveWire Installer for Debian 13 (pyenv Python 3.11.2)

export PYENV_ROOT="$HOME/.pyenv"
export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init -)"

PYTHON_VERSION="3.11.2"
PYENV_PYTHON="$HOME/.pyenv/versions/${PYTHON_VERSION}/bin/python3"

echo "Checking pyenv..."
if ! command -v pyenv >/dev/null 2>&1; then
  echo "pyenv not found"
  exit 1
fi

if pyenv versions --bare | grep -q "^${PYTHON_VERSION}$"; then
  echo "Python ${PYTHON_VERSION} already installed"
else
  echo "Installing Python ${PYTHON_VERSION}..."
  pyenv install "${PYTHON_VERSION}"
fi

pyenv shell "${PYTHON_VERSION}"

echo
python --version
echo

echo "Installing required Python modules..."
python -m pip install --upgrade pip wheel setuptools
python -m pip install pyserial reportlab playsound==1.2.2

echo
echo "Preparing pyDriveWire source..."
cd "$HOME/source"

if [ -L "$HOME/pyDriveWire" ]; then
  rm "$HOME/pyDriveWire"
fi

if [ -d "pyDriveWire-git" ]; then
  foldername=$(date +%Y-%m-%d_%H.%M.%S)
  mv "pyDriveWire-git" "pyDriveWire-git-$foldername"
  echo "Archived previous pyDriveWire-git → pyDriveWire-git-$foldername"
fi

git clone https://github.com/n6il/pyDriveWire.git pyDriveWire-git
cd pyDriveWire-git
git checkout develop

echo "Patching pyDriveWire wrapper to use pyenv Python..."
sed -i "s|python=\"python3\"|python=\"$PYENV_PYTHON\"|" pyDriveWire
sed -i "s|python=\"python\"|python=\"$PYENV_PYTHON\"|" pyDriveWire
sed -i "s|python=\$(which python3)|python=\"$PYENV_PYTHON\"|" pyDriveWire
sed -i "s|python=\$(which python)|python=\"$PYENV_PYTHON\"|" pyDriveWire

echo "Patching eval() issues for Python 3.11..."
sed -i "s/\[o for o in list(opts) if eval('args.%s' % o)\]/[o for o in list(opts) if getattr(args, o)]/" pyDriveWire.py
sed -i "s/\[eval('args.%s' % o) for o in list(opts)\]/[getattr(args, o) for o in list(opts)]/" pyDriveWire.py

echo "Fixing daemon.py buffering bug..."
sed -i "s/se = open(self.stderr, 'a+', 0)/se = open(self.stderr, 'ab+', 0)/" daemon.py

chmod a+x *.py pyDriveWire

echo "Embedding pydrivewirerc-daemon..."

cat > "$HOME/source/pyDriveWire-git/config/pydrivewirerc-daemon" <<'EOF'
# Main Instance
option daemonPidFile /tmp/pyDriveWire.pid
option daemonLogFile /tmp/pyDriveWire.log
option accept True
option port 65504
option uiPort 6800
option hdbdos True
option printFormat txt
option printPrefix output
option printDir /media/share1/printer/
option experimental printer
option experimental ssh
option experimental playsound
dw server debug 1
dw server conn debug 1
dw disk insert 0 /media/share1/DW4/FURMAN/DWTERM/DWTERM.dsk

#[serial]
#option port /dev/ttyUSB0
#option speed 38400
#mc setdir /media/share1/JIMG

[connect]
option accept True
option host localhost
#option port 54321
option port 6809
mc setdir /media/share1/JIMG
EOF

echo "Creating ~/.pydrivewirerc symlink..."

rm -f "$HOME/.pydrivewirerc"
ln -s "$HOME/source/pyDriveWire-git/config/pydrivewirerc-daemon" "$HOME/.pydrivewirerc"

echo
echo "Embedding lifecycle scripts..."

###############################################
# start_pyDW.sh
###############################################
cat > start_pyDW.sh <<EOF
#!/bin/bash
PIDFILE="/tmp/pyDriveWire.pid"
SRCDIR="\$HOME/pyDriveWire"
PYTHON="$PYENV_PYTHON"

echo "Starting pyDriveWire..."
rm -f "\$PIDFILE" /tmp/pyDriveWire.log

cd "\$SRCDIR"
\$PYTHON pyDriveWire.py --daemon

sleep 2

if [ -f "\$PIDFILE" ]; then
    PID=\$(cat "\$PIDFILE")
    if ps -p "\$PID" >/dev/null 2>&1; then
        echo "pyDriveWire started (PID \$PID)"
    else
        echo "PID file exists but process is not running."
    fi
else
    echo "pyDriveWire did not create a PID file."
fi
EOF

###############################################
# status_pyDW.sh
###############################################
cat > status_pyDW.sh <<EOF
#!/bin/bash
PIDFILE="/tmp/pyDriveWire.pid"

if [ ! -f "\$PIDFILE" ]; then
    echo "pyDriveWire is not running."
    exit 1
fi

PID=\$(cat "\$PIDFILE")

if ps -p "\$PID" >/dev/null 2>&1; then
    echo "pyDriveWire is running (PID \$PID)"
else
    echo "PID file exists but process is not running."
fi
EOF

###############################################
# stop_pyDW.sh
###############################################
cat > stop_pyDW.sh <<EOF
#!/bin/bash
PIDFILE="/tmp/pyDriveWire.pid"
SRCDIR="\$HOME/pyDriveWire"
PYTHON="$PYENV_PYTHON"

echo "Stopping pyDriveWire..."

if [ ! -f "\$PIDFILE" ]; then
    echo "pyDriveWire is not running."
    exit 1
fi

PID=\$(cat "\$PIDFILE")

cd "\$SRCDIR"
\$PYTHON pyDriveWire.py --stop

sleep 1

if ps -p "\$PID" >/dev/null 2>&1; then
    echo "Force killing pyDriveWire..."
    kill -9 "\$PID"
fi

rm -f "\$PIDFILE"
echo "pyDriveWire stopped."
EOF

###############################################
# pyDwCli
###############################################
cat > pyDwCli <<EOF
#!/bin/bash
PYTHON="$PYENV_PYTHON"

if [ ! -x "\$PYTHON" ]; then
    echo "ERROR: pyenv Python 3.11.2 not found."
    exit 1
fi

\$PYTHON <<CHECK
try:
    import serial
except:
    exit(1)
CHECK

if [ \$? != 0 ]; then
    echo "ERROR: pyserial is required!"
    echo "Run: \$PYTHON -m pip install pyserial"
    exit 1
fi

exec "\$PYTHON" "\$0.py" "\$@"
EOF

###############################################
# pyDwCli.py
###############################################
cat > pyDwCli.py <<'EOF'
import urllib.request
import re
import traceback
import sys

if len(sys.argv) < 2:
    print("Usage: pyDwCli <url> [<cmd>]")
    sys.exit(1)

url = sys.argv[1]
cmd = None
if len(sys.argv) > 2:
    cmd = " ".join(sys.argv[2:])

while True:
    try:
        if cmd:
            wdata = cmd
        else:
            print("pyDriveWire>", end=" ")
            wdata = input()
    except EOFError:
        print("\nBye!")
        break

    if wdata.startswith(chr(4)) or wdata.lower() in ["exit", "quit"]:
        print("Bye!")
        break

    try:
        wdata = re.subn('.\b', '', wdata)[0]
        wdata = re.subn('.\x7f', '', wdata)[0]

        data = wdata.encode('latin-1')
        req = urllib.request.Request(url, data=data)
        req.add_header('Content-Type', 'application/x-www-form-urlencoded')

        with urllib.request.urlopen(req) as conn:
            result = conn.read().decode('latin-1')
            print(result)

        if cmd:
            break
    except Exception as ex:
        print("ERROR:: %s" % str(ex))
        traceback.print_exc()
EOF

chmod a+x start_pyDW.sh stop_pyDW.sh status_pyDW.sh pyDwCli

cd ..
ln -s "$HOME/source/pyDriveWire-git" "$HOME/pyDriveWire"

echo
echo "pyDriveWire installation complete."
echo

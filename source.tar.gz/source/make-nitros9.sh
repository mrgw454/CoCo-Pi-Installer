#!/bin/bash

cd $HOME/source

# if a previous nitros9 folder exists, move into a date-time named folder

if [ -d "nitros9" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "nitros9" "nitros9-$foldername"

        echo -e Archiving existing nitros9 folder ["nitros9"] into backup folder ["nitros9-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/nitros9project/nitros9
git clone https://github.com/nitros9project/nitros9.git

cd nitros9

GITREV=`git rev-parse --short HEAD`

# modifications start here
sed -i 's/-t1024/-t29126 -e -ss -dd/' ./level1/coco1/makefile
sed -i 's/-t1024/-t29126 -e -ss -dd/' ./level2/coco3/makefile
sed -i 's/OS9FORMAT_DW	= $(OS9) format -t29126 -ss -dd/OS9FORMAT_DW	= $(OS9) format -e -t29126 -ss -dd/' ./rules.mak

echo 'git rev $GITREV' >> ./level2/coco3/startup
echo >> ./level2/coco3/startup
echo 'inetd <>>>/w&' >> ./level2/coco3/startup
echo 'shell i=/w&' >> ./level2/coco3/startup
echo 'shell i=/w&' >> ./level2/coco3/startup
echo 'shell i=/w&' >> ./level2/coco3/startup
echo 'shell i=/w&' >> ./level2/coco3/startup

echo 'git rev $GITREV' >> ./level2/coco3/startup.dw
echo >> ./level2/coco3/startup.dw
echo 'inetd <>>>/w&' >> ./level2/coco3/startup.dw
echo 'shell i=/w&' >> ./level2/coco3/startup.dw
echo 'shell i=/w&' >> ./level2/coco3/startup.dw
echo 'shell i=/w&' >> ./level2/coco3/startup.dw
echo 'shell i=/w&' >> ./level2/coco3/startup.dw


# replace with better terminal window definitions
if [ ! -f $HOME/source/new_windows.zip ]; then
        echo
        echo new_windows.zip archive missing.  Aborting.
        echo
        exit 1
fi

unzip -o ../new_windows.zip -d ./level2/modules

export NITROS9DIR=$HOME/source/nitros9

make
make dsk
make dskcopy


echo
echo Done!


#!/bin/bash

cd $HOME/source

# if a previous pod folder exists, move into a date-time named folder

if [ -d "pod" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "pod" "pod-$foldername"

        echo -e Archiving existing pod folder ["pod"] into backup folder ["pod-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/beretta42/pod
git clone https://github.com/beretta42/pod.git

cd pod

GITREV=`git rev-parse --short HEAD`

echo $(nproc) / 2 | bc
cores=$(echo $(nproc) / 2 | bc)
make -j$cores

if [ $? -eq 0 ]
then
        echo "Compilation was successful."
        echo
else
        echo "Compilation was NOT successful.  Aborting installation."
        echo
        exit 1
fi

if [ ! -d /media/share1/SDC/GORDON/POD ]; then
	mkdir -p /media/share1/SDC/GORDON/POD
fi

cp pod.dsk /media/share1/SDC/GORDON/POD

cd $HOME/source


echo
echo Done!

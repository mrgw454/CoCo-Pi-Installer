#!/bin/bash
set -e

cd "$HOME/source"

# ---------------------------------------------------------------------------
# 1. Ensure uv exists (install if missing)
# ---------------------------------------------------------------------------
if ! command -v uv >/dev/null 2>&1; then
    echo "uv not found. Installing..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    export PATH="$HOME/.local/bin:$PATH"
fi

# ---------------------------------------------------------------------------
# 2. Archive existing folder
# ---------------------------------------------------------------------------
if [ -d "coco-tools" ]; then
    foldername=$(date +%Y-%m-%d_%H.%M.%S)
    mv "coco-tools" "coco-tools-$foldername"
    echo "Archived existing coco-tools into coco-tools-$foldername"
fi

# ---------------------------------------------------------------------------
# 3. Clone fresh repo
# ---------------------------------------------------------------------------
git clone https://github.com/jamieleecho/coco-tools.git
cd coco-tools

GITREV=$(git rev-parse --short HEAD)
echo "Building coco-tools revision $GITREV"

# ---------------------------------------------------------------------------
# 4. Sync dependencies (creates .venv)
# ---------------------------------------------------------------------------
uv sync

# ---------------------------------------------------------------------------
# 5. Create symlinks into /usr/local/bin (SAFE FILTER)
# ---------------------------------------------------------------------------
SRC="$PWD/.venv/bin"
DEST="/usr/local/bin"

echo "Cleaning old coco-tools symlinks from $DEST"
sudo bash -c '
find "'"$DEST"'" -maxdepth 1 -type l -exec sh -c "
    for link; do
        target=\$(readlink \"\$link\")
        case \"\$target\" in
            */source/coco-tools/*) rm \"\$link\";;
        esac
    done
" sh {} +
'

echo "Creating new coco-tools symlinks"

for f in "$SRC"/*; do
    base=$(basename "$f")

    case "$base" in
        cm3toppm|hrstoppm|maxtoppm|mgetoppm|mge_viewer2|pixtopgm|rattoppm|veftopng|decb-to-b09)
            sudo ln -sf "$f" "$DEST/$base"
            ;;
        png-to-*|pri*png)
            sudo ln -sf "$f" "$DEST/$base"
            ;;
    esac
done

echo "Symlinks created in $DEST"

# ---------------------------------------------------------------------------
# 6. Verify
# ---------------------------------------------------------------------------
echo
echo "Installed coco-tools commands now in /usr/local/bin:"
ls -1 "$DEST" | grep -E 'ppm|png|b09|mge|pix|ratt' || true

echo
echo "Done."

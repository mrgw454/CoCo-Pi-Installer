#!/bin/bash

cd $HOME/source

# if a previous mc09-linux-port folder exists, move into a date-time named folder

if [ -d "mc09-linux-port" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "mc09-linux-port" "mc09-linux-port-$foldername"

        echo -e Archiving existing mc09-linux-port folder ["mc09-linux-port"] into backup folder ["mc09-linux-port-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/lindoran/mc09-linux-port
git clone https://github.com/lindoran/mc09-linux-port.git

cd mc09-linux-port

GITREV=`git rev-parse --short HEAD`

echo $(nproc) / 2 | bc
cores=$(echo $(nproc) / 2 | bc)
make -j$cores

if [ $? -eq 0 ]
then
        echo "Compilation was successful."
        echo
else
        echo "Compilation was NOT successful.  Aborting installation."
        echo
        exit 1
fi

INSTALL_DIR="/usr/local/bin"
SOURCE_DIR="$HOME/source/mc09-linux-port"

echo "Scanning for executable binaries in $SOURCE_DIR..."

# Move into the directory to scan files
pushd "$SOURCE_DIR" > /dev/null

for file in *; do
    # Check if it's a regular file (-f) AND executable (-x)
    if [[ -f "$file" && -x "$file" ]]; then
        echo "Found executable: $file. Creating symlink..."

        # Use -f to overwrite existing links and -s for symbolic
        sudo ln -sf "$SOURCE_DIR/$file" "$INSTALL_DIR/$file"

        if [ $? -eq 0 ]; then
            echo "  Successfully linked $file -> $INSTALL_DIR/$file"
        else
            echo "  Failed to link $file"
        fi
    fi
done

popd > /dev/null

cd $HOME/source


echo
echo Done!

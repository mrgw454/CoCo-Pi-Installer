#!/usr/bin/env bash

set -euo pipefail

REPO_URL="https://github.com/justindthomas/drivewire-rs.git"
SOURCE_ROOT="${HOME}/source"
REPO_DIR="${SOURCE_ROOT}/drivewire-rs"
LAUNCHER_PATH="${REPO_DIR}/target/release/start-drivewire-rs-becker.sh"

need_cmd() {
    command -v "$1" >/dev/null 2>&1
}

install_apt_packages() {
    local packages=()

    for pkg in ca-certificates curl git build-essential pkg-config; do
        if ! dpkg -s "$pkg" >/dev/null 2>&1; then
            packages+=("$pkg")
        fi
    done

    if ((${#packages[@]} == 0)); then
        return
    fi

    echo "Installing Debian packages: ${packages[*]}"
    sudo apt-get update
    sudo apt-get install -y "${packages[@]}"
}

install_rustup() {
    if need_cmd cargo; then
        return
    fi

    echo "Installing Rust toolchain with rustup"
    curl https://sh.rustup.rs -sSf | sh -s -- -y
}

load_rust_env() {
    if [[ -f "${HOME}/.cargo/env" ]]; then
        # shellcheck disable=SC1090
        source "${HOME}/.cargo/env"
    fi
}

ensure_repo() {
    mkdir -p "${SOURCE_ROOT}"

    if [[ -e "${REPO_DIR}" ]]; then
        local timestamp
        local backup_dir

        timestamp="$(date +%Y%m%d-%H%M%S)"
        backup_dir="${SOURCE_ROOT}/drivewire-rs-${timestamp}"

        echo "Backing up existing ${REPO_DIR} to ${backup_dir}"
        mv "${REPO_DIR}" "${backup_dir}"
    fi

    echo "Cloning ${REPO_URL} into ${REPO_DIR}"
    git clone "${REPO_URL}" "${REPO_DIR}"
}

build_project() {
    echo "Building drivewire-rs in release mode"
    cargo build --release --manifest-path "${REPO_DIR}/Cargo.toml"
}

create_launcher() {
    echo "Creating Becker-port launcher at ${LAUNCHER_PATH}"

    mkdir -p "$(dirname "${LAUNCHER_PATH}")"

    cat > "${LAUNCHER_PATH}" <<'EOF'
#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DW_BIN="${SCRIPT_DIR}/dw"

if [[ $# -ne 1 ]]; then
    echo "Usage: $0 /path/to/disk.dsk" >&2
    exit 1
fi

if [[ ! -x "${DW_BIN}" ]]; then
    echo "drivewire-rs binary not found at ${DW_BIN}" >&2
    exit 1
fi

exec "${DW_BIN}" serve \
    --tcp 127.0.0.1:65504 \
    --disk0 "$1"
EOF

    chmod 755 "${LAUNCHER_PATH}"
}

print_result() {
    local binary="${REPO_DIR}/target/release/dw"

    if [[ ! -x "${binary}" ]]; then
        echo "Build finished, but ${binary} was not found." >&2
        exit 1
    fi

    cat <<EOF

Build complete.
Binary: ${binary}
Source checkout: ${REPO_DIR}
Backup pattern: ${SOURCE_ROOT}/drivewire-rs-YYYYMMDD-HHMMSS
Becker launcher: ${LAUNCHER_PATH}

Example:
  ${binary} --help
EOF
}

main() {
    if ! need_cmd sudo; then
        echo "This script expects sudo to be available for apt installs." >&2
        exit 1
    fi

    install_apt_packages
    install_rustup
    load_rust_env

    if ! need_cmd cargo; then
        echo "cargo is still not available after rustup installation." >&2
        exit 1
    fi

    ensure_repo
    build_project
    create_launcher
    print_result
}

main "$@"

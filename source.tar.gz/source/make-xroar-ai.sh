#!/usr/bin/env bash

set -euo pipefail

repo_url="${XROAR_AI_REPO:-https://github.com/mrgw454/xroar-ai.git}"
branch="${XROAR_AI_BRANCH:-feature/ai-agent}"
source_root="${XROAR_AI_SOURCE_ROOT:-$HOME/source}"
checkout_name="${XROAR_AI_CHECKOUT:-xroar-ai-git}"
install_dir="${XROAR_AI_INSTALL_DIR:-/usr/local/bin}"
jobs="${XROAR_AI_JOBS:-}"
do_install=1
configure_args=(--enable-experimental)

usage() {
  cat <<'EOF'
Usage: make-xroar-ai.sh [OPTIONS] [-- CONFIGURE-OPTIONS]

Clone and build the private AI-enabled XRoar branch from scratch. An existing
checkout is archived alongside the new one before cloning.

Options:
  --repo URL          Git repository (default: private xroar-ai repository)
  --branch NAME       Branch to build (default: feature/ai-agent)
  --source-root DIR   Parent directory for the checkout (default: $HOME/source)
  --checkout NAME     Checkout directory name (default: xroar-ai-git)
  --jobs N            Parallel build jobs (default: half the available CPUs)
  --install-dir DIR   Installation directory (default: /usr/local/bin)
  --no-install        Build only; do not install a system binary
  -h, --help          Show this help

Arguments after -- replace the default configure option
--enable-experimental. Environment variables matching the XROAR_AI_* option
names above may also set defaults.

The installed revision is named xroar-ai-REV, with xroar-ai as a symlink.
Private GitHub authentication must already be configured for git.
EOF
}

while (($#)); do
  case "$1" in
    --repo) repo_url=${2:?missing value for --repo}; shift 2 ;;
    --branch) branch=${2:?missing value for --branch}; shift 2 ;;
    --source-root) source_root=${2:?missing value for --source-root}; shift 2 ;;
    --checkout) checkout_name=${2:?missing value for --checkout}; shift 2 ;;
    --jobs) jobs=${2:?missing value for --jobs}; shift 2 ;;
    --install-dir) install_dir=${2:?missing value for --install-dir}; shift 2 ;;
    --no-install) do_install=0; shift ;;
    -h|--help) usage; exit 0 ;;
    --) shift; configure_args=("$@"); break ;;
    *) printf 'Unknown option: %s\n\n' "$1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ -z "$jobs" ]]; then
  processors=$(getconf _NPROCESSORS_ONLN 2>/dev/null || printf '1')
  jobs=$((processors > 1 ? processors / 2 : 1))
fi
if [[ ! "$jobs" =~ ^[1-9][0-9]*$ ]]; then
  printf 'Build jobs must be a positive integer: %s\n' "$jobs" >&2
  exit 2
fi

mkdir -p "$source_root"
checkout="$source_root/$checkout_name"
if [[ -e "$checkout" ]]; then
  archive="${checkout}-$(date +%Y%m%d-%H%M%S)"
  printf 'Archiving existing checkout as %s\n' "$archive"
  mv "$checkout" "$archive"
fi

printf 'Cloning %s branch %s\n' "$repo_url" "$branch"
git clone --branch "$branch" --single-branch "$repo_url" "$checkout"
cd "$checkout"

revision=$(git rev-parse HEAD)
short_revision=$(git rev-parse --short=8 HEAD)
printf 'Building revision %s with %s jobs\n' "$revision" "$jobs"
./autogen.sh
./configure "${configure_args[@]}"
make -j"$jobs"

cat >xroar-ai-build-info.txt <<EOF
repository=$repo_url
branch=$branch
revision=$revision
configure=${configure_args[*]}
jobs=$jobs
binary=$checkout/src/xroar
capabilities=agent-control,gdb
EOF

if ((do_install)); then
  install_name="xroar-ai-$short_revision"
  if [[ -w "$install_dir" ]]; then
    install -m 0755 src/xroar "$install_dir/$install_name"
    install -m 0644 xroar-ai-build-info.txt "$install_dir/$install_name.build-info"
    ln -sfn "$install_name" "$install_dir/xroar-ai"
    ln -sfn "$install_name.build-info" "$install_dir/xroar-ai.build-info"
  else
    sudo install -m 0755 src/xroar "$install_dir/$install_name"
    sudo install -m 0644 xroar-ai-build-info.txt "$install_dir/$install_name.build-info"
    sudo ln -sfn "$install_name" "$install_dir/xroar-ai"
    sudo ln -sfn "$install_name.build-info" "$install_dir/xroar-ai.build-info"
  fi
  printf 'Installed %s, provenance sidecar, and %s/xroar-ai\n' \
    "$install_dir/$install_name" "$install_dir"
else
  printf 'Built %s\n' "$checkout/src/xroar"
fi
printf 'Build provenance: %s/xroar-ai-build-info.txt\n' "$checkout"

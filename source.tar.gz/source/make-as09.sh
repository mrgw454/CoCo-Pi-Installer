#!/bin/bash

systemtype=$(dpkg --print-architecture)
echo architecture = $systemtype

if [[ $systemtype =~ arm64 ]];then
        echo This project is not compatible with your device platform.  Aborting.
        echo
        echo
        exit 1
fi

cd $HOME/source

# if a previous as09 folder exists, move into a date-time named folder

if [ -d "as09" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "as09" "as09-$foldername"

        echo -e Archiving existing as09 folder ["as09"] into backup folder ["as09-$foldername"]
        echo -e
        echo -e
fi

if [ ! -f as09_142.zip ]; then
	# https://www.kingswood-consulting.co.uk/assemblers/index.html
	wget --no-check-certificate https://www.kingswood-consulting.co.uk/assemblers/as09_142.zip
fi

if [ ! -d as09 ]; then
	mkdir as09
fi

unzip -j as09_142.zip -d $HOME/source/as09

cd as09

if [ -f as09 ]; then
	sudo ln -s $HOME/source/as09/as09 /usr/local/bin/as09
fi

cd ..


echo
echo Done!

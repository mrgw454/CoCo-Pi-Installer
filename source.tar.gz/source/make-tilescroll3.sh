#!/bin/bash

cd $HOME/source

# if a previous tilescroll3 folder exists, move into a date-time named folder

if [ -d "tilescroll3" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "tilescroll3" "tilescroll3-$foldername"

        echo -e Archiving existing tilescroll3 folder ["tilescroll3"] into backup folder ["tilescroll3-$foldername"]
        echo -e
        echo -e
fi

# https://gitlab.com/cocodev/lee/tilescroll3
git clone https://gitlab.com/cocodev/lee/tilescroll3.git

cd tilescroll3

GITREV=`git rev-parse --short HEAD`

echo $(nproc) / 2 | bc
cores=$(echo $(nproc) / 2 | bc)
make -j$cores

if [ $? -eq 0 ]
then
        echo "Compilation was successful."
        echo
else
        echo "Compilation was NOT successful.  Aborting installation."
        echo
        exit 1
fi

if [ ! -f /media/share1/SDC/PERKINS ]; then
	mkdir -p /media/share1/SDC/PERKINS
fi

cp build/tileScroll.dsk /media/share1/SDC/PERKINS/TILESCRL.DSK

cd ..


echo
echo Done!

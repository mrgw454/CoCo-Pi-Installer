#!/bin/bash

# install prerequisites
echo NOTE!  You need to make sure the following projects are already built and installed:
echo
echo toolshed
echo lwtools
echo
echo
read -p "Press any key to continue... " -n1 -s
echo

cd $HOME/source

# if a previous coco-forth folder exists, move into a date-time named folder

if [ -d "coco-forth" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "coco-forth" "coco-forth-$foldername"

        echo -e Archiving existing coco-forth folder ["coco-forth"] into backup folder ["coco-forth-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/ugufru/coco
git clone https://github.com/ugufru/coco.git coco-forth

cd coco-forth

GITREV=`git rev-parse --short HEAD`

echo $(nproc) / 2 | bc
cores=$(echo $(nproc) / 2 | bc)
make -j$cores

if [ $? -eq 0 ]
then
        echo "Compilation was successful."
        echo
else
        echo "Compilation was NOT successful.  Aborting installation."
        echo
        exit 1
fi

if [ ! -d /media/share1/SDC/FORTH ]; then
	mkdir -p /media/share1/SDC/FORTH
fi

cp build/*.dsk /media/share1/SDC/FORTH

cd $HOME/source


echo
echo Done!

#!/bin/bash

cd $HOME/source

# if a previous foxhunt folder exists, move into a date-time named folder

if [ -d "foxhunt" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "foxhunt" "foxhunt-$foldername"

        echo -e Archiving existing foxhunt folder ["foxhunt"] into backup folder ["foxhunt-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/yggdrasilradio/foxhunt
git clone https://github.com/yggdrasilradio/foxhunt.git

cd foxhunt

GITREV=`git rev-parse --short HEAD`

cd redistribute

makeDSK-pyDW.sh

if [ -f redistribute.DSK ]; then
	if [ ! -d /media/share1/SDC/ADAMS ]; then
		mkdir /media/share1/SDC/ADAMS
	fi
	echo "cp foxhunt.DSK /media/share1/SDC/ADAMS/FOXHUNT.DSK"
	echo
	cp redistribute.DSK /media/share1/SDC/ADAMS/FOXHUNT.DSK
else
	echo foxhunt.DSK image not found!
	echo
fi


cd ..

echo
echo Done!


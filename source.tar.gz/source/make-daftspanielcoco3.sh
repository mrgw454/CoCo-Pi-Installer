#!/bin/bash

cd $HOME/source

# if a previous daftspanielcoco3 folder exists, move into a date-time named folder

if [ -d "daftspanielcoco3" ]; then
       	foldername=$(date +%Y-%m-%d_%H.%M.%S)

       	mv "daftspanielcoco3" "daftspanielcoco3-$foldername"

       	echo -e Archiving existing daftspanielcoco3 folder ["daftspanielcoco3"] into backup folder ["daftspanielcoco3-$foldername"]
       	echo -e
       	echo -e
fi

# https://github.com/daftspaniel/daftspanielcoco3
git clone https://github.com/daftspaniel/daftspanielcoco3.git

cd daftspanielcoco3

GITREV=`git rev-parse --short HEAD`

cd ..


echo
echo Done!


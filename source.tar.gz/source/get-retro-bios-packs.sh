#!/bin/bash

cd $HOME/source

# if a previous retro_bios_packs folder exists, move into a date-time named folder

if [ -d "retro_bios_packs" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "retro_bios_packs" "retro_bios_packs-$foldername"

        echo -e Archiving existing retro_bios_packs folder ["retro_bios_packs"] into backup folder ["retro_bios_packs-$foldername"]
        echo -e
        echo -e
fi


if [ ! -d retro_bios_packs ]; then
	mkdir retro_bios_packs
fi

cd retro_bios_packs
wget https://archive.org/download/retropiebiosfilesconfiguredforeverysystem_20190904/Retropie%20Bios%20Files%20Configured%20for%20Every%20System.zip
wget https://archive.org/download/19990506-hack/emulateur%20pack%20-%20All%20Consoles-With%20BIOS%20%5BXBOX.PS2.PSX.DC.N64.GBA.GB.WS.NGP.SS.SFC.FC.GG.MD.MAME.PC88.PCE%5D.zip
wget https://archive.org/download/OpenEmuBIOSPack/OpenEmu%20BIOS%20Pack.zip
wget https://archive.org/download/batocera-bios-v-29/Batocera%20BIOS%20V29%2B.zip
git clone https://github.com/archtaurus/RetroPieBIOS.git
git clone https://github.com/Abdess/retroarch_system.git

# Apple II IIgs specific

# Coleco Adam specific

# Commodore 64 128 specific

# Dragon specific

# MSX MSX2 specific

# Tandy CoCo MC-10

# TI-994a specific

# TRS-80 specific

# Altirra specific
wget https://forums.atariage.com/applications/core/interface/file/attachment.php?id=706925 -O "Altirra bios (k1w1).zip"
wget https://forums.atariage.com/applications/core/interface/file/attachment.php?id=706924 -O "Altirra bios.rar"
wget https://forums.atariage.com/applications/core/interface/file/attachment.php?id=706922 -O "Altirra Roms.7z"
wget https://forums.atariage.com/applications/core/interface/file/attachment.php?id=706975 -O "Altirra Bios_by Scotty.rar"
wget https://forums.atariage.com/applications/core/interface/file/attachment.php?id=706974 -O "Altirra bios_by Mclaneinc .rar"
wget https://forums.atariage.com/applications/core/interface/file/attachment.php?id=706973 -O "Altirra Bios _by Serj list.rar"

# ScummVM specific
wget https://github.com/Abdess/retroarch_system/raw/libretro/ScummVM/scummvm.zip

cd ..


echo
echo Done!


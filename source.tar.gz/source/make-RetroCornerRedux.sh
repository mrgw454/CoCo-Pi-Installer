#!/bin/bash

cd $HOME/source

# if a previous RetroCornerRedux folder exists, move into a date-time named folder

if [ -d "RetroCornerRedux" ]; then
       	foldername=$(date +%Y-%m-%d_%H.%M.%S)

       	mv "RetroCornerRedux" "RetroCornerRedux-$foldername"

       	echo -e Archiving existing RetroCornerRedux folder ["RetroCornerRedux"] into backup folder ["RetroCornerRedux-$foldername"]
       	echo -e
       	echo -e
fi

# https://github.com/daftspaniel/RetroCornerRedux
git clone https://github.com/daftspaniel/RetroCornerRedux.git

cd RetroCornerRedux

GITREV=`git rev-parse --short HEAD`

cd ..


echo
echo Done!


#!/bin/bash
# tag: application assembler 6502

cd $HOME/source

# if a previous 64tass folder exists, move into a date-time named folder

if [ -d "64tass" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "64tass" "64tass-$foldername"

        echo -e Archiving existing 64tass folder ["64tass"] into backup folder ["64tass-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/irmen/64tass
git clone https://github.com/irmen/64tass.git

cd 64tass

GITREV=`git rev-parse --short HEAD`

echo $(nproc) / 2 | bc
cores=$(echo $(nproc) / 2 | bc)
make -j$cores

if [ $? -eq 0 ]
then
       	echo "Compilation was successful."
       	echo
else
       	echo "Compilation was NOT successful.  Aborting installation." >&2
       	echo
       	exit 1
fi

sudo ln -s $HOME/source/64tass/64tass /usr/local/bin/64tass

cd ..


echo
echo Done!


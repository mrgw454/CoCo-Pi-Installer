#!/bin/bash

# tag: BASIC

# install prerequisites
echo NOTE!  You need to make sure the following projects are already built and installed:
echo
echo as02
echo
echo
read -p "Press any key to continue... " -n1 -s
echo

cd $HOME/source

# if a previous MicroBas folder exists, move into a date-time named folder

if [ -d "MicroBas" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "MicroBas" "MicroBas-$foldername"

        echo -e Archiving existing MicroBas folder ["MicroBas"] into backup folder ["MicroBas-$foldername"]
        echo -e
        echo -e
fi

if [ ! -f MicroBas.zip ]; then
	# https://www.corshamtech.com/tech-tips/basic-for-6800/
	wget --no-check-certificate https://www.corshamtech.com/wp-content/uploads/2021/01/MicroBas.zip
fi

if [ ! -d MicroBas ]; then
	mkdir MicroBas
fi

unzip -j MicroBas.zip -d $HOME/source/MicroBas

cd MicroBas

as02 -v -x -omicrobas.bin MicroBas.asm

if [ $? -eq 0 ]
then
        echo "Compilation was successful."
        echo
else
        echo "Compilation was NOT successful.  Aborting installation."
        echo
        exit 1
fi

makeWAV-mc10.sh

cd ..


echo
echo Done!

#!/usr/bin/env bash

# Build the newest gcc6809 source package published in Tormod Volden's PPA,
# using Debian 13 as the host and an existing lwtools installation.

set -Eeuo pipefail

PPA_ROOT=${PPA_ROOT:-https://ppa.launchpadcontent.net/tormodvolden/m6809/ubuntu}
PPA_SUITE=${PPA_SUITE:-bionic}
WORK_DIR=${WORK_DIR:-"$HOME/source/gcc6809-build"}
DOWNLOAD_DIR=${DOWNLOAD_DIR:-"$HOME/.cache/gcc6809"}
PREFIX=${PREFIX:-/usr/local}
TOOL_PREFIX=${TOOL_PREFIX:-$PREFIX}
JOBS=${JOBS:-"$(nproc)"}
HOST_CC=${HOST_CC:-gcc-12}
HOST_CXX=${HOST_CXX:-g++-12}
HOST_CFLAGS=${HOST_CFLAGS:--O2 -w}

INDEX_FILE="$DOWNLOAD_DIR/${PPA_SUITE}-Sources"

die() { printf 'error: %s\n' "$*" >&2; exit 1; }
need_command() { command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"; }

for command_name in curl gzip sha256sum tar patch make awk "$HOST_CC" "$HOST_CXX" \
    "$TOOL_PREFIX/bin/lwasm" "$TOOL_PREFIX/bin/lwlink" \
    "$TOOL_PREFIX/bin/lwar" "$TOOL_PREFIX/bin/m6809-unknown-as" \
    "$TOOL_PREFIX/bin/m6809-unknown-ld" "$TOOL_PREFIX/bin/m6809-unknown-ar" \
    "$TOOL_PREFIX/bin/m6809-unknown-ranlib"; do
    need_command "$command_name"
done
for package_name in libgmp-dev libmpfr-dev libmpc-dev bison flex; do
    dpkg-query -W -f='${db:Status-Status}' "$package_name" 2>/dev/null \
        | grep -qx installed || die "missing Debian package: $package_name"
done
[[ "$WORK_DIR" != / && "$WORK_DIR" != "$HOME" ]] || die "unsafe WORK_DIR: $WORK_DIR"
mkdir -p "$DOWNLOAD_DIR" "$(dirname -- "$WORK_DIR")"

if [[ -e "$WORK_DIR" ]]; then
    archive_dir="$WORK_DIR-$(date +%Y-%m-%d_%H.%M.%S)"
    mv -- "$WORK_DIR" "$archive_dir"
    printf 'Archived existing build directory as %s\n' "$archive_dir"
fi
mkdir -p "$WORK_DIR"

# Refresh on every run. The index identifies the newest package currently
# published for the PPA's newest gcc6809 suite and supplies archive checksums.
curl --fail --location --retry 3 \
    "$PPA_ROOT/dists/$PPA_SUITE/main/source/Sources.gz" \
    | gzip -dc > "$INDEX_FILE.part"
mv -- "$INDEX_FILE.part" "$INDEX_FILE"

source_field() {
    local package=$1 field=$2
    awk -v package="$package" -v field="$field:" '
        $1 == "Package:" { active = ($2 == package) }
        active && $1 == field { print $2; exit }
    ' "$INDEX_FILE"
}

source_archive_record() {
    local package=$1 pattern=$2
    awk -v package="$package" -v pattern="$pattern" '
        $1 == "Package:" { active = ($2 == package); hashes = 0 }
        active && $1 == "Checksums-Sha256:" { hashes = 1; next }
        active && hashes && $1 ~ /^[A-Za-z][A-Za-z0-9-]*:$/ { hashes = 0 }
        active && hashes && $3 ~ pattern { print $1, $3; exit }
    ' "$INDEX_FILE"
}

download_record() {
    local directory=$1 record=$2 checksum filename destination
    read -r checksum filename <<< "$record"
    [[ -n ${checksum:-} && -n ${filename:-} ]] || die 'invalid PPA source index record'
    destination="$DOWNLOAD_DIR/$filename"
    if [[ ! -f "$destination" ]] \
        || ! printf '%s  %s\n' "$checksum" "$destination" | sha256sum -c - >/dev/null 2>&1; then
        curl --fail --location --retry 3 --output "$destination.part" \
            "$PPA_ROOT/$directory/$filename"
        printf '%s  %s\n' "$checksum" "$destination.part" | sha256sum -c - >/dev/null
        mv -- "$destination.part" "$destination"
    else
        printf 'Using verified download %s\n' "$destination" >&2
    fi
    printf '%s\n' "$destination"
}

GCC_VERSION=$(source_field gcc6809 Version)
GCC_DIRECTORY=$(source_field gcc6809 Directory)
[[ -n "$GCC_VERSION" ]] || die "gcc6809 is absent from $PPA_SUITE"

GCC_ORIG=$(download_record "$GCC_DIRECTORY" "$(source_archive_record gcc6809 'orig[.]tar')")
GCC_DEBIAN=$(download_record "$GCC_DIRECTORY" "$(source_archive_record gcc6809 'debian[.]tar')")

printf 'Using installed %s and %s\n' \
    "$("$TOOL_PREFIX/bin/lwasm" --version | head -n 1)" \
    "$("$TOOL_PREFIX/bin/lwlink" --version | head -n 1)"
printf 'Selected PPA source: gcc6809 %s\n' "$GCC_VERSION"

GCC_SOURCE="$WORK_DIR/gcc6809-source"
GCC_BUILD="$WORK_DIR/gcc6809-build"
rm -rf -- "$GCC_SOURCE" "$GCC_BUILD"
mkdir -p "$GCC_SOURCE" "$GCC_BUILD"

tar -xf "$GCC_ORIG" -C "$GCC_SOURCE" --strip-components=1
tar -xf "$GCC_DEBIAN" -C "$GCC_SOURCE"
while IFS= read -r patch_name; do
    [[ -n "$patch_name" && ${patch_name:0:1} != '#' ]] || continue
    patch --batch -d "$GCC_SOURCE" -p1 < "$GCC_SOURCE/debian/patches/$patch_name"
done < "$GCC_SOURCE/debian/patches/series"
patch --batch -d "$GCC_SOURCE" -p1 <<'HOST_PATCH'
--- a/gcc/cfglayout.c
+++ b/gcc/cfglayout.c
@@ -21,6 +21,7 @@ along with GCC; see the file COPYING3.  If not see
 #include "system.h"
 #include "coretypes.h"
 #include "tm.h"
+#include "tm_p.h"
 #include "tree.h"
 #include "rtl.h"
 #include "flags.h"
HOST_PATCH

# Correct old build-system defects by matching their semantics rather than
# source line numbers. Newer sources that already lack either defect pass
# through unchanged.
GCC_MAKEFILE="$GCC_SOURCE/gcc/Makefile.in"
if grep -Fq '<$(DATESTAMP))' "$GCC_MAKEFILE"; then
    sed -i 's|<$(DATESTAMP))|<$(srcdir)/DATESTAMP)|' "$GCC_MAKEFILE"
fi

M6809_TMAKE="$GCC_SOURCE/gcc/config/m6809/t-m6809"
if grep -Fqx 'crt0.o: s-crt0 ; @true' "$GCC_MAKEFILE" \
    && grep -Fqx '$(T)crt0.o: $(CRT0_S) $(GCC_PASSES)' "$M6809_TMAKE"; then
    temporary_makefile="$GCC_MAKEFILE.tmp"
    awk '
        /^# Compile the start modules crt0[.]o and mcrt0[.]o/ { skipping = 1; found_start++; next }
        skipping && /^\t[$][(]STAMP[)] s-crt0$/ { skipping = 0; found_end++; next }
        !skipping { print }
        END { if (found_start != 1 || found_end != 1 || skipping) exit 1 }
    ' "$GCC_MAKEFILE" > "$temporary_makefile" \
        || die 'could not remove duplicate generic crt0 rules'
    mv -- "$temporary_makefile" "$GCC_MAKEFILE"
fi

(
    cd "$GCC_BUILD"
    PATH="$TOOL_PREFIX/bin:/usr/bin:/bin" CC="$HOST_CC" CXX="$HOST_CXX" \
        "$GCC_SOURCE/configure" \
        --enable-languages=c --target=m6809-unknown --disable-libada \
        --program-prefix=m6809-unknown- --enable-obsolete --disable-threads \
        --disable-nls --disable-libssp --disable-multilib --prefix="$PREFIX" \
        --with-as="$TOOL_PREFIX/bin/m6809-unknown-as" \
        --with-ld="$TOOL_PREFIX/bin/m6809-unknown-ld" \
        --with-ar="$TOOL_PREFIX/bin/m6809-unknown-ar"
    PATH="$TOOL_PREFIX/bin:/usr/bin:/bin" make -s -j"$JOBS" MAKEINFO=true POD2MAN=true \
        CFLAGS="$HOST_CFLAGS" CXXFLAGS="$HOST_CFLAGS" all-gcc
    PATH="$TOOL_PREFIX/bin:/usr/bin:/bin" make -s -j"$JOBS" MAKEINFO=true POD2MAN=true \
        CFLAGS="$HOST_CFLAGS" CXXFLAGS="$HOST_CFLAGS" all-target-libgcc
)

ELEVATE=()
if [[ ! -w "$PREFIX" && ! ( ! -e "$PREFIX" && -w "$(dirname -- "$PREFIX")" ) ]]; then
    need_command sudo
    ELEVATE=(sudo)
fi
"${ELEVATE[@]}" make -s -C "$GCC_BUILD" MAKEINFO=true POD2MAN=true \
    install-gcc install-target-libgcc

"$PREFIX/bin/m6809-unknown-gcc" --version | head -n 1
printf 'Installed GCC M6809 under %s; existing lwtools under %s was not changed\n' \
    "$PREFIX" "$TOOL_PREFIX"

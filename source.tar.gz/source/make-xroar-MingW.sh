#!/bin/bash

cd $HOME/source

if [ -z "$1" ]; then

	echo "No arguments provided.  Defaulting to build from git repository."
	echo

	# if a previous xroar-git-MingW folder exists, move into a date-time named folder

	if [ -d "xroar-git-MingW" ]; then

        	foldername=$(date +%Y-%m-%d_%H.%M.%S)

        	mv "xroar-git-MingW" "xroar-git-MingW-$foldername"

        	echo -e Archiving existing xroar-git-MingW folder ["xroar-git-MingW"] into backup folder ["xroar-git-MingW-$foldername"]
        	echo -e
        	echo -e
	fi

	# https://www.6809.org.uk/xroar/
	git clone https://www.6809.org.uk/git/xroar.git xroar-git-MingW

	cd xroar-git-MingW

	git checkout dev

	GITREV=`git rev-parse --short HEAD`

	./autogen.sh

	git clone https://github.com/libsdl-org/SDL.git
	cd SDL
	../configure --prefix=/usr/i686-w64-mingw32 --host=i686-w64-mingw32 \
	--enable-static --disable-shared \
	CFLAGS="-Ofast -g" CPPFLAGS="-D__USE_MINGW_ANSI_STDIO=1"
	make
	cd $HOME/source/xroar-git-MingW


	git clone https://github.com/erikd/libsndfile.git
	cd libsndfile
	../configure --prefix=/usr/i686-w64-mingw32 --host=i686-w64-mingw32 \
	--enable-static --disable-shared --disable-external-libs \
	CFLAGS="-Ofast -g" CPPFLAGS="-D__USE_MINGW_ANSI_STDIO=1" \
	ac_cv_func_malloc_0_nonnull=yes ac_cv_func_realloc_0_nonnull=yes
	make
	cd $HOME/source/xroar-git-MingW


	git clone https://github.com/laurikari/tre.git
	cd tre
	../configure --prefix=/usr/i686-w64-mingw32 --host=i686-w64-mingw32 \
	--enable-static --disable-shared \
	--disable-agrep --disable-approx \
	CFLAGS="-Ofast -g" CPPFLAGS="-D__USE_MINGW_ANSI_STDIO=1"
	make
	cd $HOME/source/xroar-git-MingW


ac_cv_func_malloc_0_nonnull=yes ac_cv_func_realloc_0_nonnull=yes ../configure \
--host=i686-w64-mingw32 --prefix=/usr/i686-w64-mingw32 \
--with-sdl-prefix="/usr/i686-w64-mingw32" \
--enable-filereq-cli --without-gtk2 --without-gtkgl --without-alsa \
--without-oss --without-pulse --without-sndfile --without-joydev \
CFLAGS="-std=c11 -Ofast -flto=auto -D__USE_MINGW_ANSI_STDIO=1" \
LDFLAGS="-std=c11 -Ofast -flto=auto -D__USE_MINGW_ANSI_STDIO=1"

#./autogen.sh
#./configure --enable-experimental

echo $(nproc) / 2 | bc
cores=$(echo $(nproc) / 2 | bc)
#make -j$cores
make


fi


echo
echo Done!

#!/bin/bash

# Cross-compile m6809-gdb.exe for Windows (x64) from Linux.
# Uses the mingw-w64 cross-compiler (gcc-mingw-w64-x86-64).
#
# Prerequisites:
#   sudo apt install gcc-mingw-w64-x86-64 binutils-mingw-w64-x86-64 g++-mingw-w64-x86-64
#
# Output: ~/scripts/m6809-gdb.exe
#   Copy to %USERPROFILE%\scripts\m6809-gdb.exe on Windows.

# install prerequisites
sudo apt -y install gcc-mingw-w64-x86-64 binutils-mingw-w64-x86-64 g++-mingw-w64-x86-64

cd $HOME/source

# if a previous binutils-gdb-git-MinGW folder exists, move into a date-time named folder

if [ -d "binutils-gdb-git-MinGW" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "binutils-gdb-git-MinGW" "binutils-gdb-git-MinGW-$foldername"

        echo -e Archiving existing binutils-gdb-git-MinGW folder ["binutils-gdb-git-MinGW"] into backup folder ["binutils-gdb-git-MinGW-$foldername"]
        echo -e
        echo -e
fi

# https://www.6809.org.uk/dragon/m6809-gdb.shtml
git clone -b m6809-15.2 https://www.6809.org.uk/git/binutils-gdb.git binutils-gdb-git-MinGW

cd binutils-gdb-git-MinGW

GITREV=`git rev-parse --short HEAD`

./configure \
        --target=m6809 \
        --host=x86_64-w64-mingw32 \
        --disable-readline \
        --disable-sim \
        --disable-ld \
        --with-gnu-as=no \
        --without-python \
        --disable-nls \
        --disable-docs \
        --disable-werror

echo $(nproc) / 2 | bc
cores=$(echo $(nproc) / 2 | bc)
make -j$cores

if [ $? -eq 0 ]
then
        echo "Compilation was successful.  Copying m6809-gdb.exe to ~/scripts/"
        echo
        cp gdb/m6809-gdb.exe $HOME/scripts/
        echo "Done.  Copy $HOME/scripts/m6809-gdb.exe to %USERPROFILE%\xroar\ on Windows."
else
        echo "Compilation was NOT successful.  Aborting." >&2
        echo
        exit 1
fi

cd ..

echo
echo Done!

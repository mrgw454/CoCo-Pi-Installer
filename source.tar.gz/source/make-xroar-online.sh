#!/usr/bin/env bash

set -euo pipefail

SOURCE_HOME="$HOME/source"
INSTALLDIR="$HOME/xroar-online"
DESKTOP_FILE="$HOME/Desktop/XRoar Online.desktop"
LAUNCH_SCRIPT="$INSTALLDIR/start-xroar-online.sh"
HOST="${XROAR_ONLINE_HOST:-127.0.0.1}"
PORT="${XROAR_ONLINE_PORT:-8080}"
DEFAULT_QUERY="${XROAR_ONLINE_QUERY:-?machine=coco3}"
REPO_URL="https://www.6809.org.uk/git/xroar.git"
EMSCRIPTEN_CACHE_DIR="${XROAR_ONLINE_EM_CACHE:-$HOME/.cache/emscripten}"

require_cmd() {
    if ! command -v "$1" >/dev/null 2>&1; then
        echo "Required command not found: $1"
        echo
        exit 1
    fi
}

ensure_emscripten() {
    if command -v emconfigure >/dev/null 2>&1 && \
       command -v emmake >/dev/null 2>&1 && \
       command -v emcc >/dev/null 2>&1; then
        return
    fi

    echo "Emscripten tools not found. Installing Debian package: emscripten"
    echo
    sudo apt -y install emscripten
    echo
}

check_prereqs() {
    require_cmd git
    require_cmd python3
    require_cmd sudo
    ensure_emscripten
    require_cmd emconfigure
    require_cmd emmake
    require_cmd emcc
    require_cmd autoreconf
    require_cmd make
    require_cmd awk

    if ! command -v xdg-open >/dev/null 2>&1; then
        echo "Warning: xdg-open not found. Desktop launcher will still be created,"
        echo "but it may not be able to open a browser automatically."
        echo
    fi
}

run_wasm_configure() {
    EM_FROZEN_CACHE=0 \
    EM_CACHE="$EMSCRIPTEN_CACHE_DIR" \
    emconfigure ./configure --enable-wasm --enable-ui-sdl CFLAGS="-O3 -flto" LDFLAGS="-O3 -flto"
}

run_wasm_make() {
    EM_FROZEN_CACHE=0 \
    EM_CACHE="$EMSCRIPTEN_CACHE_DIR" \
    emmake make -j"$(half_cores)"
}

half_cores() {
    local cores
    cores=$(( $(nproc) / 2 ))
    if [[ "$cores" -lt 1 ]]; then
        cores=1
    fi
    echo "$cores"
}

archive_if_exists() {
    local path="$1"
    if [[ -d "$path" ]]; then
        local foldername
        foldername="$(date +%Y-%m-%d_%H.%M.%S)"
        mv "$path" "${path}-${foldername}"
        echo "Archiving existing folder [$path] into backup folder [${path}-${foldername}]"
        echo
    fi
}

create_flat_index() {
    local outer="$1"
    local inner="$2"
    local out="$3"

    python3 - "$outer" "$inner" "$out" <<'PY'
import pathlib
import sys

outer = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
inner = pathlib.Path(sys.argv[2]).read_text(encoding="utf-8")
out = pathlib.Path(sys.argv[3])

needle = "<!--#include virtual='xroar-wasm.html' -->"
if needle not in outer:
    raise SystemExit(f"SSI include marker not found in {sys.argv[1]}")

out.write_text(outer.replace(needle, inner), encoding="utf-8")
PY
}

copy_if_found() {
    local src="$1"
    local dst="$2"
    if [[ -f "$src" ]]; then
        cp -f "$src" "$dst"
        echo "Copied $(basename "$src")"
    fi
}

install_common_roms() {
    local rom_dirs=(
        "$HOME/.xroar/roms"
        "/media/share1/roms"
    )
    local rom_names=(
        bas10.rom
        bas11.rom
        bas12.rom
        bas13.rom
        extbas10.rom
        extbas11.rom
        coco3.rom
        coco3p.rom
        mc10.rom
        alice.rom
        deluxe.rom
        adv070_u24.rom
        adv071_u24.rom
        adv072_u24.rom
        adv073-2_u24.rom
        adv073_u24.rom
        disk11.rom
        disk10.rom
        hdbdw3bck.rom
        yados.rom
        hdblba.rom
    )

    echo "Copying common ROMs into $INSTALLDIR ..."
    mkdir -p "$INSTALLDIR"

    for rom in "${rom_names[@]}"; do
        local copied=false
        for rom_dir in "${rom_dirs[@]}"; do
            if [[ -f "$rom_dir/$rom" ]]; then
                cp -f "$rom_dir/$rom" "$INSTALLDIR/$rom"
                echo "  ROM: $rom"
                copied=true
                break
            fi
        done
        if [[ "$copied" == false ]]; then
            echo "  ROM missing: $rom"
        fi
    done
    echo
}

link_software_sources() {
    local source_root="/media/share1"
    local source_dirs=(
        carts
        cassette
        CoCo
        MC-10
        MCX
        RonD
        SDC
    )
    local link_root="$INSTALLDIR/share1"

    echo "Linking software source folders into $link_root ..."
    mkdir -p "$link_root"

    for dir_name in "${source_dirs[@]}"; do
        local src="$source_root/$dir_name"
        local dst="$link_root/$dir_name"
        if [[ -d "$src" ]]; then
            ln -sfn "$src" "$dst"
            echo "  Linked: $dst -> $src"
        else
            echo "  Missing source folder: $src"
        fi
    done
    echo
}

generate_software_js() {
    local outfile="$INSTALLDIR/software.js"

    echo "Generating software menu: $outfile"

    python3 - "$outfile" <<'PY'
import json
import pathlib
import re
import sys

outfile = pathlib.Path(sys.argv[1])
root = outfile.parent

def rel(path: pathlib.Path) -> str:
    return path.relative_to(root).as_posix()

def title_from_name(path: pathlib.Path) -> str:
    name = path.stem
    name = re.sub(r'\s+', ' ', name).strip()
    return name

def machine_for_coco(path: pathlib.Path) -> str:
    text = str(path).lower()
    if 'coco3' in text or '[coco3]' in text:
        return 'coco3'
    return 'coco2bus'

def add_section(name: str, description: str, entries):
    if entries:
        sections.append({
            'name': name,
            'description': description,
            'entries': entries,
        })

def sorted_files(base: pathlib.Path, patterns):
    files = []
    for pattern in patterns:
        files.extend(base.rglob(pattern))
    return sorted(p for p in files if p.is_file())

sections = []

coco = root / 'share1' / 'CoCo'
if coco.exists():
    apps_dsk = []
    apps_rom = []
    edu_dsk = []
    edu_rom = []
    games_cas = []
    games_dsk = []
    games_rom = []

    for path in sorted_files(coco, ['*.cas', '*.CAS']):
        games_cas.append({
            'name': title_from_name(path),
            'machine': machine_for_coco(path),
            'tape': rel(path),
            'autorun': rel(path),
        })

    for path in sorted_files(coco, ['*.dsk', '*.DSK']):
        entry = {
            'name': title_from_name(path),
            'machine': machine_for_coco(path),
            'cart': 'rsdos',
            'disk0': rel(path),
        }
        lowered = str(path).lower()
        if 'os9' in lowered or 'nitr' in lowered:
            entry['basic'] = '\003BOOT\r'
        if 'applications' in lowered:
            apps_dsk.append(entry)
        elif 'educational' in lowered:
            edu_dsk.append(entry)
        else:
            games_dsk.append(entry)

    for path in sorted_files(coco, ['*.rom', '*.ROM']):
        entry = {
            'name': title_from_name(path),
            'machine': machine_for_coco(path),
            'cart': 'rom',
            'cart_rom': rel(path),
        }
        lowered = str(path).lower()
        if 'applications' in lowered:
            apps_rom.append(entry)
        elif 'educational' in lowered:
            edu_rom.append(entry)
        else:
            games_rom.append(entry)

    add_section('CoCo App DSK', 'CoCo disk applications from /media/share1/CoCo', apps_dsk)
    add_section('CoCo App ROM', 'CoCo ROM applications from /media/share1/CoCo', apps_rom)
    add_section('CoCo Edu DSK', 'CoCo educational disks from /media/share1/CoCo', edu_dsk)
    add_section('CoCo Edu ROM', 'CoCo educational ROMs from /media/share1/CoCo', edu_rom)
    add_section('CoCo CAS', 'CoCo cassette software from /media/share1/CoCo', games_cas)
    add_section('CoCo Game DSK', 'CoCo game disks from /media/share1/CoCo', games_dsk)
    add_section('CoCo Game ROM', 'CoCo ROM cartridges from /media/share1/CoCo', games_rom)

mc10 = root / 'share1' / 'MC-10'
if mc10.exists():
    mc10_tape = []
    mc10_cart = []
    mc10_text = []

    for path in sorted_files(mc10, ['*.c10', '*.C10']):
        mc10_tape.append({
            'name': title_from_name(path),
            'machine': 'mc10',
            'tape': rel(path),
            'autorun': rel(path),
        })

    for path in sorted_files(mc10, ['*.bin', '*.BIN', '*.rom', '*.ROM']):
        mc10_cart.append({
            'name': title_from_name(path),
            'machine': 'mc10',
            'cart': 'rom',
            'cart_rom': rel(path),
        })

    for path in sorted_files(mc10, ['*.bas', '*.BAS']):
        mc10_text.append({
            'name': title_from_name(path),
            'machine': 'mc10',
            'text': rel(path),
            'type': rel(path),
        })

    add_section('MC-10 Tape', 'MC-10 cassette software from /media/share1/MC-10', mc10_tape)
    add_section('MC-10 Cart', 'MC-10 cartridge/BIN images from /media/share1/MC-10', mc10_cart)
    add_section('MC-10 BASIC', 'MC-10 BASIC text files from /media/share1/MC-10', mc10_text)

with outfile.open('w', encoding='utf-8') as f:
    f.write("// Auto-generated by make-xroar-online.sh\n")
    f.write("// Uses symlinked source folders under share1/ to avoid copying software media.\n\n")
    f.write("const software = ")
    json.dump(sections, f, indent=2)
    f.write(";\n")
PY

    echo
}

create_launch_script() {
    mkdir -p "$INSTALLDIR"

    cat > "$LAUNCH_SCRIPT" <<EOF
#!/usr/bin/env bash

set -euo pipefail

WEBROOT="\$HOME/xroar-online"
HOST="${HOST}"
PORT="${PORT}"
RUNTIME_DIR="\$HOME/.cache/xroar-online"
PIDFILE="\$RUNTIME_DIR/http-server.pid"
LOGFILE="\$RUNTIME_DIR/http-server.log"

mkdir -p "\$RUNTIME_DIR"

if [[ ! -f "\$WEBROOT/index.html" ]]; then
    echo "XRoar Online is not installed at \$WEBROOT yet."
    echo "Run: bash \$HOME/source/make-xroar-online.sh"
    exit 1
fi

server_running=false
if [[ -f "\$PIDFILE" ]]; then
    old_pid="\$(cat "\$PIDFILE" 2>/dev/null || true)"
    if [[ -n "\${old_pid:-}" ]] && ps -p "\$old_pid" >/dev/null 2>&1; then
        server_running=true
    fi
fi

if [[ "\$server_running" == false ]]; then
    nohup python3 -m http.server "\$PORT" --bind "\$HOST" --directory "\$WEBROOT" \\
        >"\$LOGFILE" 2>&1 &
    echo \$! > "\$PIDFILE"
    sleep 1
fi

URL="http://\${HOST}:\${PORT}/"
if [[ -n "${DEFAULT_QUERY}" ]]; then
    URL="\${URL}\$(printf '%s' "${DEFAULT_QUERY}" | sed 's#^?##; s#^#?#')"
fi
echo "Opening \$URL"

if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "\$URL" >/dev/null 2>&1 &
else
    echo "xdg-open not found. Open this manually:"
    echo "\$URL"
fi
EOF

    chmod +x "$LAUNCH_SCRIPT"
}

create_desktop_icon_if_missing() {
    mkdir -p "$HOME/Desktop"

    if [[ -f "$DESKTOP_FILE" ]]; then
        echo "Desktop icon already exists: $DESKTOP_FILE"
        echo
        return
    fi

    cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Type=Application
Name=XRoar Online
Comment=Launch local XRoar WebAssembly build
Exec=$LAUNCH_SCRIPT
Icon=applications-games
Terminal=false
Categories=Game;Emulator;
EOF

    chmod +x "$DESKTOP_FILE"
    echo "Created desktop icon: $DESKTOP_FILE"
    echo
}

prepare_install_tree() {
    local build_root="$1"

    mkdir -p "$INSTALLDIR"

    create_flat_index \
        "$build_root/wasm/index.shtml" \
        "$build_root/wasm/xroar-wasm.html" \
        "$INSTALLDIR/index.html"

    cp -f "$build_root/wasm/software.js" "$INSTALLDIR/"
    cp -f "$build_root/wasm/xroar-wasm.css" "$INSTALLDIR/"

    copy_if_found "$build_root/src/xroar.js" "$INSTALLDIR/"
    copy_if_found "$build_root/src/xroar.wasm" "$INSTALLDIR/"
    copy_if_found "$build_root/src/xroar.data" "$INSTALLDIR/"

    local worker
    for worker in "$build_root"/src/*.worker.js; do
        if [[ -f "$worker" ]]; then
            cp -f "$worker" "$INSTALLDIR/"
            echo "Copied $(basename "$worker")"
        fi
    done

    cat > "$INSTALLDIR/BUILD-INFO.txt" <<EOF
Built: $(date --iso-8601=seconds)
Source: $build_root
URL: http://${HOST}:${PORT}/
EOF
}

build_git() {
    local worktree="$SOURCE_HOME/xroar-online-git"

    archive_if_exists "$worktree"

    git clone "$REPO_URL" "$worktree"
    cd "$worktree"
    git checkout dev

    local gitrev
    gitrev="$(git rev-parse --short HEAD)"

    echo
    git log -1
    echo

    ./autogen.sh
    run_wasm_configure
    run_wasm_make

    prepare_install_tree "$worktree"

    echo "Git revision: $gitrev" >> "$INSTALLDIR/BUILD-INFO.txt"
}

build_release() {
    local version="$1"
    local tarball="$SOURCE_HOME/xroar-$version.tar.gz"
    local tmpdir

    if [[ ! -f "$tarball" ]]; then
        wget -O "$tarball" "https://www.6809.org.uk/xroar/dl/xroar-$version.tar.gz"
    fi

    if [[ ! -f "$tarball" ]]; then
        echo "xroar-$version.tar.gz archive file NOT found. Aborting installation."
        echo
        exit 1
    fi

    tmpdir="$(mktemp -d /tmp/xroar-online-${version}.XXXXXX)"
    tar zxf "$tarball" -C "$tmpdir"

    local build_root="$tmpdir/xroar-$version"
    if [[ ! -d "$build_root" ]]; then
        echo "Unable to locate extracted source tree under $tmpdir"
        exit 1
    fi

    cd "$build_root"
    ./autogen.sh
    run_wasm_configure
    run_wasm_make

    prepare_install_tree "$build_root"

    echo "Release version: $version" >> "$INSTALLDIR/BUILD-INFO.txt"
}

main() {
    cd "$SOURCE_HOME"

    check_prereqs

    if [[ -z "${1:-}" ]]; then
        echo "No arguments provided. Defaulting to build from git repository."
        echo
        build_git
    else
        echo "$1 argument passed. Looking for XRoar-$1 release source..."
        echo
        build_release "$1"
    fi

    install_common_roms
    link_software_sources
    generate_software_js
    create_launch_script
    create_desktop_icon_if_missing

    echo "XRoar Online install path: $INSTALLDIR"
    echo "Launch script: $LAUNCH_SCRIPT"
    echo "Desktop icon:  $DESKTOP_FILE"
    echo
    echo "Run it with:"
    echo "bash $LAUNCH_SCRIPT"
    echo
    echo "Done!"
}

main "$@"

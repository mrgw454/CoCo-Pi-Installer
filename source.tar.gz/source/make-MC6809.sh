#!/bin/bash

cd $HOME/source

# if a previous MC6809 folder exists, move into a date-time named folder

if [ -d "MC6809" ]; then

       	foldername=$(date +%Y-%m-%d_%H.%M.%S)
       	mv "MC6809" "MC6809-$foldername"

       	echo -e Archiving existing MC6809 folder ["MC6809"] into backup folder ["MC6809-$foldername"]
       	echo -e
       	echo -e
fi

# https://github.com/6809/MC6809
git clone https://github.com/6809/MC6809.git

cd MC6809

GITREV=`git rev-parse --short HEAD`

./cli.py --help

if [ $? -eq 0 ]
then
        echo "Testing was successful."
        echo
else
        echo "Testing was NOT successful.  Aborting"
        echo
        exit 1
fi


echo
echo Done!


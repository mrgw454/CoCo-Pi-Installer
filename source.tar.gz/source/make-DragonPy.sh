#!/bin/bash

cd $HOME/source

# if a previous DragonPy folder exists, move into a date-time named folder

if [ -d "DragonPy" ]; then

       	foldername=$(date +%Y-%m-%d_%H.%M.%S)
       	mv "DragonPy" "DragonPy-$foldername"

       	echo -e Archiving existing DragonPy folder ["DragonPy"] into backup folder ["DragonPy-$foldername"]
       	echo -e
       	echo -e
fi

# https://github.com/jedie/DragonPy
git clone https://github.com/jedie/DragonPy.git

cd DragonPy

GITREV=`git rev-parse --short HEAD`

./cli.py --help
if [ $? -eq 0 ]
then
        echo "Testing was successful."
        echo
else
        echo "Testing was NOT successful.  Aborting"
        echo
        exit 1
fi


./cli.py download-roms
if [ $? -eq 0 ]
then
        echo "download-roms command was successful."
        echo
else
        echo "download-roms command was NOT successful.  Aborting"
        echo
        exit 1
fi

cd roms

if [ ! -f bas13.rom ]; then
	wget https://archive.org/download/mame-0.221-roms-merged/coco.zip/coco2b%2Fbas13.rom -O bas13.rom
fi

if [ ! -f extbas11.rom ]; then
	wget https://archive.org/download/mame-0.221-roms-merged/coco.zip/coco2%2Fextbas11.rom -O extbas11.rom
fi

cd ..


echo
echo Done!


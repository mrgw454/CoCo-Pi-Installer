#!/bin/bash

cd $HOME/source

# if a previous VideoTexDemoServer folder exists, move into a date-time named folder

if [ -d "VideoTexDemoServer" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "VideoTexDemoServer" "VideoTexDemoServer-$foldername"

        echo -e Archiving existing VideoTexDemoServer folder ["VideoTexDemoServer"] into backup folder ["VideoTexDemoServer-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/tlindner/VideoTexDemoServer
git clone https://github.com/tlindner/VideoTexDemoServer.git

cd VideoTexDemoServer

GITREV=`git rev-parse --short HEAD`

cd ..

echo
echo Done!

#!/bin/bash

cd $HOME/source

# if a previous forth folder exists, move into a date-time named folder

if [ -d "forth" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "forth" "forth-$foldername"

        echo -e Archiving existing forth folder ["forth"] into backup folder ["forth-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/ugufru/coco
git clone https://github.com/ugufru/coco.git forth

cd forth

GITREV=`git rev-parse --short HEAD`

cd forth
cd kernel

make

if [ $? -eq 0 ]
then
        echo "Compilation was successful."
        echo
else
        echo "Compilation was NOT successful.  Aborting installation."
        echo
        exit 1
fi

cd build

$HOME/scripts/launcher/tools/build_dsk.py

if [ -f $HOME/source/forth/forth/kernel/build/build.dsk ]; then
	if [ ! -d /media/share1/SDC/FORTH ]; then
		mkdir -p /media/share1/SDC/FORTH
	fi

	cp build.dsk /media/share1/SDC/FORTH/forth.dsk
else
	echo
	echo build.dsk image does NOT exist.  Aborting.
	echo
	exit 1
fi

cd $HOME/source


echo
echo Done!

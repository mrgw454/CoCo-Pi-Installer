#!/bin/bash
set -euo pipefail

# ------------------------------------------------------------
# COLORS
# ------------------------------------------------------------
RED="\033[1;31m"
GRN="\033[1;32m"
YLW="\033[1;33m"
BLU="\033[1;34m"
CYN="\033[1;36m"
RST="\033[0m"

# ------------------------------------------------------------
# PREREQUISITES
# ------------------------------------------------------------
echo -e "${CYN}Installing prerequisites...${RST}"
sudo apt install -y \
    qtbase5-dev qtbase5-dev-tools qtchooser qt5-qmake \
    qttools5-dev qttools5-dev-tools libqt5x11extras5-dev \
    cmake g++ make wget

# ------------------------------------------------------------
# SOURCE ROOT
# ------------------------------------------------------------
cd "$HOME/source"

# ------------------------------------------------------------
# ARCHIVE OLD FLEXEMU
# ------------------------------------------------------------
if [ -d "flexemu" ]; then
    foldername=$(date +%Y-%m-%d_%H.%M.%S)
    mv flexemu "flexemu-$foldername"
    echo -e "${YLW}Archived existing flexemu → flexemu-$foldername${RST}"
fi

# ------------------------------------------------------------
# CLONE REPO
# ------------------------------------------------------------
echo -e "${CYN}Cloning Flexemu...${RST}"
git clone --recursive https://github.com/aladur/flexemu.git
cd flexemu
git submodule update --init --recursive

# ------------------------------------------------------------
# BUILD
# ------------------------------------------------------------
echo -e "${CYN}Configuring build...${RST}"
mkdir -p build
cd build
cmake ..

cores=$(echo "$(nproc) / 2" | bc)
echo -e "${CYN}Compiling using $cores cores...${RST}"
make -j"$cores"

echo -e "${GRN}Build successful. Installing...${RST}"
sudo make install

# ------------------------------------------------------------
# SOFTWARE DOWNLOAD AREA
# ------------------------------------------------------------
echo -e "${CYN}Preparing software directory...${RST}"
SOFTDIR="$HOME/source/flexemu/software"
mkdir -p "$SOFTDIR"
cd "$SOFTDIR"

# ------------------------------------------------------------
# WGET FUNCTION (MINIMAL RECURSION, NO REWRITING)
# ------------------------------------------------------------
fetch() {
    local url="$1"
    local cut="$2"
    local exts="$3"

    echo -e "${BLU}Fetching:${RST} $url"
    wget -r -np -nH --cut-dirs="$cut" -A "$exts" "$url"
}

# ------------------------------------------------------------
# DOWNLOAD SETS
# ------------------------------------------------------------
fetch "http://www.flexusergroup.com/flexusergroup/fugdflx2.htm" \
      1 "dsk,DSK"

fetch "https://deramp.com/downloads/swtpc/software/FLEX/FLEX%202.0%20and%203.0%20Disk%20Images/" \
      5 "dsk,DSK"

fetch "https://deramp.com/downloads/swtpc/software/FLEX/" \
      4 "dsk,DSK"

fetch "https://deramp.com/downloads/swtpc/software/G2%20(Microsoft)%20BASIC/" \
      4 "dsk,DSK,s19,S19"

fetch "https://deramp.com/downloads/swtpc/software/Sieve%20Benchmark/" \
      4 "dsk,DSK,s19,S19,lst,LST,asm,ASM"

# ------------------------------------------------------------
# NORMALIZE WINDOWS-STYLE BACKSLASH FILENAMES
# ------------------------------------------------------------
echo -e "${CYN}Normalizing Windows-style filenames...${RST}"

cd "$SOFTDIR"

find . -type f -name '*\\*' | while read -r f; do
    new=$(echo "$f" | sed 's#\\#/#g')
    mkdir -p "$(dirname "$new")"
    mv "$f" "$new"
done

# ------------------------------------------------------------
# SUMMARY
# ------------------------------------------------------------
echo -e "${GRN}Download and normalization complete.${RST}"
echo -e "${CYN}DSK file count:${RST}"
find "$SOFTDIR" -type f -iname "*.dsk" | wc -l

echo -e "${CYN}Software stored under:${RST} $SOFTDIR"
echo -e "${GRN}Done.${RST}"

#!/bin/bash

# install prerequisites
sudo apt install libqt5x11extras5-dev

cd $HOME/source

# if a previous flexemu folder exists, move into a date-time named folder

if [ -d "flexemu" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "flexemu" "flexemu-$foldername"

        echo -e Archiving existing flexemu folder ["flexemu"] into backup folder ["flexemu-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/aladur/flexemu
# https://flexemu.neocities.org/

git clone --recursive https://github.com/aladur/flexemu.git

cd flexemu

git submodule update --init --recursive

GITREV=`git rev-parse --short HEAD`

./configure

echo $(nproc) / 2 | bc
cores=$(echo $(nproc) / 2 | bc)
make -j$cores

if [ $? -eq 0 ]
then
        echo "Compilation was successful.  Installing..."
        echo
        sudo make install
else
        echo "Compilation was NOT successful.  Aborting installation." >&2
        echo
        exit 1
fi

# get flex software
wget --no-cookies -r -p -e robots=off -v --mirror --convert-links -U mozilla --no-parent -A.dsk -A.DSK -A.pdf -A.PDF -A.txt -A.TXT "http://www.flexusergroup.com/flexusergroup/fugdflx2.htm"
wget --no-cookies -r -p -e robots=off -v --mirror --convert-links -U mozilla --no-parent -A.dsk -A.DSK -A.pdf -A.PDF -A.txt -A.TXT "https://deramp.com/downloads/swtpc/software/FLEX/FLEX%202.0%20and%203.0%20Disk%20Images/"

wget --no-cookies -r -p -e robots=off -v --mirror --convert-links -U mozilla --no-parent -A.dsk -A.DSK -A.pdf -A.PDF -A.txt -A.TXT "https://deramp.com/downloads/swtpc/software/FLEX/"
wget --no-cookies -r -p -e robots=off -v --mirror --convert-links -U mozilla --no-parent -A.dsk -A.DSK -A.pdf -A.PDF -A.txt -A.TXT "https://deramp.com/downloads/swtpc/software/FLEX/FLEX%202.0%20and%203.0%20Disk%20Images/"

wget --no-cookies -r -p -e robots=off -v --mirror --convert-links -U mozilla --no-parent -A.dsk -A.DSK -A.pdf -A.PDF -A.txt -A.TXT -A.s19 "https://deramp.com/downloads/swtpc/software/G2%20(Microsoft)%20BASIC/"
wget --no-cookies -r -p -e robots=off -v --mirror --convert-links -U mozilla --no-parent -A.dsk -A.DSK -A.pdf -A.PDF -A.txt -A.TXT -A.s19 -A.S19 -A.lst -A.LST -A.asm -A.ASM "https://deramp.com/downloads/swtpc/software/Sieve%20Benchmark/"


cd ..

echo
echo Done!


#!/bin/bash

# Force deterministic pyenv environment
export PYENV_ROOT="$HOME/.pyenv"
export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init -)"

# Choose the Python version for this script
PYTHON_VERSION="3.11.2"
pyenv shell "$PYTHON_VERSION"

echo "Using Python: $(python3 --version)"
echo

# install prerequisites
sudo apt -y install git gcc-arm-none-eabi srecord stm32flash zip unzip python3-intelhex python3-crcmod

python3 -m pip install --upgrade pip
python3 -m pip install intelhex crcmod weasyprint

cd $HOME/source

# if a previous flashfloppy folder exists, move into a date-time named folder

if [ -d "flashfloppy" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "flashfloppy" "flashfloppy-$foldername"

        echo -e Archiving existing flashfloppy folder ["flashfloppy"] into backup folder ["flashfloppy-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/keirf/flashfloppy
git clone https://github.com/keirf/flashfloppy.git

cd flashfloppy

# Set your github username and repo name
repo="keirf/flashfloppy"

# Get latest release info
release=$(curl --silent -m 10 --connect-timeout 5 \
    "https://api.github.com/repos/$repo/releases/latest")

# Release version
vtag=$(echo "$release" | grep '"tag_name":' | sed -E 's/.*"([^"]+)".*/\1/')
tag=${vtag:1}

echo
echo current version = $tag
echo

version="${tag:0:4}"
echo $version
echo

# get official pre-built firmware package
wget https://github.com/keirf/flashfloppy/releases/download/v${version}/flashfloppy-${version}.zip


# Check if intelhex is installed
python3 -c "import intelhex" 2>/dev/null

if [[ $? -eq 0 ]]; then
        echo "intelhex is already installed."
        echo
else
        echo "intelhex not found. Installing..."
        pip install intelhex
        echo
fi


make dist

if find . -name *.upd 1> /dev/null 2>&1; then
	echo flashfloppy firmware created successfully
	echo
	find . -name *.upd
	echo
else
	echo no flashfloppy firmware files found
	echo
fi
echo



echo
echo Done!

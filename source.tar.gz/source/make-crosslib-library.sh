#!/usr/bin/env bash

set -u
set -o pipefail

readonly SCRIPT_VERSION="0.3.1"
readonly DEFAULT_REPO_URL="https://github.com/Fabrizio-Caruso/CROSS-LIB.git"

workspace="${CROSSLIB_HOME:-$HOME/source/CROSS-LIB-coco}"
repo_url="${CROSSLIB_REPO_URL:-$DEFAULT_REPO_URL}"
data_root="${CROSSLIB_DATA_HOME:-$HOME/source/CROSS-LIB-builds}"
reports_dir="${CROSSLIB_REPORTS_DIR:-$data_root/reports}"
logs_dir="${CROSSLIB_LOGS_DIR:-$data_root/logs}"
output_dir="${CROSSLIB_OUTPUT_DIR:-$data_root/output}"
jobs="${CROSSLIB_JOBS:-$(getconf _NPROCESSORS_ONLN 2>/dev/null || printf '1')}"
dry_run=0
fresh_builds=1
c128_makefile_backup=""

readonly -a COCO_TARGETS=(coco coco3 dragon mc10)
readonly -a RETRO_TARGETS=(
    coco coco3 dragon mc10
    atari apple2 apple2enh
    c64 c128_z80_40col c128_z80_80col c128_8502 c128_8502_80col
    msx spectrum coleco coleco_adam nabu ti99 trs80 m100
    aquarius
)
readonly -a REQUESTED_TARGETS=(
    coco coco3 dragon mc10
    c64 c128_8502 c128_8502_80col c128_z80_40col c128_z80_80col
    msx ti99 trs80 atari apple2 apple2enh coleco_adam aquarius spectrum
)

usage() {
    cat <<'EOF'
Usage: make-crosslib-library.sh [--dry-run] [--no-clean] [--jobs N] COMMAND [ARGS...]

Commands:
  setup [--update]              Clone CROSS-LIB if absent; optionally fast-forward it
  doctor [PROFILE|TARGET...]    Check the checkout and relevant toolchains
  targets                       List the maintained target profiles
  build PROFILE [PROJECT]       Build a profile (PROJECT defaults to all)
  build-targets PROJECT TARGET... Build an explicit target list
  status                        Show checkout revision and latest build report

Profiles:
  coco    CoCo 1/2, CoCo 3, Dragon 32/64, and MC-10
  requested All directly supported configurations Ron specifically requested
  retro   coco plus the systems retained from Ron's older CROSS-LIB script

Environment overrides:
  CROSSLIB_HOME, CROSSLIB_REPO_URL, CROSSLIB_DATA_HOME,
  CROSSLIB_REPORTS_DIR, CROSSLIB_LOGS_DIR, CROSSLIB_OUTPUT_DIR,
  CROSSLIB_JOBS

Builds clean generated CROSS-LIB files before every target by default. Use
--no-clean only for diagnosis. Builds never delete an existing checkout.
Organized media is available below CROSSLIB_DATA_HOME/media after each run.
EOF
}

die() {
    printf 'ERROR: %s\n' "$*" >&2
    exit 1
}

run() {
    if ((dry_run)); then
        printf 'DRY-RUN:'
        printf ' %q' "$@"
        printf '\n'
    else
        "$@"
    fi
}

prepend_path_if_dir() {
    [[ -d "$1" ]] && PATH="$1:$PATH"
}

configure_toolchains() {
    # Prefer Ron's maintained local toolchains without changing shell startup files.
    prepend_path_if_dir "$HOME/source/cc65-2.13.3/usr/local/bin"
    prepend_path_if_dir "$HOME/source/cc65/bin"
    prepend_path_if_dir "$HOME/source/Puny-BuildTools/z88dk/bin"
    prepend_path_if_dir "$HOME/source/z88dk/bin"
    prepend_path_if_dir "$HOME/source/CC6303/cc68"
    prepend_path_if_dir "$HOME/source/CC6303/frontend"
    prepend_path_if_dir "$HOME/source/vice/vice/src"
    prepend_path_if_dir "$HOME/source/vice-emu-code/vice/src"
    if [[ -x "/opt/gcc4ti/bin/tms9900-gcc" ]]; then
        tms9900_dir="/opt/gcc4ti/bin"
    elif [[ -x "$HOME/source/tms9900-gcc-mburkley/tms9900-gcc-mburkley/bin/tms9900-gcc" ]]; then
        tms9900_dir="$HOME/source/tms9900-gcc-mburkley/tms9900-gcc-mburkley/bin"
    elif [[ -x "$HOME/source/tms9900-gcc/tms9900-gcc/bin/tms9900-gcc" ]]; then
        tms9900_dir="$HOME/source/tms9900-gcc/tms9900-gcc/bin"
    else
        tms9900_dir="/opt/gcc4ti/bin"
    fi
    prepend_path_if_dir "$tms9900_dir"

    if [[ -x "$HOME/source/z88dk/bin/zcc" && -d "$HOME/source/z88dk/lib/config" ]]; then
        # zcc and its libraries must come from the same checkout/version.
        export ZCCCFG="$HOME/source/z88dk/lib/config"
    fi
    export PATH
}

prepare_ti99_layout() {
    local ti_root="$data_root/toolchains/gcc4ti"
    local tool
    [[ -d "$HOME/source/libti99" && -f "$HOME/source/libti99/libti99.a" ]] || return 1
    mkdir -p "$ti_root/bin"
    ln -sfn "$HOME/source/libti99" "$ti_root/include"
    for tool in tms9900-ar tms9900-as tms9900-gcc tms9900-ld; do
        [[ -x "$tms9900_dir/$tool" ]] || return 1
        ln -sfn "$tms9900_dir/$tool" "$ti_root/bin/$tool"
    done
    # These bundled helpers are pre-C99 sources and fail with GCC's modern
    # default language mode on Debian 13. Compile unmodified source compatibly.
    if [[ ! -x "$workspace/tools/ti99/elf2ea5.out" ]]; then
        gcc -std=gnu89 "$workspace/tools/ti99/elf2ea5/elf2ea5.c" \
            -o "$workspace/tools/ti99/elf2ea5.out" || return 1
    fi
    if [[ ! -x "$workspace/tools/ti99/ea5split.out" ]]; then
        gcc -std=gnu89 "$workspace/tools/ti99/ea5split/ea5split.c" \
            -o "$workspace/tools/ti99/ea5split.out" || return 1
    fi
    tms9900_dir="$ti_root/bin"
    ti99_lib_dir="$HOME/source/libti99"
}

restore_c128_makefile() {
    if [[ -n "$c128_makefile_backup" && -f "$c128_makefile_backup" ]]; then
        cp -a "$c128_makefile_backup" "$workspace/src/Makefile_common"
        rm -f "$c128_makefile_backup"
        c128_makefile_backup=""
    fi
}

prepare_c128_makefile() {
    c128_makefile_backup="$(mktemp)"
    cp -a "$workspace/src/Makefile_common" "$c128_makefile_backup"
    sed -i \
        -e 's/a40\.ldr/A40.LDR/g' -e 's/-write a40$/-write A40/' -e 's/rm a40$/rm A40/' \
        -e 's/a80\.ldr/A80.LDR/g' -e 's/-write a80$/-write A80/' -e 's/rm a80$/rm A80/' \
        "$workspace/src/Makefile_common"
}

trap restore_c128_makefile EXIT INT TERM

require_checkout() {
    [[ -d "$workspace/.git" && -x "$workspace/src/xl" ]] ||
        die "CROSS-LIB checkout not found at $workspace; run setup first"
}

targets_for_profile() {
    case "$1" in
        coco) printf '%s\n' "${COCO_TARGETS[@]}" ;;
        requested) printf '%s\n' "${REQUESTED_TARGETS[@]}" ;;
        retro) printf '%s\n' "${RETRO_TARGETS[@]}" ;;
        *) die "unknown profile: $1 (expected coco, requested, or retro)" ;;
    esac
}

compiler_for_target() {
    case "$1" in
        coco|coco3|dragon) printf 'cmoc\n' ;;
        mc10) printf 'cc68\n' ;;
        ti99) printf 'tms9900-gcc\n' ;;
        atari|apple2|apple2enh|c64|c128_8502*) printf 'cl65\n' ;;
        *) printf 'zcc\n' ;;
    esac
}

setup_checkout() {
    local update=0
    [[ "${1:-}" == "--update" ]] && update=1
    if [[ ! -d "$workspace/.git" ]]; then
        run mkdir -p "$(dirname "$workspace")"
        run git clone "$repo_url" "$workspace"
    elif ((update)); then
        [[ -z "$(git -C "$workspace" status --porcelain)" ]] ||
            die "checkout has local changes; refusing to update"
        run git -C "$workspace" pull --ff-only
    else
        printf 'Using existing checkout: %s\n' "$workspace"
    fi
}

doctor() {
    require_checkout
    configure_toolchains
    local -a requested=()
    local arg compiler missing=0
    if (($# == 0)); then
        requested=("${COCO_TARGETS[@]}")
    elif [[ "$1" == "coco" || "$1" == "requested" || "$1" == "retro" ]]; then
        mapfile -t requested < <(targets_for_profile "$1")
    else
        requested=("$@")
    fi

    printf 'CROSS-LIB: %s\n' "$workspace"
    printf 'Revision:  %s\n' "$(git -C "$workspace" rev-parse --short HEAD)"
    printf 'Python:    %s\n' "$(command -v python3 || printf MISSING)"
    printf 'Make:      %s\n' "$(command -v make || printf MISSING)"
    for arg in "${requested[@]}"; do
        compiler="$(compiler_for_target "$arg")"
        if command -v "$compiler" >/dev/null 2>&1; then
            printf '%-18s %-8s %s\n' "$arg" "$compiler" "$(command -v "$compiler")"
        else
            printf '%-18s %-8s MISSING\n' "$arg" "$compiler"
            missing=1
        fi
    done
    return "$missing"
}

snapshot_build() {
    local destination="$1"
    mkdir -p "$destination"
    find "$workspace/build" -maxdepth 1 -type f ! -name '.keepthisfile.txt' \
        -newer "$2" -size +0c -exec cp -a -t "$destination" {} + 2>/dev/null || true
}

build_targets() {
    local project="$1"
    shift
    (($# > 0)) || die "no targets specified"
    require_checkout
    configure_toolchains
    mkdir -p "$reports_dir" "$logs_dir" "$output_dir" ||
        die "cannot create report/output directories (check CROSSLIB_*_DIR overrides)"

    local stamp report target log target_output started finished count status rc overall=0
    local makeflags_value c128_target
    stamp="$(date +%Y%m%d-%H%M%S)"
    report="$reports_dir/build-$stamp.tsv"
    printf 'target\tproject\tstatus\texit_code\tartifacts\tstarted\tfinished\tlog\n' >"$report"

    for target in "$@"; do
        log="$logs_dir/$stamp-$target.log"
        target_output="$output_dir/$stamp/$target"
        started="$(date --iso-8601=seconds)"
        printf 'Building %-18s project=%s\n' "$target" "$project"
        if ((dry_run)); then
            printf 'DRY-RUN: (cd %q && ./xl build %q %q %q)\n' \
                "$workspace/src" "$project" "$target" "$jobs"
            rc=0
            count=0
            status=DRY_RUN
        else
            local marker
            marker="$(mktemp)"
            if ((fresh_builds)); then
                (cd "$workspace/src" && ./xl clean) >>"$log" 2>&1 || true
            fi

            c128_target=0
            case "$target" in
                c128_z80_40col|c128_z80_80col) c128_target=1 ;;
            esac
            ((c128_target)) && prepare_c128_makefile

            makeflags_value="${MAKEFLAGS:-}"
            if [[ "$target" == "ti99" ]]; then
                if ! prepare_ti99_layout >>"$log" 2>&1; then
                    printf 'TI-99 toolchain or libti99 is incomplete\n' >>"$log"
                    rc=1
                else
                    makeflags_value="$makeflags_value LIB_TI99_PATH=$ti99_lib_dir TMS9900-GCC_PATH=$tms9900_dir"
                    (cd "$workspace/src" && env \
                        "TMS9900-GCC_PATH=$tms9900_dir" \
                        "MAKEFLAGS=$makeflags_value" \
                        ./xl build "$project" "$target" "$jobs") >>"$log" 2>&1
                    rc=$?
                fi
            else
                (cd "$workspace/src" && env "TMS9900-GCC_PATH=$tms9900_dir" \
                    ./xl build "$project" "$target" "$jobs") >>"$log" 2>&1
                rc=$?
            fi
            # This older xl logs a failed Make return code but itself exits 0.
            if grep -Eq 'return code: [1-9][0-9]*' "$log"; then
                rc=1
            fi
            snapshot_build "$target_output" "$marker"
            ((c128_target)) && restore_c128_makefile
            rm -f "$marker"
            count="$(find "$target_output" -maxdepth 1 -type f -size +0c | wc -l)"
            if ((rc == 0 && count > 0)); then
                status=OK
            elif ((rc == 0)); then
                status=NO_ARTIFACT
                overall=1
            else
                status=FAILED
                overall=1
            fi
        fi
        finished="$(date --iso-8601=seconds)"
        printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
            "$target" "$project" "$status" "$rc" "$count" "$started" "$finished" "$log" >>"$report"
        printf '  %-12s artifacts=%s log=%s\n' "$status" "$count" "$log"
    done
    ln -sfn "$(basename "$report")" "$reports_dir/latest.tsv"
    ln -sfn "$stamp" "$output_dir/latest"
    ln -sfn "output/$stamp" "$data_root/media"
    printf 'Report: %s\n' "$report"
    return "$overall"
}

show_status() {
    require_checkout
    git -C "$workspace" status --short --branch
    git -C "$workspace" log -1 --date=iso --format='Revision: %H%nDate:     %ad%nSubject:  %s'
    if [[ -e "$reports_dir/latest.tsv" ]]; then
        printf '\nLatest report: %s\n' "$(readlink -f "$reports_dir/latest.tsv")"
        column -t -s $'\t' "$reports_dir/latest.tsv" 2>/dev/null || cat "$reports_dir/latest.tsv"
    fi
}

while (($#)); do
    case "$1" in
        --dry-run) dry_run=1; shift ;;
        --no-clean) fresh_builds=0; shift ;;
        --jobs) (($# >= 2)) || die "--jobs needs a value"; jobs="$2"; shift 2 ;;
        --help|-h) usage; exit 0 ;;
        --version) printf '%s\n' "$SCRIPT_VERSION"; exit 0 ;;
        --) shift; break ;;
        -*) die "unknown option: $1" ;;
        *) break ;;
    esac
done

command="${1:-help}"
shift || true
case "$command" in
    help) usage ;;
    setup) setup_checkout "$@" ;;
    doctor) doctor "$@" ;;
    targets)
        printf 'coco:\n'; printf '  %s\n' "${COCO_TARGETS[@]}"
        printf 'requested:\n'; printf '  %s\n' "${REQUESTED_TARGETS[@]}"
        printf 'retro:\n'; printf '  %s\n' "${RETRO_TARGETS[@]}"
        ;;
    build)
        profile="${1:-coco}"; project="${2:-all}"
        mapfile -t selected_targets < <(targets_for_profile "$profile")
        build_targets "$project" "${selected_targets[@]}"
        ;;
    build-targets)
        (($# >= 2)) || die "build-targets needs PROJECT and at least one TARGET"
        project="$1"; shift
        build_targets "$project" "$@"
        ;;
    status) show_status ;;
    *) die "unknown command: $command" ;;
esac

#!/bin/bash

# install prerequisites
echo NOTE!  You need to make sure the following projects are already built and installed:
echo
echo lwtools
echo toolshed
echo
echo
read -p "Press any key to continue... " -n1 -s
echo

sudo apt install jam

cd $HOME/source

# if a previous coco-test folder exists, move into a date-time named folder

if [ -d "coco-test" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "coco-test" "coco-test-$foldername"

        echo -e Archiving existing coco-test folder ["coco-test"] into backup folder ["coco-test-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/callsop/coco-test
git clone https://github.com/callsop/coco-test.git

cd coco-test

GITREV=`git rev-parse --short HEAD`

jam clean
jam dsk

if [ $? -eq 0 ]
then
        echo "Compilation was successful."
        echo
else
        echo "Compilation was NOT successful.  Aborting installation."
        echo
        exit 1
fi


cd $HOME/source


echo
echo Done!

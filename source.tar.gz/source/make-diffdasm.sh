#!/usr/bin/env bash

set -euo pipefail

repo_url="${DIFFDASM_REPO:-https://github.com/cyberabi/diffdasm.git}"
branch="${DIFFDASM_BRANCH:-main}"
source_root="${DIFFDASM_SOURCE_ROOT:-$HOME/source}"
checkout_name="${DIFFDASM_CHECKOUT:-diffdasm}"
install_dir="${DIFFDASM_INSTALL_DIR:-/usr/local/bin}"
jobs="${DIFFDASM_JOBS:-}"
do_install=1

usage() {
  cat <<'EOF'
Usage: make-diffdasm.sh [OPTIONS]

Clone, build, and optionally install cyberabi/diffdasm. An existing checkout
is archived alongside the new checkout before cloning.

Options:
  --repo URL          Git repository (default: cyberabi/diffdasm)
  --branch NAME       Branch to build (default: main)
  --source-root DIR   Parent directory for checkout (default: $HOME/source)
  --checkout NAME     Checkout directory name (default: diffdasm)
  --jobs N            Parallel build jobs (default: half available CPUs)
  --install-dir DIR   Installation directory (default: /usr/local/bin)
  --no-install        Build only; do not install the binary
  -h, --help          Show this help

DIFFDASM_REPO, DIFFDASM_BRANCH, DIFFDASM_SOURCE_ROOT, DIFFDASM_CHECKOUT,
DIFFDASM_JOBS, and DIFFDASM_INSTALL_DIR provide equivalent defaults.

Debian build requirements: git, make, gcc, and g++ (the build-essential
package supplies the compiler and build tools).
EOF
}

while (($#)); do
  case "$1" in
    --repo) repo_url=${2:?missing value for --repo}; shift 2 ;;
    --branch) branch=${2:?missing value for --branch}; shift 2 ;;
    --source-root) source_root=${2:?missing value for --source-root}; shift 2 ;;
    --checkout) checkout_name=${2:?missing value for --checkout}; shift 2 ;;
    --jobs) jobs=${2:?missing value for --jobs}; shift 2 ;;
    --install-dir) install_dir=${2:?missing value for --install-dir}; shift 2 ;;
    --no-install) do_install=0; shift ;;
    -h|--help) usage; exit 0 ;;
    *) printf 'Unknown option: %s\n\n' "$1" >&2; usage >&2; exit 2 ;;
  esac
done

for command in git make gcc g++; do
  if ! command -v "$command" >/dev/null 2>&1; then
    printf 'Required command not found: %s\n' "$command" >&2
    printf 'On Debian, install prerequisites with: sudo apt install git build-essential\n' >&2
    exit 1
  fi
done

if [[ -z "$jobs" ]]; then
  processors=$(getconf _NPROCESSORS_ONLN 2>/dev/null || printf '1')
  jobs=$((processors > 1 ? processors / 2 : 1))
fi
if [[ ! "$jobs" =~ ^[1-9][0-9]*$ ]]; then
  printf 'Build jobs must be a positive integer: %s\n' "$jobs" >&2
  exit 2
fi

mkdir -p "$source_root"
checkout="$source_root/$checkout_name"
if [[ -e "$checkout" ]]; then
  archive="${checkout}-$(date +%Y-%m-%d_%H.%M.%S)"
  printf 'Archiving existing checkout as %s\n' "$archive"
  mv "$checkout" "$archive"
fi

printf 'Cloning %s branch %s\n' "$repo_url" "$branch"
git clone --branch "$branch" --single-branch "$repo_url" "$checkout"
cd "$checkout"

revision=$(git rev-parse HEAD)
short_revision=$(git rev-parse --short=8 HEAD)
printf 'Building revision %s with %s jobs\n' "$revision" "$jobs"
make -j"$jobs" BUILD_MODE=run

if [[ ! -x diffdasm ]]; then
  printf 'Build completed without producing executable: %s/diffdasm\n' "$checkout" >&2
  exit 1
fi

cat >diffdasm-build-info.txt <<EOF
repository=$repo_url
branch=$branch
revision=$revision
build_mode=run
jobs=$jobs
binary=$checkout/diffdasm
EOF

if ((do_install)); then
  install_name="diffdasm-$short_revision"
  if mkdir -p "$install_dir" 2>/dev/null && [[ -w "$install_dir" ]]; then
    install -m 0755 diffdasm "$install_dir/$install_name"
    install -m 0644 diffdasm-build-info.txt "$install_dir/$install_name.build-info"
    ln -sfn "$install_name" "$install_dir/diffdasm"
    ln -sfn "$install_name.build-info" "$install_dir/diffdasm.build-info"
  else
    sudo install -d "$install_dir"
    sudo install -m 0755 diffdasm "$install_dir/$install_name"
    sudo install -m 0644 diffdasm-build-info.txt "$install_dir/$install_name.build-info"
    sudo ln -sfn "$install_name" "$install_dir/diffdasm"
    sudo ln -sfn "$install_name.build-info" "$install_dir/diffdasm.build-info"
  fi
  printf 'Installed %s and selected it through %s/diffdasm\n' \
    "$install_dir/$install_name" "$install_dir"
else
  printf 'Built %s/diffdasm\n' "$checkout"
fi
printf 'Build provenance: %s/diffdasm-build-info.txt\n' "$checkout"

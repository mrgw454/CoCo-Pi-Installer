#!/bin/bash

cd $HOME/source

# if a previous crasm folder exists, move into a date-time named folder

if [ -d "crasm-master" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "crasm-master" "crasm-master-$foldername"

        echo -e Archiving existing crasm folder ["crasm-master"] into backup folder ["crasm-master-$foldername"]
        echo -e
        echo -e
fi

if [ ! -f crasm-master.zip ]; then
	# https://htmlpreview.github.io/?https://github.com/colinbourassa/crasm/blob/master/crasm.html
	wget --no-check-certificate https://github.com/colinbourassa/crasm/archive/master.zip -O crasm-master.zip
fi

if [ ! -d crasm-master ]; then
	mkdir crasm-master
fi

unzip crasm-master.zip

cd crasm-master

sed -i 's|prefix=/usr|prefix=/usr/local|' Makefile

make

if [ $? -eq 0 ]
then
        echo "Compilation was successful.  Continuing."
        echo
else
        echo "Compilation was NOT successful.  Aborting."
        echo
        exit 1
fi

sudo make install

cd ..


echo
echo Done!

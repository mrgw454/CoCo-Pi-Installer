#!/usr/bin/env bash
#
# make-DriveWire.sh
# Hardened, ZIP-only DriveWire4 installer.
# - No repo clone
# - Uses latest Linux ZIP from GitHub
# - Extracts ZIP into $HOME/source/drivewire4
# - Installs runtime into $HOME/DriveWire4
# - Creates GUI + NOUI launchers
# - Preserves existing config.xml
# - Safe .desktop creation
#

set -euo pipefail

REPO_OWNER="qbancoffee"
REPO_NAME="drivewire4"
REPO="${REPO_OWNER}/${REPO_NAME}"

echo "====================================================="
echo " DriveWire4 Hardened Installer (ZIP-only)"
echo "====================================================="
echo

# ---------------------------------------------------------------
# 1. Install SWT WebKit prerequisite
# ---------------------------------------------------------------
echo "[INFO] Installing prerequisite libswt-webkit-gtk-4-jni..."
sudo apt -y install libswt-webkit-gtk-4-jni

# ---------------------------------------------------------------
# 2. Detect architecture
# ---------------------------------------------------------------
systemtype="$(dpkg --print-architecture)"
echo "[INFO] Detected architecture: ${systemtype}"
echo

# ---------------------------------------------------------------
# 3. Query GitHub releases and pick latest Linux ZIP for this arch
# ---------------------------------------------------------------
echo "[INFO] Querying DriveWire4 releases from GitHub..."
releases_json="$(
    curl --silent -m 10 --connect-timeout 5 \
        "https://api.github.com/repos/${REPO}/releases?per_page=20"
)"

if [[ -z "${releases_json}" ]]; then
    echo "[ERROR] Failed to retrieve releases list from GitHub." >&2
    exit 1
fi

echo "[INFO] Selecting latest Linux ZIP asset for this architecture..."

asset_url=""
set +e
case "${systemtype}" in
    amd64)
        asset_url="$(
            echo "${releases_json}" \
            | grep -i '"browser_download_url":' \
            | grep -i 'linux_x86_64' \
            | grep -i '\.zip"' \
            | sed -E 's/.*"browser_download_url": *"([^"]+)".*/\1/' \
            | head -n1
        )"
        ;;
    arm64|aarch64)
        asset_url="$(
            echo "${releases_json}" \
            | grep -i '"browser_download_url":' \
            | grep -i 'linux_arm_64\|linux_aarch64' \
            | grep -i '\.zip"' \
            | sed -E 's/.*"browser_download_url": *"([^"]+)".*/\1/' \
            | head -n1
        )"
        ;;
    *)
        echo "[ERROR] Unsupported architecture: ${systemtype}" >&2
        exit 1
        ;;
esac
set -e

if [[ -z "${asset_url}" ]]; then
    echo "[ERROR] No Linux ZIP asset found for architecture ${systemtype}." >&2
    exit 1
fi

ZIPNAME="$(basename "${asset_url}")"

# drivewire4_4.3.6p_java21_linux_x86_64.zip -> 4.3.6p
LATEST_VERSION="$(echo "${ZIPNAME}" | sed -E 's/^drivewire4_([^_]+)_java.*/\1/')"

if [[ -z "${LATEST_VERSION}" ]]; then
    echo "[ERROR] Unable to parse version from ZIP name: ${ZIPNAME}" >&2
    exit 1
fi

echo "[INFO] Selected ZIP asset: ${ZIPNAME}"
echo "[INFO] Parsed version: ${LATEST_VERSION}"
echo

# ---------------------------------------------------------------
# 4. Check installed version (from $HOME/DriveWire4/drivewire4.desktop)
# ---------------------------------------------------------------
INSTALLDIR="$HOME/DriveWire4"
DESKTOP_FILE="${INSTALLDIR}/drivewire4.desktop"

INSTALLED_VERSION=""
if [[ -f "${DESKTOP_FILE}" ]]; then
    INSTALLED_VERSION="$(grep -E '^Version=' "${DESKTOP_FILE}" | cut -d'=' -f2 || true)"
fi

echo "=============================================="
echo " DriveWire4 Version Check"
echo "=============================================="
echo " Installed version : ${INSTALLED_VERSION:-none}"
echo " Latest Linux ver  : ${LATEST_VERSION}"
echo "=============================================="
echo

read -rp "Proceed with installation of DriveWire4 ${LATEST_VERSION}? (y/n): " yn
if [[ ! "${yn}" =~ ^[Yy]$ ]]; then
    echo "[INFO] Installation aborted by user."
    exit 0
fi

echo

# ---------------------------------------------------------------
# 5. Prepare source workspace and extract ZIP
# ---------------------------------------------------------------
mkdir -p "$HOME/source"
cd "$HOME/source"

if [[ -d "drivewire4" ]]; then
    ts="$(date +%Y-%m-%d_%H.%M.%S)"
    echo "[INFO] Archiving existing source working dir to drivewire4-${ts}"
    mv "drivewire4" "drivewire4-${ts}"
    echo
fi

mkdir -p "drivewire4"
cd "drivewire4"

echo "[INFO] Downloading ZIP into $PWD..."
wget -O "${ZIPNAME}" "${asset_url}"

echo "[INFO] Unzipping ${ZIPNAME}..."
unzip -q "${ZIPNAME}"
echo

# Detect extracted runtime dir
RUNTIMEDIR=""
if [[ -d "linux-x86_64" ]]; then
    RUNTIMEDIR="linux-x86_64"
elif [[ -d "linux-aarch64" ]]; then
    RUNTIMEDIR="linux-aarch64"
elif [[ -d "linux-arm_64" ]]; then
    RUNTIMEDIR="linux-arm_64"
fi

if [[ -z "${RUNTIMEDIR}" ]]; then
    echo "[ERROR] Unable to locate linux-x86_64 or linux-aarch64 runtime directory in ZIP." >&2
    ls -al
    exit 1
fi

echo "[INFO] Found runtime directory: ${RUNTIMEDIR}"
echo

# ---------------------------------------------------------------
# 6. Install runtime into $HOME/DriveWire4
# ---------------------------------------------------------------
echo "[INFO] Installing runtime into: ${INSTALLDIR}"
rm -rf "${INSTALLDIR}"
mkdir -p "${INSTALLDIR}"

cp -a "${RUNTIMEDIR}/." "${INSTALLDIR}/"

# ---------------------------------------------------------------
# 7. Preserve existing config.xml
# ---------------------------------------------------------------
if [[ -f "${INSTALLDIR}/config.xml" ]]; then
    echo "[INFO] Preserving existing config.xml"
else
    echo "[INFO] Installing new config.xml"
    cp "${RUNTIMEDIR}/config.xml" "${INSTALLDIR}/config.xml"
fi

# ---------------------------------------------------------------
# 8. Create GUI start launcher
# ---------------------------------------------------------------
echo "[INFO] Creating GUI start launcher..."

cat > "${INSTALLDIR}/start" <<'EOS'
#!/bin/bash
cd "$(dirname "$0")"

JAVA="java"
if [ -x "./jre/bin/java" ]; then
  JAVA="./jre/bin/java"
fi

export GDK_BACKEND=${GDK_BACKEND:-x11}

exec "$JAVA" -Djava.library.path="./lib" -jar "./drivewire4.jar" "$@"
EOS

chmod a+x "${INSTALLDIR}/start"

# ---------------------------------------------------------------
# 9. Create NOUI helper scripts
# ---------------------------------------------------------------
echo "[INFO] Creating NOUI helper scripts..."

cat > "${INSTALLDIR}/start_noui.sh" <<'EOF'
#!/bin/bash
cd "$(dirname "$0")"

PIDFILE="dw4_noui.pid"
LOGFILE="dw4_noui.log"

if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    echo "DriveWire4 NOUI is already running (PID $(cat "$PIDFILE"))."
    exit 0
fi

JAVA="./jre/bin/java"
[ -x "$JAVA" ] || JAVA="java"

nohup "$JAVA" -Djava.library.path="./lib" -jar "./drivewire4.jar" --noui \
    >> "$LOGFILE" 2>&1 &

PID=$!
echo "$PID" > "$PIDFILE"

echo "DriveWire4 NOUI started in background (PID $PID)."
echo "Log: $LOGFILE"
EOF

cat > "${INSTALLDIR}/stop_noui.sh" <<'EOF'
#!/bin/bash
cd "$(dirname "$0")"

PIDFILE="dw4_noui.pid"

if [ ! -f "$PIDFILE" ]; then
    echo "DriveWire4 NOUI is not running."
    exit 0
fi

PID=$(cat "$PIDFILE")

if kill -0 "$PID" 2>/dev/null; then
    echo "Stopping DriveWire4 NOUI (PID $PID)..."
    kill "$PID"
    sleep 1
    if kill -0 "$PID" 2>/dev/null; then
        echo "Force killing..."
        kill -9 "$PID"
    fi
else
    echo "PID file exists but process is not running."
fi

rm -f "$PIDFILE"
echo "DriveWire4 NOUI stopped."
EOF

cat > "${INSTALLDIR}/status_noui.sh" <<'EOF'
#!/bin/bash
cd "$(dirname "$0")"

PIDFILE="dw4_noui.pid"

if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    echo "DriveWire4 NOUI is running (PID $(cat "$PIDFILE"))."
else
    echo "DriveWire4 NOUI is not running."
fi
EOF

chmod +x "${INSTALLDIR}/start_noui.sh" \
         "${INSTALLDIR}/stop_noui.sh" \
         "${INSTALLDIR}/status_noui.sh"

# ---------------------------------------------------------------
# 10. Safe .desktop creation
# ---------------------------------------------------------------
echo "[INFO] Ensuring ~/.local/share/applications exists..."
USER_APPS="$HOME/.local/share/applications"
mkdir -p "${USER_APPS}"

DESKTOP_FILE="${INSTALLDIR}/drivewire4.desktop"

echo "[INFO] Creating drivewire4.desktop..."
cat > "${DESKTOP_FILE}" <<EOF
[Desktop Entry]
Type=Application
Name=DriveWire 4
Exec=${INSTALLDIR}/start
Path=${INSTALLDIR}
Icon=${INSTALLDIR}/dw4_icon.png
Terminal=false
Categories=Utility;
Version=${LATEST_VERSION}
EOF

echo "[INFO] Installing Desktop shortcut..."
mkdir -p "$HOME/Desktop"
cp "${DESKTOP_FILE}" "$HOME/Desktop/"

echo "[INFO] Installing .desktop into local applications..."
cp "${DESKTOP_FILE}" "${USER_APPS}/"

# ---------------------------------------------------------------
# 11. Done
# ---------------------------------------------------------------
cd "$HOME/source"

echo
echo "[INFO] DriveWire4 installation complete."
echo "Installed Linux version: ${LATEST_VERSION}"
echo "Installed at: ${INSTALLDIR}"
echo "Launch via menu or: ${INSTALLDIR}/start"
echo

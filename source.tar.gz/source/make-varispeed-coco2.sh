#!/bin/bash

if ! command -v node >/dev/null 2>&1; then
        echo "node is not installed.  Please install Node.js first, for example:"
        echo "sudo apt install -y nodejs npm"
        echo
        exit 1
fi

if ! command -v npm >/dev/null 2>&1; then
        echo "npm is not installed.  Please install npm first, for example:"
        echo "sudo apt install -y nodejs npm"
        echo
        exit 1
fi

cd $HOME/source

# if a previous varispeed-coco2 folder exists, move into a date-time named folder

if [ -d "varispeed-coco2" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "varispeed-coco2" "varispeed-coco2-$foldername"

        echo -e Archiving existing varispeed-coco2 folder ["varispeed-coco2"] into backup folder ["varispeed-coco2-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/star-fs/varispeed-coco2
git clone https://github.com/star-fs/varispeed-coco2.git

cd varispeed-coco2

GITREV=`git rev-parse --short HEAD`

echo
git log -1
echo

npm run check

if [ $? -eq 0 ]
then
        echo "Sanity check was successful."
        echo
else
        echo "Sanity check was NOT successful.  Aborting."
        echo
        exit 1
fi

echo "To run locally:"
echo "cd $HOME/source/varispeed-coco2 && npm start"
echo
echo "Open http://127.0.0.1:8080/ in your browser."
echo

cd $HOME/source


echo
echo Done!

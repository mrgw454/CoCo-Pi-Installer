#!/bin/bash

cd $HOME/source

# if a previous folder exists, move into a date-time named folder

if [ -d "fujinet-apps" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "fujinet-apps" "fujinet-apps-$foldername"

        echo -e Archiving existing ugbasic folder ["fujinet-apps"] into backup folder ["fujinet-apps-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/FujiNetWIFI/fujinet-apps
git clone https://github.com/FujiNetWIFI/fujinet-apps.git
cd fujinet-apps

git pull
git submodule update --force --recursive --init --remote

cd netcat/adam

make


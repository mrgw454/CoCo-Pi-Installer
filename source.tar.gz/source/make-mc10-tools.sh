#!/bin/bash
set -e

cd "$HOME/source"

# ---------------------------------------------------------------------------
# 1. Prepare fresh folder
# ---------------------------------------------------------------------------
if [ -d "mc10-tools" ]; then
    foldername=$(date +%Y-%m-%d_%H.%M.%S)
    mv "mc10-tools" "mc10-tools-$foldername"
    echo "Archived existing mc10-tools into mc10-tools-$foldername"
fi

mkdir mc10-tools
cd mc10-tools

# ---------------------------------------------------------------------------
# 2. Create venv and install mc10-tools
# ---------------------------------------------------------------------------
echo "Creating virtual environment..."
python3 -m venv .venv
source .venv/bin/activate

echo "Installing mc10-tools==0.9..."
pip install --upgrade pip
pip install mc10-tools==0.9

deactivate

# ---------------------------------------------------------------------------
# 3. Symlink mc10-tools executables into /usr/local/bin
# ---------------------------------------------------------------------------
SRC="$PWD/.venv/bin"
DEST="/usr/local/bin"

echo "Cleaning old mc10-tools symlinks from $DEST"
sudo bash -c '
find "'"$DEST"'" -maxdepth 1 -type l -exec sh -c "
    for link; do
        target=\$(readlink \"\$link\")
        case \"\$target\" in
            */source/mc10-tools/*) rm \"\$link\";;
        esac
    done
" sh {} +
'

echo "Creating new mc10-tools symlinks"

for tool in bastoc10 c10tobas; do
    if [ -x "$SRC/$tool" ]; then
        sudo ln -sf "$SRC/$tool" "$DEST/$tool"
        echo "Linked $tool"
    fi
done

echo "Symlinks created in $DEST"

# ---------------------------------------------------------------------------
# 4. Verify
# ---------------------------------------------------------------------------
echo
echo "Installed mc10-tools commands now in /usr/local/bin:"
ls -1 "$DEST" | grep -E 'bastoc10|c10tobas' || true

echo
echo "Done."

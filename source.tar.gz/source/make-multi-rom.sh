#!/bin/bash
# MOOH Multi-ROM builder — clone repo, patch, generate scripts, build SD card image.
#
# This script is self-contained. It clones the upstream multi-rom repo, applies
# necessary bug fixes, writes the dynamic build script (build-sdcard.py), the
# XRoar launch script (xroar-mooh.sh), and documentation (BUILD-HOWTO.txt),
# then runs the build.
#
# Usage:
#   ./make-multi-rom.sh
#       Clone and build using the default ROM paths embedded below.
#
#   ./make-multi-rom.sh "Games:/path/to/games" "Apps:/path/to/apps" ...
#       Clone and build using the given category directories.
#       Each argument is "Label:path" — the label appears in the menu.
#
# Dependencies:
#   lwasm   (lwtools)  — 6809 assembler   https://www.lwtools.ca/
#   python3            — 3.6 or later
#   SDBOOT EPROM       — ~/source/sdboot/bootrom/eprom8.rom (for XRoar testing)
#   xroar              — CoCo emulator (optional, for testing)

set -e
cd "$HOME/source"

# ---------------------------------------------------------------------------
# Archive existing folder if present
# ---------------------------------------------------------------------------
if [ -d "multi-rom" ]; then
        foldername=$(date +%Y-%m-%d_%H.%M.%S)
        mv "multi-rom" "multi-rom-$foldername"
        echo "Archived existing multi-rom/ -> multi-rom-$foldername/"
        echo
fi

# ---------------------------------------------------------------------------
# Clone upstream repo (provides runmenu.asm and multirom-packer.py)
# ---------------------------------------------------------------------------
git clone https://gitlab.com/mooh-board/multi-rom.git
cd multi-rom

# ---------------------------------------------------------------------------
# Check dependencies
# ---------------------------------------------------------------------------
echo "Checking dependencies..."

if ! command -v lwasm &>/dev/null; then
        echo "ERROR: lwasm not found. Install lwtools (https://www.lwtools.ca/)."
        exit 1
fi

if ! command -v python3 &>/dev/null; then
        echo "ERROR: python3 not found."
        exit 1
fi

SDBOOT_ROM="$HOME/source/sdboot/bootrom/eprom8.rom"
if [ ! -f "$SDBOOT_ROM" ]; then
        echo "WARNING: SDBOOT EPROM not found at $SDBOOT_ROM"
        echo "         XRoar testing will not work without it."
        echo "         See https://gitlab.com/tormod.volden/sdboot"
        echo
fi

echo

# ---------------------------------------------------------------------------
# Patch runmenu.asm — fix 16K ROM crash
#
# SDBDOS direct loader writes bytes sequentially from $C000. For 16K ROMs
# (Y=$4000), the last sector lands at $FE00-$FFFF and writes into $FF00-$FFFF
# hardware registers (PIA, DAT, $FF90 MOOH control), corrupting the system.
# Fix: cap Y at $3F00 so the load stops at $FEFF.
# ---------------------------------------------------------------------------
echo "Patching runmenu.asm (16K ROM fix)..."
python3 - << 'PATCHEOF'
import sys
with open('runmenu.asm', 'r') as f:
    content = f.read()

old = '\ttfr\td,y\t; number of bytes\n\tldx\t#$C000\t; cartridge ROM location'
new = (
    '\ttfr\td,y\t; number of bytes\n'
    '\t; $FF00-$FFFF is always hardware (PIA, DAT, etc.) - never writable as ROM.\n'
    '\t; Cap Y at $3F00 so the load stops at $FEFF, avoiding hardware register\n'
    '\t; corruption when loading 16K ROMs whose image extends to $FFFF.\n'
    '\tcmpy\t#$3F01\t\t; if Y > $3F00 ($C000+Y would reach $FF00)\n'
    '\tblo\tsetsrc\n'
    '\tldy\t#$3F00\t\t; cap: load $C000-$FEFF only\n'
    'setsrc\tldx\t#$C000\t; cartridge ROM location'
)
if old in content:
    content = content.replace(old, new)
    with open('runmenu.asm', 'w') as f:
        f.write(content)
    print("  OK")
else:
    print("  WARNING: pattern not found -- runmenu.asm may already be patched or has changed upstream")
PATCHEOF

# ---------------------------------------------------------------------------
# Patch multirom-packer.py — strip TOSEC metadata from display names
#
# Allows passing full TOSEC filenames directly without creating symlinks.
# "Canyon Climber (1982)(Tandy)[26-3089].rom" -> display name "Canyon Climber"
# ---------------------------------------------------------------------------
echo "Patching multirom-packer.py (TOSEC name cleaning)..."
python3 - << 'PATCHEOF'
import re, sys
with open('multirom-packer.py', 'r') as f:
    content = f.read()

# Add import re after import sys (idempotent)
if 'import re' not in content:
    content = content.replace('import sys\n', 'import sys\nimport re\n', 1)

# Replace bare p.stem with cleaned version (idempotent)
old_name = '    name = p.stem\n'
new_name = (
    '    # Strip TOSEC metadata: "Name (year)(pub)[cat]" -> "Name"\n'
    '    name = re.sub(r\'\\s*[\\(\\[].*\', \'\', p.stem).strip().rstrip(\' -\')\n'
)
if old_name in content:
    content = content.replace(old_name, new_name)

with open('multirom-packer.py', 'w') as f:
    f.write(content)
print("  OK")
PATCHEOF

# ---------------------------------------------------------------------------
# Write build-sdcard.py
# ---------------------------------------------------------------------------
echo "Writing build-sdcard.py..."
cat > build-sdcard.py << 'PYEOF'
#!/usr/bin/env python3
"""
MOOH Multi-ROM dynamic SD card builder for CoCo 1/2.

Scans ROM directories by category, filters to recognized cartridge sizes,
strips TOSEC metadata from filenames, auto-paginates (25 ROMs per page),
and builds sdcard.img ready for XRoar or real MOOH hardware.

Usage:
  ./build-sdcard.py
      Use default category paths defined in DEFAULT_CATEGORIES below.

  ./build-sdcard.py "Category Name:/path/to/roms" ...
      Scan the given directories instead of defaults.
      Each argument is "Label:path". The label is shown in the menu.
"""

import sys
import re
import subprocess
from pathlib import Path

# ---------------------------------------------------------------------------
# Configuration -- edit to match your ROM collection paths
# ---------------------------------------------------------------------------
DEFAULT_CATEGORIES = [
    ("Games",
     "/media/share1/CoCo/Tandy Radio Shack TRS-80 Color Computer - Games - [ROM] (TOSEC-v2011-01-01_CM)"),
    ("Educational",
     "/media/share1/CoCo/Tandy Radio Shack TRS-80 Color Computer - Educational - [ROM] (TOSEC-v2011-01-01_CM)"),
    ("Applications",
     "/media/share1/CoCo/Tandy Radio Shack TRS-80 Color Computer - Applications - [ROM] (TOSEC-v2011-01-01_CM)"),
    ("Homebrew",
     "/media/share1/carts"),
]

SDBOOT_ROM = Path.home() / "source/sdboot/bootrom/eprom8.rom"
# ---------------------------------------------------------------------------

SCRIPT_DIR  = Path(__file__).parent
RUNMENU_BIN = SCRIPT_DIR / "runmenu_coco.bin"
PACKER      = SCRIPT_DIR / "multirom-packer.py"
SDCARD_IMG  = SCRIPT_DIR / "sdcard.img"

# Only these exact sizes are recognized as cartridge ROMs (bytes -> KB type)
RECOGNIZED_SIZES = {4096: 4, 8192: 8, 16384: 16, 32768: 32}

# Page layout: 1 back-link + ROMs [+ 1 next-link if more pages follow]
ROMS_PER_PAGE  = 24   # when a next-link is also needed
ROMS_LAST_PAGE = 25   # no next-link on final page of a category

MAX_PAGES = 16        # hardware limit (runtime + packer)


def find_roms(directory):
    """Return sorted list of recognized ROM/cart paths in directory."""
    p = Path(directory)
    if not p.is_dir():
        print(f"  WARNING: directory not found: {directory}")
        return []
    roms = []
    for f in p.iterdir():
        if f.suffix.lower() not in ('.rom', '.ccc'):
            continue
        try:
            size = f.stat().st_size
        except OSError:
            continue
        if size not in RECOGNIZED_SIZES:
            continue
        roms.append(f)
    # Sort by clean name (case-insensitive)
    roms.sort(key=lambda f: re.sub(r'\s*[\(\[].*', '', f.stem).strip().upper())
    return roms


def paginate(roms):
    """Split ROM list into pages of ROMS_PER_PAGE / ROMS_LAST_PAGE."""
    if not roms:
        return []
    pages = []
    i = 0
    while i < len(roms):
        remaining = len(roms) - i
        if remaining <= ROMS_LAST_PAGE:
            pages.append(roms[i:])
            break
        pages.append(roms[i : i + ROMS_PER_PAGE])
        i += ROMS_PER_PAGE
    return pages


def page_label(cat_name, page_idx, num_pages):
    """Short back-link label for a category page."""
    if num_pages == 1:
        return f"-- {cat_name} --"[:14]
    return f"-- {cat_name} {page_idx+1}/{num_pages}"[:14]


def main():
    # Parse categories from args or use defaults
    if len(sys.argv) > 1:
        categories = []
        for arg in sys.argv[1:]:
            if ':' in arg:
                label, path = arg.split(':', 1)
            else:
                label, path = Path(arg).name, arg
            categories.append((label.strip(), path.strip()))
    else:
        categories = DEFAULT_CATEGORIES

    # -----------------------------------------------------------------------
    # Step 1: Assemble menu runtime
    # -----------------------------------------------------------------------
    print("Assembling runmenu_coco.bin...", flush=True)
    result = subprocess.run(
        ["lwasm", "--decb", "-DCOCO", "-o", str(RUNMENU_BIN), str(SCRIPT_DIR / "runmenu.asm")],
        cwd=str(SCRIPT_DIR), capture_output=True, text=True
    )
    if result.returncode != 0:
        print(result.stderr)
        sys.exit(1)
    print(f"  OK: {RUNMENU_BIN.stat().st_size} bytes", flush=True)

    # -----------------------------------------------------------------------
    # Step 2: Scan directories
    # -----------------------------------------------------------------------
    print("Scanning ROM directories...", flush=True)
    cat_pages = []
    for label, directory in categories:
        roms = find_roms(directory)
        pages = paginate(roms)
        if not pages:
            print(f"  {label}: 0 recognized ROMs -- skipping")
            continue
        total = sum(len(p) for p in pages)
        print(f"  {label}: {total} ROMs -> {len(pages)} page(s)  [{directory}]")
        cat_pages.append((label, pages))

    if not cat_pages:
        print("No recognized ROMs found. Check your source directories.")
        sys.exit(1)

    # -----------------------------------------------------------------------
    # Step 3: Assign page numbers (0-based internally)
    #   Page 0 = main menu
    #   Pages 1..N = category pages in order
    # -----------------------------------------------------------------------
    page_assignments = []
    next_page = 1
    for label, pages in cat_pages:
        nums = list(range(next_page, next_page + len(pages)))
        page_assignments.append(nums)
        next_page += len(pages)

    total_pages = next_page
    if total_pages > MAX_PAGES:
        print(f"ERROR: {total_pages} pages needed but MAX_PAGES={MAX_PAGES}.")
        print("Reduce your collection or split into fewer categories.")
        sys.exit(1)
    print(f"  Total pages: {total_pages}", flush=True)

    # -----------------------------------------------------------------------
    # Step 4: Build packer argument list
    # -----------------------------------------------------------------------
    # @NN:name -- NN is 1-based (packer subtracts 1 to get 0-based page index)
    def at(page_no, name):
        return f"@{page_no+1:02d}:{name}"

    args = [str(RUNMENU_BIN)]

    # Page 0: main menu -- one link per category (to its first page)
    for i, (label, pages) in enumerate(cat_pages):
        first = page_assignments[i][0]
        args.append(at(first, label[:14]))

    # Category pages
    for i, (label, pages) in enumerate(cat_pages):
        page_nums = page_assignments[i]
        num_pages = len(pages)
        for j, roms_on_page in enumerate(pages):
            args.append("--page")
            args.append(at(0, page_label(label, j, num_pages)))
            for rom_path in roms_on_page:
                args.append(str(rom_path))
            if j < num_pages - 1:
                args.append(at(page_nums[j + 1], "-- Next -->"))

    # -----------------------------------------------------------------------
    # Step 5: Run packer
    # -----------------------------------------------------------------------
    print("Packing ROM image...", flush=True)
    result = subprocess.run([sys.executable, str(PACKER)] + args, cwd=str(SCRIPT_DIR))
    if result.returncode != 0:
        sys.exit(result.returncode)

    # -----------------------------------------------------------------------
    # Step 6: Build SD card image
    # -----------------------------------------------------------------------
    print("Building sdcard.img...", flush=True)
    subprocess.run(["truncate", "-s", "65M", str(SDCARD_IMG)], check=True)
    subprocess.run(["dd", "if=bootfile.bin", f"of={SDCARD_IMG}", "seek=64",
                    "conv=notrunc", "status=none"], cwd=str(SCRIPT_DIR), check=True)
    subprocess.run(["dd", "if=romimages.bin", f"of={SDCARD_IMG}", f"seek={0x20000}",
                    "conv=notrunc", "status=none"], cwd=str(SCRIPT_DIR), check=True)

    bootfile  = SCRIPT_DIR / "bootfile.bin"
    romimages = SCRIPT_DIR / "romimages.bin"
    print()
    print("Done! sdcard.img ready.")
    print(f"  bootfile.bin:  {bootfile.stat().st_size} bytes")
    print(f"  romimages.bin: {romimages.stat().st_size} bytes")
    print(f"  sdcard.img:    {SDCARD_IMG.stat().st_size} bytes")
    print()
    print("To test in XRoar:  ./xroar-mooh.sh")
    print("To write to SD card:")
    print("  sudo dd if=sdcard.img of=/dev/sdX bs=1M status=progress")


if __name__ == "__main__":
    main()
PYEOF
chmod +x build-sdcard.py
echo "  OK"

# ---------------------------------------------------------------------------
# Write xroar-mooh.sh
# ---------------------------------------------------------------------------
echo "Writing xroar-mooh.sh..."
cat > xroar-mooh.sh << 'XROAREOF'
#!/bin/bash
# Launch XRoar with the MOOH multi-ROM SD card image.
# Run ./build-sdcard.py first to generate sdcard.img.

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SDBOOT_ROM="$HOME/source/sdboot/bootrom/eprom8.rom"
SDCARD_IMG="$SCRIPT_DIR/sdcard.img"

if [ ! -f "$SDBOOT_ROM" ]; then
        echo "ERROR: SDBOOT EPROM not found at $SDBOOT_ROM"
        echo "       See https://gitlab.com/tormod.volden/sdboot"
        exit 1
fi

if [ ! -f "$SDCARD_IMG" ]; then
        echo "ERROR: sdcard.img not found."
        echo "       Run ./build-sdcard.py first."
        exit 1
fi

exec xroar \
        -default-machine coco2bus \
        -cart mooh \
        -cart-rom "$SDBOOT_ROM" \
        -load-sd "$SDCARD_IMG"
XROAREOF
chmod +x xroar-mooh.sh
echo "  OK"

# ---------------------------------------------------------------------------
# Write BUILD-HOWTO.txt
# ---------------------------------------------------------------------------
echo "Writing BUILD-HOWTO.txt..."
cat > BUILD-HOWTO.txt << 'DOCEOF'
MOOH Multi-ROM -- Build How-To
==============================

What this is
------------
A bootable SD card image for the MOOH cartridge (CoCo 1/2).  The menu
runtime assembles to a small kernel that lives on the SD card and presents
a paginated selection screen at boot.  Choose a title and it loads and
runs as a cartridge ROM.

Prerequisites
-------------
  lwasm      6809 assembler from lwtools  https://www.lwtools.ca/
  python3    version 3.6 or later
  SDBOOT EPROM  eprom8.rom from https://gitlab.com/tormod.volden/sdboot
               Expected at: ~/source/sdboot/bootrom/eprom8.rom
  xroar      CoCo emulator (optional, for testing)

ROM files
---------
Supported cartridge sizes: 4K, 8K, 16K, 32K (exact file size required).
Files with any other size are skipped.

Common TOSEC collection files that will NOT be recognized:
  16128 bytes  (e.g. Demon Attack, Dragonfire -- bad dumps, skip these)

CoCo 3-only titles to avoid (will be included if present but will not
run correctly on CoCo 1/2):
  Rad Warrior, Rampage, Super Pitfall, Mind-Roll,
  GFL Championship Football II (all 32K enhanced CoCo 3).
  Robocop (128K) also CoCo 3 only.

Building
--------
  cd ~/source/multi-rom

  ./build-sdcard.py
      Scan DEFAULT_CATEGORIES directories defined at the top of the script.

  ./build-sdcard.py "Games:/path/to/games" "Homebrew:/path/to/carts"
      Scan the given directories.  Each argument is "Label:path".
      Label = category name shown in the main menu (14 chars max).

  build-sdcard.py scans each directory, keeps only recognized sizes,
  strips TOSEC metadata from filenames, sorts alphabetically, and
  paginates automatically with Back / Next navigation links.

  Maximum 16 pages total (hardware limit).
  Up to 25 ROM entries per page.
  Categories with more than 25 ROMs are split across multiple pages.

Testing in XRoar
----------------
  ./xroar-mooh.sh

Menu navigation
---------------
  1-9, 0   Jump to page 1-10 (0 = page 10).  Out-of-range digits ignored.
  A-Z      Launch the corresponding entry on the current page.
  , . / ;  Entries beyond Z (positions 27-30).

Writing to a real SD card
-------------------------
  sudo dd if=sdcard.img of=/dev/sdX bs=1M status=progress

Replace /dev/sdX with your device.  Use  lsblk  to identify it.
WARNING: This overwrites the entire device.

SD card layout (MOOH standard)
-------------------------------
  sector 64        (32KB offset)   Menu kernel   (bootfile.bin)
  sector 0x20000   (64MB offset)   ROM images    (romimages.bin)
DOCEOF
echo "  OK"
echo

# ---------------------------------------------------------------------------
# Run the build
# ---------------------------------------------------------------------------
./build-sdcard.py "$@"

cd ..
echo
echo "Files are in: $HOME/source/multi-rom/"
echo "  sdcard.img     -- write to SD card or use with xroar-mooh.sh"
echo "  BUILD-HOWTO.txt -- usage reference"

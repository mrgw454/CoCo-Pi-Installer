#!/bin/bash

systemtype=$(dpkg --print-architecture)
echo "architecture = $systemtype"

if [[ $systemtype != arm64 ]]; then
    echo "This project is only compatible with arm64. Aborting."
    echo
    exit 1
fi

cd "$HOME/source"

# Archive previous clone if it exists
if [ -d "BASIC-To-6809" ]; then
    foldername=$(date +%Y-%m-%d_%H.%M.%S)
    mv "BASIC-To-6809" "BASIC-To-6809-$foldername"
    echo "Archived existing BASIC-To-6809 folder into backup: BASIC-To-6809-$foldername"
    echo
fi

# Clone fresh copy
git clone https://github.com/nowhereman999/BASIC-To-6809.git
cd BASIC-To-6809
GITREV=$(git rev-parse --short HEAD)

SRC_DIR="$PWD/Source_Code"
BINZIP="$PWD/Binary_Versions/BASIC-To-6809_v5.25_Linux_arm64.zip"

if [ ! -f "$BINZIP" ]; then
    echo "ERROR: Prebuilt binary ZIP not found:"
    echo "  $BINZIP"
    exit 1
fi

echo
echo "Using prebuilt BASIC-To-6809 binaries for arm64..."
echo

# Temporary extraction area
TMPDIR=$(mktemp -d)
unzip -q "$BINZIP" -d "$TMPDIR"

# ------------------------------------------------------------
# INTELLIGENT ZIP ROOT DETECTION
# ------------------------------------------------------------
EXPECTED_FILES=(
    "BasTo6809"
    "BasTo6809.1.Tokenizer"
    "BasTo6809.2.Compile"
    "cc1sl"
    "PNGtoCC3Playfield"
    "PNGtoCCSB"
    "SDECB"
)

ZIP_ROOT=""

while IFS= read -r -d '' candidate; do
    for f in "${EXPECTED_FILES[@]}"; do
        if [ -f "$candidate/$f" ] || [ -f "$candidate/IDE/$f" ]; then
            ZIP_ROOT="$candidate"
            break 2
        fi
    done
done < <(find "$TMPDIR" -type d -print0)

if [ -z "$ZIP_ROOT" ]; then
    echo "ERROR: Could not locate binaries inside ZIP."
    exit 1
fi

echo "Detected ZIP root: $ZIP_ROOT"
echo

# ------------------------------------------------------------
# COPY BINARIES ONLY — NEVER TOUCH INCLUDES
# ------------------------------------------------------------

mkdir -p "$SRC_DIR"
mkdir -p "$SRC_DIR/IDE"

copy_if_exists() {
    local src="$1"
    local dest="$2"
    if [ -f "$src" ]; then
        cp "$src" "$dest"
    fi
}

# Core binaries
copy_if_exists "$ZIP_ROOT/BasTo6809" "$SRC_DIR/"
copy_if_exists "$ZIP_ROOT/BasTo6809.1.Tokenizer" "$SRC_DIR/"
copy_if_exists "$ZIP_ROOT/BasTo6809.2.Compile" "$SRC_DIR/"
copy_if_exists "$ZIP_ROOT/cc1sl" "$SRC_DIR/"
copy_if_exists "$ZIP_ROOT/PNGtoCC3Playfield" "$SRC_DIR/"
copy_if_exists "$ZIP_ROOT/PNGtoCCSB" "$SRC_DIR/"

# IDE binary
copy_if_exists "$ZIP_ROOT/SDECB" "$SRC_DIR/IDE/"
copy_if_exists "$ZIP_ROOT/IDE/SDECB" "$SRC_DIR/IDE/"

# Make everything executable
chmod +x "$SRC_DIR"/* 2>/dev/null || true
chmod +x "$SRC_DIR/IDE/SDECB" 2>/dev/null || true

echo
echo "Downloading manual..."
wget -q -O "$SRC_DIR/basto6809.pdf" https://github.com/pwillard/basto6809Manual/raw/main/basto6809.pdf

cd "$HOME/source"
echo
echo "✅ Done! BASIC-To-6809 prebuilt arm64 installation complete."
echo "   Git revision: $GITREV"


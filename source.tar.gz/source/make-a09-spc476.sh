#!/bin/bash

# install prerequisites
echo NOTE!  You need to make sure the following projects are already built and installed:
echo
echo CGILib
echo mc6809
echo
echo
echo
read -p "Press any key to continue... " -n1 -s
echo

cd $HOME/source

# if a previous a09-spc476 folder exists, move into a date-time named folder

if [ -d "a09-spc476" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "a09-spc476" "a09-spc476-$foldername"

        echo -e Archiving existing a09-spc476 folder ["a09-spc476"] into backup folder ["a09-spc476-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/spc476/a09
git clone https://github.com/spc476/a09.git a09-spc476

cd a09-spc476

GITREV=`git rev-parse --short HEAD`

echo $(nproc) / 2 | bc
cores=$(echo $(nproc) / 2 | bc)
make -j$cores

if [ $? -eq 0 ]
then
        echo "compilation was successful.  Installing."
        echo
else
        echo "compilation was NOT successful.  Aborting."
        echo
        exit 1
fi


sudo ln -s $HOME/source/a09-spc476/a09 /usr/local/bin/a09-spc476

cd ..


echo
echo Done!

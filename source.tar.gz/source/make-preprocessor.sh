#!/bin/bash

cd $HOME/source

# if a previous preprocessor folder exists, move into a date-time named folder

if [ -d "preprocessor" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "preprocessor" "preprocessor-$foldername"

        echo -e Archiving existing preprocessor folder ["preprocessor"] into backup folder ["preprocessor-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/yggdrasilradio/preprocessor
git clone https://github.com/yggdrasilradio/preprocessor.git

cd preprocessor

GITREV=`git rev-parse --short HEAD`

sudo ln -s $HOME/source/preprocessor/decbpp /usr/local/bin/decbpp

if [ ! -d $HOME/.vim ]; then
	mkdir $HOME/.vim
fi

cp basic.vim ~/.vim/basic.vim

makeDSK-pyDW.sh

if [ -f preprocessor.DSK ]; then
	if [ ! -d /media/share1/SDC/ADAMS ]; then
		mkdir /media/share1/SDC/ADAMS
	fi
	echo "cp preprocessor.DSK /media/share1/SDC/ADAMS/PREPROC.DSK"
	echo
	cp preprocessor.DSK /media/share1/SDC/ADAMS/PREPROC.DSK
else
	echo PREPROC.DSK image not found!
	echo
fi


cd ..

echo
echo Done!


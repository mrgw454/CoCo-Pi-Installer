#!/usr/bin/env bash

set -euo pipefail

repository="https://github.com/TomHarte/CLK.git"
branch="master"
source_dir="${HOME}/source/CLK"
install_dir="${HOME}/CLK"
rom_source="/media/share1/roms"
jobs=""
install=yes

usage() {
    cat <<'EOF'
Build the SDL and Qt versions of Clock Signal (CLK) on Debian 13.

Usage: build-clk-debian13.sh [options]

Options:
  --repository URL   Git repository (default: TomHarte/CLK)
  --branch NAME      Branch or tag to build (default: master)
  --source-dir PATH  Checkout destination (default: ~/source/CLK)
  --install-dir PATH User-level installation (default: ~/CLK)
  --rom-source PATH  CoCo ROM source directory (default: /media/share1/roms)
  --jobs N           Positive parallel job count (default: half the CPUs)
  --no-install       Build and verify, but do not install
  -h, --help         Show this help

The script validates the user's Color BASIC 1.1, Extended BASIC 1.1, and Disk
BASIC 1.1 ROMs, copies them into the fresh checkout, installs the SDL frontend
through CMake, installs the Qt frontend alongside it, fills missing/incorrect
ROMs for both frontends, and creates INSTALL_DIR/launch-coco.sh and
INSTALL_DIR/launch-coco-qt.sh. Its tested default-CoCo and Qt-audio patch is
embedded, generated in a temporary file, checked, applied, and removed during
each build. It never downloads ROMs.
EOF
}

die() {
    printf 'Error: %s\n' "$*" >&2
    exit 1
}

write_qt_patch() {
    local destination=$1

    cat >"$destination" <<'CLK_QT_PATCH'
diff --git a/OSBindings/Qt/main.cpp b/OSBindings/Qt/main.cpp
index 3e11f1e70..3bee00029 100644
--- a/OSBindings/Qt/main.cpp
+++ b/OSBindings/Qt/main.cpp
@@ -1,9 +1,12 @@
 #include "mainwindow.h"
+#include "settings.h"
 
 #include <QApplication>
+#include <QTimer>
 
 int main(int argc, char *argv[])
 {
+	const bool startTandyCoCo = argc == 2 && QString(argv[1]) == "--new=TandyCoCo";
 	// "Calling QSurfaceFormat::setDefaultFormat() before constructing the
 	// QApplication instance is mandatory on some platforms ... when an
 	// OpenGL core profile context is requested."
@@ -34,9 +37,20 @@ int main(int argc, char *argv[])
 	QSurfaceFormat::setDefaultFormat(format);
 
 	QApplication a(argc, argv);
-	MainWindow *const w = (argc > 1) ? new MainWindow(argv[1]) : new MainWindow();
+	if(startTandyCoCo) {
+		Settings settings;
+		settings.setValue("machineSelection", 13);
+		settings.setValue("tandy.memorySize", "64 kb");
+		settings.setValue("tandy.hasDiskDrive", true);
+	}
+	MainWindow *const w = (argc > 1 && !startTandyCoCo) ? new MainWindow(argv[1]) : new MainWindow();
 	w->setAttribute(Qt::WA_DeleteOnClose);
 	w->show();
+	if(startTandyCoCo) {
+		QTimer::singleShot(0, w, [w] {
+			QMetaObject::invokeMethod(w, "start_tandyCoCo");
+		});
+	}
 
 	return a.exec();
 }
diff --git a/OSBindings/Qt/mainwindow.cpp b/OSBindings/Qt/mainwindow.cpp
index 35e78382d..0a6e7bde4 100644
--- a/OSBindings/Qt/mainwindow.cpp
+++ b/OSBindings/Qt/mainwindow.cpp
@@ -70,6 +70,7 @@ void MainWindow::deleteMachine() {
 	if(audioOutput) {
 		audioThread.performAsync([this] {
 			audioOutput->stop();
+			audioOutputDevice = nullptr;
 			audioOutput.reset();
 		});
 		audioThread.stop();
@@ -343,15 +344,14 @@ void MainWindow::launchMachine() {
 				speaker->set_delegate(this);
 
 				audioThread.start();
-				audioThread.performAsync([&] {
+				audioThread.performAsync([this, device, idealFormat, channelCount] {
 					// Create an audio output.
 					audioOutput = std::make_unique<QAudioSink>(device, idealFormat);
 
-					// Start the output. The additional `audioBuffer` is meant to minimise latency,
-					// believe it or not, given Qt's semantics.
-					audioOutput->setBufferSize(samplesPerBuffer * sizeof(int16_t) * channelCount);
-					audioOutput->start(&audioBuffer);
-					audioBuffer.setDepth(audioOutput->bufferSize());
+					// Use QAudioSink's push mode. Completed CLK sample buffers are posted
+					// to this audio thread by speaker_did_complete_samples().
+					audioOutput->setBufferSize(4 * samplesPerBuffer * sizeof(int16_t) * channelCount);
+					audioOutputDevice = audioOutput->start();
 				});
 			}
 		}
@@ -797,7 +797,14 @@ void MainWindow::setAppleIISquarePixels(const bool squarePixels) {
 }
 
 void MainWindow::speaker_did_complete_samples(Outputs::Speaker::Speaker &, const std::vector<int16_t> &buffer) {
-	audioBuffer.write(buffer);
+	audioThread.performAsync([this, buffer] {
+		if(!audioOutput || !audioOutputDevice) return;
+		const auto byteCount = qint64(buffer.size() * sizeof(int16_t));
+		if(audioOutput->bytesFree() < byteCount) return;
+		audioOutputDevice->write(
+			reinterpret_cast<const char *>(buffer.data()), byteCount
+		);
+	});
 }
 
 void MainWindow::dragEnterEvent(QDragEnterEvent *const event) {
diff --git a/OSBindings/Qt/mainwindow.h b/OSBindings/Qt/mainwindow.h
index 523522e9c..51c1a8161 100644
--- a/OSBindings/Qt/mainwindow.h
+++ b/OSBindings/Qt/mainwindow.h
@@ -7,7 +7,6 @@
 #include <memory>
 #include <mutex>
 
-#include "audiobuffer.h"
 #include "timer.h"
 #include "ui_mainwindow.h"
 #include "functionthread.h"
@@ -71,9 +70,9 @@ class MainWindow : public QMainWindow, public Outputs::Speaker::Speaker::Delegat
 		std::mutex machineMutex;
 
 		std::unique_ptr<QAudioSink> audioOutput;
+		QIODevice *audioOutputDevice = nullptr;
 		bool audioIs8bit = false, audioIsStereo = false;
 		void speaker_did_complete_samples(Outputs::Speaker::Speaker &, const std::vector<int16_t> &) override;
-		AudioBuffer audioBuffer;
 		FunctionThread audioThread;
 
 		bool processEvent(QKeyEvent *);
CLK_QT_PATCH
}

while (($#)); do
    case "$1" in
        --repository)
            (($# >= 2)) || die "--repository requires a value"
            repository=$2
            shift 2
            ;;
        --branch)
            (($# >= 2)) || die "--branch requires a value"
            branch=$2
            shift 2
            ;;
        --source-dir)
            (($# >= 2)) || die "--source-dir requires a value"
            source_dir=$2
            shift 2
            ;;
        --install-dir)
            (($# >= 2)) || die "--install-dir requires a value"
            install_dir=$2
            shift 2
            ;;
        --rom-source)
            (($# >= 2)) || die "--rom-source requires a value"
            rom_source=$2
            shift 2
            ;;
        --jobs)
            (($# >= 2)) || die "--jobs requires a value"
            jobs=$2
            shift 2
            ;;
        --no-install)
            install=no
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "unknown option: $1"
            ;;
    esac
done

for command in git cmake crc32; do
    command -v "$command" >/dev/null 2>&1 || die "required command not found: $command"
done
if [[ -z $jobs ]]; then
    cpu_count=$(getconf _NPROCESSORS_ONLN 2>/dev/null || printf '1')
    [[ $cpu_count =~ ^[1-9][0-9]*$ ]] || cpu_count=1
    jobs=$((cpu_count / 2))
    ((jobs >= 1)) || jobs=1
fi
[[ $jobs =~ ^[1-9][0-9]*$ ]] || die "--jobs must be a positive integer"

rom_bas="${rom_source}/bas11.rom"
rom_extbas="${rom_source}/extbas11.rom"
rom_disk="${rom_source}/disk11.rom"

verify_rom() {
    local path=$1
    local expected_crc=$2
    local actual_crc

    [[ -f $path ]] || die "required CoCo ROM not found: $path"
    actual_crc=$(crc32 "$path")
    [[ $actual_crc == "$expected_crc" ]] || \
        die "unexpected CRC32 for $path: got $actual_crc, expected $expected_crc"
}

# Validate before preserving the old checkout, so a missing ROM cannot leave a
# new build half-started after the previous source tree has been archived.
verify_rom "$rom_bas" "6270955a"
verify_rom "$rom_extbas" "a82a6254"
verify_rom "$rom_disk" "0b9c5415"

source_parent=$(dirname "$source_dir")
source_name=$(basename "$source_dir")
mkdir -p "$source_parent"

if [[ -e $source_dir ]]; then
    timestamp=$(date +%Y%m%d-%H%M%S)
    archive_path="${source_parent}/${source_name}-${timestamp}"
    [[ ! -e $archive_path ]] || die "archive destination already exists: $archive_path"
    printf 'Preserving existing checkout as %s\n' "$archive_path"
    mv -- "$source_dir" "$archive_path"
fi

printf 'Cloning %s (%s) into %s\n' "$repository" "$branch" "$source_dir"
git clone --branch "$branch" --single-branch "$repository" "$source_dir"

qt_patch=$(mktemp "${TMPDIR:-/tmp}/clk-qt-integration.XXXXXX.patch")
trap 'rm -f -- "$qt_patch"' EXIT
write_qt_patch "$qt_patch"
printf 'Applying embedded Qt default-CoCo/audio integration patch\n'
git -C "$source_dir" apply --check "$qt_patch"
git -C "$source_dir" apply "$qt_patch"
grep -q -- '--new=TandyCoCo' "${source_dir}/OSBindings/Qt/main.cpp" || \
    die "Qt default-CoCo integration patch verification failed"
grep -q 'audioOutputDevice = audioOutput->start();' \
    "${source_dir}/OSBindings/Qt/mainwindow.cpp" || \
    die "Qt push-audio integration patch verification failed"

checkout_rom_dir="${source_dir}/ROMImages/TandyCoCo"
mkdir -p "$checkout_rom_dir"
install -m 0644 "$rom_bas" \
    "${checkout_rom_dir}/Color Basic v1.1 (1980) (Tandy).rom"
install -m 0644 "$rom_extbas" "${checkout_rom_dir}/extbas11.rom"
install -m 0644 "$rom_disk" "${checkout_rom_dir}/disk11.rom"

revision=$(git -C "$source_dir" rev-parse HEAD)
short_revision=$(git -C "$source_dir" rev-parse --short=12 HEAD)
build_dir="${source_dir}/build-sdl"
qt_build_dir="${source_dir}/build-qt"

cmake -S "$source_dir" -B "$build_dir" \
    -DCLK_UI=SDL \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX="$install_dir"
cmake --build "$build_dir" --parallel "$jobs"

cmake -S "$source_dir" -B "$qt_build_dir" \
    -DCLK_UI=Qt \
    -DCMAKE_BUILD_TYPE=Release
cmake --build "$qt_build_dir" --parallel "$jobs"

binary="${build_dir}/clksignal"
[[ -x $binary ]] || die "expected executable was not produced: $binary"
qt_binary="${qt_build_dir}/clksignal"
[[ -x $qt_binary ]] || die "expected Qt executable was not produced: $qt_binary"
help_output=$($binary --help)
grep -q -- '--new=.*TandyCoCo' <<<"$help_output" || \
    die "built executable does not advertise the TandyCoCo target"

printf 'Verified CLK revision %s with SDL Tandy CoCo CLI and Qt frontends.\n' "$revision"

if [[ $install == no ]]; then
    printf 'SDL build retained at %s (--no-install).\n' "$binary"
    printf 'Qt build retained at %s (--no-install).\n' "$qt_binary"
    exit 0
fi

cmake --install "$build_dir"
installed_binary="${install_dir}/bin/clksignal"
[[ -x $installed_binary ]] || \
    die "CMake install did not produce the expected executable: $installed_binary"
installed_qt_binary="${install_dir}/bin/clksignal-qt"
install -m 0755 "$qt_binary" "$installed_qt_binary"

installed_rom_dir="${install_dir}/share/CLK/TandyCoCo"
mkdir -p "$installed_rom_dir"

install_rom_if_needed() {
    local source_path=$1
    local destination_path=$2
    local expected_crc=$3

    if [[ -f $destination_path ]] && \
       [[ $(crc32 "$destination_path") == "$expected_crc" ]]; then
        printf 'Keeping verified ROM %s\n' "$destination_path"
        return
    fi

    install -m 0644 "$source_path" "$destination_path"
    printf 'Installed verified ROM %s\n' "$destination_path"
}

install_rom_if_needed "$rom_bas" \
    "${installed_rom_dir}/Color Basic v1.1 (1980) (Tandy).rom" "6270955a"
install_rom_if_needed "$rom_extbas" \
    "${installed_rom_dir}/extbas11.rom" "a82a6254"
install_rom_if_needed "$rom_disk" \
    "${installed_rom_dir}/disk11.rom" "0b9c5415"
install -m 0644 "${source_dir}/ROMImages/TandyCoCo/readme.txt" \
    "${installed_rom_dir}/readme-upstream.txt"

# The Qt frontend uses QStandardPaths::AppDataLocation rather than --rompath.
# launch-coco-qt.sh fixes XDG_DATA_HOME inside the self-contained installation;
# because the installed executable is named clksignal-qt, Qt appends that name.
qt_rom_dir="${install_dir}/share/CLK/qt-data/clksignal-qt/ROMImages/TandyCoCo"
mkdir -p "$qt_rom_dir"
install_rom_if_needed "$rom_bas" \
    "${qt_rom_dir}/Color Basic v1.1 (1980) (Tandy).rom" "6270955a"
install_rom_if_needed "$rom_extbas" \
    "${qt_rom_dir}/extbas11.rom" "a82a6254"
install_rom_if_needed "$rom_disk" \
    "${qt_rom_dir}/disk11.rom" "0b9c5415"

launcher="${install_dir}/launch-coco.sh"
cat >"$launcher" <<'EOF'
#!/usr/bin/env bash

set -euo pipefail

clk_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
exec "${clk_dir}/bin/clksignal" \
    --new=TandyCoCo \
    --model=TandyCoCo \
    --memory-size=SixtyFourKB \
    --rom-version=V11 \
    --has-disk-drive \
    --accelerate-media-loading \
    --rompath="${clk_dir}/share/CLK" \
    "$@"
EOF
chmod 0755 "$launcher"

qt_launcher="${install_dir}/launch-coco-qt.sh"
cat >"$qt_launcher" <<'EOF'
#!/usr/bin/env bash

set -euo pipefail

clk_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
export XDG_DATA_HOME="${clk_dir}/share/CLK/qt-data"
if (($# == 0)); then
    exec "${clk_dir}/bin/clksignal-qt" --new=TandyCoCo
fi
exec "${clk_dir}/bin/clksignal-qt" "$@"
EOF
chmod 0755 "$qt_launcher"

provenance="${install_dir}/share/CLK/clksignal-${short_revision}.build-info.txt"
cat >"$provenance" <<EOF
project=Clock Signal (CLK)
repository=${repository}
selection=${branch}
revision=${revision}
build_ui=SDL
additional_ui=Qt
build_type=Release
jobs=${jobs}
source=${source_dir}
artifact=${installed_binary}
qt_artifact=${installed_qt_binary}
rom_source=${rom_source}
rom_profile=CoCo BASIC 1.1 / Extended BASIC 1.1 / Disk BASIC 1.1
launcher=${launcher}
qt_launcher=${qt_launcher}
built_at=$(date --iso-8601=seconds)
EOF

printf 'Installed %s\n' "$installed_binary"
printf 'Installed %s\n' "$installed_qt_binary"
printf 'Installed ROM directory: %s\n' "$installed_rom_dir"
printf 'Installed Qt ROM directory: %s\n' "$qt_rom_dir"
printf 'Provenance: %s\n' "$provenance"
printf 'CoCo launcher: %s [optional media file]\n' "$launcher"
printf 'CoCo Qt launcher: %s [optional media file]\n' "$qt_launcher"

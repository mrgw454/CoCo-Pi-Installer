#!/bin/bash

cd $HOME/source

# if a previous msnyder folder exists, move into a date-time named folder

if [ -d "msnyder" ]; then

       	foldername=$(date +%Y-%m-%d_%H.%M.%S)

       	mv "msnyder" "msnyder-$foldername"

       	echo -e Archiving existing msnyder folder ["msnyder"] into backup folder ["msnyder-$foldername"]
       	echo -e
       	echo -e
fi

# https://www.cocoquest.com/#DOWNLOAD

cd msnyder

wget https://www.cocoquest.com/msnyder1.dsk
wget https://www.cocoquest.com/msnyder2.dsk
wget https://www.cocoquest.com/msnyder3.dsk
wget https://www.cocoquest.com/msnyder4.dsk
wget https://www.cocoquest.com/msnyder5.dsk
wget https://www.cocoquest.com/msnyder6.dsk
wget https://www.cocoquest.com/msnyder7.dsk
wget https://www.cocoquest.com/msnyder8.dsk
wget https://www.cocoquest.com/msnyder9.dsk
wget https://www.cocoquest.com/msnyder0.dsk
wget https://www.cocoquest.com/msnyder.zip

if [ -f msnyder.zip ]; then

	if [ ! -d /media/share1/SDC/MSNYDER ]; then
		mkdir -f /media/share1/SDC/MSNYDER
	fi

	unzip msnyder.zip -d /media/share1/SDC/MSNYDER
else

	echo
	echo msnyder.zip archive not found.  Aborting.
	echo
fi


echo
echo Done!

#!/bin/bash

cd $HOME/source

# if a previous CGILib-git folder exists, move into a date-time named folder

if [ -d "CGILib-git" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "CGILib-git" "CGILib-git-$foldername"

        echo -e Archiving existing CGILib-git folder ["CGILib-git"] into backup folder ["CGILib-git-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/spc476/CGILib.git
git clone https://github.com/spc476/CGILib.git

cd CGILib

GITREV=`git rev-parse --short HEAD`

echo $(nproc) / 2 | bc
cores=$(echo $(nproc) / 2 | bc)
make -j$cores

if [ $? -eq 0 ]
then
        echo "compilation was successful.  Installing."
        echo
else
        echo "compilation was NOT successful.  Aborting."
        echo
	exit 1
fi

sudo make install

cd ..


echo
echo Done!

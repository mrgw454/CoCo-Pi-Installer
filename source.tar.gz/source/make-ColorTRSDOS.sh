#!/usr/bin/env bash

set -euo pipefail

usage() {
    cat <<'EOF'
Usage:
  make-ColorTRSDOS.sh [options]

Clone ColorTRSDOS from scratch, archive any previous clone, build it, and
create a CoCo disk image.

Options:
  --repo-url URL      Git repository URL
  --ref REF           Branch, tag, or commit to check out after clone
  --base-dir DIR      Parent directory that will contain the ColorTRSDOS clone
  --clone-name NAME   Directory name to use for the clone
  --out-dir DIR       Output directory for the built disk image
  --disk-name NAME    Base name for the generated .dsk image
  --keep-existing     Reuse an existing clone directory instead of archiving it
  --help              Show this help text
EOF
}

require_tool() {
    if ! command -v "$1" >/dev/null 2>&1; then
        echo "Missing required tool: $1" >&2
        exit 1
    fi
}

normalize_sources_for_lwasm() {
    local project_dir="$1"

    sed -i 's#\.\.\\OriginalDOSBIN\\ColorTRSDOS\.asm#../OriginalDOSBIN/ColorTRSDOS.asm#' \
        "$project_dir/ColorTRSDOS/BootableDOSCore/DOSCore.asm"

    sed -i 's#bin\\DOSCore\.RAW#bin/DOSCore.raw#g' \
        "$project_dir/ColorTRSDOS/BootableDOSCore/DOSCoreWrapper.asm"

    sed -i 's#bin\\DOSCore\.raw#bin/DOSCore.raw#g' \
        "$project_dir/ColorTRSDOS/BootableDOSCore/BootWrapper.asm"

    sed -i 's#bin\\ColorTRSDOS\.RAW#bin/ColorTRSDOS.raw#g' \
        "$project_dir/ColorTRSDOS/OriginalDOSBIN/DOSWrapper.asm"
}

REPO_URL="https://github.com/DarkChocoholicDev/ColorTRSDOS.git"
BASE_DIR="$(pwd)"
CLONE_NAME="ColorTRSDOS"
REF=""
OUT_DIR=""
DISK_NAME="ColorTRSDOS"
KEEP_EXISTING=0

while (($#)); do
    case "$1" in
        --repo-url)
            REPO_URL="$2"
            shift 2
            ;;
        --ref)
            REF="$2"
            shift 2
            ;;
        --base-dir)
            BASE_DIR="$2"
            shift 2
            ;;
        --clone-name)
            CLONE_NAME="$2"
            shift 2
            ;;
        --out-dir)
            OUT_DIR="$2"
            shift 2
            ;;
        --disk-name)
            DISK_NAME="$2"
            shift 2
            ;;
        --keep-existing)
            KEEP_EXISTING=1
            shift
            ;;
        --help|-h)
            usage
            exit 0
            ;;
        *)
            echo "Unknown argument: $1" >&2
            usage >&2
            exit 1
            ;;
    esac
done

require_tool git
require_tool lwasm
require_tool decb
require_tool dd
require_tool truncate

mkdir -p "$BASE_DIR"
cd "$BASE_DIR"

CLONE_DIR="$BASE_DIR/$CLONE_NAME"

if [[ -d "$CLONE_DIR" && "$KEEP_EXISTING" -eq 0 ]]; then
    foldername="$(date +%Y-%m-%d_%H.%M.%S)"
    backup_dir="$BASE_DIR/${CLONE_NAME}-$foldername"
    mv "$CLONE_DIR" "$backup_dir"
    echo "Archiving existing ColorTRSDOS folder [$CLONE_DIR] into backup folder [$backup_dir]"
    echo
fi

if [[ -d "$CLONE_DIR/.git" && "$KEEP_EXISTING" -eq 1 ]]; then
    echo "Reusing existing clone at $CLONE_DIR"
else
    if [[ -e "$CLONE_DIR" ]]; then
        echo "Clone target already exists and cannot be reused: $CLONE_DIR" >&2
        exit 1
    fi

    git clone "$REPO_URL" "$CLONE_DIR"
fi

cd "$CLONE_DIR"

if [[ -n "$REF" ]]; then
    git checkout "$REF"
fi

PROJECT_DIR="$CLONE_DIR/ColorTRSDOS"
ORIGINAL_DIR="$PROJECT_DIR/OriginalDOSBIN"
BOOTABLE_DIR="$PROJECT_DIR/BootableDOSCore"
ORIGINAL_OUT="$ORIGINAL_DIR/bin"
BOOTABLE_OUT="$BOOTABLE_DIR/bin"

if [[ -z "$OUT_DIR" ]]; then
    OUT_DIR="$CLONE_DIR"
fi

DISK_IMAGE="$OUT_DIR/${DISK_NAME}.dsk"

normalize_sources_for_lwasm "$CLONE_DIR"

mkdir -p "$OUT_DIR" "$ORIGINAL_OUT" "$BOOTABLE_OUT"

echo "Assembling original DOS.BIN..."
lwasm --raw -o "$ORIGINAL_OUT/ColorTRSDOS.raw" "$ORIGINAL_DIR/ColorTRSDOS.asm"
lwasm --decb -o "$ORIGINAL_OUT/DOS.BIN" "$ORIGINAL_DIR/DOSWrapper.asm"

echo "Assembling bootable DOS core..."
lwasm --raw -o "$BOOTABLE_OUT/DOSCore.raw" "$BOOTABLE_DIR/DOSCore.asm"
lwasm --decb -o "$BOOTABLE_OUT/DOS.BIN" "$BOOTABLE_DIR/DOSCoreWrapper.asm"
lwasm --raw -o "$BOOTABLE_OUT/DOSBOOT.raw" "$BOOTABLE_DIR/BootWrapper.asm"

echo "Creating disk image $DISK_IMAGE..."
rm -f "$DISK_IMAGE"
decb dskini "$DISK_IMAGE"
decb copy -2 -b "$BOOTABLE_OUT/DOS.BIN" "$DISK_IMAGE,DOS.BIN"
truncate -s 161280 "$DISK_IMAGE"
dd if="$BOOTABLE_OUT/DOSBOOT.raw" of="$DISK_IMAGE" bs=4608 seek=34 conv=notrunc status=none

echo
echo "Build complete."
echo "Repository:           $CLONE_DIR"
echo "Original DOS binary:  $ORIGINAL_OUT/DOS.BIN"
echo "Bootable DOS binary:  $BOOTABLE_OUT/DOS.BIN"
echo "Boot image:           $BOOTABLE_OUT/DOSBOOT.raw"
echo "Disk image:           $DISK_IMAGE"

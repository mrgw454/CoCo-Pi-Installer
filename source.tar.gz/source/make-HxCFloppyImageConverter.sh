#!/bin/bash

cd $HOME/source

# if a previous HxCFloppyImageConverter folder exists, move into a date-time named folder

if [ -d "HxCFloppyImageConverter" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "HxCFloppyImageConverter" "HxCFloppyImageConverter-$foldername"

        echo -e Archiving existing HxCFloppyImageConverter folder ["HxCFloppyImageConverter"] into backup folder ["HxCFloppyImageConverter-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/latchdevel/HxCFloppyImageConverter
git clone https://github.com/latchdevel/HxCFloppyImageConverter.git

cd HxCFloppyImageConverter/build

GITREV=`git rev-parse --short HEAD`

echo $(nproc) / 2 | bc
cores=$(echo $(nproc) / 2 | bc)
make -j$cores

if [ -f hxcfe ]; then
	echo HxCFloppyImageConverter binary found
	echo
	sudo cp $HOME/source/HxCFloppyImageConverter/build/hxcfe /usr/local/bin
else
	echo HxCFloppyImageConverter binary NOT found!  Aborting.
	echo
	exit 1
fi

echo
echo Done!

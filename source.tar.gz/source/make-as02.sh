#!/bin/bash

systemtype=$(dpkg --print-architecture)
echo architecture = $systemtype

if [[ $systemtype =~ arm64 ]];then
        echo This project is not compatible with your device platform.  Aborting.
        echo
        echo
        exit 1
fi

cd $HOME/source

# if a previous as02 folder exists, move into a date-time named folder

if [ -d "as02" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "as02" "as02-$foldername"

        echo -e Archiving existing as02 folder ["as02"] into backup folder ["as02-$foldername"]
        echo -e
        echo -e
fi

if [ ! -f as02_142.zip ]; then
	# https://www.kingswood-consulting.co.uk/assemblers/index.html
	wget --no-check-certificate https://www.kingswood-consulting.co.uk/assemblers/as02_142.zip
fi

if [ ! -d as02 ]; then
	mkdir as02
fi

unzip -j as02_142.zip -d $HOME/source/as02

cd as02

if [ -f as02 ]; then
	sudo ln -s $HOME/source/as02/as02 /usr/local/bin/as02
fi

cd ..


echo
echo Done!

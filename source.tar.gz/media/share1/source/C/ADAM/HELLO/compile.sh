#zcc +coleco -subtype=adam -create-app -pragma-need=ansiterminal -pragma-define:ansicolumns=64 -pragma-redirect:CRT_FONT=_font_8x8_msx_system -lndos hello.c -o hello
zcc +coleco -subtype=adam -create-app -pragma-need=ansiterminal -pragma-define:ansicolumns=80 -pragma-redirect:CRT_FONT=_font_8x8_msx_system -lndos hello.c -o hello


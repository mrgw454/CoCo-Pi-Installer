#!/bin/bash

echo "Stopping DriveWire 4 daemon..."
echo ""

# Define a unique pattern to match the process
PATTERN="com.groupunix.drivewireui.MainWin"

# Find the PID(s) of matching processes
PIDS=$(pgrep -f "$PATTERN")

# If any PIDs are found, kill them
if [[ -n "$PIDS" ]]; then
  echo "Killing process(es): $PIDS"
  kill $PIDS
else
  echo "No matching process found for DriveWire: $PATTERN"
fi


#!/bin/sh

cd /home/pi/DriveWire4

# with UI
#./drivewire4_linux_arm_64 --liteui > /dev/null 2>&1 &

# without UI (default)
./drivewire4_linux_arm_64 --noui > /dev/null 2>&1 &

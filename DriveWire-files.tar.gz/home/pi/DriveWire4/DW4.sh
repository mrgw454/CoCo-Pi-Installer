#!/bin/bash

cd $HOME/DriveWire4

systemtype=$(dpkg --print-architecture)
echo architecture = $systemtype

if [[ $systemtype =~ arm64 ]];then
	# with UI
	#./drivewire4_linux_arm_64 --liteui > /dev/null 2>&1 &

	# without UI (default)
	./drivewire4_linux_arm_64 --noui > /dev/null 2>&1 &
fi


if [[ $systemtype =~ amd64 ]];then
	# with full UI
	./drivewire4_linux_x86_64 > /dev/null 2>&1 &

	# with lite UI
	#./drivewire4_linux_x86_64 --liteui > /dev/null 2>&1 &

	# without UI
	#./drivewire4_linux_x86_64 --noui > /dev/null 2>&1 &
fi


#!/bin/bash

echo "<!DOCTYPE html>" > bookmarks.html
echo "<html>" >> bookmarks.html
echo "  <head>" >> bookmarks.html
echo "    <meta charset="UTF-8">" >> bookmarks.html
echo "    <title>Retro Comptuter Forums & News</title>" >> bookmarks.html
echo "  </head>" >> bookmarks.html
echo "  <body>" >> bookmarks.html

grep -h -E URL *.desktop | sed 's/URL=//' >> bookmarks.temp
# <a href="http://sample.com">http://sample.com</a>

unix2dos bookmarks.temp
cat bookmarks.temp >> bookmarks.html
rm bookmarks.temp

echo "  </body>" >> bookmarks.html
echo "</html>" >> bookmarks.html

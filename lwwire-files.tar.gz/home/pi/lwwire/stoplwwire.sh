cd $HOME/lwwire
sudo ./tap-disable.sh

cd $HOME/.mame



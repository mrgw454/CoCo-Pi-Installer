nano $HOME/lwwire/tcpserv

cd $HOME/.mame


#!/bin/bash

attract-mode-random-atari800.sh /media/share1/atari/games &
sleep 6

attract-mode-coleco.sh /media/share1/coleco/Roms/ &
sleep 6

attract-mode-random-coco2-xroar.sh /media/share1/carts &
sleep 6

attract-mode-random-mc-10-128k.sh /media/share1/JIMG &
sleep 6

attract-mode-random-coco2.sh /media/share1/carts &
sleep 6

attract-mode-random-ti99.sh && TI99Pi-menu-Attract.sh &
sleep 6

attract-mode-random-c64.sh /media/share1/C64/top50 &
sleep 6

attract-mode-random-c128.sh /media/share1/C128 &
sleep 6

attract-mode-dragon64h-ssfm.sh &
sleep 6

trs80-model4-DOS.sh &
sleep 6

$HOME/virtualt-linux64-v1.7/virtualt &
sleep 6

/opt/openMSX/bin/openmsx &
sleep 6

$HOME/.ovcc/coco3-hdbdos-6309-nitros9-OVCC.sh &
sleep 6

$HOME/.xtrs/xtrs-m4.sh &
sleep 6

#!/bin/bash

SAVEIFS=$IFS
IFS=$(echo -en "\n\b")

# select random Commodore 128 computer programs and run them for 120 seconds each

VICEPARMSFILE=`cat $HOME/.vice/.optional_vice_parameters.txt`
export VICEPARMS=$VICEPARMSFILE

# ignore file extension case
shopt -s nocasematch

shopt -s extglob

for run in {1..200}
do

file=$(shuf -ezn 1 $1/*.* | xargs -0 -n1 echo)

     clear

     echo "Random program $run"
     echo "file = $file"
     echo

     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     echo
     sleep 2

     if [[ $file == *.d64 ]]; then

                echo D64
		$HOME/.vice/bin/x128 -silent -limitcycles 99999999 "$file"

     fi


     if [[ $file == *.d71 ]]; then

                echo D71
		$HOME/.vice/bin/x128 -silent -limitcycles 99999999 "$file"

     fi


     if [[ $file == *.d81 ]]; then

                echo D81
		$HOME/.vice/bin/x128 -silent -limitcycles 99999999 "$file"

     fi


     if [[ $file == *.g64 ]]; then

                echo G64
		$HOME/.vice/bin/x128 -silent -limitcycles 99999999 "$file"

     fi


     if [[ $file == *.prg ]]; then

                echo PRG
		$HOME/.vice/bin/x128 -silent -limitcycles 99999999 "$file"

     fi


done

sleep 2

# restore $IFS
IFS=$SAVEIFS

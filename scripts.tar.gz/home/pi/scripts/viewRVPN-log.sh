#!/bin/bash

clear

if [ -f $HOME/rvpn/rvpn.log ]; then
	less $HOME/rvpn/rvpn.log
	exit 0
fi

read -p "Press any key to continue... " -n1 -s


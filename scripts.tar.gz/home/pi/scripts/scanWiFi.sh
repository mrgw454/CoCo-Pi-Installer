sudo iwlist wlan0 scan | grep ESSID


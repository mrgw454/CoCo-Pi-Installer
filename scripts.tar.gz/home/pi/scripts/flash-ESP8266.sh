esptool.py -p /dev/ttyUSB1 --baud 460800 write_flash --flash_size=detect 0 Downloads/zimodem.ino.nodemcu-3.4.bin


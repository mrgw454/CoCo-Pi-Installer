#!/usr/bin/python
from playsound import playsound
playsound('/usr/share/sounds/alsa/Front_Center.wav')


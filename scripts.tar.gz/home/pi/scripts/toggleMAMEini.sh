clear

echo -e "This setting will toggle (enable/disable) the use of user defined MAME ini files" > msg.txt
echo -e "vs CoCo-Pi supplied ini files." >> msg.txt
echo -e >> msg.txt
echo -e "If enabled, user defined MAME ini files will be used.  If disabled, CoCo-Pi MAME" >> msg.txt
echo -e "ini files will be used." >> msg.txt
echo -e >> msg.txt
echo -e >> msg.txt

whiptail --title "Toggle MAME ini file usage" --textbox msg.txt 0 0
rm msg.txt

if [ -e $HOME/.mame/.override_ini_files ]
then

    echo Use user defined MAME ini setting found.  Disabling...
    echo
    rm $HOME/.mame/.override_ini_files

else

    echo Use user defined MAME ini setting not found.  Enabling...
    echo
    touch $HOME/.mame/.override_ini_files

fi

echo
read -p "Press any key to continue." -n1 -s

cd $HOME/.mame

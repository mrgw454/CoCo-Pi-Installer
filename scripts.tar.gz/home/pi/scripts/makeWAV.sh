cecb bulkerase kns.wav
cecb copy -2 -b -g kns.bin kns.wav,KNS


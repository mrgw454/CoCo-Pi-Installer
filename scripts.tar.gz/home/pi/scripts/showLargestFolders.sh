sudo du -hs * | sort -rh | head -5


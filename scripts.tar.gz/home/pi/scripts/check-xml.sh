cd $HOME/.mame/hash
xmllint --noout -valid *.xml


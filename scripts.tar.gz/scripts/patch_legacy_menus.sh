#!/bin/bash
# patch_legacy_menus.sh

PATCH_SCRIPT="$HOME/scripts/patch_legacy_menus.py"
PYTHON_VERSION="3.11.2"

if command -v pyenv >/dev/null 2>&1; then
  eval "$(pyenv init -)"
  pyenv shell "$PYTHON_VERSION"
else
  echo "❌ pyenv is not installed or not in PATH."
  exit 1
fi

if [[ ! -f "$PATCH_SCRIPT" ]]; then
  echo "❌ Patch script not found at $PATCH_SCRIPT"
  exit 1
fi

function show_help() {
  echo "Usage: $0 [--dry-run | --patch | --help]"
  echo ""
  echo "Options:"
  echo "  --dry-run   Show legacy menu scripts missing COCOPI_MENU_CALLER (default)"
  echo "  --patch     Inject export line and create .bak backups"
  echo "  --help      Show this help message"
}

case "$1" in
  --dry-run|"")
    echo "🔍 Running dry-run legacy menu audit using Python $PYTHON_VERSION..."
    pyenv exec python "$PATCH_SCRIPT"
    ;;
  --patch)
    echo "🛠️  Patching legacy menu scripts using Python $PYTHON_VERSION..."
    pyenv exec python "$PATCH_SCRIPT" --patch
    ;;
  --help|-h)
    show_help
    ;;
  *)
    echo "❌ Unknown option: $1"
    show_help
    exit 1
    ;;
esac

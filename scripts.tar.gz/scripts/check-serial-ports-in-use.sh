#!/bin/bash


echo
for port in /dev/ttyUSB*; do
  if [ -e "$port" ]; then  # Check if the port exists
    echo "Found port: $port"

    PID=$(lsof -t -S 2 -O "$port")

    if [ -z "${PID}" ]; then
       echo No process found for "$port"
	echo
    else
       #echo $PID
       ps -p $PID -o pid,vsz=MEMORY -o user,group=GROUP -o comm,args=ARGS
       echo
    fi

  fi
done

echo

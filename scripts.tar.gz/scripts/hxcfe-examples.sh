!#/bin/bash

# https://github.com/latchdevel/HxCFloppyImageConverter/blob/master/README.md

# convert dmk to hfe
./hxcfe -finput:$HOME/Downloads/SD/m3-4p-frehd-boot.dmk  -conv:HXC_HFE         -foutput:$HOME/Downloads/SD/m3-4p-frehd-boot.hfe

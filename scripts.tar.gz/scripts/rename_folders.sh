find . -type d -exec rename 's/0.219/0.220/g' {} \;

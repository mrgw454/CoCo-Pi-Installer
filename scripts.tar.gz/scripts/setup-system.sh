#!/usr/bin/env bash
# setup-system.sh
# One-time system configuration for CoCo-Pi Launcher on a fresh Debian/Pi OS install.
#
# Performs:
#   - Enable and start SSH server
#   - Add current user to dialout and plugdev groups (serial port access)
#   - Optionally disable system suspend (useful for dedicated/kiosk machines)
#
# Run this once after setup-apt-packages.sh, before cloning the launcher repo.
# Re-running is safe.
#
# Usage:
#   bash setup-system.sh
#
# Optional flag:
#   DISABLE_SUSPEND=1   — write /etc/systemd/sleep.conf.d/nosuspend.conf

set -euo pipefail

DISABLE_SUSPEND="${DISABLE_SUSPEND:-0}"

userid=$(whoami)

echo "=============================================================="
echo " CoCo-Pi Launcher — system configuration"
echo "=============================================================="
echo
echo "User: $userid"
echo

# -------------------------------------------------------
# SSH — enable and start
# Required for remote access and for some DriveWire workflows
# -------------------------------------------------------
echo "--- Enabling SSH ---"
sudo systemctl enable ssh
sudo systemctl start ssh

# Silence the SSH password change warning that appears on first login
if [ -f /etc/profile.d/sshpwd.sh ]; then
    sudo rm /etc/profile.d/sshpwd.sh
    sudo touch /etc/profile.d/sshpwd.sh
    sudo chattr +i /etc/profile.d/sshpwd.sh
    echo "SSH login warning suppressed."
fi

echo "SSH enabled and running."
echo

# -------------------------------------------------------
# User groups — dialout and plugdev
# Required for serial port access (real CoCo hardware, DriveWire, Greaseweazle)
# Changes take effect on next login / reboot
# -------------------------------------------------------
echo "--- Adding $userid to dialout and plugdev groups ---"
sudo usermod -a -G dialout "$userid"
sudo usermod -a -G plugdev "$userid"
echo "Done. Group membership takes effect on next login."
echo

# -------------------------------------------------------
# Disable suspend (optional)
# Useful for machines used as dedicated CoCo-Pi stations or kiosks.
# Laptops with the lid closed would otherwise suspend and drop connections.
# -------------------------------------------------------
if [ "$DISABLE_SUSPEND" -eq 1 ]; then
    echo "--- Disabling system suspend ---"
    NOSUSPEND_CONF=/etc/systemd/sleep.conf.d/nosuspend.conf

    if [ -f "$NOSUSPEND_CONF" ]; then
        echo "nosuspend.conf already exists — skipping."
    else
        sudo mkdir -p /etc/systemd/sleep.conf.d
        sudo tee "$NOSUSPEND_CONF" > /dev/null <<'EOF'
[Sleep]
AllowSuspend=no
AllowHibernation=no
AllowSuspendThenHibernate=no
AllowHybridSleep=no
EOF
        echo "Suspend disabled. Reboot required to take effect."
    fi
    echo
fi

echo "=============================================================="
echo " Done."
if [ "$DISABLE_SUSPEND" -eq 0 ]; then
    echo
    echo " To also disable system suspend (recommended for kiosk/dedicated use):"
    echo "   DISABLE_SUSPEND=1 bash setup-system.sh"
fi
echo
echo " Log out and back in (or reboot) for group changes to take effect."
echo "=============================================================="
echo

#!/bin/bash

echo -e "zenity --info --width=200 --height=50 --title=\"Attract Mode\" --text=\"Click OK to cancel\nAttract Mode.\n\nProcess ID: $$\"; kill $$ &" > /tmp/cancel.sh
chmod a+x /tmp/cancel.sh; /tmp/cancel.sh &

# select random Apple ][ or Apple IIgs programs and run for 120 seconds each

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_apple2gs.txt`
export MAMEPARMS=$MAMEPARMSFILE

shopt -s extglob
shopt -s nocasematch

for run in {1..100}
do

     #file=$(shuf -ezn 1 $1/* | xargs -0 -n1 echo)
	 file=$(find "$1" -type f -print0 | shuf -z | xargs -0 -n1 echo 2>/dev/null | head -n 1)

     file_path="$file"

     # Extract filename with extension
     filename_with_ext=$(basename "$file_path")

     # Extract filename without extension
     filename_no_ext="${filename_with_ext%.*}"

     #echo "Original path: $file_path"
     #echo "Filename with extension: $filename_with_ext"
     #echo "Filename without extension: $filename_no_ext"

     clear
     echo
     echo
     echo
     echo
     echo
     echo
     echo
     echo

     echo "Random program $run"
     echo "file = $file"
     echo
     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     echo
     echo "Press [F10] to toggle the no throttle option (helps speed things up)."
     sleep 2

     if [[ $file == *.dsk ]]; then

	sleep 2
	mame apple2gs -ramsize 8M -gameio joy -flop1 "$file" -seconds_to_run 120 $MAMEPARMS

     fi


done

cd $HOME/.mame

#!/bin/bash

# script to extact all files from a TI-994a floppy disk image

# syntax example:

# ./extractDSK-TI99.sh <DSK image>

# set log filename
logtimestamp=$(date +%Y-%m-%d_%H.%M.%S)
logfilename=/tmp/extractDSK-TI99-index.txt

# get name of script and place it into a variable
scriptname=`basename "$0"`

# get name of current folder and place it into a variable
curfolder=`basename "$PWD"`

# get name of DSK image filename
diskimagename=$1


# get size of DSK image
filesize=$(stat -c%s "$diskimagename")

# abort process if DSK image is 254.1K PC99 format
if [ $filesize -eq 260240 ]; then

	echo "$diskimagename is an incompatible file size and format (PC99).  Skipping."
	echo

	touch $logfilename
	echo "$diskimagename is an incompatible file size and format (PC99).  Skipping." >> $logfilename
	echo >> $logfilename

	exit 1
fi

# abort process if DSK image is less than 90K
if [ $filesize -lt 92160 ]; then

	echo "$diskimagename is filesize is less than 90K.  Skipping."
	echo

	touch $logfilename
	echo "$diskimagename is filesize is less than 90K.  Skipping." >> $logfilename
	echo >> $logfilename

	exit 1
fi



# use xdm99.py to extract catalog of DSK image
xdm99.py "$diskimagename" > tempdir.tmp

        # capture xdm99.py errors (ERRORLEVEL)
        if [ $? -ne 0 ]
        then
            echo "ERROR trying to dump catalog of DSK image!"

			touch $logfilename
			echo "$diskimagename - ERROR trying to dump catalog of DSK image!" >> $logfilename
			echo >> $logfilename

			exit 1
        fi

# get internal DSK image name and remove colon at end of string
line=$(head -n 1 tempdir.tmp)

# separate line into individual elements
stringarray=($line)

# remove special characters from DSK image name
disknametmp=${stringarray[0]}
diskname=$(echo "$disknametmp" | tr -d ':,/,*,_')

# check if final diskname is empty and create a new one based on DSK image filename
if [ "$diskname" = "" ]; then
    echo Creating new DSK image name since original is empty...
    disknametmp=$(echo "$diskimagename" | cut -c1-8)

    # convert DSK image filename to uppercase
    diskname=$(echo ${disknametmp^^})

fi

# check for existing or duplicate internal DSK image name folder and generate unique one based on original one if exists
if [ -d "$diskname" ]
then
	disknametmp="$diskname"-$(openssl rand -hex 2)
	diskname=$(echo ${disknametmp^^})

fi

echo
echo Processing: ["$diskimagename"]  ["$diskname"]

# create new internal DSK image folder
mkdir "$diskname"

echo

# remove first 2 lines of tmp catalog listing file
sed -e '1,2d' < tempdir.tmp > ti99dir.txt

# check to see if ti99dir.txt is 0 bytes there is an error

ti99dirfilesize=$(stat -c%s ti99dir.txt)
if [ $ti99dirfilesize -lt 3 ]; then
	echo "ERROR trying to dump catalog of DSK image!"

	touch $logfilename
	echo "$diskimagename - ERROR trying to dump catalog of DSK image!" >> $logfilename
	echo >> $logfilename

	# remove DSK image folder since nothing was extracted
	rmdir "$diskname"

	exit 1
fi


# read ti99dir.txt file
while read line;
do

	# separate line into individual elements
	stringarray=($line)

	# clean up filenames if they have certain characters
	filenametmp1=${stringarray[0]}

	# replace / in filename with .
	filenametmp2=${filenametmp1////.}

	# replace > in filename with _
	filenametmp3=${filenametmp2//>/_}

	# replace * in filename by deleting it
	filenametmp4=$(echo $filenametmp3 | tr -d '*')

	# remove hyphen character if its in first position of filename
	filename=$(echo $filenametmp4 | sed 's/-//1')

	## replace * in filename by deleting it
	#filename=$(echo $filenametmp3 | sed 's/*/2/g')

	## replace * in filename with ^
	#filename=${filenametmp3////*/^}


	sectors=${stringarray[1]}
	type=${stringarray[2]}
	field3=${stringarray[3]}
	bytes=${stringarray[4]}
	b=${stringarray[5]}
	free=${stringarray[6]}
	recs=${stringarray[7]}

#	echo "filename = $filename"
#	echo "sectors  = $sectors"
#	echo "type     = $type"
#	echo "field3   = $field3"
#	echo "bytes    = $bytes"
#	echo "b        = $b"
#	echo "free     = $free"
#	echo "recs     = $recs"

	# extact files(s) into internal DSK image name folder
	xdm99.py "$diskimagename" -t -e "$filenametmp1"  -o "$diskname/$filename"

	# capture xdm99.py errors (ERRORLEVEL)
	if [ $? -ne 0 ]
	then
	    echo "ERROR during file extraction process!"

		touch $logfilename
		echo "$diskimagename - ERROR during file extraction process!  -  $filename" >> $logfilename

	fi

done < ti99dir.txt


# housekeeping

rm tempdir.tmp > /dev/null
rm ti99dir.txt > /dev/null

touch $logfilename

timestamp=$(date +%Y-%m-%d_%H.%M.%S)
currentdir=$(pwd)

echo $timestamp [path: $currentdir] [filename: $diskimagename] [volume: $diskname] >> $logfilename
echo >> $logfilename

echo -e
echo "Done."
echo -e

# sample DSK image listing
# TI-WRITER :     129 used  231 free   90 KB  1S/1D 40T  9 S/T
# ----------------------------------------------------------------------------
# EDITA1       33  PROGRAM       8190 B
# EDITA2        6  PROGRAM       1046 B
# FORMA1       33  PROGRAM       8190 B
# FORMA2       15  PROGRAM       3342 B
# FORMATDOC    26  DIS/VAR 80    6392 B  113 recs
# PRACTICE      7  DIS/VAR 80    1303 B   24 recs
# PRACTICE1     7  DIS/VAR 80    1470 B   26 recs

#!/bin/bash

SAVEIFS=$IFS
IFS=$(echo -en "\n\b")

# select random Atari 8 bit computer programs and run them for 120 seconds each

ATARI800PARMSFILE=`cat $HOME/.atari800/.optional_atari800_parameters.txt`
export ATARI800PARMS=$ATARI800PARMSFILE

# ignore file extension case
shopt -s nocasematch

shopt -s extglob

for run in {1..200}
do

file=$(shuf -ezn 1 $1/*.* | xargs -0 -n1 echo)

     clear

     echo "Random program $run"
     echo "file = $file"
     echo

     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     echo
     sleep 2

     if [[ $file == *.atr ]]; then

                echo ATR
		timelimit -t120 atari800 -config $HOME/.atari800/.atari800.cfg -xl -osa_rom $HOME/.atari800/roms/Atariosa.rom -osb_rom $HOME/.atari800/roms/ATARIOSB.ROM -xlxe_rom $HOME/.atari800/roms/ATARIXL.ROM -nobasic -basic_rom $HOME/.atari800/roms/REVC.ROM -rambo $ATARI800PARMS "$file"

     fi


     if [[ $file == *.atx ]]; then

                echo ATX
		timelimit -t120 atari800 -config $HOME/.atari800/.atari800.cfg -xl -osa_rom $HOME/.atari800/roms/Atariosa.rom -osb_rom $HOME/.atari800/roms/ATARIOSB.ROM -xlxe_rom $HOME/.atari800/roms/ATARIXL.ROM -nobasic -basic_rom $HOME/.atari800/roms/REVC.ROM -rambo $ATARI800PARMS "$file"

     fi


     if [[ $file == *.bin ]]; then

                echo BIN
		timelimit -t120 atari800 -config $HOME/.atari800/.atari800.cfg -xl -nobasic -rambo $ATARI800PARMS -cart "$file"

     fi


     if [[ $file == *.car ]]; then

                echo CAR
		timelimit -t120 atari800 -config $HOME/.atari800/.atari800.cfg -xl -nobasic -rambo $ATARI800PARMS -cart "$file"

     fi


     if [[ $file == *.cas ]]; then

                echo CAS
		timelimit -t120 atari800 -config $HOME/.atari800/.atari800.cfg -xl -nobasic -rambo $ATARI800PARMS -boottape "$file"

     fi


     if [[ $file == *.com ]]; then

                echo COM
		timelimit -t120 atari800 -config $HOME/.atari800/.atari800.cfg -xl -nobasic -rambo $ATARI800PARMS -run "$file"

     fi


     if [[ $file == *.rom ]]; then

                echo ROM
		timelimit -t120 atari800 -config $HOME/.atari800/.atari800.cfg -xl -nobasic -rambo $ATARI800PARMS -cart "$file"

     fi


     if [[ $file == *.xex ]]; then

                echo XEX
		timelimit -t120 atari800 -config $HOME/.atari800/.atari800.cfg -xl -nobasic -rambo $ATARI800PARMS -run "$file"

     fi

done

sleep 2

# restore $IFS
IFS=$SAVEIFS

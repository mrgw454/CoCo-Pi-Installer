#!/bin/bash

SAVEIFS=$IFS
IFS=$(echo -en "\n\b")

# select random Atari 8 bit computer programs and run them for 120 seconds each

ATARI800PARMSFILE=`cat $HOME/.atari800/.optional_atari800_parameters.txt`
export ATARI800PARMS=$ATARI800PARMSFILE

shopt -s extglob
shopt -s nocasematch

cd $HOME/.atari800

for run in {1..200}
do

#file=$(shuf -ezn 1 $1/*.* | xargs -0 -n1 echo)
file=$(find "$1" -type f -print0 | shuf -z | xargs -0 -n1 echo 2>/dev/null | head -n 1)

     clear

     echo "Random program $run"
     echo "file = $file"
     echo

     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     echo
     sleep 2

     if [[ $file == *.atr ]]; then

                echo ATR
		timelimit -t120 atari800 -xl -nobasic -rambo -stretch 4 $ATARI800PARMS "$file"

     fi


     if [[ $file == *.atx ]]; then

                echo ATX
		timelimit -t120 atari800 -xl -nobasic -rambo -stretch 4 $ATARI800PARMS "$file"

     fi


     if [[ $file == *.bin ]]; then

                echo BIN
		timelimit -t120 atari800 -xl -nobasic -rambo -stretch 4 $ATARI800PARMS -cart "$file"

     fi


     if [[ $file == *.car ]]; then

                echo CAR
		timelimit -t120 atari800 -xl -nobasic -rambo -stretch 4 $ATARI800PARMS -cart "$file"

     fi


     if [[ $file == *.cas ]]; then

                echo CAS
		timelimit -t120 atari800 -xl -nobasic -rambo -stretch 4 $ATARI800PARMS -boottape "$file"

     fi


     if [[ $file == *.com ]]; then

                echo COM
		timelimit -t120 atari800 -xl -nobasic -rambo -stretch 4 $ATARI800PARMS -run "$file"

     fi


     if [[ $file == *.rom ]]; then

                echo ROM
		timelimit -t120 atari800 -xl -nobasic -rambo -stretch 4 $ATARI800PARMS -cart "$file"

     fi


     if [[ $file == *.xex ]]; then

                echo XEX
		timelimit -t120 atari800  -xl -nobasic -rambo -stretch 4 $ATARI800PARMS -run "$file"

     fi

done

sleep 2

# restore $IFS
IFS=$SAVEIFS

#!/bin/bash

# make sure python3 is the default prior to running this
pyenv shell system
# ... or ...
PATH=`echo $PATH | tr ':' '\n' | sed '/pyenv/d' | tr '\n' ':' | sed -r 's/:$/\n/'`

# start FujiNet bridge
cd $HOME/source/fujinet-emulator-bridge/fujinet-bridge
python3 -m netsiohub &

# start FujiNet PC
cd $HOME/source/fujinet-pc-Atari/build/dist
./run-fujinet &

#read -p "Press any key to continue... " -n1 -s

cd $HOME/source

echo
echo

ps auwx | grep fuji
ps auwx | grep netsiohub

echo
echo

google-chrome http://localhost:8000 &


echo Setting terminal for ANSI emulation
export TERM=ansi
echo Setting terminal for 51 x 24 size
stty rows 24 cols 51
echo -e
echo Run 'tack' to perform terminal testing.
echo -e


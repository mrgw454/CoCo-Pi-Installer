#!/bin/bash

# select random Atari 2600 console games and run them for 120 seconds each

ATARI2600PARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_atari2600.txt`
export ATARI2600PARMS=$ATARI2600PARMSFILE

shopt -s extglob

for run in {1..200}
do

file=$(shuf -ezn 1 $1/*.* | xargs -0 -n1 echo)

     clear

     echo "Random program $run"
     echo "file = $file"
     echo

     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     echo
     sleep 2

     if [[ $file == *.bin ]]; then

                echo BIN
		mame a2600 -cart "$file" -seconds_to_run 120 $ATARI2600PARMS

     fi


     if [[ $file == *.car ]]; then

                echo CAR
		mame a2600 -cart "$file" -seconds_to_run 120 $ATARI2600PARMS

     fi


     if [[ $file == *.rom ]]; then

                echo ROM
		mame a2600 -cart "$file" -seconds_to_run 120 $ATARI2600PARMS

     fi


# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi


done

sleep 2

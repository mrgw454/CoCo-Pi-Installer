#!/bin/bash

# copy Apple IIx disk formats PO HDV and DSK

shopt -s globstar
shopt -s extglob
shopt -s nocasematch


if [ -f verify-errors.txt ]; then
	rm verify-errors.txt
fi


for f in "$PWD"/**/*
do

    fullfilename="$f"
    filename=$(basename "$fullfilename")
    fname="${filename%.*}"
    filesize=$(stat -c%s "$fullfilename")
    filepath=$(dirname "$f")
    parentname="$(basename "$(dirname "$filepath")")"
    fujipath=$(echo $filepath | cut -d'/' -f4-)

#echo fullfilename $fullfilenmae
#echo filename $filename
#echo fname $fname
#echo filesize $filesize
#echo filepath $filepath
#echo parentname $parentname
#echo $fujipath

	if [[ $f == *.PO ]] || [[ $f == *.HDV ]] || [[ $f == *.DSK ]]; then

		java -jar $HOME/AppleCommander/ac.jar -i "$f" > "$fname.output"
		filesize=$(stat -c%s "$fname.output")

		if [ $filesize -eq 0 ]; then
			echo "$fname" is not a valid disk image file.
			echo "$f" >> verify-errors.txt
			echo
		else
			echo "$fname" is a valid disk image file.
			echo cp --parents "$f" "/media/share1/FUJINET-APPLE"
			cp --parents "$f" "/media/share1/FUJINET-APPLE"
			echo
		fi

       		rm "$fname.output"

		echo
		echo

	fi

done

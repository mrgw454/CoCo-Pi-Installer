#!/bin/bash

# verify Apple IIx disk images

shopt -s globstar
shopt -s extglob
shopt -s nocasematch


if [ -f verify-errors.txt ]; then
	rm verify-errors.txt
fi

for f in **/*
do

    fullfilename="$f"
    filename=$(basename "$fullfilename")
    fname="${filename%.*}"
    filesize=$(stat -c%s "$fullfilename")

#echo fullfilename $fullfilenmae
#echo filename $filename
#echo fname $fname
#echo filesize $filesize

	if [[ $f == *.po ]] || [[ $f == *.do ]] || [[ $f == *.2mg ]] || [[ $f == *.dsk ]] || [[ $f == *.hdv ]]; then

		java -jar $HOME/AppleCommander/ac.jar -i "$f" > "$fname.output"
		filesize=$(stat -c%s "$fname.output")

		if [ $filesize -eq 0 ]; then
			echo "$f" did not verify successfully.
			echo "$f" >> verify-errors.txt
		else
			echo "$f" verified successfully.
		fi

       		rm "$fname.output"

		echo

	fi

done

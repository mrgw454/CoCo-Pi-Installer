#!/bin/bash
set -e
clear

echo "🧼 Removing old Zenity menus..."
rm -f ~/scripts/CoCoPi-menu*.z3.sh

echo "📦 Backing up legacy menus before patching..."
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="$HOME/scripts/legacy_menus_backup_$TIMESTAMP.tar.gz"
tar -czf "$BACKUP_FILE" ~/.mame/CoCoPi-menu*.sh
echo "  → Saved to: $BACKUP_FILE"

echo "🩹 Patching legacy menus for COCOPI_MENU_CALLER..."
python3 ~/scripts/patch_legacy_menus.py --patch

echo "🔁 Converting patched menus to Zenity (.z3.sh)..."
python3 ~/scripts/convert_whiptail_to_zenity.py

echo "✅ Running integrity audit on new Zenity menus..."
python3 ~/scripts/menu_action_integrity.py --zenity-only --errors-only

echo "🎉 Conversion complete. Zenity menus are ready."

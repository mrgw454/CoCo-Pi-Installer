#!/bin/bash

# Usage: ./network_speed_test.sh sender <receiver_ip>
#        ./network_speed_test.sh receiver

ROLE="$1"
TARGET_IP="$2"
PORT=5201
DURATION=10

function run_receiver() {
    echo "Starting iperf3 in receiver mode on port $PORT..."
    iperf3 -s -p $PORT
}

function run_sender() {
    if [ -z "$TARGET_IP" ]; then
        echo "Error: Missing receiver IP address."
        echo "Usage: $0 sender <receiver_ip>"
        exit 1
    fi
    echo "Running iperf3 in sender mode to $TARGET_IP for $DURATION seconds..."
    iperf3 -c "$TARGET_IP" -p $PORT -t $DURATION | tee /tmp/iperf3_output.txt

    echo -e "\n📊 Summary:"
    grep -A1 "sender" /tmp/iperf3_output.txt | tail -n1 | awk '{print "Sent: " $7 " " $8 " | Bandwidth: " $9 " " $10}'
    grep -A1 "receiver" /tmp/iperf3_output.txt | tail -n1 | awk '{print "Received: " $7 " " $8 " | Bandwidth: " $9 " " $10}'
}

case "$ROLE" in
    receiver)
        run_receiver
        ;;
    sender)
        run_sender
        ;;
    *)
        echo "Usage: $0 sender <receiver_ip> | receiver"
        exit 1
        ;;
esac

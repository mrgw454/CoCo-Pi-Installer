#!/bin/bash
PIDFILE="/tmp/tnfsd.pid"

echo "Stopping TNFS server..."

if [ ! -f "$PIDFILE" ]; then
    echo "TNFS server is not running."
    exit 1
fi

PID=$(cat "$PIDFILE")

if ps -p "$PID" >/dev/null 2>&1; then
    kill "$PID"
    sleep 1
    if ps -p "$PID" >/dev/null 2>&1; then
        echo "Force killing TNFS server..."
        kill -9 "$PID"
    fi
else
    echo "PID file exists but process is not running."
fi

rm -f "$PIDFILE"
echo "TNFS server stopped."

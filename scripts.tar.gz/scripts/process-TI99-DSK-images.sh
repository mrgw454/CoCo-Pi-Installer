#!/bin/bash

# use this command to run this script recursively
# find . -maxdepth 10 -type d \( ! -name . \) -exec bash -c "cd '{}' && pwd && process-TI99-DSK-images.sh" \;

shopt -s nocaseglob
shopt -s globstar
shopt -s nocasematch

if compgen -G "*.dsk" > /dev/null; then

    for d in *.dsk; do

	touch /tmp/extractDSK-TI99-index.txt
	pwd >> /tmp/extractDSK-TI99-index.txt
	extractDSK-TI99.sh "$d"

    done

#find . -type f -name '*.dsk-errors.txt' -delete
find . -type f -name 'tempdir.tmp' -delete
find . -type f -name 'ti99dir.txt' -delete

#find . -type f -name '*.dsk' -delete

fi


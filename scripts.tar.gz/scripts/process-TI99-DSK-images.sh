#!/bin/bash

shopt -s nocaseglob
shopt -s globstar
shopt -s nocasematch

# use this command to run this script recursively

# single-line version
#find . -iname "*.DSK" -type f -execdir bash -c 'extractDSK-TI99.sh {}' \;


# multi-line version
find . -iname "*.DSK" -type f \
	-execdir bash -c '
	basefile=$(basename {})
	extractDSK-TI99.sh $basefile' \;

find . -type f -name 'tempdir.tmp' -delete
find . -type f -name 'ti99dir.txt' -delete
#find . -type f -name '*.dsk' -delete

echo
echo Done!
echo


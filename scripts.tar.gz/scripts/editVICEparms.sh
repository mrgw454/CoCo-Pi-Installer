clear

echo -e "Any parameters you add/change/remove from this file will be applied to most" > msg.txt
echo -e "VICE launch scripts as part of VicePi." >> msg.txt
echo -e >> msg.txt
echo -e "More information about MAME command line options can be found at:" >> msg.txt
echo -e >> msg.txt
echo -e "https://vice-emu.sourceforge.io/vice_toc.html#TOC23" >> msg.txt
echo -e >> msg.txt
echo -e >> msg.txt

whiptail --title "Edit optional VICE parameters" --textbox msg.txt 0 0
rm msg.txt

nano $HOME/.vice/.optional_vice_parameters.txt

VICEPARMSFILE=`cat $HOME/.vice/.optional_vice_parameters.txt`
export VICEPARMS=$VICEPARMSFILE
set VICEPARMS=$VICEPARMSFILE

clear

echo
echo
echo
echo
echo
echo
echo
echo

echo VICE optional parameters are set to:
echo
echo $VICEPARMS
echo
read -p "Press any key to continue." -n1 -s

cd $HOME/.vice

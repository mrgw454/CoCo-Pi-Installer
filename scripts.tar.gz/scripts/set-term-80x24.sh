echo Setting terminal for ANSI emulation
export TERM=ansi
echo Setting terminal for 80 x 24 size
stty rows 24 cols 80
echo -e
echo Run 'tack' to perform terminal testing.
echo -e


#!/usr/bin/env python3
import os
import platform
import shutil
import subprocess

IS_WINDOWS = (os.name == "nt")
IS_LINUX = (os.name == "posix" and platform.system() == "Linux")

def run_capture(cmd, env=None):
    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env
        )
        return result.stdout.strip()
    except Exception:
        return None


# ---------------------------------------------------------
# MAME
# ---------------------------------------------------------
def get_mame_version():
    if IS_WINDOWS:
        exe = os.path.expandvars(r"%USERPROFILE%\mame\mame.exe")
        if os.path.exists(exe):
            out = run_capture([exe, "-version"])
            if out:
                return out.splitlines()[0]
        return "MAME not found"

    exe = shutil.which("mame")
    if exe:
        out = run_capture([exe, "-version"])
        if out:
            return out.splitlines()[0]
    return "MAME not found"


# ---------------------------------------------------------
# XRoar
# ---------------------------------------------------------
def get_xroar_version():
    if IS_WINDOWS:
        exe = os.path.expandvars(r"%USERPROFILE%\xroar\xroar.exe")
        if os.path.exists(exe):
            out = run_capture([exe, "--version"])
            if out:
                for line in out.splitlines():
                    if line.startswith("XRoar "):
                        return line
        return "XRoar not found"

    exe = shutil.which("xroar")
    if exe:
        out = run_capture([exe, "--version"])
        if out:
            for line in out.splitlines():
                if line.startswith("XRoar "):
                    return line
    return "XRoar not found"


# ---------------------------------------------------------
# trs80gp
# ---------------------------------------------------------
def get_trs80gp_version():
    if IS_WINDOWS:
        exe = os.path.expandvars(r"%USERPROFILE%\trs80gp\trs80gp.exe")
        if os.path.exists(exe):
            out = run_capture([exe, "-version"])
            if out:
                return out.splitlines()[0]
        return "trs80gp not found"

    exe = shutil.which("trs80gp")
    if exe:
        out = run_capture(["strings", exe])
        if out:
            for line in out.splitlines():
                if line.startswith("trs80gp version "):
                    return line
    return "trs80gp not found"


# ---------------------------------------------------------
# MAIN
# ---------------------------------------------------------
def main():
    print("=== Emulator Versions ===\n")

    print("MAME:    ", get_mame_version())
    print("XRoar:   ", get_xroar_version())
    print("trs80gp: ", get_trs80gp_version())

    print("\nDone.")


if __name__ == "__main__":
    main()

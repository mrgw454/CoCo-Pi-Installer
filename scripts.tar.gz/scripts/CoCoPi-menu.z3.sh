#!/bin/bash
clear
export COCOPI_MENU_CALLER="$HOME/scripts/CoCoPi-menu.z3.sh"
TITLE="$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)"

CHOICE=$(zenity --list \
  --title="$TITLE" \
  --width=700 --height=500 \
  --column="Option" --column="Description" \
  "1" "TRS-80 Color Computer 2 Menu" \
  "2" "TRS-80 Color Computer 2 Menu (XRoar)" \
  "3" "TRS-80 Color Computer 2 Menu (trs80gp)" \
  "4" "Tandy  Color Computer 3 Menu" \
  "5" "Tandy  Color Computer 3 Menu (XRoar)" \
  "6" "Tandy  Color Computer 3 Menu (OVCC)" \
  "7" "TRS-80 MC-10 Menu" \
  "8" "TRS-80 MC-10 Menu (XRoar)" \
  "9" "TRS-80 MC-10 Menu (trs80gp)" \
  "10" "Dragon Menu" \
  "11" "Dragon Menu (XRoar)" \
  "12" "Clone Systems Menu" \
  "13" "Utilities Menu" \
  "14" "Internet/Online Menu" \
  "15" "Attract (Kiosk) Mode Menu" \
  "16" "Shutdown Raspberry Pi"
)

case $CHOICE in
  "1") CoCoPi-menu-Coco2.z3.sh;;
  "2") CoCoPi-menu-Coco2-XRoar.z3.sh;;
  "3") CoCoPi-menu-Coco2-trs80gp.z3.sh;;
  "4") CoCoPi-menu-Coco3.z3.sh;;
  "5") CoCoPi-menu-Coco3-XRoar.z3.sh;;
  "6") CoCoPi-menu-Coco3-OVCC.z3.sh;;
  "7") CoCoPi-menu-MC10.z3.sh;;
  "8") CoCoPi-menu-MC10-XRoar.z3.sh;;
  "9") CoCoPi-menu-MC10-trs80gp.z3.sh;;
  "10") CoCoPi-menu-Dragon.z3.sh;;
  "11") CoCoPi-menu-Dragon-XRoar.z3.sh;;
  "12") CoCoPi-menu-Clones.z3.sh;;
  "13") CoCoPi-menu-Utilities.z3.sh;;
  "14") CoCoPi-menu-Online.z3.sh;;
  "15") CoCoPi-menu-Attract.z3.sh;;
  "16") shutdownRPi.sh;;
  "*") echo "Quitting...";;
  "*") echo "Quitting...";;
esac

sudo shutdown -h 0


#!/bin/bash

if pgrep -f fujinet >/dev/null 2>&1; then
    PID=$(pgrep -f fujinet | head -n 1)
    echo "FujiNet-PC (Atari800) is running (PID $PID)"
else
    echo "FujiNet-PC (Atari800) is not running."
fi

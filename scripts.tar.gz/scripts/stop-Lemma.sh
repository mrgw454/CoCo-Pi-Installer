killall -9 lemma
kill -9 `pgrep -f lemma`

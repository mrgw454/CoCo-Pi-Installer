#!/bin/bash

# Start FujiNet-PC for Atari800

cd $HOME/source/fujinet-pc-atari800/build/dist
./fujinet &

cd $HOME/source

echo
echo "FujiNet-PC (Atari800) started."
echo

ps auwx | grep fujinet | grep -v grep

echo
exit

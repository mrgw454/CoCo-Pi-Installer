#!/bin/bash

if pgrep -f fujinet >/dev/null 2>&1; then
    PID=$(pgrep -f fujinet | head -n 1)
    echo "FujiNet-PC (AppleWin) is running (PID $PID)"
else
    echo "FujiNet-PC (AppleWin) is not running."
fi

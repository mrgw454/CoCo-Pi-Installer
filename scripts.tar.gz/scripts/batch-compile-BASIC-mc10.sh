#!/bin/bash

# set up some variables
workdir=$(pwd)


if [ -d $workdir/logs ]
then

    echo logs folder already present.  Removing any existing log files.
    rm -r -f $workdir/logs/*.txt
    echo
else
    echo logs folder does not exist.  Creating.
    mkdir $workdir/logs
    echo
fi


if [ -d $workdir/batch ]
then

    echo batch folder already present.  Removing any existing batch shell script.
    rm -r -f $workdir/batch/*.sh
    echo
else
    echo batch folder does not exist.  Creating.
    mkdir $workdir/batch
    echo
fi


# set processed files counter
COUNTER=1

# create new batch process script for CLOADM
echo \#\!\/bin\/bash > $workdir/batch/batch-process-mc10-CLOADM.sh
echo echo >> $workdir/batch/batch-process-mc10-CLOADM.sh
echo clear >> $workdir/batch/batch-process-mc10-CLOADM.sh
echo echo >> $workdir/batch/batch-process-mc10-CLOADM.sh

# case insensitive
shopt -s nocaseglob

# JG's programs are provided in TEXT format (*.txt)
shopt -s globstar dotglob
#for file in **/*.txt
for file in **/*

do


  if [[ $file == *.txt || $file == *.TXT ]]; then


	# set up some variables
	filename=$(basename -- "$file")
	dir=$(dirname -- "$file")
	extension="${filename##*.}"
	filename="${filename%.*}"

	cd "$workdir/$dir"

	echo Compiling $COUNTER - $dir/$filename.$extension...
	compile-BASIC-mc10.sh $filename.$extension

	# check if .c10 file exists (after compiling).  If so, make sure it's larger than 283 bytes
	if [[ -f $workdir/$dir/$filename.c10 ]] && [[ $(find $workdir/$dir/$filename.c10 -type f -size +283c 2>/dev/null) ]]; then

		echo echo $COUNTER - $dir/$filename.wav >> $workdir/batch/batch-process-mc10-CLOADM.sh
		echo echo >> $workdir/batch/batch-process-mc10-CLOADM.sh

		echo echo Make sure to type CLOADM on MC-10 and ... >> $workdir/batch/batch-process-mc10-CLOADM.sh
		echo read -p \""Press any key to continue... \"" -n1 -s >> $workdir/batch/batch-process-mc10-CLOADM.sh
		echo echo >> $workdir/batch/batch-process-mc10-CLOADM.sh

		echo echo Playing $dir/$filename.wav ... >> $workdir/batch/batch-process-mc10-CLOADM.sh
		echo echo >> $workdir/batch/batch-process-mc10-CLOADM.sh

		echo omxplayer -p -o hdmi $dir/$filename.wav >> $workdir/batch/batch-process-mc10-CLOADM.sh
		echo echo >> $workdir/batch/batch-process-mc10-CLOADM.sh

		echo echo Now type EXEC on the MC-10. >> $workdir/batch/batch-process-mc10-CLOADM.sh
		echo read -p \""Press any key to continue... \"" -n1 -s >> $workdir/batch/batch-process-mc10-CLOADM.sh
		echo echo >> $workdir/batch/batch-process-mc10-CLOADM.sh
		echo echo >> $workdir/batch/batch-process-mc10-CLOADM.sh
		echo clear >> $workdir/batch/batch-process-mc10-CLOADM.sh

		echo $COUNTER - $dir/$filename.$extension - .c10 file does exist.  Compilation was successful. >> $workdir/logs/success-log.txt

	else

		echo $COUNTER - $dir/$filename.$extension - .c10 file does NOT exist.  Compilation was NOT successful. >> $workdir/logs/error-log.txt

	fi

	echo -e

	let COUNTER++

	cd ..

  fi

done

chmod a+x $workdir/batch/batch-process-mc10-CLOADM.sh


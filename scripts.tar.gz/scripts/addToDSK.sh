#!/bin/bash

# script to add files to an existing Coco floppy disk image and and copy all Coco related files to it.
# It will also (optionally) run MAME mount the disk image (pyDriveWire or normal DECB)

# this script can take up to 3 command line parameters:
# Coco driver to use for MAME (i.e. coco2b coco3, etc.) and use pyDriveWire (yes or no) and existing DSK image name

# syntax example:

# ./makeDSK coco2b y TEST.DSK

# this will add files to an existing disk image and copy all Coco compatible files to it
# using name you pass to it.  In addition, it will launch MAME using the Coco 2
# driver for MAME (with HDBDOS) and use pyDriveWire with this disk image mounted as DRIVE 0.
# If pyDriveWire is not running, the script will start it.

# Define function for displaying error codes from Toolshed's 'decb' command

functionErrorLevel() {

	if [ $? -eq 0 ]
	then

		echo -e "Successfully copied file to DSK image."
		echo -e

	else

		echo -e "Error during copy process to DSK image."
		echo -e
		read -p "Press any key to continue... " -n1 -s
		echo -e
		echo -e

	fi

}

# use parameter file for MAME (if found)
MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters.txt`
export MAMEPARMS=$MAMEPARMSFILE

# get name of script and place it into a variable
scriptname=`basename "$0"`


# use name of existing disk image if it exists
floppy=$3

if ! [ -f "$floppy" ]; then

	echo -e
	echo "[$floppy]" does not exist.  Aborting.
	echo -e
	echo -e
	
	exit 1

fi


workdir=$(pwd)


# parse command line parameters for standard help options
if [[ $1 =~ --h|--help|-h ]];then

    echo -e
    echo -e "Example syntax:"
    echo -e
    echo -e "./$scriptname <coco driver> <y>|<n> <DSK image>"
    echo -e
    exit 1

fi

# ignore file extension case
shopt -s nocasematch

for f in *; do

	# Copy all BASIC files (and convert names to UPPERCASE) to DSK image
	if [[ $f == *.BAS ]]; then

		echo -e decb copy -0 -a -t -r "$f" "$floppy","${f^^}"
		decb copy -0 -a -t -r "$f" "$floppy","${f^^}"
		functionErrorLevel

	fi


	# Copy all BINARY files (and convert names to UPPERCASE) to DSK image
	if [[ $f == *.BIN ]]; then

		echo -e decb copy -2 -b -r "$f" "$floppy","${f^^}"
		decb copy -2 -b -r "$f" "$floppy","${f^^}"
		functionErrorLevel

	fi


	# Copy all TEXT files (and convert names to UPPERCASE) to DSK image
	if [[ $f == *.TXT ]]; then

		echo -e decb copy -3 -a -r "$f" "$floppy","${f^^}"
		decb copy -3 -a -r "$f" "$floppy","${f^^}"
		functionErrorLevel

	fi


	# Copy all DAT files (and convert names to UPPERCASE) to DSK image
	if [[ $f == *.DAT ]]; then

		echo -e decb copy -2 -b -r "$f" "$floppy","${f^^}"
		decb copy -2 -b -r "$f" "$floppy","${f^^}"
		functionErrorLevel

	fi


	# Copy all ROM files (and convert names to UPPERCASE) to DSK image
	if [[ $f == *.ROM ]]; then

		echo -e decb copy -2 -b -r "$f" "$floppy","${f^^}"
		decb copy -2 -b -r "$f" "$floppy","${f^^}"
		functionErrorLevel

	fi


	# Copy all CHR files for CoCoVGA (and convert names to UPPERCASE) to DSK image
	if [[ $f == *.CHR ]]; then

		echo -e decb copy -2 -b -r "$f" "$floppy","${f^^}"
		decb copy -2 -b -r "$f" "$floppy","${f^^}"
		functionErrorLevel

	fi


# Copy all VG6 files for CoCoVGA (and convert names to UPPERCASE) to DSK image
	if [[ $f == *.VG6 ]]; then

		echo -e decb copy -2 -b -r "$f" "$floppy","${f^^}"
		decb copy -2 -b -r "$f" "$floppy","${f^^}"
		functionErrorLevel

	fi


# Copy all SCR files for CoCoVGA (and convert names to UPPERCASE) to DSK image
	if [[ $f == *.SCR ]]; then

		echo -e decb copy -2 -b -r "$f" "$floppy","${f^^}"
		decb copy -2 -b -r "$f" "$floppy","${f^^}"
		functionErrorLevel

	fi


# Copy all PNG files for ugBasicA (and convert names to UPPERCASE) to DSK image
	if [[ $f == *.PNG ]]; then

		echo -e decb copy -2 -b -r "$f" "$floppy","${f^^}"
		decb copy -2 -b -r "$f" "$floppy","${f^^}"
		functionErrorLevel

	fi


done

echo -e

# list disk image contents
decb dir "$floppy"
echo -e


# if no parameters, only make disk image and exit
if [ $# -eq 0 ]
  then
    echo -e "Only made disk image as no command line parameters supplied"

	echo -e
	echo -e "Done."
	echo -e

	exit 1

fi



# (optional) load MAME and mount disk image in pyDrivewire INSTANCE 0 as DRIVE 0
if [[ $2 =~ Y|y ]];then

	# make sure HDBDOS is used for pyDriveWire access

	# Coco 2 section
	if [[ $1 =~ coco2b|coco2bh ]];then

		# enable Becker port
		cp $HOME/.mame/cfg/coco2b.cfg.beckerport-enabled $HOME/.mame/cfg/coco2b.cfg


		# eject disk from pyDriveWire
		$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk eject 0
		echo -e

		# insert disk for pyDriveWire
		$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk insert 0 "$workdir/$floppy"
		echo -e

		# show (confirm) disk mounted in pyDriveWire
		$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk show 0
		echo -e


		mame $1 -homepath $HOME/.mame -cart /media/share1/roms/hdbdw3bck.rom -ext fdc $MAMEPARMS

		# eject disk from pyDriveWire
		$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk eject 0

		# disable Becker port
		cp $HOME/.mame/cfg/coco2b.cfg.beckerport-disabled $HOME/.mame/cfg/coco2b.cfg


		echo -e
		echo -e "Done."
		echo -e
		exit 1

	fi


	# Coco 3 section
	if [[ $1 =~ coco3|coco3h ]];then

		# enable Becker port
		cp $HOME/.mame/cfg/coco3.cfg.beckerport-enabled $HOME/.mame/cfg/coco3.cfg

		# eject disk from pyDriveWire
		$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk eject 0
		echo -e

		# insert disk for pyDriveWire
		$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk insert 0 "$workdir/$floppy"
		echo -e

		# show (confirm) disk mounted in pyDriveWire
		$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk show 0
		echo -e

		mame $1 -homepath $HOME/.mame -ramsize 512k -ext multi -ext:multi:slot4 fdc -cart5 /media/share1/roms/hdbdw3bc3.rom $MAMEPARMS

		# eject disk from pyDriveWire
		$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk eject 0

		# disable Becker port
		cp $HOME/.mame/cfg/coco3.cfg.beckerport-disabled $HOME/.mame/cfg/coco3.cfg

		echo -e
		echo -e "Done."
		echo -e
		exit 1

	fi


	echo -e
	echo -e "Not a valid Coco based driver for DriveWire.  Exiting."
	echo -e
	echo -e "Some valid Coco drivers for MAME are:"
	echo -e
	mame -listfull | grep "Color Computer "

	echo -e
	echo -e "Done."
	echo -e
	exit 1

else


	# (optional) load MAME and mount the disk image as DRIVE 0

	# Coco 2 and Coco 3 section
	if [[ $1 =~ coco2b|coco2bh|coco3|coco3h|coco3p ]];then

		mame -homepath $HOME/.mame $1 -flop1 "$PWD/$floppy" $MAMEPARMS

		echo -e
		echo -e "Done."
		echo -e

		exit 1

	fi

	echo -e
	echo -e "Not a valid Coco based driver.  Exiting."
	echo -e
	echo -e "Some valid Coco drivers for MAME are:"
	echo -e
	mame -listfull | grep "Color Computer "

	echo -e
	echo -e "Done."
	echo -e

	exit 1

fi

	echo -e
	echo -e "Done."
	echo -e

	exit 1

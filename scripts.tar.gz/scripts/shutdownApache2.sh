sudo /etc/init.d/apache2 stop
echo -e
read -p "Press any key to continue." -n1 -s

cd $HOME/.mame


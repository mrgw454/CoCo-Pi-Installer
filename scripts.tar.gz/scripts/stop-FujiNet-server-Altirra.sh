#!/bin/bash

echo "Stopping FujiNet-PC (Altirra)..."

killall -9 fujinet 2>/dev/null
killall -9 netsiohub 2>/dev/null

# Some FujiNet-PC builds spawn helper processes
kill -9 $(pgrep -f netsiohub) 2>/dev/null

echo "Stopped."

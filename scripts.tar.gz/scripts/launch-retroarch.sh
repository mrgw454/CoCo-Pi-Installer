#!/bin/bash
# Launch RetroArch (Flatpak)
exec flatpak run org.libretro.RetroArch

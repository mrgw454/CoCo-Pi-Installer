#!/usr/bin/env python3
import os
import platform
import subprocess
from pathlib import Path

# ---------------------------------------------------------
# Platform detection
# ---------------------------------------------------------

IS_WINDOWS = (os.name == "nt")
IS_LINUX = (os.name == "posix" and platform.system() == "Linux")

WIN_HOME = os.environ.get("USERPROFILE", "")
LIN_HOME = os.environ.get("HOME", "")

# ---------------------------------------------------------
# ENUMERATION
# ---------------------------------------------------------

def find_mame_versions():
    """
    Returns a sorted list of MAME version directories.

    Linux: /opt/mame-<version>
    Windows: USERPROFILE/mame-<version>
    """
    if IS_LINUX:
        return sorted([p for p in Path("/opt").glob("mame-*") if p.is_dir()])
    else:
        return sorted([p for p in Path(WIN_HOME).glob("mame-*") if p.is_dir()])


def find_xroar_versions():
    """
    Returns a sorted list of XRoar version binaries or directories.

    Linux: /usr/local/bin/xroar-<version>
    Windows: USERPROFILE/xroar-<version>
    """
    if IS_LINUX:
        return sorted([p for p in Path("/usr/local/bin").glob("xroar-*") if p.is_file()])
    else:
        return sorted([p for p in Path(WIN_HOME).glob("xroar-*") if p.is_dir()])


# ---------------------------------------------------------
# ACTIVATION
# ---------------------------------------------------------

def activate_mame(path):
    """
    Activates a MAME version by updating the canonical symlink or junction.
    """
    if IS_LINUX:
        subprocess.call(["sudo", "rm", "-f", "/opt/mame"])
        subprocess.call(["sudo", "ln", "-s", str(path), "/opt/mame"])

        # Ensure /usr/local/bin/mame exists
        if not Path("/usr/local/bin/mame").exists():
            subprocess.call(["sudo", "ln", "-s", "/opt/mame/mame", "/usr/local/bin/mame"])

    else:
        active = Path(WIN_HOME) / "mame"
        if active.exists():
            subprocess.call(["rmdir", "/q", str(active)], shell=True)
        subprocess.call(["mklink", "/j", str(active), str(path)], shell=True)


def activate_xroar(path):
    """
    Activates an XRoar version by updating the canonical symlink or junction.
    """
    if IS_LINUX:
        subprocess.call(["sudo", "rm", "-f", "/usr/local/bin/xroar"])
        subprocess.call(["sudo", "ln", "-s", str(path), "/usr/local/bin/xroar"])

    else:
        active = Path(WIN_HOME) / "xroar"
        if active.exists():
            subprocess.call(["rmdir", "/q", str(active)], shell=True)
        subprocess.call(["mklink", "/j", str(active), str(path)], shell=True)


# ---------------------------------------------------------
# PUBLIC API (used by launcher.py)
# ---------------------------------------------------------

def get_versions(action):
    """
    Returns a list of version paths for the given action.
    """
    if action == "select_mame":
        return find_mame_versions()

    if action == "select_xroar":
        return find_xroar_versions()

    return []


def activate(action, path):
    """
    Activates the selected version.
    """
    if action == "select_mame":
        activate_mame(path)

    elif action == "select_xroar":
        activate_xroar(path)

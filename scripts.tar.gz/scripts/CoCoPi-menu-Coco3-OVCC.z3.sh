#!/bin/bash
clear
export COCOPI_MENU_CALLER="/home/ron/scripts/CoCoPi-menu-Coco3-OVCC.z3.sh"
TITLE="$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)"

CHOICE=$(zenity --list \
  --title="$TITLE" \
  --width=700 --height=500 \
  --column="Option" --column="Description" \
  "1" "Tandy Color Computer 3 DECB" \
  "2" "Tandy Color Computer 3 DECB w/6309,2MB" \
  "3" "Tandy Color Computer 3 DECB w/6309 & ORCH90" \
  "4" "Tandy Color Computer 3 HDB-DOS" \
  "5" "Tandy Color Computer 3 HDB-DOS w/6309,2MB & NitrOS9 EOU" \
  "6" "Tandy Color Computer 3 HDB-DOS w/6309,2MB,Fuzix & pyDW" \
  "7" "Tandy Color Computer 3 HDB-DOS w/6309,2MB,Fuzix & lwwire" \
  "8" "Tandy Color Computer 3 HDB-DOS w/PLATO" \
  "9" "Tandy Color Computer 3 YA-DOS w/6309,2MB & HDD" \
  "10" "Return to Main Menu"
)

case $CHOICE in
  "1") $HOME/.ovcc/coco3-decb-OVCC.sh;;
  "2") $HOME/.ovcc/coco3-decb-6309-2MB-OVCC.sh;;
  "3") $HOME/.ovcc/coco3-decb-6309-ORCH90-OVCC.sh;;
  "4") $HOME/.ovcc/coco3-hdbdos-OVCC.sh;;
  "5") $HOME/.ovcc/coco3-hdbdos-6309-nitros9-OVCC.sh;;
  "6") $HOME/.ovcc/coco3-Fuzix-pyDW-OVCC.sh;;
  "7") $HOME/.ovcc/coco3-Fuzix-lwwire-OVCC.sh;;
  "8") $HOME/.ovcc/coco3-hdbdos-pyDW-PLATO-OVCC.sh;;
  "9") $HOME/.ovcc/coco3-yados-HD-6309-mpi-OVCC.sh;;
  "10") menu;;
  "*") echo "Quitting...";;
  *) echo "Quitting...";;
esac

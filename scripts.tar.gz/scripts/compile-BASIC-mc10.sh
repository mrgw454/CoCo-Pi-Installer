#!/bin/bash
set -e

# ------------------------------------------------------------
# compile-BASIC-mc10.sh
# Compile MC-10 BASIC using mcbasic, then hand off to makeWAV-mc10.sh
# ------------------------------------------------------------

FILE="$1"
EMU="$2"

# ------------------------------------------------------------
# Help / Syntax
# ------------------------------------------------------------
if [[ -z "$FILE" || "$FILE" == "--help" || "$FILE" == "-h" ]]; then
    echo ""
    echo "compile-BASIC-mc10.sh - Compile MC-10 BASIC using mcbasic"
    echo ""
    echo "USAGE:"
    echo "  ./compile-BASIC-mc10.sh <file> <mame|xroar|trs80gp|mcx128|none>"
    echo ""
    echo "NOTES:"
    echo "  - 'none' = compile-only mode (used by VS Code)"
    echo "  - No emulator argument defaults to XRoar"
    echo ""
    exit 0
fi

# Default emulator is XRoar if none specified
if [[ -z "$EMU" ]]; then
    EMU="xroar"
fi

MCBASIC="/usr/local/bin/mcbasic"

DIR="$(pwd)"
BASE="$(basename "$FILE")"
NAME="${BASE%.*}"

C10="$DIR/$NAME.c10"
WAV="$DIR/$NAME.wav"

# Clean old outputs
rm -f "$C10" "$WAV"

# Compile
echo "Compiling $FILE ..."
"$MCBASIC" -native -el -v "$FILE"
echo ""

if [[ ! -f "$C10" ]]; then
    echo "ERROR: Compilation failed. No .C10 file produced."
    exit 1
fi

# Mark that this run produced a compiled .c10
touch "$DIR/.mcbasic_c10"
touch "$DIR/.last_was_mcbasic"

# VS Code compile-only mode
if [[ "$EMU" == "none" ]]; then
    echo "Compile-only mode: skipping WAV build and emulator launch."
    exit 0
fi

# Determine model
MODEL="mc10"
if [[ "$EMU" == "mcx128" ]]; then
    MODEL="mcx128"
    EMU="mame"
fi

# Hand off to WAV builder + emulator launcher
/home/ron/scripts/makeWAV-mc10.sh "$MODEL" "$EMU"

exit 0

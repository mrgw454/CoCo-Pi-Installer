#!/usr/bin/env bash
# setup-apt-packages.sh
# Installs system packages required for CoCo-Pi Launcher and related tools.
#
# Covers: build dependencies for all emulators and dev tools, pyenv/Python,
# DriveWire4/Java, VS Code, serial port utilities, fonts, and optional services.
#
# Run this once on a fresh Debian 13 (amd64 or arm64) or Raspberry Pi OS install.
# Re-running is safe — apt skips already-installed packages.
#
# Usage:
#   bash setup-apt-packages.sh
#
# Optional flags (edit variables below or pass as environment overrides):
#   INSTALL_SAMBA=1   — install Samba for network share support
#   INSTALL_TELNETD=1 — install telnet daemon (for telnet-based serial access)

set -euo pipefail

# -------------------------------------------------------
# Options — set to 1 to enable optional components
# -------------------------------------------------------
INSTALL_SAMBA="${INSTALL_SAMBA:-0}"
INSTALL_TELNETD="${INSTALL_TELNETD:-0}"

# -------------------------------------------------------
# Detect environment
# -------------------------------------------------------
systemtype=$(dpkg --print-architecture)

WSL=0
if uname -a | grep -qi "WSL"; then
    WSL=1
fi

userid=$(whoami)

echo "=============================================================="
echo " CoCo-Pi Launcher — system package setup"
echo "=============================================================="
echo
echo "Architecture : $systemtype"
echo "WSL          : $WSL"
echo "User         : $userid"
echo
read -p "Press Enter to continue or Ctrl-C to abort..." -r
echo

# -------------------------------------------------------
# Remove stale apt sources (cdrom entries cause errors on headless installs)
# -------------------------------------------------------
sudo sed -i '/cdrom/d' /etc/apt/sources.list 2>/dev/null || true

sudo apt update
sudo apt -y autoremove

# -------------------------------------------------------
# Core utilities
# -------------------------------------------------------
echo "--- Core utilities ---"
sudo apt -y install \
    git curl wget \
    screen \
    dos2unix \
    net-tools \
    xxd \
    xclip \
    plocate \
    p7zip p7zip-full \
    meld \
    minicom \
    putty putty-tools \
    mc \
    subversion mercurial \
    rhash \
    socat setserial

# -------------------------------------------------------
# Build infrastructure
# -------------------------------------------------------
echo "--- Build infrastructure ---"
sudo apt -y install \
    build-essential cmake pkg-config \
    bison flex texinfo intltool \
    markdown cpanminus \
    libssl-dev zlib1g-dev libbz2-dev \
    libreadline-dev libsqlite3-dev \
    libffi-dev liblzma-dev \
    xz-utils tk-dev \
    llvm \
    libncurses5-dev libncursesw5-dev \
    libgmp-dev libmpfr-dev libmpc-dev \
    clang

# -------------------------------------------------------
# Python / pyenv build dependencies
# (make-python3-pyenv.sh needs these to compile Python from source)
# -------------------------------------------------------
echo "--- Python / pyenv dependencies ---"
sudo apt -y install \
    python3-openssl python3-pip python3-dev \
    python3-setuptools

# -------------------------------------------------------
# XRoar and trs80gp build dependencies
# -------------------------------------------------------
echo "--- XRoar / trs80gp build dependencies ---"
sudo apt -y install \
    libsdl2-dev libsdl2-ttf-dev \
    libfontconfig-dev \
    libpulse-dev \
    libsndfile1-dev \
    libgtk2.0-dev libgtk-3-dev \
    libasound2-dev \
    qtbase5-dev qtbase5-dev-tools qtchooser qt5-qmake \
    libao-dev

# libgtkglext1-dev — needed for XRoar OpenGL support (amd64 only)
if [ "$systemtype" = "amd64" ]; then
    sudo apt -y install libgtkglext1-dev
fi

# -------------------------------------------------------
# MAME build dependencies
# -------------------------------------------------------
echo "--- MAME build dependencies ---"
sudo apt -y install \
    libgl1-mesa-dev \
    libx11-dev libxext-dev libxrender-dev libxrandr-dev libxpm-dev \
    libglew-dev \
    libcurl4-openssl-dev \
    libtinfo6 \
    libgpm-dev \
    nodejs npm \
    nala

# -------------------------------------------------------
# DriveWire4 (Java-based disk server)
# -------------------------------------------------------
echo "--- DriveWire4 / Java ---"
sudo apt -y install \
    openjdk-21-jdk ant maven \
    libswt-gtk-4-java libswt-gtk-4-jni \
    libswt-webkit-gtk-4-jni \
    libharfbuzz-icu0 libhyphen0 \
    libjavascriptcoregtk-4.1-0 \
    libmanette-0.2-0 libwoff1 \
    xdg-dbus-proxy

# -------------------------------------------------------
# Flashfloppy / Greaseweazle (STM32 floppy bridge tools)
# -------------------------------------------------------
echo "--- Greaseweazle / Flashfloppy tools ---"
sudo apt -y install \
    gcc-arm-none-eabi srecord stm32flash \
    zip unzip \
    python3-intelhex python3-crcmod

# -------------------------------------------------------
# fastfetch (neofetch replacement — used in .bashrc on SSH login)
# -------------------------------------------------------
echo "--- fastfetch ---"
sudo apt -y install fastfetch
if [ ! -f /usr/bin/neofetch ] && [ ! -L /usr/bin/neofetch ]; then
    sudo ln -s /usr/bin/fastfetch /usr/bin/neofetch
    echo "Created /usr/bin/neofetch → fastfetch symlink"
fi

# -------------------------------------------------------
# Source Code Pro font (used in PuTTY and terminal)
# -------------------------------------------------------
echo "--- Source Code Pro font ---"
SCP_URL="https://github.com/adobe-fonts/source-code-pro/releases/download/2.042R-u%2F1.062R-i%2F1.026R-vf/TTF-source-code-pro-2.042R-u_1.062R-i.zip"
SCP_ZIP="/tmp/source-code-pro.zip"

if [ ! -d "$HOME/.fonts" ]; then
    mkdir -p "$HOME/.fonts"
fi

wget -q -O "$SCP_ZIP" "$SCP_URL"
unzip -j -o "$SCP_ZIP" -d "$HOME/.fonts"
fc-cache -f
rm -f "$SCP_ZIP"
echo "Source Code Pro installed to ~/.fonts"

# -------------------------------------------------------
# VS Code
# Skipped if already installed; installs Microsoft apt repo otherwise.
# -------------------------------------------------------
echo "--- VS Code ---"
if dpkg -l code >/dev/null 2>&1; then
    echo "VS Code already installed — skipping."
else
    sudo apt -y install wget gpg apt-transport-https
    wget -qO- https://packages.microsoft.com/keys/microsoft.asc \
        | gpg --dearmor > /tmp/packages.microsoft.gpg
    sudo install -D -o root -g root -m 644 \
        /tmp/packages.microsoft.gpg \
        /etc/apt/keyrings/packages.microsoft.gpg
    sudo sh -c 'echo "deb [arch=amd64,arm64,armhf signed-by=/etc/apt/keyrings/packages.microsoft.gpg] https://packages.microsoft.com/repos/code stable main" \
        > /etc/apt/sources.list.d/vscode.list'
    rm -f /tmp/packages.microsoft.gpg
    sudo apt update
    sudo apt -y install code
    echo "VS Code installed."
fi

# -------------------------------------------------------
# Optional: Samba (for sharing /media/share1 over the network)
# -------------------------------------------------------
if [ "$INSTALL_SAMBA" -eq 1 ]; then
    echo "--- Samba ---"
    sudo apt -y install samba samba-common-bin smbclient cifs-utils
    echo
    echo "Samba installed. You will need to set a Samba password for $userid:"
    echo "  sudo smbpasswd -a $userid"
    echo
    echo "A sample smb.conf entry for /media/share1 can be found in the"
    echo "CoCo-Pi Launcher docs."
fi

# -------------------------------------------------------
# Optional: telnet daemon
# (useful for telnet-based access from real CoCo hardware or terminal emulators)
# -------------------------------------------------------
if [ "$INSTALL_TELNETD" -eq 1 ]; then
    echo "--- telnetd ---"
    sudo apt -y install inetutils-telnet inetutils-telnetd inetutils-inetd

    if [ -f /etc/inetd.conf ]; then
        backupdate=$(date +"%Y%m%d_%H%M%S")
        sudo cp /etc/inetd.conf /etc/inetd.conf."$backupdate"
        sudo sed -i 's|#<off># telnet|telnet|' /etc/inetd.conf

        process=$(pidof inetutils-inetd 2>/dev/null || true)
        if [ -z "$process" ]; then
            sudo inetutils-inetd
            echo "inetd started ($(pidof inetutils-inetd))."
        else
            sudo kill "$process"
            sudo inetutils-inetd
            echo "inetd restarted ($(pidof inetutils-inetd))."
        fi
    fi
fi

# -------------------------------------------------------
# Final cleanup
# -------------------------------------------------------
sudo apt -y autoremove

echo
echo "=============================================================="
echo " Done. Reboot recommended before building emulators."
echo "=============================================================="
echo

#!/bin/bash
#
# SID Browser + Player (Verified Edition)
# ---------------------------------------
# Requirements (install with apt):
#   sudo apt install fzf sidplayfp unrar
#
# HVSC Setup:
#   Download the HVSC archive from:
#     https://hvsc.brona.dk/HVSC/HVSC_84-all-of-them.rar
#
#   Or from the main HVSC downloads page:
#     https://www.hvsc.c64.org/downloads
#
#   Extract it so that the directory structure looks like:
#     /media/share1/SID/C64Music/...
#
#   (The archive already contains the C64Music root folder.)
#

HVSC_ROOT="/media/share1/SID/C64Music"

# Verify HVSC exists
if [ ! -d "$HVSC_ROOT" ]; then
    echo "ERROR: HVSC directory not found at: $HVSC_ROOT"
    exit 1
fi

# Detect metadata tool availability
if command -v sidinfo >/dev/null 2>&1; then
    META_TOOL="sidinfo"
elif command -v psid >/dev/null 2>&1; then
    META_TOOL="psid"
else
    META_TOOL=""
fi

# Configure preview behavior
if [ -n "$META_TOOL" ]; then
    PREVIEW_HEADER=$'\x1b[36mENTER=Play  ESC=Quit  F1=Help  CTRL-H=Toggle Preview  / Search  PGUP/PGDN Jump\x1b[0m'
    PREVIEW_ARGS=(
        --bind "ctrl-h:toggle-preview"
        --preview "$META_TOOL \"$HVSC_ROOT/{}\""
        --preview-window "right:50%"
    )
else
    PREVIEW_HEADER=$'\x1b[36mENTER=Play  ESC=Quit  F1=Help  / Search  PGUP/PGDN Jump  (no preview tool available)\x1b[0m'
    PREVIEW_ARGS=(
        --preview-window "hidden"
    )
fi

# Help text for F1 toggle
HELP_TEXT=$'SID Browser Help\n\n\
ENTER      Play tune\n\
ESC        Quit browser\n\
F1         Show this help screen\n\
CTRL-H     Toggle preview visibility (when available)\n\
/          Search\n\
TAB        Next match\n\
SHIFT-TAB  Previous match\n\
PGUP/PGDN  Jump by pages\n\
HOME/END   Jump to top/bottom\n\n\
Use fuzzy search to jump anywhere instantly.\nExamples:\n  apollo\n  mus a ap\n  m/a/ap'

# Help mode function
show_help() {
    echo -e "$HELP_TEXT" | fzf --ansi \
        --header=$'\x1b[35mSID Browser Help — Press ENTER to return\x1b[0m' \
        --preview-window=hidden \
        --no-sort \
        --no-multi \
        --no-hscroll \
        --no-separator \
        --bind "enter:abort"
}

# Help mode entry point
if [ "$1" == "--help-mode" ]; then
    show_help
    exit 0
fi

# Main loop
while true; do
    FILE=$(
        find "$HVSC_ROOT" -type f -iname "*.sid" \
        | sed "s|$HVSC_ROOT/||" \
        | awk -F'/' '{
              dir=$0; file=$NF; sub("/"file"$", "", dir);
              if (dir == "") dir=".";
              printf "%-60s  %s\n", dir, file;
          }' \
        | fzf --ansi \
              --prompt="SID> " \
              --header="$PREVIEW_HEADER" \
              --bind "f1:execute($0 --help-mode)+abort" \
              --color=fg:#d0d0d0,bg:#202020,hl:#ffaf00 \
              --color=fg+:#ffffff,bg+:#303030,hl+:#ffaf00 \
              --color=info:#87afff,prompt:#5fd7ff,pointer:#ff5f5f \
              --color=marker:#5fff5f,spinner:#ffaf00,header:#87af87 \
              "${PREVIEW_ARGS[@]}"
    )

    [ -z "$FILE" ] && exit 0

    # Recover the original path from the formatted line:
    DIR=$(echo "$FILE" | sed 's/  .*//' | sed 's/[[:space:]]*$//')
    BASENAME=$(echo "$FILE" | sed 's/^.*  //')
    RELPATH="$DIR/$BASENAME"
    [ "$DIR" = "." ] && RELPATH="$BASENAME"

    sidplayfp "$HVSC_ROOT/$RELPATH"
done

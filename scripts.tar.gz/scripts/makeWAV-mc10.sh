#!/bin/bash
set -e

MODEL="$1"
EMULATOR="$2"

PROJECT_DIR="$(pwd)"

# Uppercase cassette base name and extensions
CASSETTE_RAW="$(basename "$PROJECT_DIR")"
CASSETTE="${CASSETTE_RAW^^}"

WAV="$CASSETTE.WAV"
C10="$CASSETTE.C10"

echo "Project folder: $PROJECT_DIR"
echo "Cassette images: $WAV and $C10"
echo ""

# ------------------------------------------------------------
# 1. RENAME FILESYSTEM FILENAMES TO UPPERCASE (for MCX128 EMCEE)
# ------------------------------------------------------------
echo "Renaming filesystem filenames to uppercase for EMCEE..."

shopt -s nullglob

for FILE in *; do
    [[ -f "$FILE" ]] || continue

    UPPER="$(echo "$FILE" | tr '[:lower:]' '[:upper:]')"

    if [[ "$FILE" != "$UPPER" ]]; then
        echo "Renaming: $FILE → $UPPER"
        mv "$FILE" "$UPPER"
    fi
done

echo ""

# ------------------------------------------------------------
# 2. CREATE NEW CASSETTE IMAGES
# ------------------------------------------------------------
echo "Creating new cassette images..."

if [[ -f "$PROJECT_DIR/.mcbasic_c10" ]]; then
    echo "Detected mcbasic-compiled .c10 — preserving existing .c10"
    rm "$PROJECT_DIR/.mcbasic_c10"
else
    EXISTING=()
    [[ -f "$WAV" ]] && EXISTING+=("$WAV")
    [[ -f "$C10" ]] && EXISTING+=("$C10")

    if (( ${#EXISTING[@]} > 0 )); then
        STAMP="$(date +%Y%m%d-%H%M%S)"
        BACKUP_DIR="$PROJECT_DIR/$STAMP"
        mkdir -p "$BACKUP_DIR"
        for f in "${EXISTING[@]}"; do
            cp "$f" "$BACKUP_DIR/"
        done
        echo "Backed up existing cassette images to $BACKUP_DIR"
        echo ""
    fi

    cecb bulkerase "$C10"
fi

cecb bulkerase "$WAV"
echo ""

# ------------------------------------------------------------
# 3. INTERNAL CASSETTE FILENAME RULES (DECB)
# ------------------------------------------------------------
declare -A RULES=(
    [".BAS"]="-0 -a -l -t"
    [".BIN"]="-2 -b"
    [".TXT"]="-3 -a"
)

DEFAULT_FLAGS="-2 -b"

convert_to_decb() {
    local name="$1"
    name="${name^^}"
    name="${name// /}"
    name="${name%.*}"
    echo "${name:0:8}"
}

echo "Copying files into cassette images..."
echo ""

shopt -s nullglob nocasematch

for FILE in *; do
    [[ -f "$FILE" ]] || continue

    # --------------------------------------------------------
    # *** CRITICAL FIX ***
    # Skip cassette output files so they NEVER get copied
    # into themselves (prevents 25MB WAV/C10 explosions)
    # --------------------------------------------------------
    if [[ "$FILE" == "$WAV" || "$FILE" == "$C10" ]]; then
        continue
    fi

    EXT="${FILE##*.}"
    EXT=".$EXT"
    EXT="${EXT^^}"

    FLAGS="${RULES[$EXT]:-$DEFAULT_FLAGS}"
    UPPERNAME="$(convert_to_decb "$FILE")"

    echo "Copying $FILE as ${UPPERNAME^^}"

    cecb -z copy $FLAGS "$FILE" "$WAV,${UPPERNAME^^}"
    cecb -z copy $FLAGS "$FILE" "$C10,${UPPERNAME^^}"
done

echo ""
echo "Cassette build complete."
echo ""

# ------------------------------------------------------------
# 4. STOP IF NO EMULATOR REQUESTED
# ------------------------------------------------------------
if [[ -z "$EMULATOR" ]]; then
    echo "No emulator requested."
    rm -f "$PROJECT_DIR/.last_was_mcbasic"
    exit 0
fi

# ------------------------------------------------------------
# 5. DECIDE WHAT TO LOAD
# ------------------------------------------------------------
if [[ "$EMULATOR" == "trs80gp" ]]; then
    LOADFILE="$C10"
elif [[ -f "$PROJECT_DIR/.mcbasic_c10" || -f "$PROJECT_DIR/.last_was_mcbasic" ]]; then
    LOADFILE="$C10"
else
    LOADFILE="$WAV"
fi

rm -f "$PROJECT_DIR/.last_was_mcbasic" "$PROJECT_DIR/.mcbasic_c10"

# ------------------------------------------------------------
# 6. EMULATOR LAUNCH
# ------------------------------------------------------------

# MCX128 EMCEE MODE
if [[ "$EMULATOR" == "mame" && "$MODEL" == "mcx128" ]]; then
    echo "Setting EMCEE directory to $PROJECT_DIR (instance 1)"
    "$HOME/pyDriveWire/pyDwCli" http://localhost:6800 dw instance select 1
    "$HOME/pyDriveWire/pyDwCli" http://localhost:6800 mc setdir "$PROJECT_DIR"

    if [[ -f "$HOME/.mame/.optional_mame_parameters.txt" ]]; then
        MAMEPARMSFILE=$(cat "$HOME/.mame/.optional_mame_parameters.txt")
        export MAMEPARMS=$MAMEPARMSFILE
    else
        MAMEPARMS=""
    fi

    mame -homepath "$HOME/.mame" \
         mc10 \
         -ext mcx128 \
         -rs232 null_modem \
         -bitb socket.localhost:6809 \
         $MAMEPARMS

    echo "Restoring pyDriveWire instance 0 and default EMCEE directory"
    "$HOME/pyDriveWire/pyDwCli" http://localhost:6800 dw instance select 0
    "$HOME/pyDriveWire/pyDwCli" http://localhost:6800 mc setdir /media/share1/JIMG

    exit 0
fi

# MC-10 CASSETTE MODE
if [[ "$EMULATOR" == "mame" && "$MODEL" == "mc10" ]]; then
    if [[ -f "$HOME/.mame/.optional_mame_parameters.txt" ]]; then
        MAMEPARMSFILE=$(cat "$HOME/.mame/.optional_mame_parameters.txt")
        export MAMEPARMS=$MAMEPARMSFILE
    else
        MAMEPARMS=""
    fi

    mame -homepath "$HOME/.mame" mc10 -cass "$LOADFILE" $MAMEPARMS
    exit 0
fi

# XRoar
if [[ "$EMULATOR" == "xroar" ]]; then
    if [[ -f "$HOME/.xroar/.optional_xroar_parameters.txt" ]]; then
        XROARPARMSFILE=$(cat "$HOME/.xroar/.optional_xroar_parameters.txt")
        export XROARPARMS=$XROARPARMSFILE
    else
        XROARPARMS=""
    fi

    xroar \
        -default-machine "$MODEL" \
        -ram 20k \
        -load "$LOADFILE" \
        $XROARPARMS
    exit 0
fi

# trs80gp
if [[ "$EMULATOR" == "trs80gp" ]]; then
    if [[ -f "$HOME/.trs80gp/.optional_trs80gp_parameters.txt" ]]; then
        TRS80GPPARMSFILE=$(cat "$HOME/.trs80gp/.optional_trs80gp_parameters.txt")
        export TRS80GPPARMS=$TRS80GPPARMSFILE
    else
        TRS80GPPARMS=""
    fi

    trs80gp $TRS80GPPARMS -mc10 -c "$LOADFILE"
    exit 0
fi

echo "Unknown emulator: $EMULATOR"
exit 1

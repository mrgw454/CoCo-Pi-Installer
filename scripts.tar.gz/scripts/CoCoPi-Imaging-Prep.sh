#!/bin/bash

# script to prepare filesystem for distribution image creation


rm -rf !(carts|cassette|cassette-dragon|DW4|EMU|MCX|samples|SDC|SDC-Dragon|software|source)

echo
echo

checkdir="$HOME/.ssh"

if [ -z "$(ls -A "$checkdir")" ]; then
  echo "$checkdir is empty."
  echo
else
  echo "$checkdir is not empty.  Removing all files..."
  echo
  rm -r -f $checkdir/*
fi

echo
echo


checkdir="/tmp"

if [ -z "$(ls -A "$checkdir")" ]; then
  echo "$checkdir is empty."
  echo
else
  echo "$checkdir is not empty.  Removing all files..."
  echo
  sudo rm -r -f $checkdir/*
fi


checkdir="/media/share1/SDC"

if [ -z "$(ls -A "$checkdir")" ]; then
  echo "$checkdir is empty."
  echo
else
  echo "$checkdir is not empty.  Removing all files..."
  echo
  sudo rm -r -f $checkdir/*
fi

echo
echo


if [ -f $HOME/error.log ]; then
  rm error.log
fi

if [ -f $HOME/.bash_history ]; then
  rm .bash_history
fi

echo
echo

echo Done!
echo

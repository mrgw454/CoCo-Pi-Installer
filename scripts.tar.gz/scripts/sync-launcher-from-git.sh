#!/usr/bin/env bash
# sync-launcher-from-git.sh
# Pulls the latest CoCo-Pi Launcher from GitHub and deploys it to Linux.
#
# Works on: Debian 13 native, g814fp laptop, any Linux with the repo cloned.
# Looks for the repo at common paths; set REPO_ROOT manually if yours differs.
#
# Usage:
#   ./sync-launcher-from-git.sh           # deploy
#   ./sync-launcher-from-git.sh --dry-run # preview without writing

set -euo pipefail

DRY_RUN=false
[[ "${1:-}" == "--dry-run" ]] && DRY_RUN=true

# -------------------------------------------------------
# Locate repo root — works whether run from inside the repo
# or from ~/scripts/ after being deployed there
# -------------------------------------------------------
_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_candidate="$(cd "$_script_dir/../.." && pwd)"

if [[ -d "$_candidate/unified" ]]; then
    REPO_ROOT="$_candidate"
elif [[ -d "$HOME/source/CoCo-Pi-Launcher/unified" ]]; then
    REPO_ROOT="$HOME/source/CoCo-Pi-Launcher"
elif [[ -d "$HOME/source-CoCo-Pi/CoCo-Pi-Launcher/unified" ]]; then
    REPO_ROOT="$HOME/source-CoCo-Pi/CoCo-Pi-Launcher"
else
    echo "ERROR: Cannot find repo. Clone it or set REPO_ROOT manually." >&2
    exit 1
fi

LAUNCHER="$HOME/scripts/launcher"
SCRIPTS="$HOME/scripts"
PYDW="$HOME/pyDriveWire"
VSCODE_TASKS="$HOME/.config/Code/User/tasks.json"

MODE_TAG=""
$DRY_RUN && MODE_TAG=" [DRY-RUN]"

count_new=0; count_updated=0; count_identical=0

echo "=== CoCo-Pi Launcher Sync from Git$MODE_TAG ==="
echo "Repo:     $REPO_ROOT"
echo "Launcher: $LAUNCHER"

# -------------------------------------------------------
# git pull
# -------------------------------------------------------
echo ""
echo "--- git pull ---"
git -C "$REPO_ROOT" pull
GIT_INFO="$(git -C "$REPO_ROOT" log -1 --format="%h %ad" --date=short)"

# Write git_info.txt to launcher dir so launcher.py can display commit/date
if ! $DRY_RUN; then
    mkdir -p "$LAUNCHER"
    echo "$GIT_INFO" > "$LAUNCHER/git_info.txt"
    echo "  [git_info] $GIT_INFO"
fi

# -------------------------------------------------------
# Helpers
# -------------------------------------------------------
deploy_file() {
    local src="$1" dst="$2"
    if [[ ! -f "$src" ]]; then
        echo "  [!] MISSING: $src"
        return
    fi
    if [[ ! -f "$dst" ]]; then
        tag="NEW"
    elif [[ "$(sha256sum "$src" | cut -d' ' -f1)" == "$(sha256sum "$dst" | cut -d' ' -f1)" ]]; then
        echo "  [=] $(basename "$dst")"
        (( count_identical++ )) || true
        return
    else
        tag="UPDATED"
    fi
    echo "  [$tag] $dst"
    [[ "$tag" == "NEW" ]]     && (( count_new++ ))     || true
    [[ "$tag" == "UPDATED" ]] && (( count_updated++ )) || true
    if ! $DRY_RUN; then
        mkdir -p "$(dirname "$dst")"
        cp -p "$src" "$dst"
    fi
}

deploy_dir() {
    local src="$1" dst="$2"; shift 2
    local excludes=("$@")
    if [[ ! -d "$src" ]]; then
        echo "  [!] MISSING dir: $src"
        return
    fi
    echo "  [DIR] $(basename "$src")  ->  $dst"
    local rsync_args=(-rvc --checksum --delete)
    for ex in "${excludes[@]}"; do
        rsync_args+=(--exclude="$ex")
    done
    $DRY_RUN && rsync_args+=(--dry-run)
    rsync "${rsync_args[@]}" "$src/" "$dst/" \
        | grep -Ev '^(sending|sent|total|receiving|$|\./)' \
        | sed 's/^/    /' || true
}

# -------------------------------------------------------
# unified/ -> ~/scripts/launcher/
# -------------------------------------------------------
echo ""
echo "--- Unified launcher ---"
deploy_file "$REPO_ROOT/unified/launcher.py"         "$LAUNCHER/launcher.py"
deploy_file "$REPO_ROOT/unified/audit_all.py"        "$LAUNCHER/audit_all.py"
deploy_file "$REPO_ROOT/unified/audit_all.ps1"       "$LAUNCHER/audit_all.ps1"
deploy_file "$REPO_ROOT/unified/version_selector.py" "$LAUNCHER/version_selector.py"
deploy_dir  "$REPO_ROOT/unified/config"              "$LAUNCHER/config"
deploy_dir  "$REPO_ROOT/unified/tools"               "$LAUNCHER/tools"
deploy_dir  "$REPO_ROOT/unified/assets"              "$LAUNCHER/assets"
deploy_dir  "$REPO_ROOT/unified/vscode-extension"    "$LAUNCHER/vscode-extension"
deploy_dir  "$REPO_ROOT/unified/maintenance"         "$LAUNCHER/maintenance"
deploy_dir  "$REPO_ROOT/unified/.vscode"             "$LAUNCHER/.vscode"
deploy_dir  "$REPO_ROOT/unified/templates"           "$LAUNCHER/templates"

# -------------------------------------------------------
# linux/scripts/launcher/ supplement -> ~/scripts/launcher/
# -------------------------------------------------------
echo ""
echo "--- Linux launcher supplement ---"
deploy_file "$REPO_ROOT/linux/scripts/launcher/create-launcher-shortcut.sh" \
            "$LAUNCHER/create-launcher-shortcut.sh"
$DRY_RUN || chmod +x "$LAUNCHER/create-launcher-shortcut.sh"

# -------------------------------------------------------
# linux/scripts/*.sh -> ~/scripts/
# -------------------------------------------------------
echo ""
echo "--- Linux scripts ---"
while IFS= read -r -d '' src; do
    fname="$(basename "$src")"
    deploy_file "$src" "$SCRIPTS/$fname"
    $DRY_RUN || chmod +x "$SCRIPTS/$fname"
done < <(find "$REPO_ROOT/linux/scripts" -maxdepth 1 -name "*.sh" \
              -not -name "sync-launcher-from-git.sh" -print0)

# -------------------------------------------------------
# linux/pyDriveWire/ -> ~/pyDriveWire/
# -------------------------------------------------------
if [[ -d "$REPO_ROOT/linux/pyDriveWire" ]]; then
    echo ""
    echo "--- pyDriveWire scripts ---"
    while IFS= read -r -d '' src; do
        fname="$(basename "$src")"
        deploy_file "$src" "$PYDW/$fname"
        $DRY_RUN || chmod +x "$PYDW/$fname"
    done < <(find "$REPO_ROOT/linux/pyDriveWire" -maxdepth 1 -name "*.sh" -print0)
fi

# -------------------------------------------------------
# VS Code tasks.json
# -------------------------------------------------------
echo ""
echo "--- VS Code tasks.json ---"
deploy_file "$REPO_ROOT/linux/.config/Code/User/tasks.json" "$VSCODE_TASKS"

# -------------------------------------------------------
# VS Code extension install
# -------------------------------------------------------
echo ""
echo "--- VS Code extension ---"
_vsix=$(find "$LAUNCHER/vscode-extension/coco-basic-syntax" -name "*.vsix" 2>/dev/null \
        | sort -V | tail -1)
if [[ -n "$_vsix" ]]; then
    if $DRY_RUN; then
        echo "  [dry-run] would install: $(basename "$_vsix")"
    elif command -v code &>/dev/null; then
        code --install-extension "$_vsix" 2>&1 | sed 's/^/  /'
    else
        echo "  [!] 'code' not in PATH — skipping extension install"
    fi
else
    echo "  [!] No .vsix found in vscode-extension/coco-basic-syntax"
fi

# -------------------------------------------------------
# Summary
# -------------------------------------------------------
echo ""
echo "--- Summary ---"
echo "  New:       $count_new"
echo "  Updated:   $count_updated"
echo "  Identical: $count_identical"
echo ""
echo "=== Done.$MODE_TAG ==="

# Self-update must be last: overwriting this script while bash is still reading it
# causes bash to re-read the new file content at the wrong byte offset.
deploy_file "$REPO_ROOT/linux/scripts/sync-launcher-from-git.sh" "$SCRIPTS/sync-launcher-from-git.sh"
$DRY_RUN || chmod +x "$SCRIPTS/sync-launcher-from-git.sh"

#!/bin/bash

# for WSL environments only
# needed for USB support

if [ -f /etc/wsl.conf ]; then
	echo WSL detected.
	echo
	echo " mkdir -p /run/dbus"
	sudo  mkdir -p /run/dbus

	echo "dbus-daemon --system"
	sudo dbus-daemon --system
fi

# start FujiNet PC
cd $HOME/source/fujinet-pc-AppleWin/build/dist

./run-fujinet &

#read -p "Press any key to continue... " -n1 -s

cd $HOME/source

echo
echo

ps auwx | grep fuji

echo
echo

google-chrome http://localhost:8000 &


#ddd --debugger m6809-gdb --eval-command="target remote localhost:65520"
$HOME/gdbgui//gdbgui -g /usr/local/bin/m6809-gdb --eval-command="target remote localhost:65520"

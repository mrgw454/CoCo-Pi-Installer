sudo ifconfig wlan0 down


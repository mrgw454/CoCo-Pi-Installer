#!/bin/bash

echo Setting execute permissions on all scripts in $HOME/scripts folder...
echo

chmod a+x $HOME/scripts/*.sh
chmod a+x $HOME/.mame/*.sh
chmod a+x $HOME/.mame/menu
chmod a+x $HOME/.xroar/*.sh
chmod a+x $HOME/.atari800/*.sh
chmod a+x $HOME/.sdltrs/*.sh
chmod a+x $HOME/.vice/*.sh

read -p  "Press any key to continue." -n1 -s


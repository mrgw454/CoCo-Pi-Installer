import os
import re
import shutil
import sys
from pathlib import Path

HOME = os.path.expanduser("~")
SEARCH_DIRS = [
    ".mame",
    ".xroar",
    ".trs80gp",
    ".ovcc",
    "scripts"
]

MENU_CALL_PATTERN = re.compile(r'^\s*(CoCoPi-menu.*\.sh)\s*$')
EXCLUDE_SUFFIX = ".z3.sh"
REPLACEMENT_LINE = '[ -n "$COCOPI_MENU_CALLER" ] && "$COCOPI_MENU_CALLER"\n'

def find_trailing_menu_call(lines):
    for i in reversed(range(len(lines))):
        line = lines[i].strip()
        if MENU_CALL_PATTERN.match(line):
            return i, line
    return None, None

def classify_menu_type(script_name):
    if script_name.endswith(".z3.sh"):
        return "Zenity"
    elif script_name.endswith(".sh"):
        return "Dialog"
    return "Unknown"

def audit_and_patch(patch_mode=False):
    flagged = []
    for subdir in SEARCH_DIRS:
        full_path = os.path.join(HOME, subdir)
        for root, _, files in os.walk(full_path):
            for fname in files:
                if fname.endswith(".sh") and not fname.endswith(EXCLUDE_SUFFIX):
                    path = os.path.join(root, fname)
                    with open(path, "r") as f:
                        lines = f.readlines()
                    idx, call = find_trailing_menu_call(lines)
                    if idx is not None:
                        menu_type = classify_menu_type(call)
                        suggested = REPLACEMENT_LINE.strip()
                        flagged.append((path, call, suggested, menu_type))

                        if patch_mode:
                            backup_path = path + ".bak"
                            shutil.copy2(path, backup_path)
                            lines[idx] = REPLACEMENT_LINE
                            with open(path, "w") as f:
                                f.writelines(lines)
    return flagged

def print_results(flagged, patch_mode):
    if not flagged:
        print("✅ No emulator scripts found with trailing menu calls.")
        return

    mode = "Patched" if patch_mode else "Dry-run"
    print(f"\n🔍 {mode}: Found {len(flagged)} scripts with trailing menu calls:\n")
    for path, original, suggested, menu_type in flagged:
        print(f"📄 {path}")
        print(f"   ─ Menu Type: {menu_type}")
        print(f"   ─ Original: {original}")
        print(f"   ─ Suggested: {suggested}")
        if patch_mode:
            print(f"   ✔️ Patched and backed up to {path}.bak")
        print()

if __name__ == "__main__":
    patch_mode = "--patch" in sys.argv
    results = audit_and_patch(patch_mode=patch_mode)
    print_results(results, patch_mode)

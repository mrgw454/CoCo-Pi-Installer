#!/bin/bash

# Start FujiNet-PC for AppleWin

cd $HOME/source/fujinet-pc-AppleWin/build/dist
./run-fujinet &

cd $HOME/source

echo
echo "FujiNet-PC (AppleWin) started."
echo

ps auwx | grep fujinet | grep -v grep

echo
exit

#!/bin/bash

# script to extact all files from an OS9 disk image

# syntax example:

# ./extractDSK-OS9.sh <DSK image>

# Define function for displaying error codes from Toolshed's 'decb' command

functionErrorLevel() {

        if [ $? -eq 0 ]
        then

                echo -e "Successfully extracted DSK/VHD image."
                echo -e

        else

                echo -e "Error during extract process from DSK/VHD image."
                echo -e
                read -p "Press any key to continue... " -n1 -s
                echo -e
                echo -e

        fi

}


# get name of script and place it into a variable
scriptname=`basename "$0"`


# get name of current folder and place it into a variable
floppy=`basename "$PWD"`
echo current folder $floppy

# use Toolshed's os9 command to extract all files from DSK image

os9 dsave -l -e "$1", ./
functionErrorLevel


exit 1

echo -e
echo "Done."
echo -e


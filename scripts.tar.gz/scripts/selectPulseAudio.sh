#!/bin/bash

# use proper pulse audio daemon config

# detect model of Raspberry Pi
RPI=`cat /proc/device-tree/model | cut -c14-16`

if [[ "$RPI" == "400" ]]; then
        sudo cp /etc/pulse/daemon.conf.rpi400 /etc/pulse/daemon.conf
 fi

 if [[ "$RPI" == "4 M" ]]; then
        sudo cp /etc/pulse/daemon.conf.rpi4 /etc/pulse/daemon.conf
 fi

 if [[ "$RPI" == "3 M" ]]; then
        sudo cp /etc/pulse/daemon.conf.rpi3 /etc/pulse/daemon.conf
 fi


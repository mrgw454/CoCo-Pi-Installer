#!/bin/bash

# hold packages
#apt-mark hold <package(s)>

# show held packages
sudo dpkg --get-selections | grep "hold"

# unhold held packages
#sudo apt-mark unhold <package(s)>


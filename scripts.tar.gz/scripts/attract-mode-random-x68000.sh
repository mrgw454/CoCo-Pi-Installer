#!/bin/bash

echo -e "zenity --info --width=200 --height=50 --title=\"Attract Mode\" --text=\"Click OK to cancel\nAttract Mode.\n\nProcess ID: $$\"; kill $$ &" > /tmp/cancel.sh
chmod a+x /tmp/cancel.sh; /tmp/cancel.sh &

# select random X68000 games and run for 120 seconds each

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_x68000.txt`
export MAMEPARMS=$MAMEPARMSFILE

shopt -s extglob
shopt -s nocasematch

for run in {1..100}
do

     #file=$(shuf -ezn 1 $1/* | xargs -0 -n1 echo)
	 file=$(find "$1" -type f -print0 | shuf -z | xargs -0 -n1 echo 2>/dev/null | head -n 1)
	 
     file_path="$file"

     # Extract filename with extension
     filename_with_ext=$(basename "$file_path")

     # Extract filename without extension
     filename_no_ext="${filename_with_ext%.*}"

     #echo "Original path: $file_path"
     #echo "Filename with extension: $filename_with_ext"
     #echo "Filename without extension: $filename_no_ext"

     clear
     echo
     echo
     echo
     echo
     echo
     echo
     echo
     echo

     echo "Random program $run"
     echo "file = $file"
     echo
     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     echo
     echo "Press [F10] to toggle the no throttle option (helps speed things up)."
     sleep 2

     if [[ $file == *.zip ]]; then

	sleep 2
	mame x68000 -ram 6MB -sasihd "$filename_no_ext" -seconds_to_run 480 $MAMEPARMS

     fi


     if [[ $file == *.hdf || $file == *.xm6 ]]; then

	sleep 2
	mame x68000 -ram 6MB -sasihd "$file" -seconds_to_run 480 $MAMEPARMS

     fi


     if [[ $file == *.hds ]]; then

	sleep 2
	mame x68000 -ram 6MB -flop1 /media/share1/X68000/work/MasterDisk_V2.xdf -exp1 cz6bs1 -hard1 "$file" -seconds_to_run 480 $MAMEPARMS

     fi


     if [[ $file == *.dim || $file == *.xdf ]]; then

	sleep 2
	mame x68000 -ram 6MB -flop1 "$file" -seconds_to_run 480 $MAMEPARMS


     fi


done

cd $HOME/.mame

# Menu Action Integrity Report

- `CoCoPi-menu-Attract.z3.sh` → `attract-mode-coco2-ssfm.sh` → `missing`
- `CoCoPi-menu-Attract.z3.sh` → `attract-mode-dragon64h-ssfm.sh` → `missing`
- `CoCoPi-menu-Utilities-All.z3.sh` → `$HOME/emceed/start_emceed.sh` → `missing`
- `CoCoPi-menu-Utilities-All.z3.sh` → `$HOME/emceed/stop_emceed.sh` → `missing`
- `CoCoPi-menu-Utilities-All.z3.sh` → `backupSD.sh` → `missing`
- `CoCoPi-menu-Utilities-All.z3.sh` → `$HOME/rvpn/startRVPN.sh` → `missing`
- `CoCoPi-menu-Utilities-All.z3.sh` → `$HOME/rvpn/stopRVPN.sh` → `missing`
- `CoCoPi-menu-Utilities-DriveEmu.z3.sh` → `$HOME/emceed/start_emceed.sh` → `missing`
- `CoCoPi-menu-Utilities-DriveEmu.z3.sh` → `$HOME/emceed/stop_emceed.sh` → `missing`
- `CoCoPi-menu-Utilities-RVPN.z3.sh` → `$HOME/rvpn/startRVPN.sh` → `missing`
- `CoCoPi-menu-Utilities-RVPN.z3.sh` → `$HOME/rvpn/stopRVPN.sh` → `missing`
- `CoCoPi-menu-rclone.z3.sh` → `$HOME/rclone/rclone-box.sh` → `missing`
- `CoCoPi-menu-rclone.z3.sh` → `$HOME/rclone/rclone-dropbox.sh` → `missing`
- `CoCoPi-menu-rclone.z3.sh` → `$HOME/rclone/rclone-google.sh` → `missing`
- `CoCoPi-menu-rclone.z3.sh` → `$HOME/rclone/rclone-microsoft.sh` → `missing`

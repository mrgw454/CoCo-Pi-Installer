#!/bin/bash

# loop over ColecoVision/ADAM games and run them for 120 seconds each

shopt -s extglob

for f in $1/*;

do

     clear

     echo file = "$f"
     echo

     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     echo
     sleep 2

     if [[ $f == *.dsk ]]; then

                echo DSK
		timelimit -t120 gearcoleco "$f"

     fi


     if [[ $f == *.rom ]]; then

                echo ROM
		timelimit -t120 gearcoleco "$f"

     fi


# capture ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi


done

sleep 2

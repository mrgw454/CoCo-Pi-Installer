#!/usr/bin/env bash
# setup-share1.sh
# Creates the standard /media/share1 directory structure expected by the
# CoCo-Pi Launcher and related tools (MAME, pyDriveWire, DriveWire4, etc.).
#
# Run this once on a fresh install. Re-running is safe — existing directories
# are left untouched.
#
# Usage:
#   bash setup-share1.sh

set -euo pipefail

userid=$(whoami)
SHARE1=/media/share1

echo "=============================================================="
echo " CoCo-Pi Launcher — /media/share1 setup"
echo "=============================================================="
echo

# -------------------------------------------------------
# Create /media/share1 root (needs sudo for /media)
# -------------------------------------------------------
if [ ! -d "$SHARE1" ]; then
    sudo mkdir -p "$SHARE1"
    sudo chown "$userid":"$userid" "$SHARE1"
    echo "Created $SHARE1"
else
    echo "$SHARE1 already exists — skipping root creation."
fi

# -------------------------------------------------------
# Create subdirectories (no sudo needed once root is owned by user)
# -------------------------------------------------------
dirs=(
    carts               # ROM cartridge images
    cassette            # CoCo cassette images
    cassette-dragon     # Dragon cassette images
    software/coco       # CoCo disk/tape software
    software/dragon     # Dragon disk/tape software
    software/mc10       # MC-10 software
    samples/floppy      # Floppy disk image samples
    SDC                 # SuperDrive Controller images
    SDC-dragon          # SDC images for Dragon
    MCX                 # MC-10 MCX expansion images
    DW4                 # DriveWire4 disk images
    EMU                 # Emulator-related files
    HDBDOS              # HDB-DOS hard disk images
    source/ASM          # 6809/6309 assembly source
    source/BASIC        # BASIC source files
    source/BASIC09      # BASIC09 source files
    source/C            # C source (CMOC, gcc6809)
    source/ugBasic      # ugBasic source
    source/MC-10        # MC-10 specific source
)

created=0
skipped=0

for d in "${dirs[@]}"; do
    full="$SHARE1/$d"
    if [ ! -d "$full" ]; then
        mkdir -p "$full"
        echo "  Created: $full"
        ((created++))
    else
        ((skipped++))
    fi
done

echo
echo "=============================================================="
echo " Done. $created created, $skipped already existed."
echo
echo " Default path used by launcher.py: $SHARE1"
echo " Edit SHARE1_LINUX in launcher.py if your path differs."
echo "=============================================================="
echo

#!/bin/bash
PIDFILE="/tmp/tnfsd.pid"
LOGFILE="/tmp/tnfsd.log"

echo "Starting TNFS server..."

# Remove stale PID/log
rm -f "$PIDFILE" "$LOGFILE"

# Start tnfsd in background
/usr/local/bin/tnfsd -p 16384 -r /media/share1/source >"$LOGFILE" 2>&1 &

PID=$!
echo $PID > "$PIDFILE"

sleep 1

if ps -p "$PID" >/dev/null 2>&1; then
    echo "TNFS server started (PID $PID)"
else
    echo "TNFS server failed to start."
    rm -f "$PIDFILE"
fi

import os
import re
import sys
import shutil
from pathlib import Path

HOME = os.path.expanduser("~")
REPORT_PATH = os.path.join(HOME, "scripts", "menu_integrity_report.md")

def resolve_path(menu_path, script_ref):
    base = os.path.dirname(menu_path)
    full = os.path.normpath(os.path.join(base, script_ref))
    return full

def validate_script(path):
    resolved = os.path.realpath(path)
    if not os.path.exists(resolved):
        return "missing"
    if not os.access(resolved, os.X_OK):
        return "not executable"
    try:
        with open(resolved, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except Exception as e:
        return f"unreadable ({type(e).__name__})"

    emulator_dirs = [".xroar", ".trs80gp", ".ovcc"]
    if any(dir in resolved for dir in emulator_dirs) or os.path.basename(resolved).startswith("mame"):
        if "COCOPI_MENU_CALLER" not in content:
            return "missing COCOPI_MENU_CALLER"

    return "valid"

def is_nested_menu(path):
    resolved = os.path.realpath(path)
    return os.path.basename(resolved).startswith("CoCoPi-menu") and resolved.endswith(".sh")

def extract_case_items(lines):
    items = []
    in_case = False
    for i, line in enumerate(lines):
        if re.search(r'case\s+["\']?\$?RETVAL["\']?', line):
            in_case = True
            continue
        if in_case:
            match = re.match(r'\s*["\']?(\d+)["\']?\)\s+(.*?)(?:\s*;;|\s*$)', line)
            if match:
                tag = match.group(1)
                action = match.group(2).strip()
                items.append((i, line.strip(), tag, action))
            elif re.match(r'\s*\*\)', line) or line.strip().startswith("esac"):
                in_case = False
    if not items:
        for i, line in enumerate(lines):
            match = re.match(r'\s*["\']?(\d+)["\']?\)\s+(.*?)(?:\s*;;|\s*$)', line)
            if match:
                tag = match.group(1)
                action = match.group(2).strip()
                items.append((i, line.strip(), tag, action))
    return items
def scan_menus(patch_mode=False, verbose=False, replace_menu=False, errors_only=False, zenity_only=False, dialog_only=False):
    flagged = []
    markdown = []
    replace_preview = []
    total_menus = 0
    total_entries = 0

    menu_dirs = [os.path.join(HOME, "scripts"), os.path.join(HOME, ".mame")]
    action_dirs = [os.path.join(HOME, ".xroar"), os.path.join(HOME, ".trs80gp"), os.path.join(HOME, ".ovcc"), os.path.join(HOME, "scripts")]
    skip_keywords = ["nano", "less", "cat", "echo", "clear", "sleep", "$WEBBROWSER"]

    for directory in menu_dirs:
        for fname in sorted(os.listdir(directory)):
            if not fname.startswith("CoCoPi-"):
                continue
            if zenity_only and not fname.endswith(".z3.sh"):
                continue
            if dialog_only and (fname.endswith(".z3.sh") or not fname.endswith(".sh")):
                continue
            if not fname.endswith(".z3.sh") and not (fname.endswith(".sh") and ".z" not in fname):
                continue

            path = os.path.join(directory, fname)
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    lines = f.readlines()
            except Exception as e:
                print(f"⚠️ Cannot read {fname}: {e}")
                continue

            if fname.endswith(".z3.sh"):
                is_menu = any(re.match(r'\s*["\']?\d+["\']?\)\s+.*', line) for line in lines)
                menu_type = "[Zenity]"
            else:
                is_menu = any("case" in line and "RETVAL" in line for line in lines)
                menu_type = "[Dialog]"
            if not is_menu:
                continue

            total_menus += 1
            if verbose:
                print(f"\n📂 Scanning menu: {fname} {menu_type}")

            items = extract_case_items(lines)
            for idx, raw_line, tag, action in items:
                total_entries += 1
                command_parts = [cmd.strip() for cmd in re.split(r'\s*&&\s*', action)]
                for full_cmd in command_parts:
                    script = full_cmd.split()[0]
                    if script in skip_keywords or not script.endswith(".sh"):
                        continue

                    resolved = None
                    if script == "menu":
                        resolved = os.path.realpath(os.path.join(directory, "menu"))
                    elif script.startswith("$HOME"):
                        resolved = os.path.expandvars(script)
                    elif script.startswith("~"):
                        resolved = os.path.expanduser(script)
                    elif script.startswith("/"):
                        resolved = script
                    else:
                        resolved = resolve_path(path, script)
                        if not os.path.exists(resolved):
                            for alt_dir in action_dirs:
                                test_path = os.path.join(alt_dir, script)
                                if os.path.exists(test_path):
                                    resolved = test_path
                                    break
                            else:
                                path_lookup = shutil.which(script)
                                if path_lookup:
                                    resolved = path_lookup

                    status = validate_script(resolved) if resolved else "missing"
                    if status == "valid" and is_nested_menu(resolved):
                        status += " (nested menu)"
                    if resolved and os.path.islink(resolved):
                        link_target = os.path.realpath(resolved)
                        status += f" (symlink → {os.path.basename(link_target)})"

                    entry_line = f"- `{fname}` → `{full_cmd}` → `{status}`"
                    if not errors_only or "valid" not in status:
                        markdown.append(entry_line)
                        print(entry_line)

                    if "valid" not in status:
                        flagged.append((fname, idx+1, tag, resolved or full_cmd, status))
                        if patch_mode:
                            if script == "menu":
                                lines[idx] = re.sub(r'menu;;', '"$COCOPI_MENU_CALLER";;', lines[idx])
                                lines[idx] = lines[idx].strip() + "  # AUTO-REPLACED: menu → $COCOPI_MENU_CALLER\n"
                            else:
                                lines[idx] = f"# {lines[idx].strip()}  # AUTO-COMMENTED: {status}\n"
                    elif replace_menu and script == "menu":
                        lines[idx] = re.sub(r'menu;;', '"$COCOPI_MENU_CALLER";;', lines[idx])
                        lines[idx] = lines[idx].strip() + "  # AUTO-REPLACED: menu → $COCOPI_MENU_CALLER\n"
                        replace_preview.append((fname, idx+1, "menu", "$COCOPI_MENU_CALLER"))

            if patch_mode or replace_menu:
                shutil.copy2(path, path + ".bak")
                with open(path, "w") as f:
                    f.writelines(lines)

    return flagged, markdown, replace_preview, total_menus, total_entries

def print_results(flagged, markdown, replace_preview, patch_mode, total_menus, total_entries, errors_only):
    if not flagged:
        print("\n✅ All menu entries passed deep validation.")
    else:
        print(f"\n🔍 Found {len(flagged)} flagged entries across {len(set(f[0] for f in flagged))} menus:\n")
        for fname, lineno, tag, resolved, status in flagged:
            print(f"📄 {fname}: Line {lineno} → {tag}")
            print(f"   ❌ {status}: {resolved}\n")

    if replace_preview:
        print("\n🔄 Replace Preview:")
        for fname, lineno, old, new in replace_preview:
            print(f"📄 {fname}: Line {lineno} → {old} → {new}")

    print(f"\n📊 Summary: Scanned {total_menus} menus, {total_entries} entries, {len(flagged)} flagged.")

    if not errors_only:
        print("\n📝 Markdown Summary:\n")
        print("# Menu Action Integrity Report\n")
        for line in markdown:
            print(line)

    with open(REPORT_PATH, "w") as f:
        f.write("# Menu Action Integrity Report\n\n")
        for line in markdown:
            f.write(line + "\n")

if __name__ == "__main__":
    patch_mode = "--patch" in sys.argv
    verbose_mode = "--verbose" in sys.argv
    replace_mode = "--replace-menu" in sys.argv
    errors_only = "--errors-only" in sys.argv
    zenity_only = "--zenity-only" in sys.argv
    dialog_only = "--dialog-only" in sys.argv

    flagged, markdown, replace_preview, total_menus, total_entries = scan_menus(
        patch_mode=patch_mode,
        verbose=verbose_mode,
        replace_menu=replace_mode,
        errors_only=errors_only,
        zenity_only=zenity_only,
        dialog_only=dialog_only
    )

    print_results(
        flagged,
        markdown,
        replace_preview,
        patch_mode,
        total_menus,
        total_entries,
        errors_only
    )

#!/bin/bash
clear
export COCOPI_MENU_CALLER="$HOME/scripts/CoCoPi-menu.z3.sh"
TITLE="$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)"

CHOICE=$(zenity --list \
  --title="$TITLE" \
  --width=700 --height=500 \
  --column="Option" --column="Description" \
  "1" "Sync to 'Box'" \
  "2" "Sync to 'DropBox'" \
  "3" "Sync to 'Google Drive'" \
  "4" "Sync to 'Microsoft OneDrive'" \
  "5" "Return to Utilities Menu"
)

case $CHOICE in
  "1") $HOME/rclone/rclone-box.sh && CoCoPi-menu-rclone.sh;;
  "2") $HOME/rclone/rclone-dropbox.sh && CoCoPi-menu-rclone.sh;;
  "3") $HOME/rclone/rclone-google.sh && CoCoPi-menu-rclone.sh;;
  "4") $HOME/rclone/rclone-microsoft.sh && CoCoPi-menu-rclone.sh;;
  "5") CoCoPi-menu-Utilities.z3.sh;;
  "*") echo "Quitting...";;
  "*") echo "Quitting...";;
esac

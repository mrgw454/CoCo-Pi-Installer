#!/bin/bash

shopt -s globstar
shopt -s extglob
shopt -s nocasematch

find . -name "*.pdf" -type f -exec mv {} $HOME/Downloads/PDF \;
find . -name "*.PDF" -type f -exec mv {} $HOME/Downloads/PDF \;
find . -name "*.txt" -type f -exec mv {} $HOME/Downloads/PDF \;
find . -name "*.TXT" -type f -exec mv {} $HOME/Downloads/PDF \;
find . -name "*.doc" -type f -exec mv {} $HOME/Downloads/PDF \;
find . -name "*.DOC" -type f -exec mv {} $HOME/Downloads/PDF \;
find . -name "*.bas" -type f -exec mv {} $HOME/Downloads/PDF \;
find . -name "*.BAS" -type f -exec mv {} $HOME/Downloads/PDF \;
find . -name "*.jpg" -type f -exec mv {} $HOME/Downloads/PDF \;
find . -name "*.JPG" -type f -exec mv {} $HOME/Downloads/PDF \;
find . -name "*.png" -type f -exec mv {} $HOME/Downloads/PDF \;
find . -name "*.PNG" -type f -exec mv {} $HOME/Downloads/PDF \;


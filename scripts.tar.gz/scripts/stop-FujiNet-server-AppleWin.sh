#!/bin/bash

echo "Stopping FujiNet-PC (AppleWin)..."

killall -9 fujinet 2>/dev/null

# FujiNet-PC sometimes spawns netsiohub
kill -9 $(pgrep -f netsiohub) 2>/dev/null

echo "Stopped."

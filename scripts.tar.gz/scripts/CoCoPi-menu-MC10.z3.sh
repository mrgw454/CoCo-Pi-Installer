#!/bin/bash
clear
export COCOPI_MENU_CALLER="/home/ron/scripts/CoCoPi-menu-MC10.z3.sh"
TITLE="$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)"

CHOICE=$(zenity --list \
  --title="$TITLE" \
  --width=700 --height=500 \
  --column="Option" --column="Description" \
  "1" "TRS-80 Micro Color Computer   4K" \
  "2" "TRS-80 Micro Color Computer   8K" \
  "3" "TRS-80 Micro Color Computer  20K" \
  "4" "TRS-80 Micro Color Computer  32K" \
  "5" "TRS-80 Micro Color Computer 128K (MCX BASIC) & pyDW" \
  "6" "Return to Main Menu"
)

case $CHOICE in
  "1") mc-10-4k.sh;;
  "2") mc-10-8k.sh;;
  "3") mc-10-20k.sh;;
  "4") mc-10-32k.sh;;
  "5") mc-10-MCX128-pyDW.sh;;
  "6") menu;;
  "*") echo "Quitting...";;
  *) echo "Quitting...";;
esac

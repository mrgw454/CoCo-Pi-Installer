#!/bin/bash

SAVEIFS=$IFS
IFS=$(echo -en "\n\b")

# select random Commodore 64 computer programs and run them for 120 seconds each

VICEPARMSFILE=`cat $HOME/.vice/.optional_vice_parameters.txt`
export VICEPARMS=$VICEPARMSFILE

shopt -s extglob
shopt -s nocasematch

for run in {1..200}
do

#file=$(shuf -ezn 1 $1/*.* | xargs -0 -n1 echo)
file=$(find "$1" -type f -print0 | shuf -z | xargs -0 -n1 echo 2>/dev/null | head -n 1)

     clear

     echo "Random program $run"
     echo "file = $file"
     echo

     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     echo
     sleep 2

     if [[ $file == *.crt ]]; then

                echo CRT
		$HOME/.vice/bin/x64sc -silent -limitcycles 99999999 "$file"

     fi


     if [[ $file == *.d64 ]]; then

                echo D64
		$HOME/.vice/bin/x64sc -silent -limitcycles 99999999 "$file"

     fi


     if [[ $file == *.d71 ]]; then

                echo D71
		$HOME/.vice/bin/x64sc -silent -limitcycles 99999999 "$file"

     fi


     if [[ $file == *.d81 ]]; then

                echo D81
		$HOME/.vice/bin/x64sc -silent -limitcycles 99999999 "$file"

     fi


     if [[ $file == *.g64 ]]; then

                echo G64
		$HOME/.vice/bin/x64sc -silent -limitcycles 99999999 "$file"

     fi


     if [[ $file == *.prg ]]; then

                echo PRG
		$HOME/.vice/bin/x64sc -silent -limitcycles 99999999 "$file"

     fi


done

sleep 2

# restore $IFS
IFS=$SAVEIFS

kill -9 `pgrep -f "ng serve"`

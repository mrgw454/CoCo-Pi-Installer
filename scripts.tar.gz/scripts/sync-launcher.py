#!/usr/bin/env python3
import os
import shutil
from pathlib import Path
import argparse
import filecmp
import sys
import hashlib

# ------------------------------------------------------------
# Platform / paths
# ------------------------------------------------------------

IS_WINDOWS = os.name == "nt"
IS_LINUX = os.name == "posix"

if not IS_LINUX:
    print("This sync tool must be run from Linux (Windows cannot see Linux paths).")
    sys.exit(1)

LIN_HOME = Path(os.environ.get("HOME", ""))

# Linux side
LIN_LAUNCHER = LIN_HOME / "scripts" / "launcher"
LIN_TASKS = LIN_HOME / ".config" / "Code" / "User" / "tasks.json"

# Windows side as seen from Linux
WIN_HOME = Path("/media/ron/OS/Users/Ron")
WIN_LAUNCHER = WIN_HOME / "scripts" / "launcher"
WIN_TASKS = WIN_HOME / "AppData" / "Roaming" / "Code" / "User" / "tasks.json"

# ------------------------------------------------------------
# Summary counters
# ------------------------------------------------------------

count_new = 0
count_updated = 0
count_identical = 0

# ------------------------------------------------------------
# Helpers
# ------------------------------------------------------------

def is_backup(path: Path) -> bool:
    """Ignore backup files and backup directories."""
    return any(".backup" in part for part in path.parts)


def sha256sum(path: Path) -> str:
    """Compute SHA-256 hash of a file."""
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def newer(src: Path, dst: Path) -> bool:
    """Return True if src is newer than dst or dst does not exist."""
    if not dst.exists():
        return True
    return src.stat().st_mtime > dst.stat().st_mtime


def compare_files(src: Path, dst: Path) -> str:
    """Hybrid compare: timestamp first, then hash if needed."""
    # Destination missing → NEW
    if not dst.exists():
        return "NEW"

    # If timestamps differ, verify with hashing
    if newer(src, dst):
        try:
            if sha256sum(src) == sha256sum(dst):
                return "IDENTICAL"
            else:
                return "UPDATED"
        except Exception:
            return "UPDATED"

    # If timestamps match, still verify with hashing to avoid NTFS drift
    try:
        if sha256sum(src) == sha256sum(dst):
            return "IDENTICAL"
        else:
            return "UPDATED"
    except Exception:
        return "UPDATED"


def sync_file(src: Path, dst: Path, real: bool):
    global count_new, count_updated, count_identical

    status = compare_files(src, dst)

    if status == "IDENTICAL":
        count_identical += 1
        print(f"[=] {src}")
        return

    if status == "NEW":
        count_new += 1
        print(f"[+] {src}  →  {dst}")
    elif status == "UPDATED":
        count_updated += 1
        print(f"[*] {src}  →  {dst}")

    if real:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def sync_tree(src_root: Path, dst_root: Path, real: bool):
    for src in src_root.rglob("*"):
        if is_backup(src):
            continue
        if src.is_file():
            rel = src.relative_to(src_root)
            dst = dst_root / rel
            sync_file(src, dst, real)

# ------------------------------------------------------------
# Directions
# ------------------------------------------------------------

def sync_linux_to_windows(real: bool):
    print("\n=== Linux → Windows ===")
    sync_tree(LIN_LAUNCHER, WIN_LAUNCHER, real)
    if LIN_TASKS.exists():
        sync_file(LIN_TASKS, WIN_TASKS, real)
    else:
        print(f"[!] Linux tasks.json not found: {LIN_TASKS}")


def sync_windows_to_linux(real: bool):
    print("\n=== Windows → Linux ===")
    sync_tree(WIN_LAUNCHER, LIN_LAUNCHER, real)
    if WIN_TASKS.exists():
        sync_file(WIN_TASKS, LIN_TASKS, real)
    else:
        print(f"[!] Windows tasks.json not found: {WIN_TASKS}")

# ------------------------------------------------------------
# CLI
# ------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Sync launcher between Linux and Windows (run on Linux only)")

    parser.add_argument("--real", action="store_true", help="Perform real sync (default is dry-run)")
    parser.add_argument("--direction", choices=["lin2win", "win2lin", "both"], default="lin2win")

    args = parser.parse_args()
    real = args.real
    direction = args.direction

    print(f"\nDry-run: {not real}")
    print(f"Direction: {direction}")
    print(f"Linux launcher:   {LIN_LAUNCHER}")
    print(f"Windows launcher: {WIN_LAUNCHER}")

    if direction in ("lin2win", "both"):
        sync_linux_to_windows(real)

    if direction in ("win2lin", "both"):
        sync_windows_to_linux(real)

    print("\nSummary:")
    print(f"  New:       {count_new}")
    print(f"  Updated:   {count_updated}")
    print(f"  Identical: {count_identical}")

    print("\nDone.\n")


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
set -euo pipefail

ROOT="$HOME/source/open-watcom-v2"
OUT="$HOME/.local/watcom-linux-bin"

mkdir -p "$OUT"

# Clean old binaries
find "$OUT" -type f -exec rm -f {} \;

# Find all Linux-native Watcom binaries and copy them without .exe
while IFS= read -r exe; do
    base=$(basename "$exe" .exe)
    cp "$exe" "$OUT/$base"
    chmod +x "$OUT/$base"
done < <(find "$ROOT/bld" -type f -path "*/linuxx64/*" -name "*.exe")

# Output the export statement
echo "export PATH=\"$OUT:\$PATH\""

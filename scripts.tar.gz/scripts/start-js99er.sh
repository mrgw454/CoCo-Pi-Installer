#!/bin/bash

# this for running js99er with TIPI integration

# start js99er
cd $HOME/source/js99er-angular
ng serve &

sleep 6

cd $HOME/source

echo
echo

pgrep -f "ng serve"

echo
echo

/opt/google/chrome/chrome "http://localhost:4200/" "http://192.168.0.26:9900/" &

read -p "Press any key to continue... " -n1 -s

exit

cat /proc/asound/cards
aplay -l


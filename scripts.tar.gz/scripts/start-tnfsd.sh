#!/bin/bash

/usr/local/bin/tnfsd /media/share1/DW4



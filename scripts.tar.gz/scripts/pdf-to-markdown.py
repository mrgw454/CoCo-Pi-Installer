#!/usr/bin/env python3
"""
Convert all PDFs under DOCS_ROOT to markdown, placing each .md
file alongside its source PDF.

Strategy:
  1. Try marker_single (best quality, handles layout)
  2. Fallback to pypdf text extraction (text-based PDFs only)
  3. If both fail, mark as image-only (needs OCR separately)

Skips files that already have a .md unless --overwrite is passed.
"""

import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

import pypdf

DOCS_ROOT = Path("/home/ron/mnt/readynas1/docs")
OVERWRITE = "--overwrite" in sys.argv


def find_pdfs(root):
    return sorted(root.rglob("*.pdf"))


def needs_conversion(pdf_path):
    if OVERWRITE:
        return True
    md_path = pdf_path.with_suffix(".md")
    if not md_path.exists():
        return True
    return md_path.stat().st_mtime < pdf_path.stat().st_mtime


def convert_with_marker(pdf_path):
    """Try marker_single. Returns (success, md_content_or_error)."""
    stem = pdf_path.stem
    md_path = pdf_path.with_suffix(".md")

    with tempfile.TemporaryDirectory() as tmpdir:
        result = subprocess.run(
            [
                "marker_single",
                str(pdf_path),
                "--output_dir", tmpdir,
                "--output_format", "markdown",
            ],
            capture_output=True,
            text=True,
            timeout=300,
        )

        # marker writes to tmpdir/<stem>/<stem>.md
        candidate = Path(tmpdir) / stem / f"{stem}.md"
        if not candidate.exists():
            # Try a normalized name (marker may sanitize)
            matches = list(Path(tmpdir).rglob("*.md"))
            if matches:
                candidate = matches[0]

        if candidate.exists():
            content = candidate.read_text(encoding="utf-8", errors="replace")
            if content.strip():
                return True, content

    stderr = result.stderr.strip()
    # Filter out the noisy urllib3 warning to expose the real error
    real_error = "\n".join(
        l for l in stderr.splitlines()
        if "RequestsDependencyWarning" not in l
        and "urllib3" not in l
        and "chardet" not in l
        and "warnings.warn" not in l
        and l.strip()
    )
    return False, real_error[:300] if real_error else "no output produced"


def convert_with_pypdf(pdf_path):
    """Extract text with pypdf. Returns (success, md_content_or_error)."""
    try:
        reader = pypdf.PdfReader(str(pdf_path))
        pages = []
        for i, page in enumerate(reader.pages, 1):
            text = page.extract_text() or ""
            text = text.strip()
            if text:
                pages.append(f"## Page {i}\n\n{text}")
        if pages:
            header = f"# {pdf_path.stem}\n\n*Extracted with pypdf — layout not preserved.*\n\n"
            return True, header + "\n\n---\n\n".join(pages)
        return False, "no extractable text (image-only PDF)"
    except Exception as e:
        return False, str(e)[:200]


def convert(pdf_path):
    """Try marker, fall back to pypdf. Returns (method, success, error)."""
    md_path = pdf_path.with_suffix(".md")

    ok, content = convert_with_marker(pdf_path)
    if ok:
        md_path.write_text(content, encoding="utf-8")
        return "marker", True, ""

    ok2, content2 = convert_with_pypdf(pdf_path)
    if ok2:
        md_path.write_text(content2, encoding="utf-8")
        return "pypdf", True, ""

    return "none", False, content2  # pypdf error is more informative


def main():
    pdfs = find_pdfs(DOCS_ROOT)
    to_convert = [p for p in pdfs if needs_conversion(p)]

    print(f"PDFs found      : {len(pdfs)}")
    print(f"Need conversion : {len(to_convert)}")
    print(f"Already done    : {len(pdfs) - len(to_convert)}")
    if OVERWRITE:
        print("(--overwrite mode: redoing all)")
    print()

    if not to_convert:
        print("Nothing to do.")
        return

    by_marker, by_pypdf, image_only, errors = [], [], [], []

    for i, pdf in enumerate(to_convert, 1):
        rel = pdf.relative_to(DOCS_ROOT)
        print(f"[{i}/{len(to_convert)}] {rel} ... ", end="", flush=True)
        try:
            method, success, err = convert(pdf)
            if success:
                print(f"OK ({method})")
                if method == "marker":
                    by_marker.append(str(rel))
                else:
                    by_pypdf.append(str(rel))
            else:
                if "image-only" in err:
                    print("IMAGE-ONLY (no text layer)")
                    image_only.append(str(rel))
                else:
                    print(f"FAILED: {err}")
                    errors.append(str(rel))
        except subprocess.TimeoutExpired:
            print("TIMEOUT")
            errors.append(str(rel))
        except Exception as e:
            print(f"ERROR: {e}")
            errors.append(str(rel))

    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    print(f"  Converted by marker  : {len(by_marker)}")
    print(f"  Converted by pypdf   : {len(by_pypdf)}")
    print(f"  Image-only (no text) : {len(image_only)}")
    print(f"  Errors               : {len(errors)}")
    print(f"  Total .md files now  : {len(list(DOCS_ROOT.rglob('*.md')))}")
    if image_only:
        print("\n  Image-only PDFs (need OCR):")
        for f in image_only:
            print(f"    - {f}")
    if errors:
        print("\n  Errors:")
        for f in errors:
            print(f"    - {f}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()

#!/bin/bash

cd $HOME/source

ls make*.sh | sort > source-dir-list.txt
grep make- make-ALL-packages.sh | sed 's|./||' | sed 's/#//' | sort > make-ALL-packages-list.txt
# diffuse source-dir-list.txt make-ALL-packages-list.txt &

echo
echo individual [make-*.sh] scripts not in [make-ALL-packages.sh]
echo
grep -vxf make-ALL-packages-list.txt source-dir-list.txt
echo

# housekeeping
rm make-ALL-packages-list.txt
rm source-dir-list.txt

!#/bin/bash

# greaseweazle cleaning cycle (use cleaning diskette with drive)
#gw clean --cyls=60 --passes=1

# pull head back to track 0
#gw seek 0 --motor-on

# read SSSD diskette for CoCo (c=0-39 for 40 track, c=0-34 for 35 track)
#gw read --tracks h=0:c=0-39 test.scp

# read DSSD diskette for CoCo (h=0-1 for DS, c=0-39 for 40 track, c=0-34 for 35 track)
#gw read --tracks h=0-1:c=0-39 test.scp

# read DSSD 3.5 diskette for CoCo (h=0-1 for DS, c=0-79 for 80 track)
#gw read --tracks h=0-1:c=0-79 test.scp



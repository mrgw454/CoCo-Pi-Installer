#!/bin/bash
clear
export COCOPI_MENU_CALLER="$HOME/scripts/CoCoPi-menu-MC10-trs80gp.z3.sh"
TITLE="$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)"

CHOICE=$(zenity --list \
  --title="$TITLE" \
  --width=700 --height=500 \
  --column="Option" --column="Description" \
  "1" "TRS-80 Micro Color Computer  20K" \
  "2" "Return to Main Menu"
)

case $CHOICE in
  "1") $HOME/.trs80gp/mc-10-20k-trs80gp.sh;;
  "2") menu;;
  "*") echo "Quitting...";;
  *) echo "Quitting...";;
esac

#!/bin/bash

# script to mount a DSK image on all defined pyDW hosts (local and/or remote)

# this script requires 3 command line parameters (DSK image file, instance # and pyDW DRIVE #)

# syntax example:

# ./mount-DSK-pyDW </path/to/DSK/image/file> <0,1,2, etc.> <0/1/2/3>


# get name of script and place it into a variable
scriptname=`basename "$0"`

# parse command line parameters for standard help options

echo
echo "filename   : $1"
echo "instance   : $2"
echo "drive slot : $3"
echo

if [ $# -lt 3 ]; then
	echo "Not enough arguments provided."
	echo
	echo "Example syntax:"
	echo
	echo -e "./$scriptname </path/to/DSK/image/file> <0,1,2, etc.> <0/1/2/3>"
	echo
	exit 1
fi


if [ ! -f "$HOME/scripts/mount-DSK-pyDW.txt" ]; then
    echo "pyDW host file not found!  Please add at least one host in the following file:"
    echo
    echo "mount-DSK-pyDW.txt"
    echo
    exit 1
fi


cd $HOME/pyDriveWire


# read file with pyDW hosts and process each one
serverlist=$HOME/scripts/mount-DSK-pyDW.txt
while IFS= read -r pyDWhost
do

	nc -vz $pyDWhost 6800 >&2

	if [ $? -eq 0 ]
	then

		# set HDBDOS translation to false for all pyDW hosts
		$HOME/pyDriveWire/pyDwCli http://$pyDWhost:6800 dw server hdbdos 0

		# eject DSK in selected DRIVE for selected instance
		$HOME/pyDriveWire/pyDwCli http://$pyDWhost:6800 dw instance select $2
		$HOME/pyDriveWire/pyDwCli http://$pyDWhost:6800 dw disk show
		$HOME/pyDriveWire/pyDwCli http://$pyDWhost:6800 dw disk eject $3

		# insert DSK in selected DRIVE for selected instance
		$HOME/pyDriveWire/pyDwCli http://$pyDWhost:6800 dw instance select $2
		$HOME/pyDriveWire/pyDwCli http://$pyDWhost:6800 dw disk insert $3 "$1"
		$HOME/pyDriveWire/pyDwCli http://$pyDWhost:6800 dw disk show

		# set the default instance before exiting
		$HOME/pyDriveWire/pyDwCli http://$pyDWhost:6800 dw instance select 0

	else
		echo
        	echo "$pyDWhost pyDriveWire server does not appear to be online.  Aborting."
	        echo
		echo
	fi

done < "$serverlist"


echo -e
echo "Done."
echo -e

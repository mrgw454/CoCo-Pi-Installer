clear

RPI=`cat /proc/device-tree/model | cut -c14`

 if [[ "$RPI" == 4 ]]; then
        pkill x
 fi


 if [[ "$RPI" == 3 ]]; then
        pkill x
 fi


clear

echo
echo
echo
echo
echo
echo
echo
echo

echo "The following pyDriveWire versions are available:"
echo

# set the prompt used by select, replacing "#?"
PS3="
Please select one to use as the default or 'stop' to cancel:"

# allow the user to choose a file
select filename in $HOME/source/pyDriveWire-*

do
    # leave the loop if the user says 'stop'
    if [[ "$REPLY" == stop ]]; then break; fi

    # complain if no file was selected, and loop to ask again
    if [[ "$filename" == "" ]]
    then
        echo "'$REPLY' is not a valid number"
        continue
    fi

    # now we can use the selected file
    # stop pyDW server
    echo
    $HOME/pyDriveWire/stop_pyDW.sh

    sudo rm $HOME/pyDriveWire
    sudo ln -s "$filename" $HOME/pyDriveWire
    echo
    echo Starting pyDriveWire server...
    echo
    $HOME/pyDriveWire/start_pyDW.sh
    echo
    echo "$filename" is now the default version of pyDriveWire.
    echo
    read -p "Press any key to continue... " -n1 -s
    # it'll ask for another unless we leave the loop
    break
done

cd $HOME/.mame

#!/bin/bash

find . -mtime -0 -exec touch {} \;


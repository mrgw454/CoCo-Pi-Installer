#!/bin/bash

if pgrep -f fujinet >/dev/null 2>&1; then
    PID=$(pgrep -f fujinet | head -n 1)
    echo "FujiNet-PC is running (PID $PID)"
else
    echo "FujiNet-PC is not running."
fi

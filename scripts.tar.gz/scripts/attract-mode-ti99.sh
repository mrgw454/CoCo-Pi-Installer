# loop over TI-99/4a cartridges and run them for 120 seconds each

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters.txt`
export MAMEPARMS=$MAMEPARMSFILE

shopt -s extglob
shopt -s nocasematch

for f in `ls /media/share1/software/ti99_cart/*.zip`

	do
		clear
                echo
                echo
                echo
                echo
                echo
                echo
                echo
                echo

		echo file = "$f"
                echo
                echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
		echo
		echo "Press [F10] to toggle the no throttle option (helps speed things up)."
		sleep 2
		mame ti99_4a ${f//+(*\/|.*)} -ioport peb -ioport:peb:slot4 samsmem -ioport:peb:slot5 tirs232 -ioport:peb:slot7 tifdc -seconds_to_run 120 -autoboot_delay 2 -autoboot_command '\n2' $MAMEPARMS
	done

cd $HOME/.mame


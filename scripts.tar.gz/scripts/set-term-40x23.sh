echo Setting terminal for DIALUP emulation
export TERM=dialup
echo Setting terminal for 40 x 23 size
stty rows 23 cols 40
echo -e
echo Run 'tack' to perform terminal testing.
echo -e


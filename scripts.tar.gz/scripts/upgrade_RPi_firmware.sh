sudo rpi-update


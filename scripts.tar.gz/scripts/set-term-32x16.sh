echo Setting terminal for ANSI emulation
export TERM=ansi
echo Setting terminal for 32 x 16 size
stty rows 16 cols 32
echo -e
echo Run 'tack' to perform terminal testing.
echo -e


#!/bin/bash

# convert Apple IIx disk format from 2mg to PO

shopt -s globstar
shopt -s extglob
shopt -s nocasematch


if [ -f convert-errors.txt ]; then
	rm convert-errors.txt
fi

for f in "$PWD"/**/*
do

    fullfilename="$f"
    filename=$(basename "$fullfilename")
    fname="${filename%.*}"
    filesize=$(stat -c%s "$fullfilename")
	filepath=$(dirname "$f")
    parentname="$(basename "$(dirname "$filepath")")"
	fujipath=$(echo $filepath | cut -d'/' -f4-)

#echo fullfilename $fullfilenmae
#echo filename $filename
#echo fname $fname
#echo filesize $filesize
#echo filepath $filepath
#echo parentname $parentname
#echo $fujipath

	if [[ $f == *.2MG ]]; then

		echo dd bs=64 if="$f" of="$fname.po" skip=1
		dd bs=64 if="$f" of="$filepath/$fname.po" skip=1

		java -jar $HOME/source/AppleCommander/app/cli-ac/build/libs/AppleCommander-ac-1.9.1-SNAPSHOT.jar -i "$filepath/$fname.po" > "$fname.output"
		filesize=$(stat -c%s "$fname.output")

		if [ $filesize -eq 0 ]; then
			echo "$fname" did not convert successfully.  Deleting "$fname.po" file.
        		rm "$filepath/$fname.po"
			echo "$f" >> convert-errors.txt
			echo
		else
			echo "$fname" converted successfully.
			cp --parents "$filepath/$fname.po" "/media/share1/FUJINET-APPLE"
        	rm "$filepath/$fname.po"
			echo
		fi

       		rm "$fname.output"

		echo
		echo

	fi

done

find . -type d -empty -print
find . -type d -empty -delete


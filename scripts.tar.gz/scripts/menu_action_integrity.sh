#!/bin/bash

# Initialize pyenv
export PYENV_ROOT="$HOME/.pyenv"
export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init -)"

# Activate Python 3.11.2
pyenv shell 3.11.2

# Run the audit tool with all passed arguments
python3 "$HOME/scripts/menu_action_integrity.py" "$@"

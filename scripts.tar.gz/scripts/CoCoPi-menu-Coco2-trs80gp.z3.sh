#!/bin/bash
clear
export COCOPI_MENU_CALLER="$HOME/scripts/CoCoPi-menu-Coco2-trs80gp.z3.sh"
TITLE="$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)"

CHOICE=$(zenity --list \
  --title="$TITLE" \
  --width=700 --height=500 \
  --column="Option" --column="Description" \
  "1" "TRS-80 Color Computer 2 DECB w/64K" \
  "2" "TRS-80 Color Computer 2 HDBDOS w/64K" \
  "3" "Return to Main Menu"
)

case $CHOICE in
  "1") $HOME/.trs80gp/coco2-decb-trs80gp.sh;;
  "2") $HOME/.trs80gp/coco2-hdbdos-trs80gp.sh;;
  "3") menu;;
  "*") echo "Quitting...";;
  *) echo "Quitting...";;
esac

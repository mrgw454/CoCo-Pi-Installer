#!/usr/bin/env python3
"""
OCR image-based PDFs to markdown using tesseract.
Processes only PDFs that have no .md yet (or all with --overwrite).
Places output .md alongside each PDF.

Usage:
  python3 pdf-ocr-to-markdown.py [--overwrite]

Requires:
  System: tesseract-ocr, poppler-utils (for pdftoppm)
    sudo apt install tesseract-ocr poppler-utils
  Python: pdf2image, pytesseract (auto-installed below)
"""

import subprocess
import sys
import os

# ---------------------------------------------------------------------------
# Auto-install Python dependencies
# ---------------------------------------------------------------------------

def pip_install(*packages):
    subprocess.check_call(
        [sys.executable, "-m", "pip", "install", "--quiet", *packages],
        stdout=subprocess.DEVNULL,
    )

try:
    import pdf2image
except ImportError:
    print("Installing pdf2image...")
    pip_install("pdf2image")
    import pdf2image

try:
    import pytesseract
except ImportError:
    print("Installing pytesseract...")
    pip_install("pytesseract")
    import pytesseract

try:
    import pypdf
except ImportError:
    print("Installing pypdf...")
    pip_install("pypdf")
    import pypdf

# ---------------------------------------------------------------------------
# Check system dependencies
# ---------------------------------------------------------------------------

def check_system_deps():
    missing = []
    for cmd in ("tesseract", "pdftoppm"):
        result = subprocess.run(["which", cmd], capture_output=True)
        if result.returncode != 0:
            missing.append(cmd)
    if missing:
        pkg_map = {"tesseract": "tesseract-ocr", "pdftoppm": "poppler-utils"}
        pkgs = " ".join(pkg_map[m] for m in missing)
        print(f"Missing system tools: {', '.join(missing)}")
        print(f"Install with: sudo apt install {pkgs}")
        print("Then re-run this script.")
        sys.exit(1)

check_system_deps()

# ---------------------------------------------------------------------------
# Main logic
# ---------------------------------------------------------------------------

import tempfile
from pathlib import Path

DOCS_ROOT = Path("/home/ron/mnt/readynas1/docs")
OVERWRITE = "--overwrite" in sys.argv
LANG = "eng"  # tesseract language; add '+' for multiple e.g. "eng+fra"
DPI = 300     # higher = better quality but slower


def has_text_layer(pdf_path):
    """Return True if PDF has extractable text."""
    try:
        reader = pypdf.PdfReader(str(pdf_path))
        for page in reader.pages:
            text = (page.extract_text() or "").strip()
            if len(text) > 50:
                return True
    except Exception:
        pass
    return False


def needs_ocr(pdf_path):
    md_path = pdf_path.with_suffix(".md")
    if OVERWRITE:
        return not has_text_layer(pdf_path) or True  # with --overwrite, redo all image PDFs
    if md_path.exists():
        return False
    return not has_text_layer(pdf_path)


def ocr_pdf(pdf_path):
    """Convert image PDF to markdown via tesseract. Returns (success, error)."""
    md_path = pdf_path.with_suffix(".md")
    pages_text = []

    with tempfile.TemporaryDirectory() as tmpdir:
        try:
            images = pdf2image.convert_from_path(
                str(pdf_path),
                dpi=DPI,
                output_folder=tmpdir,
                fmt="png",
            )
        except Exception as e:
            return False, f"pdf2image failed: {e}"

        for i, img in enumerate(images, 1):
            try:
                text = pytesseract.image_to_string(img, lang=LANG).strip()
                if text:
                    pages_text.append(f"## Page {i}\n\n{text}")
            except Exception as e:
                pages_text.append(f"## Page {i}\n\n*(OCR failed: {e})*")

    if not pages_text:
        return False, "no text extracted by OCR"

    header = f"# {pdf_path.stem}\n\n*OCR'd with tesseract {LANG} @ {DPI}dpi — layout approximate.*\n\n"
    md_path.write_text(header + "\n\n---\n\n".join(pages_text), encoding="utf-8")
    return True, ""


def main():
    pdfs = sorted(DOCS_ROOT.rglob("*.pdf"))
    to_process = [p for p in pdfs if needs_ocr(p)]

    print(f"PDFs scanned     : {len(pdfs)}")
    print(f"Image-only / OCR : {len(to_process)}")
    print(f"Already have .md : {len(pdfs) - len(to_process)}")
    if OVERWRITE:
        print("(--overwrite mode)")
    print()

    if not to_process:
        print("Nothing to OCR.")
        return

    ok, failed = [], []

    for i, pdf in enumerate(to_process, 1):
        rel = pdf.relative_to(DOCS_ROOT)
        print(f"[{i}/{len(to_process)}] {rel} ... ", end="", flush=True)
        success, err = ocr_pdf(pdf)
        if success:
            print("OK")
            ok.append(str(rel))
        else:
            print(f"FAILED: {err}")
            failed.append(str(rel))

    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    print(f"  OCR'd successfully : {len(ok)}")
    print(f"  Failed             : {len(failed)}")
    print(f"  Total .md files    : {len(list(DOCS_ROOT.rglob('*.md')))}")
    if failed:
        print("\n  Failed:")
        for f in failed:
            print(f"    - {f}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()

#find . -name "*.gz" | while read filename; do gunzip -v "`dirname "$filename"`" "$filename"; done;
find . -name "*.gz" | while read filename; do gunzip "$filename"; done;


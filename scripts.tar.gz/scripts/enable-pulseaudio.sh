sudo systemctl enable pulseaudio
sudo systemctl start pulseaudio
sudo systemctl status pulseaudio.service


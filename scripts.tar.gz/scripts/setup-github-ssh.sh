#!/usr/bin/env bash
# setup-github-ssh.sh
# Bootstrap and maintain consistent GitHub access across all Linux systems:
#   - Workstation WSL (Debian)
#   - Workstation native Debian 13
#   - Laptop (g814fp) WSL
#   - Laptop native Debian 13
#
# Strategy:
#   HTTPS    — PRIMARY. Token stored in ~/.git-credentials (no passphrase prompts,
#              works identically on Linux, WSL, and Windows).
#   SSH key  — kept in place for non-GitHub SSH use; keychain loads it once per
#              login session so it doesn't prompt either.
#   remotes  — all GitHub remotes normalized to plain https://github.com/... URLs
#              (credentials served from ~/.git-credentials automatically).
#
# Usage:
#   bash setup-github-ssh.sh                     # setup current system (SSH + keychain)
#   bash setup-github-ssh.sh --check             # report status, no changes
#   bash setup-github-ssh.sh --sync-keys         # sync keys from mounted native partition
#   bash setup-github-ssh.sh --token TOKEN       # store HTTPS token + fix remotes
#   bash setup-github-ssh.sh --fix-remotes       # normalize GitHub remotes only (no token)
#   bash setup-github-ssh.sh --deploy-keys HOST  # scp keys to a remote host (e.g. laptop)
#   bash setup-github-ssh.sh --deploy-keys HOST --ssh-user USER
#
# Bootstrap a brand-new system (laptop native Debian, laptop WSL, etc.):
#   1. Run on the new machine:
#        bash setup-github-ssh.sh --token YOUR_TOKEN
#   2. That's it — remotes are fixed automatically.
#
#   Optional (SSH keys for non-GitHub use):
#   1. Deploy from primary:  bash setup-github-ssh.sh --deploy-keys NEW-HOST
#   2. On new machine:       bash setup-github-ssh.sh
#
# Add to ~/.bashrc for automatic agent loading on login:
#   source ~/scripts/setup-github-ssh.sh --auto

set -euo pipefail

# ------------------------------------------------------------
# Args
# ------------------------------------------------------------
CHECK_ONLY=false
SYNC_KEYS=false
AUTO=false
FIX_REMOTES=false
DEPLOY_HOST=""
DEPLOY_USER=""
TOKEN=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --check)       CHECK_ONLY=true ;;
        --sync-keys)   SYNC_KEYS=true ;;
        --auto)        AUTO=true ;;
        --fix-remotes) FIX_REMOTES=true ;;
        --token)       TOKEN="$2"; FIX_REMOTES=true; shift ;;
        --deploy-keys) DEPLOY_HOST="$2"; shift ;;
        --ssh-user)    DEPLOY_USER="$2"; shift ;;
        *) echo "Unknown arg: $1" >&2; exit 1 ;;
    esac
    shift
done

say()  { $AUTO || echo "$*"; }
warn() { echo "[WARN] $*" >&2; }

# ------------------------------------------------------------
# Detect environment
# ------------------------------------------------------------
IS_WSL=false
grep -qiE "(microsoft|wsl)" /proc/version 2>/dev/null && IS_WSL=true

# Look for a mounted Linux partition (workstation: WSL sees native Debian)
NATIVE_DEBIAN_MOUNT=""
for mp in /mnt/wsl/PHYSICALDRIVE*p* /mnt/linux /media/*/; do
    [[ -f "$mp/home/ron/.ssh/id_ed25519" ]] && { NATIVE_DEBIAN_MOUNT="$mp"; break; }
done

say "=== GitHub SSH Setup ==="
say "Host        : $(hostname)"
say "Environment : $( $IS_WSL && echo WSL || echo "Native Linux" )"
[[ -n "$NATIVE_DEBIAN_MOUNT" ]] && say "Native partition : $NATIVE_DEBIAN_MOUNT"

SSH_DIR="$HOME/.ssh"
mkdir -p "$SSH_DIR"
chmod 700 "$SSH_DIR"

# ------------------------------------------------------------
# 1. SSH key permissions
# ------------------------------------------------------------
for key in id_ed25519 id_rsa; do
    [[ -f "$SSH_DIR/$key" ]]     && chmod 600 "$SSH_DIR/$key"
    [[ -f "$SSH_DIR/$key.pub" ]] && chmod 644 "$SSH_DIR/$key.pub"
done
say "  [OK] SSH key permissions"

# ------------------------------------------------------------
# 2. Sync keys from mounted native Debian partition (same machine)
# ------------------------------------------------------------
if $SYNC_KEYS; then
    if [[ -n "$NATIVE_DEBIAN_MOUNT" ]]; then
        say ""
        say "Syncing SSH keys from $NATIVE_DEBIAN_MOUNT/home/ron/.ssh/ ..."
        for key in id_ed25519 id_ed25519.pub id_rsa id_rsa.pub known_hosts; do
            src="$NATIVE_DEBIAN_MOUNT/home/ron/.ssh/$key"
            dst="$SSH_DIR/$key"
            [[ -f "$src" ]] || continue
            if [[ ! -f "$dst" ]] || [[ "$src" -nt "$dst" ]]; then
                $CHECK_ONLY && { say "  [WOULD COPY] $key"; continue; }
                cp "$src" "$dst"
                say "  [COPIED] $key"
            else
                say "  [SKIP] $key (up-to-date)"
            fi
        done
        chmod 600 "$SSH_DIR/id_ed25519" "$SSH_DIR/id_rsa" 2>/dev/null || true
        chmod 644 "$SSH_DIR/id_ed25519.pub" "$SSH_DIR/id_rsa.pub" 2>/dev/null || true
    else
        warn "--sync-keys: no mounted native Debian partition found"
    fi
fi

# ------------------------------------------------------------
# 3. Deploy keys to a remote machine (e.g. laptop) via SCP
# ------------------------------------------------------------
if [[ -n "$DEPLOY_HOST" ]]; then
    REMOTE="${DEPLOY_USER:+${DEPLOY_USER}@}${DEPLOY_HOST}"
    say ""
    say "Deploying SSH keys to $REMOTE ..."
    if $CHECK_ONLY; then
        say "  [WOULD SCP] id_ed25519{,.pub} id_rsa{,.pub} known_hosts -> $REMOTE:~/.ssh/"
    else
        ssh "$REMOTE" "mkdir -p ~/.ssh && chmod 700 ~/.ssh"
        for key in id_ed25519 id_ed25519.pub id_rsa id_rsa.pub known_hosts; do
            [[ -f "$SSH_DIR/$key" ]] && scp "$SSH_DIR/$key" "$REMOTE:~/.ssh/$key" \
                && say "  [SENT] $key"
        done
        # Fix permissions on remote
        ssh "$REMOTE" "chmod 600 ~/.ssh/id_ed25519 ~/.ssh/id_rsa 2>/dev/null; chmod 644 ~/.ssh/id_ed25519.pub ~/.ssh/id_rsa.pub 2>/dev/null; true"
        say "  [OK] Keys deployed to $REMOTE"
        say ""
        say "  Next: on $REMOTE run:"
        say "    bash ~/scripts/setup-github-ssh.sh"
    fi
fi

# ------------------------------------------------------------
# 4. HTTPS token — primary auth strategy
# ------------------------------------------------------------
if [[ -n "$TOKEN" ]]; then
    say ""
    if $CHECK_ONLY; then
        say "  [WOULD SET] ~/.git-credentials for mrgw454"
    else
        echo "https://mrgw454:${TOKEN}@github.com" > "$HOME/.git-credentials"
        chmod 600 "$HOME/.git-credentials"
        git config --global credential.helper store
        say "  [SET] ~/.git-credentials updated"
    fi
fi

# Ensure credential.helper is set
current_helper=$(git config --global credential.helper 2>/dev/null || true)
if [[ "$current_helper" != "store" && "$current_helper" != "cache" ]]; then
    $CHECK_ONLY || git config --global credential.helper store
    say "  [SET] credential.helper = store"
else
    say "  [OK] credential.helper = $current_helper"
fi

# ------------------------------------------------------------
# 4b. Normalize GitHub remotes — strip embedded tokens, switch git@ to https://
# ------------------------------------------------------------
if $FIX_REMOTES; then
    say ""
    say "Normalizing GitHub remotes..."
    # Candidate repo dirs to check
    REPO_DIRS=(
        "$HOME/source-CoCo-Pi/CoCo-Pi-Launcher"
        "$HOME/source/claude-memory"
    )
    for repo in "${REPO_DIRS[@]}"; do
        [[ -d "$repo/.git" ]] || continue
        current_url=$(git -C "$repo" remote get-url origin 2>/dev/null || true)
        [[ -z "$current_url" ]] && continue

        # Detect SSH remote: git@github.com:user/repo.git
        if [[ "$current_url" =~ ^git@github\.com:(.+)$ ]]; then
            clean_url="https://github.com/${BASH_REMATCH[1]}"
        # Detect HTTPS with embedded token: https://TOKEN@github.com/... or https://user:TOKEN@github.com/...
        elif [[ "$current_url" =~ ^https://[^/@]+@github\.com/(.+)$ ]]; then
            clean_url="https://github.com/${BASH_REMATCH[1]}"
        else
            say "  [OK] $repo (already clean)"
            continue
        fi

        if $CHECK_ONLY; then
            say "  [WOULD FIX] $repo"
            say "              $current_url"
            say "           -> $clean_url"
        else
            git -C "$repo" remote set-url origin "$clean_url"
            say "  [FIXED] $(basename "$repo") -> $clean_url"
        fi
    done
fi

# ------------------------------------------------------------
# 5. Sync .gitconfig identity from native partition
# ------------------------------------------------------------
if [[ -n "$NATIVE_DEBIAN_MOUNT" && -f "$NATIVE_DEBIAN_MOUNT/home/ron/.gitconfig" ]]; then
    native_cfg="$NATIVE_DEBIAN_MOUNT/home/ron/.gitconfig"
    native_name=$(git config --file "$native_cfg" user.name 2>/dev/null || true)
    native_email=$(git config --file "$native_cfg" user.email 2>/dev/null || true)
    local_name=$(git config --global user.name 2>/dev/null || true)
    local_email=$(git config --global user.email 2>/dev/null || true)
    if [[ "$native_name" != "$local_name" || "$native_email" != "$local_email" ]]; then
        if $CHECK_ONLY; then
            say "  [WOULD SYNC] gitconfig: name='$native_name' email='$native_email'"
        else
            [[ -n "$native_name" ]]  && git config --global user.name  "$native_name"
            [[ -n "$native_email" ]] && git config --global user.email "$native_email"
            say "  [SYNCED] .gitconfig identity from native partition"
        fi
    else
        say "  [OK] .gitconfig identity matches"
    fi
fi

# ------------------------------------------------------------
# 6. keychain — load SSH key once per login session
# ------------------------------------------------------------
if ! $CHECK_ONLY; then
    if ! command -v keychain >/dev/null 2>&1; then
        say ""
        say "Installing keychain..."
        sudo apt-get install -y -q keychain
    fi

    KEY_FILE=""
    [[ -f "$SSH_DIR/id_ed25519" ]] && KEY_FILE="id_ed25519"
    [[ -z "$KEY_FILE" && -f "$SSH_DIR/id_rsa" ]] && KEY_FILE="id_rsa"

    if [[ -n "$KEY_FILE" ]]; then
        eval "$(keychain --eval --agents ssh --quiet "$KEY_FILE")"
        say "  [OK] keychain loaded $KEY_FILE"
    else
        warn "No SSH private key found in $SSH_DIR"
    fi
else
    command -v keychain >/dev/null 2>&1 \
        && say "  [OK] keychain installed" \
        || say "  [MISSING] keychain (sudo apt install keychain)"
fi

# ------------------------------------------------------------
# 7. Verify GitHub connectivity
# ------------------------------------------------------------
say ""
say "Testing GitHub SSH..."
ssh_out=$(ssh -T -o BatchMode=yes -o ConnectTimeout=5 git@github.com 2>&1 || true)
if echo "$ssh_out" | grep -q "successfully authenticated"; then
    say "  [OK] $ssh_out"
else
    warn "SSH not working: $ssh_out"
    $IS_WSL && say "  Tip: run interactively (not --auto) once to enter passphrase; keychain caches it."
fi

# Auto mode: just ensure agent is loaded silently
if $AUTO && command -v keychain >/dev/null 2>&1; then
    KEY_FILE=""
    [[ -f "$SSH_DIR/id_ed25519" ]] && KEY_FILE="id_ed25519"
    [[ -z "$KEY_FILE" && -f "$SSH_DIR/id_rsa" ]] && KEY_FILE="id_rsa"
    [[ -n "$KEY_FILE" ]] && eval "$(keychain --eval --agents ssh --quiet "$KEY_FILE")"
fi

say ""
say "Done."

#!/bin/bash

# ti99sim requires *.ctg cartridge format.
# you can use convert-ctg to make compatible ones

# select 200 random TI-99/4a cartridges and run them for 120 seconds each

shopt -s extglob
shopt -s nocasematch

for run in {1..200}
do

	 #file=$(shuf -ezn 1 $1/*.* | xargs -0 -n1 echo)
	 file=$(find "$1" -type f -print0 | shuf -z | xargs -0 -n1 echo 2>/dev/null | head -n 1)

     file_path="$file"

     # Extract filename with extension
     filename_with_ext=$(basename "$file_path")

     # Extract filename without extension
     filename_no_ext="${filename_with_ext%.*}"

     #echo "Original path: $file_path"
     #echo "Filename with extension: $filename_with_ext"
     #echo "Filename without extension: $filename_no_ext"



     clear
     echo
     echo
     echo
     echo
     echo
     echo
     echo
     echo

     echo "Random cartridge $run"
     echo "file = $file"
     echo
     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     sleep 2
     timeout 10s $HOME/.ti99sim/bin/ti99sim-sdl --scale=3 $file

done

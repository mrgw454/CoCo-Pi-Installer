# select 200 random TI-99/4a cartridges and run them for 120 seconds each

shopt -s extglob

for run in {1..200}
do

file=$(shuf -ezn 1 /opt/ti99sim/cartridges/* | xargs -0 -n1 echo)

     clear
     echo
     echo
     echo
     echo
     echo
     echo
     echo
     echo

     echo "Random cartridge $run"
     echo "file = $file"
     echo
     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     sleep 2
     timeout 10s ti99sim-sdl $file

done

#!/usr/bin/env python3
import os
import subprocess
import sys
from pathlib import Path

# ------------------------------------------------------------
# Platform detection
# ------------------------------------------------------------
IS_WINDOWS = (os.name == "nt")
IS_LINUX = (os.name == "posix")

def main():
    project = Path.cwd()

    print(f"Project folder: {project}")

    # --------------------------------------------------------
    # Select correct cassette builder script
    # --------------------------------------------------------
    if IS_WINDOWS:
        userprofile = os.environ.get("USERPROFILE", "")
        script = os.path.join(userprofile, "scripts", "makeWAV-mc10.ps1")
        print("Running makeWAV-mc10.ps1 for MC-10 (no emulator)...")
        cmd = [
            "powershell",
            "-ExecutionPolicy", "Bypass",
            "-File", script,
            "mc10",
            ""
        ]
    else:
        home = os.environ.get("HOME", "")
        script = os.path.join(home, "scripts", "makeWAV-mc10.sh")
        print("Running makeWAV-mc10.sh for MC-10 (no emulator)...")
        cmd = [script, "mc10", ""]

    print()

    # --------------------------------------------------------
    # Execute the command
    # --------------------------------------------------------
    result = subprocess.call(cmd)

    if result != 0:
        print(f"Cassette builder exited with code {result}")
        return result

    print("Cassette build complete.")
    return 0

if __name__ == "__main__":
    sys.exit(main())

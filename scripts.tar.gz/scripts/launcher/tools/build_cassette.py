#!/usr/bin/env python3
import os
import subprocess
import sys
from pathlib import Path

def main():
    project = Path.cwd()
    script = os.path.expanduser("~/scripts/makeWAV-mc10.sh")

    print(f"Project folder: {project}")
    print("Running makeWAV-mc10.sh for MC-10 (no emulator)...")
    print()

    cmd = [script, "mc10", ""]
    result = subprocess.call(cmd)

    if result != 0:
        print(f"makeWAV-mc10.sh exited with code {result}")
        return result

    print("Cassette build complete.")
    return 0

if __name__ == "__main__":
    sys.exit(main())

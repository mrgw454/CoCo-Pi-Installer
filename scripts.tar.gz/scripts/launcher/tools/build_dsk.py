#!/usr/bin/env python3
import os
import sys
import subprocess
from pathlib import Path
from datetime import datetime

# ------------------------------------------------------------
# Platform detection
# ------------------------------------------------------------
IS_WINDOWS = (os.name == "nt")
IS_LINUX = (os.name == "posix")

# ------------------------------------------------------------
# ToolShed paths
# ------------------------------------------------------------
if IS_WINDOWS:
    TOOLS_DIR = r"C:\Users\Ron\ToolShed\tools"
    DECB = os.path.join(TOOLS_DIR, "decb.exe")
else:
    DECB = "decb"   # Installed in /usr/local/bin

# ------------------------------------------------------------
# Extension → DECB flag map
# ------------------------------------------------------------
RULES = {
    ".BAS": ["-0", "-a", "-t", "-r"],
    ".BIN": ["-2", "-b", "-r"],
    ".TXT": ["-3", "-a", "-r"],
    ".DAT": ["-2", "-b", "-r"],
    ".ROM": ["-2", "-b", "-r"],
    ".CHR": ["-2", "-b", "-r"],
    ".VG6": ["-2", "-b", "-r"],
    ".SCR": ["-2", "-b", "-r"],
    ".PNG": ["-2", "-b", "-r"],   # ugBasic asset
}

# ------------------------------------------------------------
# Filename sanitization (PowerShell‑accurate)
# ------------------------------------------------------------
def sanitize(name: str) -> str:
    name = name.upper().replace(" ", "")
    base = os.path.splitext(name)[0][:8]
    ext = os.path.splitext(name)[1][:4]  # includes dot
    return base + ext

# ------------------------------------------------------------
# Run a ToolShed command
# ------------------------------------------------------------
def run_decb(args):
    cmd = [DECB] + args
    print(" ".join(cmd))
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print(f"ERROR running: {' '.join(cmd)}")
        sys.exit(1)

# ------------------------------------------------------------
# Main DSK builder
# ------------------------------------------------------------
def main():
    project = Path.cwd()
    diskname = project.name
    diskfile = project / f"{diskname}.dsk"

    print(f"Project folder: {project}")
    print(f"Disk image:     {diskfile}")
    print()

    # --------------------------------------------------------
    # Archive old DSK
    # --------------------------------------------------------
    if diskfile.exists():
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = project / stamp
        backup.mkdir()
        diskfile.rename(backup / diskfile.name)
        print(f"Archived existing DSK to: {backup}")
        print()

    # --------------------------------------------------------
    # Create new DSK
    # --------------------------------------------------------
    print("Creating new DSK...")
    run_decb(["dskini", str(diskfile)])

    # --------------------------------------------------------
    # Copy files
    # --------------------------------------------------------
    print("\nCopying files...")
    for f in project.iterdir():
        if not f.is_file():
            continue

        ext = f.suffix.upper()
        if ext not in RULES:
            continue

        flags = RULES[ext]
        dest = sanitize(f.name)
        combined = f"{diskfile},{dest}"

        print(f"Copying {f.name} → {dest}")
        run_decb(["copy"] + flags + [str(f), combined])

    # --------------------------------------------------------
    # Directory listing
    # --------------------------------------------------------
    print("\nDisk directory:")
    run_decb(["dir", str(diskfile)])

    print("\nDone.")
    return 0

if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
import os
import sys
import subprocess
from pathlib import Path
from datetime import datetime

# ------------------------------------------------------------
# Platform detection
# ------------------------------------------------------------
IS_WINDOWS = (os.name == "nt")
IS_LINUX = (os.name == "posix")

# ------------------------------------------------------------
# ToolShed paths
# ------------------------------------------------------------
if IS_WINDOWS:
    userprofile = os.environ.get("USERPROFILE", "")
    tools_dir = os.path.join(userprofile, "ToolShed", "tools")
    DECB = os.path.join(tools_dir, "decb.exe")
else:
    DECB = "decb"

# ------------------------------------------------------------
# Extension -> DECB flag map
# ------------------------------------------------------------
RULES = {
    ".BAS": ["-0", "-a", "-t", "-r"],
    ".BIN": ["-2", "-b", "-r"],
    ".TXT": ["-3", "-a", "-r"],
    ".DAT": ["-2", "-b", "-r"],
    ".ROM": ["-2", "-b", "-r"],
    ".CHR": ["-2", "-b", "-r"],
    ".VG6": ["-2", "-b", "-r"],
    ".SCR": ["-2", "-b", "-r"],
    ".PNG": ["-2", "-b", "-r"],   # ugBasic asset
}

# ------------------------------------------------------------
# Disk capacity (160K)
# ------------------------------------------------------------
DISK_CAPACITY = 160 * 1024   # 163,840 bytes

# ------------------------------------------------------------
# Filename sanitization (8.3 uppercase)
# ------------------------------------------------------------
def sanitize(name: str) -> str:
    name = name.upper().replace(" ", "")
    base = os.path.splitext(name)[0][:8]
    ext = os.path.splitext(name)[1][:4]
    return base + ext

# ------------------------------------------------------------
# Run a ToolShed command
# ------------------------------------------------------------
def run_decb(args):
    cmd = [DECB] + args
    print(" ".join(cmd))
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print(f"ERROR running: {' '.join(cmd)}")
        sys.exit(1)

# ------------------------------------------------------------
# Main DSK builder
# ------------------------------------------------------------
def main():
    project = Path.cwd()
    diskname = project.name
    diskfile = project / f"{diskname}.dsk"

    print(f"Project folder: {project}")
    print(f"Disk image:     {diskfile}")
    print()

    # --------------------------------------------------------
    # Collect candidate files
    # --------------------------------------------------------
    candidates = []
    total_size = 0

    for f in project.iterdir():
        if not f.is_file():
            continue

        ext = f.suffix.upper()
        if ext not in RULES:
            continue

        base = os.path.splitext(f.name)[0]
        if len(base) > 8:
            print(f"Skipping {f.name}: base name > 8 chars")
            continue

        size = f.stat().st_size
        total_size += size
        candidates.append((f, size))

    # --------------------------------------------------------
    # Capacity check
    # --------------------------------------------------------
    print(f"Total size of included files: {total_size} bytes")
    print(f"Disk capacity:                {DISK_CAPACITY} bytes")

    if total_size > DISK_CAPACITY:
        print("\nERROR: Not enough space on 160K disk image.")
        print(f"Needed: {total_size} bytes, Available: {DISK_CAPACITY} bytes")
        sys.exit(1)

    print("Capacity OK.\n")

    # --------------------------------------------------------
    # Archive old DSK
    # --------------------------------------------------------
    if diskfile.exists():
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = project / stamp
        backup.mkdir()
        diskfile.rename(backup / diskfile.name)
        print(f"Archived existing DSK to: {backup}")
        print()

    # --------------------------------------------------------
    # Create new DSK
    # --------------------------------------------------------
    print("Creating new DSK...")
    run_decb(["dskini", str(diskfile)])

    # --------------------------------------------------------
    # Copy files
    # --------------------------------------------------------
    print("\nCopying files...")
    for f, size in candidates:
        ext = f.suffix.upper()
        flags = RULES[ext]
        dest = sanitize(f.name)

        if IS_WINDOWS:
            combined = f"{diskfile.name},{dest}"
        else:
            combined = f"{diskfile},{dest}"

        print(f"Copying {f.name} -> {dest} ({size} bytes)")
        run_decb(["copy"] + flags + [str(f), combined])

    # --------------------------------------------------------
    # Directory listing
    # --------------------------------------------------------
    print("\nDisk directory:")
    if IS_WINDOWS:
        run_decb(["dir", diskfile.name])
    else:
        run_decb(["dir", str(diskfile)])

    print("\nDone.")
    return 0

if __name__ == "__main__":
    sys.exit(main())

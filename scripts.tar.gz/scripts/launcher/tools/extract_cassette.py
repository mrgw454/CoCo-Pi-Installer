#!/usr/bin/env python3
"""
extract_cassette.py - Extract programs from an MC-10 cassette image (.c10 or .cas)

Scans the cassette file for all programs and extracts each one:
  - BASIC (filetype 0): detokenized to <PROGNAME>.bas
  - ML/binary (filetype 2): raw bytes to <PROGNAME>.bin
  - Other: raw bytes to <PROGNAME>.dat

Output files are written to a subdirectory named after the cassette file (stem).
"""

import os
import sys
from pathlib import Path

# -----------------------------------------------------------------------
# MC-10 BASIC token table (from mc10-tools/mcbasic.py)
# Index = byte value, value = keyword string.  '!' = undefined/invalid.
# -----------------------------------------------------------------------
BASIC_KEYWORDS = [
    # 0x00 - 0x7f: control / printable ASCII (pass through as-is)
    *(["!"] * 0x20),          # 0x00-0x1f  control chars (should not appear mid-line)
    " ", "!", '"', "#", "$", "%", "&", "'",
    "(", ")", "*", "+", ",", "-", ".", "/",
    "0", "1", "2", "3", "4", "5", "6", "7",
    "8", "9", ":", ";", "<", "=", ">", "?",
    "@", "A", "B", "C", "D", "E", "F", "G",
    "H", "I", "J", "K", "L", "M", "N", "O",
    "P", "Q", "R", "S", "T", "U", "V", "W",
    "X", "Y", "Z", "[", "\\", "]", "^", "_",
    "`", "a", "b", "c", "d", "e", "f", "g",
    "h", "i", "j", "k", "l", "m", "n", "o",
    "p", "q", "r", "s", "t", "u", "v", "w",
    "x", "y", "z", "{", "|", "}", "~", "\x7f",
    # 0x80 - 0x8f
    "FOR", "GOTO", "GOSUB", "REM", "IF", "DATA", "PRINT", "ON",
    "INPUT", "END", "NEXT", "DIM", "READ", "LET", "RUN", "RESTORE",
    # 0x90 - 0x9f
    "RETURN", "STOP", "POKE", "CONT", "LIST", "CLEAR", "NEW", "CLOAD",
    "CSAVE", "LLIST", "LPRINT", "SET", "RESET", "CLS", "SOUND", "EXEC",
    # 0xa0 - 0xaf
    "SKIPF", "TAB(", "TO", "THEN", "NOT", "STEP", "OFF", "+",
    "-", "*", "/", "^", "AND", "OR", ">", "=",
    # 0xb0 - 0xbf
    "<", "SGN", "INT", "ABS", "!", "RND", "SQR", "LOG",
    "EXP", "SIN", "COS", "TAN", "PEEK", "LEN", "STR$", "VAL",
    # 0xc0 - 0xcf
    "ASC", "CHR$", "LEFT$", "RIGHT$", "MID$", "POINT", "VARPTR", "INKEY$",
    "MEM", "!", "!", "!", "!", "!", "!", "!",
    # 0xd0 - 0xff: undefined
    *(["!"] * 0x30),
]


def detokenize(data):
    """Convert tokenized MC-10 BASIC bytes to a plain-text BASIC listing."""
    lines = []
    i = 0
    while i < len(data):
        # Next-line pointer (2 bytes) — skip unless it signals end (0x00 0x00)
        if i + 1 >= len(data):
            break
        if data[i] == 0x00 and data[i + 1] == 0x00:
            break
        i += 2

        # Line number (2 bytes, big-endian)
        if i + 1 >= len(data):
            break
        line_num = (data[i] << 8) | data[i + 1]
        i += 2

        # Tokens until null terminator
        text = str(line_num) + " "
        while i < len(data) and data[i] != 0x00:
            b = data[i]
            if b == 0x22:  # opening quote — copy string literal verbatim
                text += '"'
                i += 1
                while i < len(data) and data[i] != 0x00 and data[i] != 0x22:
                    text += chr(data[i])
                    i += 1
                if i < len(data) and data[i] == 0x22:
                    text += '"'
                    i += 1
            else:
                kw = BASIC_KEYWORDS[b] if b < len(BASIC_KEYWORDS) else "!"
                text += kw
                i += 1
        i += 1  # skip null terminator

        lines.append(text)

    return "\n".join(lines)


# -----------------------------------------------------------------------
# C10 / CAS format parser
# -----------------------------------------------------------------------

def skip_sync(data, i):
    """Advance past 0x55 sync bytes. Returns new index."""
    while i < len(data) and data[i] == 0x55:
        i += 1
    return i


def read_block(data, i):
    """Read one block starting at i.
    Returns (new_i, block_type, block_data) or raises on error."""
    if i >= len(data):
        raise EOFError("Unexpected end of file")
    if data[i] != 0x3C:
        raise ValueError(f"Expected block marker 0x3C at offset {i}, got 0x{data[i]:02X}")
    if i + 2 >= len(data):
        raise EOFError("Truncated block header")
    block_type = data[i + 1]
    size = data[i + 2]
    i += 3
    if i + size > len(data):
        raise EOFError(f"Truncated block data (need {size} bytes at offset {i})")
    block_data = data[i:i + size]
    checksum_idx = i + size
    if checksum_idx >= len(data):
        raise EOFError("Missing checksum byte")
    expected = sum(data[i - 2:checksum_idx]) & 0xFF
    actual = data[checksum_idx]
    if expected != actual:
        print(f"  Warning: checksum mismatch at offset {checksum_idx} "
              f"(expected 0x{expected:02X}, got 0x{actual:02X})")
    return checksum_idx + 1, block_type, block_data


def parse_header_block(block_data):
    """Parse a type-0 (header) block. Returns dict with program metadata."""
    if len(block_data) < 15:
        raise ValueError(f"Header block too short ({len(block_data)} bytes)")
    raw_name = block_data[0:8]
    name = raw_name.rstrip(b"\x00").decode("ascii", errors="replace").strip()
    filetype = block_data[8]   # 0=BASIC, 1=Data, 2=ML
    binary_mode = block_data[9]
    gap_flag = block_data[10]
    exec_addr = (block_data[11] << 8) | block_data[12]
    load_addr = (block_data[13] << 8) | block_data[14]
    return {
        "name": name,
        "filetype": filetype,
        "binary_mode": binary_mode,
        "gap_flag": gap_flag,
        "exec_addr": exec_addr,
        "load_addr": load_addr,
    }


def read_program(data, i):
    """Read one complete program starting at i (past sync bytes).
    Returns (new_i, header_dict, program_bytes) or raises."""
    i = skip_sync(data, i)
    if i >= len(data):
        return None  # clean EOF between programs

    # Header block (type 0)
    i, block_type, block_data = read_block(data, i)
    if block_type != 0x00:
        raise ValueError(f"Expected header block (type 0), got type {block_type}")
    header = parse_header_block(block_data)

    # Secondary leader
    i = skip_sync(data, i)

    # Data blocks (type 1) until EOF block (type 0xFF)
    program_bytes = bytearray()
    while True:
        i, block_type, block_data = read_block(data, i)
        if block_type == 0xFF:
            break
        if block_type != 0x01:
            raise ValueError(f"Unexpected block type {block_type} in data section")
        program_bytes += block_data
        i = skip_sync(data, i)  # inter-block leader

    return i, header, bytes(program_bytes)


def extract(cassette_path, output_dir):
    """Extract all programs from cassette_path into output_dir."""
    data = cassette_path.read_bytes()
    output_dir.mkdir(exist_ok=True)

    i = 0
    count = 0
    while i < len(data):
        # Skip any trailing nulls or padding between programs
        while i < len(data) and data[i] == 0x00:
            i += 1
        if i >= len(data):
            break

        result = read_program(data, i)
        if result is None:
            break
        i, header, program_bytes = result
        count += 1

        name = header["name"] or f"PROG{count}"
        filetype = header["filetype"]

        filetype_names = {0: "BASIC", 1: "Data", 2: "ML/binary", 3: "Text"}
        type_label = filetype_names.get(filetype, f"type {filetype}")

        if filetype == 0:
            out_name = name.lower() + ".bas"
            out_path = output_dir / out_name
            try:
                listing = detokenize(program_bytes)
                out_path.write_text(listing + "\n", encoding="utf-8")
                print(f"Extracted: {out_name}  ({type_label}, detokenized)")
            except Exception as e:
                # Fall back to raw if detokenization fails
                out_name = name.lower() + ".bin"
                out_path = output_dir / out_name
                out_path.write_bytes(program_bytes)
                print(f"Extracted: {out_name}  (BASIC detokenize failed: {e}, saved raw)")
        elif filetype == 2:
            out_name = name.lower() + ".bin"
            out_path = output_dir / out_name
            out_path.write_bytes(program_bytes)
            exec_note = f", exec=0x{header['exec_addr']:04X} load=0x{header['load_addr']:04X}"
            print(f"Extracted: {out_name}  ({type_label}{exec_note})")
        else:
            out_name = name.lower() + ".dat"
            out_path = output_dir / out_name
            out_path.write_bytes(program_bytes)
            print(f"Extracted: {out_name}  ({type_label})")

    return count


def main():
    project = Path.cwd()

    # Find .c10 or .cas file
    candidates = [
        f for f in project.iterdir()
        if f.is_file() and f.suffix.lower() in (".c10", ".cas")
    ]

    if len(sys.argv) >= 2:
        cassette_file = Path(sys.argv[1])
    elif len(candidates) == 1:
        cassette_file = candidates[0]
    elif len(candidates) > 1:
        print("Multiple cassette files found. Please specify one:")
        for c in sorted(candidates):
            print(f"  python3 {sys.argv[0]} {c.name}")
        return 1
    else:
        print(f"No .c10 or .cas files found in {project}")
        return 1

    output_dir = project / cassette_file.stem

    print(f"Cassette: {cassette_file.name}")
    print(f"Output:   {output_dir.name}/")
    print("-" * 40)

    try:
        count = extract(cassette_file, output_dir)
    except Exception as e:
        print(f"Error: {e}")
        return 1

    print("-" * 40)
    if count == 0:
        print("No programs found.")
    else:
        print(f"Done. {count} program(s) extracted to {output_dir.name}/")
    return 0


if __name__ == "__main__":
    sys.exit(main())

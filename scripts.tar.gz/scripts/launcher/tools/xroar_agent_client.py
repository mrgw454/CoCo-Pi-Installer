#!/usr/bin/env python3
"""Workspace-aware CLI used by the CoCo-Pi VS Code XRoar integration."""

from __future__ import annotations

import argparse
import base64
import json
import os
import socket
import stat
import struct
import time
import zlib
from pathlib import Path


def descriptor_directory() -> Path:
    runtime = os.environ.get("XDG_RUNTIME_DIR")
    return Path(runtime) / "xroar-agent" if runtime else Path("/tmp") / f"xroar-agent-{os.getuid()}"


def parse_endpoint(endpoint: str) -> tuple[str, int]:
    host, separator, port = endpoint.rpartition(":")
    if not separator or not host:
        raise ValueError("invalid endpoint")
    return host, int(port)


class Client:
    def __init__(self, endpoint: str):
        self.socket = socket.create_connection(parse_endpoint(endpoint), timeout=2)
        self.socket.settimeout(12)
        self.stream = self.socket.makefile("rwb", buffering=0)
        self.request_id = 0

    def call(self, method: str, **parameters) -> dict:
        self.request_id += 1
        payload = {"version": 1, "id": self.request_id, "method": method, **parameters}
        self.stream.write(json.dumps(payload, separators=(",", ":")).encode() + b"\n")
        response = json.loads(self.stream.readline())
        if response.get("id") != self.request_id:
            raise RuntimeError("response ID mismatch")
        if "error" in response:
            raise RuntimeError(response["error"] + (f": {response['detail']}" if response.get("detail") else ""))
        return response["result"]

    def close(self) -> None:
        self.stream.close(); self.socket.close()


def workspace_matches(descriptor: dict, workspace: Path) -> bool:
    cwd = Path(descriptor.get("cwd", "")).resolve()
    workspace = workspace.resolve()
    return cwd == workspace or workspace in cwd.parents


def descriptors(workspace: Path) -> list[dict]:
    directory = descriptor_directory()
    if not directory.exists():
        return []
    mode = directory.stat().st_mode
    if not stat.S_ISDIR(mode) or directory.stat().st_uid != os.getuid() or mode & 0o077:
        raise PermissionError("runtime directory is not private")
    sessions = []
    for path in sorted(directory.glob("session-*.json")):
        try:
            mode = path.stat().st_mode
            if not stat.S_ISREG(mode) or mode & 0o077:
                continue
            data = json.loads(path.read_text(encoding="utf-8"))
            if data.get("schema") != 1 or data.get("protocol") != 1:
                continue
            os.kill(int(data["pid"]), 0)
            if workspace_matches(data, workspace):
                sessions.append(data)
        except (OSError, ValueError, KeyError, json.JSONDecodeError):
            continue
    return sessions


def one_session(workspace: Path) -> dict:
    sessions = descriptors(workspace)
    if len(sessions) != 1:
        raise RuntimeError(f"expected one XRoar AI session for workspace, found {len(sessions)}")
    return sessions[0]


def png_chunk(kind: bytes, data: bytes) -> bytes:
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)


def write_png(path: Path, width: int, height: int, rgb: bytes) -> None:
    if (width, height) in {(640, 240), (720, 270)}:
        source_rows = [rgb[y * width * 3:(y + 1) * width * 3] for y in range(height)]
        rgb = b"".join(row for row in source_rows for _ in range(2))
        height *= 2
    rows = b"".join(b"\0" + rgb[y * width * 3:(y + 1) * width * 3] for y in range(height))
    png = b"\x89PNG\r\n\x1a\n" + png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
    png += png_chunk(b"IDAT", zlib.compress(rows, 9)) + png_chunk(b"IEND", b"")
    path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(png)


def connect_verified(session: dict) -> Client:
    client = Client(session["endpoint"])
    hello = client.call("hello")
    if hello["session_id"] != session["session_id"]:
        client.close(); raise RuntimeError("session identity mismatch")
    return client


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("status")
    capture = sub.add_parser("capture"); capture.add_argument("--output", type=Path, required=True)
    watch = sub.add_parser("watch"); watch.add_argument("--output-dir", type=Path, required=True)
    watch.add_argument("--duration", type=float, default=10); watch.add_argument("--interval", type=float, default=0.5)
    args = parser.parse_args()
    session = one_session(args.workspace)
    if args.command == "status":
        print(json.dumps({"session": session}, separators=(",", ":"))); return 0
    client = connect_verified(session)
    try:
        if args.command == "capture":
            frame = client.call("screen.capture")
            rgb = base64.b64decode(frame.pop("data"), validate=True)
            write_png(args.output, frame["width"], frame["height"], rgb)
            print(json.dumps({"session": session, "frame": frame, "output": str(args.output)}, separators=(",", ":")))
            return 0
        deadline = time.monotonic() + max(0.5, min(args.duration, 60))
        previous = None; saved = []
        while time.monotonic() < deadline:
            frame = client.call("screen.capture"); data = frame.pop("data")
            if previous != frame["hash"]:
                output = args.output_dir / f"frame-{frame['frame_id']:06d}.png"
                write_png(output, frame["width"], frame["height"], base64.b64decode(data, validate=True))
                saved.append(str(output)); previous = frame["hash"]
            time.sleep(max(0.1, min(args.interval, 5)))
        print(json.dumps({"session": session, "saved": saved, "count": len(saved)}, separators=(",", ":")))
        return 0
    finally:
        client.close()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(json.dumps({"error": str(exc)}, separators=(",", ":")))
        raise SystemExit(1)

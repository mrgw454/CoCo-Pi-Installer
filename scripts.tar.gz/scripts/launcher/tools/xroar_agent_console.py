#!/usr/bin/env python3
"""Separate text activity/status console for one AI-enabled XRoar process."""

from __future__ import annotations

import argparse
import json
import os
import select
import socket
import stat
import sys
import time
from pathlib import Path


def descriptor_path(pid: int) -> Path:
    runtime = os.environ.get("XDG_RUNTIME_DIR")
    directory = Path(runtime) / "xroar-agent" if runtime else Path("/tmp") / f"xroar-agent-{os.getuid()}"
    return directory / f"session-{pid}.json"


def wait_descriptor(pid: int, timeout: float) -> dict:
    path = descriptor_path(pid)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            mode = path.stat().st_mode
            if not stat.S_ISREG(mode) or mode & 0o077:
                raise PermissionError("descriptor is not a private regular file")
            data = json.loads(path.read_text(encoding="utf-8"))
            if data.get("schema") == 1 and data.get("protocol") == 1 and int(data["pid"]) == pid:
                return data
        except FileNotFoundError:
            pass
        time.sleep(0.1)
    raise TimeoutError(f"no valid runtime descriptor for PID {pid} after {timeout:g}s")


def parse_endpoint(endpoint: str) -> tuple[str, int]:
    if endpoint.startswith("["):
        host, separator, port = endpoint[1:].partition("]:")
    else:
        host, separator, port = endpoint.rpartition(":")
    if not separator or not host:
        raise ValueError(f"invalid endpoint: {endpoint}")
    return host, int(port)


class Client:
    def __init__(self, endpoint: str):
        host, port = parse_endpoint(endpoint)
        self.socket = socket.create_connection((host, port), timeout=2)
        self.socket.settimeout(3)
        self.stream = self.socket.makefile("rwb", buffering=0)
        self.request_id = 0

    def call(self, method: str, **parameters) -> dict:
        self.request_id += 1
        payload = {"version": 1, "id": self.request_id, "method": method, **parameters}
        self.stream.write(json.dumps(payload, separators=(",", ":")).encode() + b"\n")
        line = self.stream.readline()
        if not line:
            raise ConnectionError("agent connection closed")
        response = json.loads(line)
        if response.get("id") != self.request_id:
            raise RuntimeError("response ID mismatch")
        return response

    def close(self) -> None:
        self.stream.close()
        self.socket.close()


def result(response: dict) -> dict:
    if "error" in response:
        detail = response.get("detail")
        raise RuntimeError(response["error"] + (f": {detail}" if detail else ""))
    return response["result"]


def print_help() -> None:
    print("Controls: [c] claim  [r] release  [s] screen hash  [x] shutdown  [q] detach  [h] help")


def main() -> int:
    parser = argparse.ArgumentParser(description="Follow one XRoar AI activity stream")
    parser.add_argument("--pid", type=int, required=True)
    parser.add_argument("--descriptor-timeout", type=float, default=10)
    parser.add_argument("--poll", type=float, default=0.5)
    parser.add_argument("--once", action="store_true", help="print current state and exit")
    args = parser.parse_args()

    print(f"XRoar AI Activity Console — waiting for PID {args.pid}", flush=True)
    descriptor = wait_descriptor(args.pid, args.descriptor_timeout)
    client = Client(descriptor["endpoint"])
    latest = 0
    last_status = None
    try:
        hello = result(client.call("hello"))
        if hello["session_id"] != descriptor["session_id"]:
            raise RuntimeError("runtime descriptor/session identity mismatch")
        print(f"Connected: pid={args.pid} session={hello['session_id']} endpoint={descriptor['endpoint']}")
        print(f"Workspace: {descriptor.get('cwd', 'unknown')}")
        print_help()

        while True:
            status = result(client.call("session.status"))
            status_key = (status.get("machine"), status.get("architecture"),
                          status.get("execution"), status.get("authority"))
            if status_key != last_status:
                print("STATUS machine={} architecture={} execution={} authority={}".format(*status_key), flush=True)
                last_status = status_key
            events = result(client.call("lifecycle.events", after=latest, limit=16))
            for event in events.get("events", []):
                latest = max(latest, int(event["sequence"]))
                print(f"EVENT seq={event['sequence']} tick={event['tick']} type={event['type']} result={event['result']}", flush=True)
            latest = max(latest, int(events.get("latest", latest)))
            if args.once:
                return 0

            readable, _, _ = select.select([sys.stdin], [], [], args.poll)
            if not readable:
                continue
            command = sys.stdin.readline()
            if not command:
                return 0
            command = command.strip().lower()
            try:
                if command == "c":
                    print("CONTROL", result(client.call("input.claim")), flush=True)
                elif command == "r":
                    print("CONTROL", result(client.call("input.release")), flush=True)
                elif command == "s":
                    screen = result(client.call("screen.hash"))
                    print(f"SCREEN frame={screen['frame_id']} size={screen['width']}x{screen['height']} hash={screen['hash']}", flush=True)
                elif command == "x":
                    answer = input("Type SHUTDOWN to close XRoar: ").strip()
                    if answer == "SHUTDOWN":
                        print("SHUTDOWN", result(client.call("session.shutdown")), flush=True)
                        return 0
                    print("Shutdown cancelled.", flush=True)
                elif command == "q":
                    print("Console detached; XRoar remains running.", flush=True)
                    return 0
                elif command == "h" or not command:
                    print_help()
                else:
                    print(f"Unknown control: {command!r}", flush=True)
            except RuntimeError as exc:
                print(f"DENIED {exc}", flush=True)
    except (ConnectionError, BrokenPipeError, OSError) as exc:
        print(f"Session ended: {exc}", flush=True)
        return 0
    finally:
        client.close()


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
import os
import sys
import subprocess
import re
from pathlib import Path

# ------------------------------------------------------------
# Platform detection & ToolShed paths
# ------------------------------------------------------------
IS_WINDOWS = (os.name == "nt")
DECB = os.path.join(os.environ.get("USERPROFILE", ""), "ToolShed", "tools", "decb.exe") if IS_WINDOWS else "decb"

def run_command(args, cwd):
    cmd = [DECB] + args
    result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return result

def main():
    if len(sys.argv) < 2:
        project = Path.cwd()
        # 1. Try directory-named DSK
        dsk_file = project / f"{project.name}.dsk"
        
        # 2. Fallback: find any .dsk in current folder (case-insensitive)
        if not dsk_file.exists():
            dsk_candidates = [f for f in project.iterdir() if f.is_file() and f.suffix.lower() == ".dsk"]
            
            if len(dsk_candidates) == 1:
                dsk_file = dsk_candidates[0]
            elif len(dsk_candidates) > 1:
                print(f"Multiple DSK files found. Please specify one:")
                for c in dsk_candidates:
                    print(f"  python3 {sys.argv[0]} {c.name}")
                sys.exit(1)
            else:
                print(f"Usage: python3 {sys.argv[0]} <image.dsk>")
                print(f"No .dsk files found in {project}")
                sys.exit(1)
    else:
        dsk_file = Path(sys.argv[1])

    dsk_dir = dsk_file.parent.resolve()
    dsk_name = dsk_file.name
    
    output_path = dsk_dir / dsk_file.stem
    output_path.mkdir(exist_ok=True)

    print(f"Scanning DSK: {dsk_name}")
    
    # 1. Get the directory listing
    dir_result = run_command(["dir", dsk_name], cwd=dsk_dir)
    
    if dir_result.returncode != 0:
        print(f"Error reading DSK directory: {dir_result.stderr}")
        sys.exit(1)

    # 2. Parse filenames
    files_to_copy = []
    lines = dir_result.stdout.splitlines()
    
    for line in lines:
        match = re.match(r"^\s*([A-Z0-9]{1,8})\s+([A-Z0-9]{1,3})\s+", line.upper())
        if match:
            name = match.group(1).strip()
            ext = match.group(2).strip()
            files_to_copy.append((name, ext))

    if not files_to_copy:
        print("No files found on disk image.")
        sys.exit(0)

    print(f"Found {len(files_to_copy)} files. Extracting...")
    print("-" * 40)

    # 3. Loop and copy each file individually
    count = 0
    for name, ext in files_to_copy:
        filename = f"{name}.{ext}"
        source_internal = f"{dsk_name},{filename}"
        dest_local = f"./{output_path.name}/{filename.lower()}"
        
        # Base flags: -l for lowercase local naming
        copy_flags = ["copy", "-l"]

        # --------------------------------------------------------
        # Extension-specific flags:
        # Only use -t (BASIC translation) for .BAS files
        # --------------------------------------------------------
        if ext == "BAS":
            copy_flags.append("-t")
        
        # Note: Your bash script used '-l' for EOL translation. 
        # In this context, ToolShed's 'copy' uses '-l' for lowercase.
        # If you need EOL (CR to LF) translation for non-BASIC text 
        # files (like .TXT), add those here.
        
        copy_args = copy_flags + [source_internal, dest_local]
        
        res = run_command(copy_args, cwd=dsk_dir)
        
        if res.returncode == 0:
            flag_note = " (detokenized)" if ext == "BAS" else ""
            print(f"Extracted: {filename}{flag_note}")
            count += 1
        else:
            print(f"Failed to extract {filename}: {res.stderr.strip()}")

    print("-" * 40)
    print(f"Done. {count} files extracted to {output_path.name}/")

if __name__ == "__main__":
    main()
#!/usr/bin/env pwsh

# Username‑agnostic Windows shortcut creator for CoCo Launcher

$homeDir = $env:USERPROFILE
$launcher = "$homeDir\scripts\launcher\launcher.py"
$icon = "$homeDir\scripts\launcher\assets\CoCo-Pi-Launcher.ico"
$shortcutPath = "$homeDir\Desktop\CoCo Launcher.lnk"

# PowerShell command to run the launcher in a terminal
$arguments = "-NoExit -ExecutionPolicy Bypass -Command `"python `"$launcher`"`""

# Create WScript.Shell COM object
$wsh = New-Object -ComObject WScript.Shell
$sc = $wsh.CreateShortcut($shortcutPath)

$sc.TargetPath = "powershell.exe"
$sc.Arguments = $arguments
$sc.IconLocation = $icon
$sc.WorkingDirectory = $homeDir
$sc.WindowStyle = 1
$sc.Description = "CoCo Launcher"

$sc.Save()

Write-Host "Shortcut created at: $shortcutPath"

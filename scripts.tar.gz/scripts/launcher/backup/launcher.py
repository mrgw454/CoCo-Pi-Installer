#!/usr/bin/env python3
import os
import json
import curses
import subprocess
import shlex
import socket

CONFIG_DIR = "/home/ron/scripts/launcher/config"

# Use PATH-resolved executables
XROAR_EXE = "xroar"
MAME_EXE = "mame"
TRS80GP_EXE = "trs80gp"

PYDWCLI = "/home/ron/pyDriveWire/pyDwCli"
PYDW_URL = "http://localhost:6800"
PYDW_PIDFILE = "/tmp/pyDriveWire.pid"

ROMPATH = "/media/share1/roms"

# ---------------- Optional parameter files ----------------

XROAR_OPT = os.path.expanduser("~/.xroar/.optional_xroar_parameters.txt")
MAME_OPT = os.path.expanduser("~/.mame/.optional_mame_parameters.txt")
TRS80GP_OPT = os.path.expanduser("~/.trs80gp/.optional_trs80gp_parameters.txt")


def load_optional_params(path):
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r") as f:
            line = f.readline().strip()
            return line.split()
    except Exception:
        return []


XROAR_PARAMS = load_optional_params(XROAR_OPT)
MAME_PARAMS = load_optional_params(MAME_OPT)
TRS80GP_PARAMS = load_optional_params(TRS80GP_OPT)

# ---------------- Path translation ----------------

def translate_path(p: str) -> str:
    if not isinstance(p, str):
        return p

    s = p.replace("\\", "/")

    # E: drive → /media/share1
    if s.lower().startswith("e:/media/share1"):
        s = "/media/share1" + s[15:]

    # C: drive → /home/ron
    if s.lower().startswith("c:/users/ron"):
        s = "/home/ron" + s[12:]

    return s


def translate_args(args):
    return [translate_path(a) for a in args]


def translate_pydw(pydw):
    if not isinstance(pydw, dict):
        return pydw

    out = dict(pydw)

    # Normalize "insert" into a list of translated paths
    if "insert" in out:
        ins = out["insert"]
        if isinstance(ins, str):
            out["insert"] = [translate_path(ins)]
        elif isinstance(ins, list):
            out["insert"] = [translate_path(x) for x in ins]

    # Normalize "disks" dict
    if "disks" in out and isinstance(out["disks"], dict):
        out["disks"] = {str(k): translate_path(v) for k, v in out["disks"].items()}

    return out

# ---------------- Load menu ----------------

def load_menu():
    categories = []
    for filename in sorted(os.listdir(CONFIG_DIR)):
        if not filename.endswith(".json"):
            continue

        path = os.path.join(CONFIG_DIR, filename)
        with open(path, "r") as f:
            data = json.load(f)

        title = data.get("title", filename)
        items = data.get("items", [])

        for it in items:
            it["args"] = translate_args(it.get("args", []))
            if "pyDW" in it:
                it["pyDW"] = translate_pydw(it["pyDW"])

        categories.append({"title": title, "items": items})

    return categories

# ---------------- pyDriveWire helpers ----------------

def run_pydw(args):
    cmd = [PYDWCLI, PYDW_URL] + args
    try:
        subprocess.call(cmd)
    except FileNotFoundError:
        pass


def pydw_set_server_mode(server, mode):
    if server is None or mode is None:
        return
    run_pydw(["dw", "server", str(server), str(mode)])


def pydw_mount_disk_slot(slot, path):
    if path:
        run_pydw(["dw", "disk", "insert", str(slot), path])


def pydw_eject_slot(slot):
    run_pydw(["dw", "disk", "eject", str(slot)])


def pydw_eject_slots(slots):
    for s in slots:
        pydw_eject_slot(s)


def validate_pydw_paths(pydw):
    missing = []
    planned = []

    if not pydw:
        return missing, planned

    # Single-slot insert
    if "insert" in pydw:
        slot = int(pydw.get("slot", 0))
        for path in pydw["insert"]:
            planned.append((slot, path))
            if not os.path.exists(path):
                missing.append(path)

    # Multi-slot dictionary
    if "disks" in pydw:
        for s, path in pydw["disks"].items():
            slot = int(s)
            planned.append((slot, path))
            if not os.path.exists(path):
                missing.append(path)

    return missing, planned


def pydw_pre_launch(pydw):
    if not pydw:
        return

    # Server mode
    if pydw.get("server") is not None and pydw.get("mode") is not None:
        pydw_set_server_mode(pydw["server"], pydw["mode"])

    # Validate paths
    missing, _ = validate_pydw_paths(pydw)
    if missing:
        print("pyDriveWire: missing DSK files:")
        for m in missing:
            print(f"  {m}")
        return

    # Single-slot
    if "insert" in pydw:
        slot = int(pydw.get("slot", 0))
        pydw_eject_slot(slot)
        for path in pydw["insert"]:
            pydw_mount_disk_slot(slot, path)
        return

    # Multi-slot
    if "disks" in pydw:
        slots = sorted(int(s) for s in pydw["disks"].keys())
        pydw_eject_slots(slots)
        for s, path in pydw["disks"].items():
            pydw_mount_disk_slot(int(s), path)


def pydw_post_launch(pydw):
    if not pydw:
        return

    # Eject
    if pydw.get("eject"):
        if "insert" in pydw:
            slot = int(pydw.get("slot", 0))
            pydw_eject_slot(slot)
        elif "disks" in pydw:
            slots = sorted(int(s) for s in pydw["disks"].keys())
            pydw_eject_slots(slots)

    # Restore server mode
    if pydw.get("server") is not None and pydw.get("restoreMode") is not None:
        pydw_set_server_mode(pydw["server"], pydw["restoreMode"])
# ---------------- pyDriveWire runtime status ----------------

def check_pid_running(pid):
    try:
        result = subprocess.run(
            ["ps", "-p", str(pid)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return result.returncode == 0
    except Exception:
        return False


def check_http_alive():
    try:
        with socket.create_connection(("localhost", 6800), timeout=0.2):
            return True
    except OSError:
        return False


def check_pydw_api():
    try:
        result = subprocess.run(
            [PYDWCLI, PYDW_URL, "dw", "disk", "list"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return result.returncode == 0
    except Exception:
        return False


def get_pydw_status_lines():
    lines = []

    # PID / process status
    if not os.path.exists(PYDW_PIDFILE):
        lines.append("pyDriveWire: not running")
    else:
        try:
            with open(PYDW_PIDFILE, "r") as f:
                pid_str = f.read().strip()
        except Exception:
            pid_str = ""

        if not pid_str.isdigit():
            lines.append("pyDriveWire: PID file invalid")
        else:
            pid = int(pid_str)
            if check_pid_running(pid):
                lines.append(f"pyDriveWire: running (PID {pid})")
            else:
                lines.append("pyDriveWire: stale PID (not running)")

    # HTTP status
    if check_http_alive():
        lines.append("pyDW HTTP: OK")
    else:
        lines.append("pyDW HTTP: unreachable")

    # API status
    if check_pydw_api():
        lines.append("pyDW API: OK")
    else:
        lines.append("pyDW API: offline")

    # Separator
    lines.append("------------------------------")
    return lines


# ---------------- Command building ----------------

def build_command(item):
    emu = item.get("emulator")
    machine = item.get("machine")
    args = item.get("args", [])

    if emu == "xroar":
        cmd = [XROAR_EXE, "-default-machine", machine] + args + XROAR_PARAMS

    elif emu == "mame":
        cmd = [MAME_EXE, machine, "-rompath", ROMPATH] + args + MAME_PARAMS

    elif emu == "trs80gp":
        cmd = [TRS80GP_EXE, f"-{machine}"] + TRS80GP_PARAMS + args

    elif emu == "browser":
        cmd = args[:]

    elif emu == "utility":
        cmd = args[:]

    else:
        cmd = ["echo", "unknown emulator type"]

    return cmd


def command_to_string(cmd):
    return " ".join(shlex.quote(c) for c in cmd)


# ---------------- pyDW preview/status helpers ----------------

def build_pydw_preview_lines(pydw):
    lines = []

    if not pydw:
        lines.append("pyDW: none")
        return lines

    missing, planned = validate_pydw_paths(pydw)

    # Server/mode
    if pydw.get("server") is not None and pydw.get("mode") is not None:
        lines.append(f"pyDW: server {pydw['server']} mode {pydw['mode']}")
    else:
        lines.append("pyDW: server unchanged")

    # Planned disks
    if planned:
        for slot, path in planned:
            tag = "MISSING" if path in missing else "OK"
            lines.append(f"  slot {slot}: {path} [{tag}]")
    else:
        lines.append("  no disks configured")

    # Eject behavior
    if pydw.get("eject"):
        lines.append("  eject after exit: yes")
    else:
        lines.append("  eject after exit: no")

    return lines


# ---------------- UI drawing ----------------

def draw_ui(stdscr, categories, cat_index, item_index, preview_cmd, pydw_lines, status_lines):
    stdscr.clear()
    max_y, max_x = stdscr.getmaxyx()

    curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
    curses.init_pair(2, curses.COLOR_BLACK, curses.COLOR_GREEN)

    # Border
    stdscr.border()

    # Title
    stdscr.attron(curses.color_pair(1))
    stdscr.addstr(0, 2, " CoCo Launcher ")
    stdscr.attroff(curses.color_pair(1))

    # pyDW status banner
    y = 1
    for line in status_lines:
        if y >= max_y - 1:
            break
        stdscr.addstr(y, 2, line[:max_x - 4])
        y += 1

    status_block_height = y

    left_w = max_x // 3

    # Dynamic preview height: command line + pyDW lines + header
    preview_h = 2 + len(pydw_lines)

    # Clamp so preview never exceeds half the screen
    preview_h = min(preview_h, max_y // 2)

    list_h = max_y - preview_h - 3

    # Headers
    if status_block_height < max_y - 1:
        stdscr.attron(curses.color_pair(1))
        stdscr.addstr(status_block_height, 2, "Categories")
        stdscr.addstr(status_block_height, left_w + 3, "Items")
        stdscr.attroff(curses.color_pair(1))

    # Categories
    start_list_y = status_block_height + 1
    for i, cat in enumerate(categories):
        row = start_list_y + i
        if row >= list_h:
            break
        label = cat["title"]
        if i == cat_index:
            stdscr.attron(curses.color_pair(2))
            stdscr.addstr(row, 2, label[:left_w - 3])
            stdscr.attroff(curses.color_pair(2))
        else:
            stdscr.addstr(row, 2, label[:left_w - 3])

    # Items
    items = categories[cat_index]["items"]
    for i, item in enumerate(items):
        row = start_list_y + i
        if row >= list_h:
            break
        label = item.get("label", "")
        if i == item_index:
            stdscr.attron(curses.color_pair(2))
            stdscr.addstr(row, left_w + 3, label[:max_x - left_w - 4])
            stdscr.attroff(curses.color_pair(2))
        else:
            stdscr.addstr(row, left_w + 3, label[:max_x - left_w - 4])

    # Preview block
    start_y = list_h + 1
    if start_y < max_y - 2:
        stdscr.attron(curses.color_pair(1))
        stdscr.addstr(start_y, 2, "Command Preview:")
        stdscr.attroff(curses.color_pair(1))

        if start_y + 1 < max_y - 1:
            safe_cmd = preview_cmd.replace("\n", " ⏎ ")
            stdscr.addstr(start_y + 1, 2, safe_cmd[:max_x - 4])

        # pyDW preview
        if start_y + 2 < max_y - 1:
            stdscr.attron(curses.color_pair(1))
            stdscr.addstr(start_y + 2, 2, "pyDriveWire:")
            stdscr.attroff(curses.color_pair(1))

            line_y = start_y + 3
            for line in pydw_lines:
                if line_y >= max_y - 1:
                    break
                stdscr.addstr(line_y, 2, line[:max_x - 4])
                line_y += 1

    stdscr.refresh()


# ---------------- Main loop ----------------

def main(stdscr):
    curses.curs_set(0)
    curses.start_color()
    stdscr.keypad(True)

    categories = load_menu()
    if not categories:
        stdscr.addstr(0, 0, "No JSON menus found.")
        stdscr.getch()
        return

    cat_index = 0
    item_index = 0

    items = categories[0]["items"]
    current_item = items[0] if items else {}
    preview_cmd = command_to_string(build_command(current_item)) if items else ""
    pydw_lines = build_pydw_preview_lines(current_item.get("pyDW"))
    status_lines = get_pydw_status_lines()

    while True:
        status_lines = get_pydw_status_lines()

        draw_ui(stdscr, categories, cat_index, item_index, preview_cmd, pydw_lines, status_lines)
        key = stdscr.getch()

        # Exit keys
        if key in (ord('q'), ord('Q'), 27, curses.KEY_F10, 24):
            break

        if key == curses.KEY_UP:
            item_index = max(0, item_index - 1)

        elif key == curses.KEY_DOWN:
            items = categories[cat_index]["items"]
            if items:
                item_index = min(len(items) - 1, item_index + 1)

        elif key == curses.KEY_LEFT:
            cat_index = max(0, cat_index - 1)
            item_index = 0

        elif key == curses.KEY_RIGHT:
            cat_index = min(len(categories) - 1, cat_index + 1)
            item_index = 0

        elif key in (curses.KEY_ENTER, 10, 13):
            items = categories[cat_index]["items"]
            if not items:
                continue

            item = items[item_index]
            cmd_list = build_command(item)
            cmd_str = command_to_string(cmd_list)
            pydw = item.get("pyDW")

            curses.endwin()
            print("\nLaunching:")
            print(cmd_str)
            print()

            pydw_pre_launch(pydw)
            try:
                subprocess.call(cmd_list)
            finally:
                pydw_post_launch(pydw)

            input("\nPress Enter to return to launcher...")
            stdscr = curses.initscr()
            curses.curs_set(0)
            curses.start_color()
            stdscr.keypad(True)

        # Update preview
        items = categories[cat_index]["items"]
        if items:
            current_item = items[item_index]
            preview_cmd = command_to_string(build_command(current_item))
            pydw_lines = build_pydw_preview_lines(current_item.get("pyDW"))
        else:
            preview_cmd = ""
            pydw_lines = ["pyDW: none"]


if __name__ == "__main__":
    curses.wrapper(main)

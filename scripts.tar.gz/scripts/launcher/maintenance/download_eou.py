#!/usr/bin/env python3
from pathlib import Path
from common import share1, download_file, extract_zip, safe_unlink

def main():
    print("Downloading latest NitrOS9 EOU...")

    eou_dir = share1() / "EMU" / "EOU"

    urls = [
        "http://lcurtisboyle.com/nitros9/NitrOS9-EOU-6309-LATEST.zip",
        "http://lcurtisboyle.com/nitros9/NitrOS9-EOU-6809-LATEST.zip",
        "http://www.lcurtisboyle.com/nitros9/EOU_USER_empty_harddrive.zip"
    ]

    zip_paths = [download_file(url, eou_dir) for url in urls]

    print("Extracting EOU files...")
    for zp in zip_paths:
        extract_zip(zp, eou_dir, flatten=False)
        safe_unlink(zp)

    print("NitrOS9 EOU updated successfully.")

if __name__ == "__main__":
    main()

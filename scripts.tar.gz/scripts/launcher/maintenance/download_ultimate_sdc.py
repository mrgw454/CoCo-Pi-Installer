#!/usr/bin/env python3
from pathlib import Path
from common import share1, download_file, extract_zip, safe_unlink, ensure_dir

def main():
    print("Downloading Ultimate CoCoSDC Image...")

    url = (
        "https://colorcomputerarchive.com/repo/Disks/Coco%20SDC/Image/"
        "Coco%20SDC%20Image%20(2025-08-28).zip"
    )

    sdc_dir = share1() / "SDC"
    ensure_dir(sdc_dir)

    zip_path = download_file(url, sdc_dir)

    print("Extracting Ultimate SDC Image...")
    extract_zip(zip_path, sdc_dir, flatten=False)

    safe_unlink(zip_path)
    print("Ultimate SDC Image updated successfully.")

if __name__ == "__main__":
    main()

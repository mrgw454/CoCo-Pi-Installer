#!/usr/bin/env python3
import sys
import os
import subprocess
from pathlib import Path
from datetime import datetime
from common import home, share1, git_clone_or_pull, is_windows

def python2_path():
    """
    Return the absolute path to the Python 2.7 interpreter installed by pyenv,
    without requiring pyenv to be on PATH or initialized.
    """
    if is_windows():
        return str(Path(os.environ["USERPROFILE"]) /
                   ".pyenv" / "pyenv-win" / "versions" /
                   "2.7.18" / "python.exe")
    else:
        return str(Path.home() /
                   ".pyenv" / "versions" /
                   "2.7.18" / "bin" / "python2.7")

def main():
    print("Updating EOU-IDE project...")

    src_dir = home() / "source"
    dest = src_dir / "eou_ide"
    repo_url = "https://github.com/n6il/eou_ide.git"

    # Archive old folder if present
    if dest.exists():
        timestamp = datetime.now().strftime("%Y-%m-%d_%H.%M.%S")
        backup = src_dir / f"eou_ide-{timestamp}"
        print(f"Archiving existing folder to {backup}")
        dest.rename(backup)

    git_clone_or_pull(repo_url, dest)

    # Check for required EOU HDD file
    eou_dir = share1() / "EMU" / "EOU"
    vhd = eou_dir / "63SDC.VHD"

    if not vhd.exists():
        print(f"ERROR: Required EOU HDD file missing: {vhd}")
        sys.exit(1)

    print("Copying VHD into project...")
    subprocess.run(["cp", str(vhd), str(dest)], check=True)

    # Absolute Python 2.7 path
    py2 = python2_path()

    if not Path(py2).exists():
        print(f"ERROR: Python 2.7 not found at expected location:\n  {py2}")
        sys.exit(1)

    print("Building disk images...")

    cmds = [
        [py2, "makebootfileide.py", "--cpu", "6309", "--vhd", "63SDC.VHD", "--emulator", "mame"],
        [py2, "makebootfileide.py", "--cpu", "6309", "--vhd", "63SDC.VHD", "--emulator", "mame", "--dw", "becker"],
        [py2, "makebootfileide.py", "--cpu", "6309", "--vhd", "63SDC.VHD", "--emulator", "xroar"],
        [py2, "makebootfileide.py", "--cpu", "6309", "--vhd", "63SDC.VHD", "--emulator", "xroar", "--dw", "becker"]
    ]

    for cmd in cmds:
        print("  Running:", " ".join(cmd))
        subprocess.run(cmd, cwd=dest, check=True)

    # Verify output
    build_dir = dest / "build"
    mame_img = build_dir / "6309_ide_mame" / "63IDE.dsk"
    xroar_img = build_dir / "6309_ide_xroar" / "63IDE.dsk"

    if not mame_img.exists():
        print(f"ERROR: MAME HDD image not created: {mame_img}")
        sys.exit(1)

    if not xroar_img.exists():
        print(f"ERROR: XRoar HDD image not created: {xroar_img}")
        sys.exit(1)

    print("EOU-IDE updated successfully.")

if __name__ == "__main__":
    main()

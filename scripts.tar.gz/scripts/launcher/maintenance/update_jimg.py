#!/usr/bin/env python3
from pathlib import Path
from common import home, share1, git_clone_or_pull, ensure_symlink

def main():
    print("Updating Jim Gerrie's MC-10 repository...")

    repo_url = "https://github.com/jggames/trs80mc10.git"
    dest = home() / "source" / "trs80mc10"
    link = share1() / "JIMG"

    git_clone_or_pull(repo_url, dest)

    target = dest / "quicktype" / "Latest_Jim_G_MC-10_Compilation"
    if not target.exists():
        print(f"ERROR: Expected directory missing: {target}")
        sys.exit(1)

    ensure_symlink(target, link)
    print("JIMG updated successfully.")

if __name__ == "__main__":
    main()

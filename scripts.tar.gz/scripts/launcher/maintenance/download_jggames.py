#!/usr/bin/env python3
from pathlib import Path
from common import share1, download_file, extract_zip, safe_unlink

def main():
    print("Downloading JGGAMES archive...")

    url = "https://github.com/jggames/jggames/releases/download/11/JGGAMES.zip"

    sdc_dir = share1() / "SDC"
    jg_dir = sdc_dir / "JGGAMES"

    zip_path = download_file(url, sdc_dir)

    print("Extracting JGGAMES...")
    extract_zip(zip_path, jg_dir, flatten=True)

    safe_unlink(zip_path)
    print("JGGAMES updated successfully.")

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
from pathlib import Path
from common import share1, download_file, extract_zip, safe_unlink

def main():
    print("Downloading Fuzix...")

    fuzix_dir = share1() / "DW4" / "GORDON" / "FUZIX"

    nightly = "http://fuzix.play-classics.net/fuzix-nightly.zip"
    tested  = "http://fuzix.play-classics.net/fuzix-tested.zip"

    # Always download both; user can choose which to use later
    print("Downloading nightly build...")
    nightly_zip = download_file(nightly, fuzix_dir)

    print("Extracting nightly build...")
    extract_zip(nightly_zip, fuzix_dir)
    safe_unlink(nightly_zip)

    print("Downloading tested build...")
    tested_zip = download_file(tested, fuzix_dir)

    print("Extracting tested build...")
    extract_zip(tested_zip, fuzix_dir)
    safe_unlink(tested_zip)

    print("Fuzix updated successfully.")

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
from pathlib import Path
from common import home, share1, git_clone_or_pull, ensure_symlink, ensure_dir

def main():
    print("Updating Ron Delvaux's picture gallery...")

    repo_url = "https://github.com/mrgw454/RonD.git"
    dest = home() / "source" / "RonD"
    link_dir = share1() / "RonD"
    link = link_dir / "BMP"

    git_clone_or_pull(repo_url, dest)

    target = dest / "BMP"
    if not target.exists():
        print(f"ERROR: Expected BMP folder missing: {target}")
        sys.exit(1)

    ensure_dir(link_dir)
    ensure_symlink(target, link)

    print("RonD gallery updated successfully.")

if __name__ == "__main__":
    main()

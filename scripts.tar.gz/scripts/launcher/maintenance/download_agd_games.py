#!/usr/bin/env python3
from pathlib import Path
from common import share1, download_file, extract_zip, safe_unlink

def main():
    print("Downloading AGD Games...")

    url = (
        "https://colorcomputerarchive.com/repo/Disks/Coco%20SDC/Games/"
        "AGD%20Games%20v3.0%20(303)%20(Pere%20Serrat)%20(Ports%20from%20ZX%20Spectrum)%20(Coco%20SDC).zip"
    )

    sdc_dir = share1() / "SDC"
    agd_dir = sdc_dir / "AGD"

    zip_path = download_file(url, sdc_dir)

    print("Extracting AGD Games...")
    extract_zip(zip_path, agd_dir, flatten=True)

    safe_unlink(zip_path)
    print("AGD Games updated successfully.")

if __name__ == "__main__":
    main()

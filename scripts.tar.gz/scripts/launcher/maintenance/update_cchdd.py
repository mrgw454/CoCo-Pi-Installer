#!/usr/bin/env python3
from pathlib import Path
from common import home, share1, git_clone_or_pull, extract_zip, ensure_dir

def main():
    print("Updating CCHDD repository...")

    repo_url = "https://github.com/mrgw454/CCHDD.git"
    dest = home() / "source" / "CCHDD"
    vhd_dir = share1() / "EMU" / "VHD"

    git_clone_or_pull(repo_url, dest)

    zip_path = dest / "YA-DOS HDD Image (2020-04-24).zip"
    if not zip_path.exists():
        print(f"ERROR: Expected ZIP not found: {zip_path}")
        sys.exit(1)

    print("Extracting HDD image...")
    extract_zip(zip_path, vhd_dir)

    # Ensure symlink HDD.DSK → DECBVHD.DSK
    link = vhd_dir / "HDD.DSK"
    target = vhd_dir / "DECBVHD.DSK"

    if not target.exists():
        print(f"ERROR: Expected target file missing: {target}")
        sys.exit(1)

    if not link.exists():
        print(f"Creating symlink {link} -> {target}")
        link.symlink_to(target)
    else:
        print("Symlink already exists.")

    print("CCHDD updated successfully.")

if __name__ == "__main__":
    main()

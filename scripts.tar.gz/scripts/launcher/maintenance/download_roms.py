#!/usr/bin/env python3
import hashlib
from pathlib import Path
from common import share1, download_file, extract_zip, safe_unlink

def md5_matches(file_path: Path, md5_path: Path) -> bool:
    try:
        expected = md5_path.read_text().split()[0].strip()
        h = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest() == expected
    except Exception:
        return False

def main():
    print("Downloading ROM files...")

    rom_dir = share1() / "roms"

    zip_url = "http://rickadams.org/ronklein/CoCoPi-roms.zip"
    md5_url = "http://rickadams.org/ronklein/CoCoPi-roms.md5"

    zip_path = download_file(zip_url, rom_dir)
    md5_path = download_file(md5_url, rom_dir)

    print("Verifying MD5 checksum...")
    if not md5_matches(zip_path, md5_path):
        print("ERROR: MD5 checksum failed. Aborting.")
        safe_unlink(zip_path)
        safe_unlink(md5_path)
        sys.exit(1)

    print("Checksum OK. Extracting ROMs...")
    extract_zip(zip_path, rom_dir, flatten=False)

    safe_unlink(zip_path)
    safe_unlink(md5_path)
    print("ROMs updated successfully.")

if __name__ == "__main__":
    main()

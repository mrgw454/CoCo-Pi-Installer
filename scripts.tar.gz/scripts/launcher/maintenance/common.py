#!/usr/bin/env python3
import os
import sys
import platform
import shutil
import zipfile
import urllib.request
from pathlib import Path
import subprocess

# ---------------- Platform helpers ----------------

def is_windows():
    return platform.system().lower().startswith("win")

def home():
    return Path(os.environ["USERPROFILE"]) if is_windows() else Path(os.environ["HOME"])

def share1():
    # Linux:  /media/share1
    # Windows: E:/media/share1
    return Path("E:/media/share1") if is_windows() else Path("/media/share1")

# ---------------- Filesystem helpers ----------------

def ensure_dir(path: Path):
    try:
        path.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        print(f"ERROR: Could not create directory {path}: {e}")
        sys.exit(1)

def safe_unlink(path: Path):
    try:
        if path.exists():
            path.unlink()
    except Exception as e:
        print(f"ERROR: Could not remove file {path}: {e}")
        sys.exit(1)

# ---------------- Download helpers ----------------

def download_file(url: str, dest_dir: Path) -> Path:
    ensure_dir(dest_dir)
    filename = dest_dir / Path(url).name

    print(f"  GET {url}")
    try:
        urllib.request.urlretrieve(url, filename)
    except Exception as e:
        print(f"ERROR: Failed to download {url}: {e}")
        sys.exit(1)

    print(f"  Saved to {filename}")
    return filename

# ---------------- ZIP extraction ----------------

def extract_zip(zip_path: Path, dest_dir: Path, flatten=False):
    ensure_dir(dest_dir)
    print(f"  Extracting {zip_path.name}...")

    try:
        with zipfile.ZipFile(zip_path, 'r') as z:
            if flatten:
                count = 0
                for member in z.namelist():
                    if not member.endswith('/'):
                        target = dest_dir / Path(member).name
                        with z.open(member) as src, open(target, 'wb') as out:
                            shutil.copyfileobj(src, out)
                        count += 1
                print(f"  Extracted {count} files (flattened)")
            else:
                z.extractall(dest_dir)
                print(f"  Extracted {len(z.namelist())} files")
    except Exception as e:
        print(f"ERROR: Failed to extract {zip_path}: {e}")
        sys.exit(1)

# ---------------- Git helpers ----------------

def git_clone_or_pull(repo_url: str, dest: Path):
    if dest.exists():
        print(f"  Updating existing repo at {dest}")
        subprocess.run(["git", "-C", str(dest), "pull"], check=True)
    else:
        print(f"  Cloning repo {repo_url}")
        subprocess.run(["git", "clone", repo_url, str(dest)], check=True)

# ---------------- Symlink helpers ----------------

def ensure_symlink(target: Path, link: Path):
    if link.exists() or link.is_symlink():
        return
    ensure_dir(link.parent)
    try:
        link.symlink_to(target)
    except Exception as e:
        print(f"ERROR: Failed to create symlink {link} -> {target}: {e}")
        sys.exit(1)

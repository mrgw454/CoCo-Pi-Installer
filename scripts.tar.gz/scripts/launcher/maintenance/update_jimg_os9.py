#!/usr/bin/env python3
from pathlib import Path
from common import home, share1, git_clone_or_pull, ensure_symlink

def main():
    print("Updating Jim Gerrie's NitrOS9 EOU Testing repository...")

    repo_url = "https://github.com/jggames/JimGerrieOS9.git"
    dest = home() / "source" / "JimGerrieOS9"
    link = share1() / "JimGerrieOS9"

    git_clone_or_pull(repo_url, dest)

    target = dest / "EOU_Testing"
    if not target.exists():
        print(f"ERROR: Expected EOU_Testing folder missing: {target}")
        sys.exit(1)

    ensure_symlink(target, link)
    print("JimG OS9 updated successfully.")

if __name__ == "__main__":
    main()

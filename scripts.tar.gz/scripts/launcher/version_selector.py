#!/usr/bin/env python3
"""
version_selector.py — enumerate and activate versioned emulator installs.

All paths come from the configurable section of launcher.py so there is a
single place to edit when the environment changes.

Linux layout (MAME example):
  /opt/mame-0.270/          ← versioned install dir
  /opt/mame-0.271/          ← another version
  /opt/mame -> mame-0.271   ← canonical symlink (managed here)
  /usr/local/bin/mame -> /opt/mame/mame  ← kept in sync automatically

Linux layout (XRoar example):
  /usr/local/bin/xroar-0.40.3   ← versioned binary
  /usr/local/bin/xroar-0.41.0
  /usr/local/bin/xroar -> xroar-0.41.0  ← canonical symlink (managed here)

Windows layout (both emulators):
  %USERPROFILE%/mame-0.270/     ← versioned install dir
  %USERPROFILE%/mame            ← NTFS junction pointing to the active version
  %USERPROFILE%/xroar-0.41.0/
  %USERPROFILE%/xroar           ← NTFS junction
"""

import subprocess
import sys
from pathlib import Path

# ------------------------------------------------------------------
# Import all path config from launcher.py (single source of truth).
# Fallback values are only used if this module is run standalone
# outside the launcher tree.
# ------------------------------------------------------------------

try:
    _here = str(Path(__file__).resolve().parent)
    if _here not in sys.path:
        sys.path.insert(0, _here)
    from launcher import (
        IS_WINDOWS, IS_LINUX,
        MAME_EXE_LINUX, MAME_EXE_WINDOWS,
        XROAR_EXE_LINUX, XROAR_EXE_WINDOWS,
        MAME_VERSIONS_DIR_LINUX, XROAR_VERSIONS_DIR_LINUX,
        WIN_HOME,
        VCC_EXE_WINDOWS,
    )
except ImportError:
    import os, platform
    IS_WINDOWS = (os.name == "nt")
    IS_LINUX   = (os.name == "posix" and platform.system() == "Linux")
    WIN_HOME   = os.environ.get("USERPROFILE", "")
    MAME_EXE_LINUX   = "mame"
    MAME_EXE_WINDOWS = str(Path(WIN_HOME) / "mame" / "mame.exe")
    XROAR_EXE_LINUX  = "xroar"
    XROAR_EXE_WINDOWS = str(Path(WIN_HOME) / "xroar" / "xroar.exe")
    VCC_EXE_WINDOWS  = str(Path(WIN_HOME) / "VCC" / "VCC.exe")
    MAME_VERSIONS_DIR_LINUX  = "/opt"
    XROAR_VERSIONS_DIR_LINUX = "/usr/local/bin"

# ------------------------------------------------------------------
# Derived paths (not user-configurable — computed from the above)
# ------------------------------------------------------------------

# Linux canonical symlinks
_MAME_CANONICAL_LINUX  = Path(MAME_VERSIONS_DIR_LINUX) / "mame"
_XROAR_CANONICAL_LINUX = Path(XROAR_VERSIONS_DIR_LINUX) / "xroar"

# Windows: canonical junction == parent of the exe (e.g. WIN_HOME/mame)
#          search dir         == parent of that  (e.g. WIN_HOME)
_MAME_JUNCTION_WIN    = Path(MAME_EXE_WINDOWS).parent
_XROAR_JUNCTION_WIN   = Path(XROAR_EXE_WINDOWS).parent
_VCC_JUNCTION_WIN     = Path(VCC_EXE_WINDOWS).parent
_MAME_SEARCH_DIR_WIN  = _MAME_JUNCTION_WIN.parent
_XROAR_SEARCH_DIR_WIN = _XROAR_JUNCTION_WIN.parent
_VCC_SEARCH_DIR_WIN   = _VCC_JUNCTION_WIN.parent


# ------------------------------------------------------------------
# ENUMERATION
# ------------------------------------------------------------------

def find_mame_versions():
    """Return a sorted list of MAME version directories."""
    if IS_LINUX:
        return sorted(
            p for p in Path(MAME_VERSIONS_DIR_LINUX).glob("mame-*") if p.is_dir()
        )
    else:
        return sorted(
            p for p in _MAME_SEARCH_DIR_WIN.glob("mame-*") if p.is_dir()
        )


def find_xroar_versions():
    """Return a sorted list of XRoar version binaries (Linux) or directories (Windows)."""
    if IS_LINUX:
        return sorted(
            p for p in Path(XROAR_VERSIONS_DIR_LINUX).glob("xroar-*") if p.is_file()
        )
    else:
        return sorted(
            p for p in _XROAR_SEARCH_DIR_WIN.glob("xroar-*") if p.is_dir()
        )


def find_vcc_versions():
    """Return a sorted list of VCC version directories (Windows only)."""
    if not IS_WINDOWS:
        return []
    return sorted(
        p for p in _VCC_SEARCH_DIR_WIN.glob("VCC-*") if p.is_dir()
    )


# ------------------------------------------------------------------
# ACTIVATION
# ------------------------------------------------------------------

def activate_mame(path):
    """Activate a MAME version by updating the canonical symlink or junction."""
    if IS_LINUX:
        subprocess.call(["sudo", "rm", "-f", str(_MAME_CANONICAL_LINUX)])
        subprocess.call(["sudo", "ln", "-s", str(path), str(_MAME_CANONICAL_LINUX)])

        # Ensure /usr/local/bin/mame exists and points into the active dir.
        bin_link = Path("/usr/local/bin/mame")
        if not bin_link.exists():
            subprocess.call([
                "sudo", "ln", "-s",
                str(_MAME_CANONICAL_LINUX / "mame"),
                str(bin_link),
            ])
    else:
        if _MAME_JUNCTION_WIN.exists():
            subprocess.call(["rmdir", "/q", str(_MAME_JUNCTION_WIN)], shell=True)
        subprocess.call(
            ["mklink", "/j", str(_MAME_JUNCTION_WIN), str(path)], shell=True
        )


def activate_xroar(path):
    """Activate an XRoar version by updating the canonical symlink or junction."""
    if IS_LINUX:
        subprocess.call(["sudo", "rm", "-f", str(_XROAR_CANONICAL_LINUX)])
        subprocess.call(["sudo", "ln", "-s", str(path), str(_XROAR_CANONICAL_LINUX)])
    else:
        if _XROAR_JUNCTION_WIN.exists():
            subprocess.call(["rmdir", "/q", str(_XROAR_JUNCTION_WIN)], shell=True)
        subprocess.call(
            ["mklink", "/j", str(_XROAR_JUNCTION_WIN), str(path)], shell=True
        )


def activate_vcc(path):
    """Activate a VCC version by updating the canonical NTFS junction (Windows only)."""
    if not IS_WINDOWS:
        return
    if _VCC_JUNCTION_WIN.exists():
        subprocess.call(["rmdir", "/q", str(_VCC_JUNCTION_WIN)], shell=True)
    subprocess.call(
        ["mklink", "/j", str(_VCC_JUNCTION_WIN), str(path)], shell=True
    )


# ------------------------------------------------------------------
# PUBLIC API (used by launcher.py)
# ------------------------------------------------------------------

def get_versions(action):
    """Return a list of version paths for the given action string."""
    if action == "select_mame":
        return find_mame_versions()
    if action == "select_xroar":
        return find_xroar_versions()
    if action == "select_vcc":
        return find_vcc_versions()
    return []


def activate(action, path):
    """Activate the selected version."""
    if action == "select_mame":
        activate_mame(path)
    elif action == "select_xroar":
        activate_xroar(path)
    elif action == "select_vcc":
        activate_vcc(path)

# PowerShell wrapper for audit_all.py
# run with 
# pwsh -ExecutionPolicy Bypass -File audit_all.ps1

$script = "$PSScriptRoot\audit_all.py"

if (-not (Test-Path $script)) {
    Write-Host "audit_all.py not found in $PSScriptRoot" -ForegroundColor Red
    exit 1
}

# Enable ANSI colors
$env:PYTHONIOENCODING = "utf-8"
$env:TERM = "xterm-256color"

python $script

#!/usr/bin/env python3
"""
Extract address→description entries from Bob Russell's Color Computer Memory Map PDF
and merge richer descriptions into memory-map.json.

Usage:
    python3 extract_bob_russell.py [--dry-run] [--dump]

    --dry-run   Show what would change without writing
    --dump      Dump all extracted entries to stdout
"""

import json
import re
import sys
import subprocess
from pathlib import Path

PDF_PATH = Path("/media/share1/source/docs/Color Computer Memory Map (Bob Russell).pdf")
MEMORY_MAP_PATH = Path(__file__).parent.parent / "data" / "memory-map.json"

# Page header lines to skip
HEADER_RE = re.compile(
    r"^Color Computer (Memory )?H?[Mm]ap By Bob Russell|"
    r"^Version|^Beginning|^Ending|^DEC\b|^HEX\b|^ADDR\b|^Page \d+|"
    r"^\d{2}/\d{2}/\d{2}|"           # dates like 10/01/83
    r"^Description$|^RAM$|^ROM$|"     # standalone section labels
    r"^System Use|^Cont\.|"
    r"^\s*$"
)

# Address line: 5-digit dec, space, 4-digit hex (start), optionally followed by end range
ADDR_LINE_RE = re.compile(
    r"^(\d{5})\s+([0-9A-Fa-f]{4})(?:\s+(\d{5})\s+([0-9A-Fa-f]{4}))?\s*$"
)


def extract_pdf_text(pdf_path: Path) -> list[str]:
    result = subprocess.run(
        ["pdftotext", str(pdf_path), "-"],
        capture_output=True, text=True, check=True
    )
    return result.stdout.splitlines()


def parse_entries(lines: list[str]) -> list[dict]:
    """Parse text into list of {addr_dec, addr_hex, end_dec, end_hex, description}."""
    entries = []
    current = None
    desc_lines = []

    def flush():
        if current is not None:
            desc = " ".join(desc_lines).strip()
            # Collapse multiple spaces
            desc = re.sub(r"\s+", " ", desc)
            entries.append({**current, "description": desc})

    for line in lines:
        # Skip page headers and blank lines
        if HEADER_RE.match(line) or not line.strip():
            continue

        m = ADDR_LINE_RE.match(line)
        if m:
            addr_dec = int(m.group(1))
            end_dec = int(m.group(3)) if m.group(3) else None
            # Skip section-header sentinel lines (e.g. 00000–7FFF "RAM", 00000–03FF "System Use")
            if addr_dec == 0 and end_dec is not None and end_dec >= 1023:
                current = None
                desc_lines = []
                continue
            flush()
            current = {
                "addr_dec": addr_dec,
                "addr_hex": m.group(2).upper(),
                "end_dec": end_dec,
                "end_hex": m.group(4).upper() if m.group(4) else None,
            }
            desc_lines = []
        elif current is not None:
            stripped = line.strip()
            if stripped:
                desc_lines.append(stripped)

    flush()
    return entries


def merge(memory_map: list[dict], br_entries: list[dict], dry_run=False) -> tuple[int, int]:
    """
    Merge Bob Russell descriptions into memory_map entries.
    BR entries with addr_dec matching a memory-map address_dec get their
    description appended as a second sentence (if not already contained).
    Returns (matched, updated) counts.
    """
    # Build lookup: decimal address → BR entry (first match wins for single-byte entries)
    br_by_addr: dict[int, dict] = {}
    for e in br_entries:
        addr = e["addr_dec"]
        if addr not in br_by_addr:
            br_by_addr[addr] = e
        # Also index range entries by each address in range (for sub-byte entries)
        # but don't overwrite single-address entries
        if e["end_dec"] is not None:
            for a in range(e["addr_dec"], e["end_dec"] + 1):
                if a not in br_by_addr:
                    br_by_addr[a] = e

    matched = 0
    updated = 0

    for entry in memory_map:
        addr_dec = entry.get("address_dec")
        if addr_dec is None:
            continue
        br = br_by_addr.get(addr_dec)
        if br is None:
            continue
        matched += 1

        br_desc = br["description"]
        if not br_desc:
            continue

        # Skip descriptions that are just address lines or contain embedded OCR garbage
        if re.match(r"^\d{5}\s+[0-9A-Fa-f<]{4}", br_desc):
            continue
        # Skip OCR garbage: contains spaced-out words like "De scription" or embedded addresses
        if re.search(r"\d{5}\s+[0-9A-Fa-f]{4}", br_desc):
            continue
        # Skip obviously spaced OCR text (letter-spaced words like "C a r t r i d g e")
        if len(re.findall(r"\b[A-Za-z]\b", br_desc)) > 6:
            continue

        existing = entry.get("description", "")
        # Skip if BR description already present
        if br_desc.lower() in existing.lower():
            continue

        new_desc = f"{existing} | {br_desc}" if existing else br_desc

        if dry_run:
            print(f"  [{entry['address']}] {existing!r}")
            print(f"       -> {new_desc!r}")
        else:
            entry["description"] = new_desc

        updated += 1

    return matched, updated


def main():
    dry_run = "--dry-run" in sys.argv
    dump = "--dump" in sys.argv

    print(f"Extracting text from PDF...")
    lines = extract_pdf_text(PDF_PATH)
    print(f"  {len(lines)} lines read")

    print("Parsing entries...")
    entries = parse_entries(lines)
    print(f"  {len(entries)} entries parsed")

    if dump:
        for e in entries:
            range_str = f"-{e['end_hex']}" if e["end_hex"] else ""
            print(f"  {e['addr_hex']}{range_str}: {e['description']}")
        return

    print(f"\nLoading {MEMORY_MAP_PATH}...")
    with open(MEMORY_MAP_PATH) as f:
        memory_map = json.load(f)
    print(f"  {len(memory_map)} entries in memory-map.json")

    print(f"\nMerging{' (dry run)' if dry_run else ''}...")
    matched, updated = merge(memory_map, entries, dry_run=dry_run)
    print(f"  Matched: {matched}, Updated: {updated}")

    if not dry_run and updated > 0:
        with open(MEMORY_MAP_PATH, "w") as f:
            json.dump(memory_map, f, indent=2)
        print(f"  Wrote {MEMORY_MAP_PATH}")


if __name__ == "__main__":
    main()

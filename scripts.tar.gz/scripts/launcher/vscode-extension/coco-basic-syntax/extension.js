'use strict';

const vscode = require('vscode');
const path   = require('path');
const fs     = require('fs');

// ── ASM instruction database ──────────────────────────────────────────────
let asmInstructions = null;   // mnemonic.toUpperCase() -> entry

function loadAsmInstructions() {
    if (asmInstructions) return;
    const dbPath = path.join(__dirname, 'data', 'asm-instructions.json');
    try {
        const entries = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
        asmInstructions = new Map();
        for (const e of entries) {
            asmInstructions.set(e.mnemonic.toUpperCase(), e);
        }
    } catch (err) {
        console.error('coco-basic: failed to load asm-instructions.json', err);
        asmInstructions = new Map();
    }
}

function buildAsmHover(mnemonic) {
    const entry = asmInstructions.get(mnemonic.toUpperCase());
    if (!entry) return null;

    const is6309 = entry.cpu === '6309';
    const heading = is6309
        ? `### \`${entry.mnemonic}\` *(HD6309 only)*`
        : `### \`${entry.mnemonic}\``;

    const modesStr = Array.isArray(entry.modes)
        ? entry.modes.join(', ')
        : entry.modes;

    const md = new vscode.MarkdownString();
    md.isTrusted = true;
    md.appendMarkdown(`${heading}\n\n`);
    md.appendMarkdown(`${entry.desc}\n\n`);
    md.appendMarkdown(`**Modes:** ${modesStr}  \n`);
    md.appendMarkdown(`**Cycles:** ${entry.cycles}  |  **Flags:** \`${entry.flags}\`  \n`);
    md.appendMarkdown(`**CPU:** ${is6309 ? 'HD6309 only' : '6809 / 6309'}`);
    return new vscode.Hover(md);
}

// ── Memory map database ────────────────────────────────────────────────────
let memoryMap = null;   // addr_dec -> entry
let memoryMapByLabel = null;

function loadMemoryMap() {
    if (memoryMap) return;
    const dbPath = path.join(__dirname, 'data', 'memory-map.json');
    try {
        const entries = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
        memoryMap = new Map();
        memoryMapByLabel = new Map();
        for (const e of entries) {
            memoryMap.set(e.address_dec, e);
            memoryMapByLabel.set(e.label.toUpperCase(), e);
        }
    } catch (err) {
        console.error('coco-basic: failed to load memory-map.json', err);
        memoryMap = new Map();
        memoryMapByLabel = new Map();
    }
}

// ── Keyword documentation ──────────────────────────────────────────────────
const KEYWORD_DOCS = {
    // ── Color BASIC ──
    'FOR':      { desc: 'Begin a FOR/NEXT loop.', syntax: 'FOR var = start TO end [STEP n]', variant: 'CB' },
    'GOTO':     { desc: 'Jump to a line number.', syntax: 'GOTO linenum', variant: 'CB' },
    'GOSUB':    { desc: 'Call a subroutine at a line number.', syntax: 'GOSUB linenum', variant: 'CB' },
    'RETURN':   { desc: 'Return from a GOSUB subroutine.', syntax: 'RETURN', variant: 'CB' },
    'IF':       { desc: 'Conditional branch.', syntax: 'IF condition THEN ... [ELSE ...]', variant: 'CB' },
    'THEN':     { desc: 'Part of IF/THEN statement.', syntax: 'IF condition THEN statement', variant: 'CB' },
    'ELSE':     { desc: 'Alternative branch in IF/THEN/ELSE.', syntax: 'IF cond THEN ... ELSE ...', variant: 'CB' },
    'NEXT':     { desc: 'End of a FOR/NEXT loop.', syntax: 'NEXT [var]', variant: 'CB' },
    'PRINT':    { desc: 'Output to screen (or file with #n).', syntax: 'PRINT [#n,] expr[;|,] ...', variant: 'CB' },
    'INPUT':    { desc: 'Read input from keyboard or file.', syntax: 'INPUT [#n,] ["prompt";] var[,var...]', variant: 'CB' },
    'DIM':      { desc: 'Declare an array.', syntax: 'DIM var(size)[, var(size)...]', variant: 'CB' },
    'DATA':     { desc: 'Store literal values for READ.', syntax: 'DATA val1, val2, ...', variant: 'CB' },
    'READ':     { desc: 'Read next value from DATA statement.', syntax: 'READ var[, var...]', variant: 'CB' },
    'RESTORE':  { desc: 'Reset DATA pointer to start (or a line).', syntax: 'RESTORE [linenum]', variant: 'CB' },
    'POKE':     { desc: 'Write a byte value to a memory address.', syntax: 'POKE address, value', variant: 'CB' },
    'PEEK':     { desc: 'Read a byte value from a memory address.', syntax: 'PEEK(address)', variant: 'CB' },
    'EXEC':     { desc: 'Execute machine language code at an address.', syntax: 'EXEC address', variant: 'CB' },
    'RUN':      { desc: 'Run the current BASIC program.', syntax: 'RUN [linenum]', variant: 'CB' },
    'NEW':      { desc: 'Erase the current BASIC program.', syntax: 'NEW', variant: 'CB' },
    'LIST':     { desc: 'List the BASIC program.', syntax: 'LIST [start[-end]]', variant: 'CB' },
    'LLIST':    { desc: 'List BASIC program to printer.', syntax: 'LLIST [start[-end]]', variant: 'CB' },
    'CLEAR':    { desc: 'Clear all variables; optionally set string space and top of memory.', syntax: 'CLEAR [size[,top]]', variant: 'CB' },
    'CLS':      { desc: 'Clear the screen. Optional color argument (0–8).', syntax: 'CLS [color]', variant: 'CB' },
    'END':      { desc: 'End the BASIC program.', syntax: 'END', variant: 'CB' },
    'STOP':     { desc: 'Pause execution; CONT resumes.', syntax: 'STOP', variant: 'CB' },
    'CONT':     { desc: 'Continue after a STOP or break.', syntax: 'CONT', variant: 'CB' },
    'SOUND':    { desc: 'Generate a tone. Frequency 1–255, duration 1–255.', syntax: 'SOUND freq, duration', variant: 'CB' },
    'MOTOR':    { desc: 'Turn cassette motor on or off.', syntax: 'MOTOR ON|OFF', variant: 'CB' },
    'AUDIO':    { desc: 'Route cassette audio to TV speaker.', syntax: 'AUDIO ON|OFF', variant: 'CB' },
    'CLOAD':    { desc: 'Load a BASIC program from cassette.', syntax: 'CLOAD ["filename"]', variant: 'CB' },
    'CLOADM':   { desc: 'Load a machine language file from cassette.', syntax: 'CLOADM ["filename"][,offset]', variant: 'CB' },
    'CSAVE':    { desc: 'Save the BASIC program to cassette.', syntax: 'CSAVE ["filename"]', variant: 'CB' },
    'CSAVEM':   { desc: 'Save a machine language block to cassette.', syntax: 'CSAVEM "name",start,end,exec', variant: 'CB' },
    'OPEN':     { desc: 'Open a file for I/O.', syntax: 'OPEN "mode",#n,"filename"[,reclen]', variant: 'CB' },
    'CLOSE':    { desc: 'Close a file.', syntax: 'CLOSE [#n[,#n...]]', variant: 'CB' },
    'SKIPF':    { desc: 'Skip to end of cassette file.', syntax: 'SKIPF ["filename"]', variant: 'CB' },
    'SET':      { desc: 'Turn on a text/low-res graphics pixel.', syntax: 'SET(x, y [,color])', variant: 'CB' },
    'RESET':    { desc: 'Turn off a text/low-res graphics pixel.', syntax: 'RESET(x, y)', variant: 'CB' },
    'ON':       { desc: 'ON/GOTO, ON/GOSUB, ON BRK GOTO, ON ERR GOTO.', syntax: 'ON expr GOTO|GOSUB line[,line...]', variant: 'CB' },
    'REM':      { desc: 'Comment — rest of line is ignored.', syntax: 'REM comment', variant: 'CB' },
    'SGN':      { desc: 'Returns sign of a number: -1, 0, or 1.', syntax: 'SGN(n)', variant: 'CB' },
    'INT':      { desc: 'Returns the integer portion (floor).', syntax: 'INT(n)', variant: 'CB' },
    'ABS':      { desc: 'Returns absolute value.', syntax: 'ABS(n)', variant: 'CB' },
    'RND':      { desc: 'Returns a random number. RND(1)=0..1, RND(n)=1..n, RND(-n)=reseed.', syntax: 'RND(n)', variant: 'CB' },
    'SIN':      { desc: 'Returns the sine of an angle in radians.', syntax: 'SIN(n)', variant: 'CB' },
    'LEN':      { desc: 'Returns the length of a string.', syntax: 'LEN(s$)', variant: 'CB' },
    'STR$':     { desc: 'Converts a number to a string.', syntax: 'STR$(n)', variant: 'CB' },
    'VAL':      { desc: 'Converts a string to a numeric value.', syntax: 'VAL(s$)', variant: 'CB' },
    'ASC':      { desc: 'Returns ASCII code of first character of string.', syntax: 'ASC(s$)', variant: 'CB' },
    'CHR$':     { desc: 'Returns character for ASCII code.', syntax: 'CHR$(n)', variant: 'CB' },
    'EOF':      { desc: 'Returns non-zero if at end of file.', syntax: 'EOF(#n)', variant: 'CB' },
    'JOYSTK':   { desc: 'Returns joystick axis value 0–63.', syntax: 'JOYSTK(n)  (0=LV,1=LH,2=RV,3=RH)', variant: 'CB' },
    'LEFT$':    { desc: 'Returns leftmost n characters.', syntax: 'LEFT$(s$, n)', variant: 'CB' },
    'RIGHT$':   { desc: 'Returns rightmost n characters.', syntax: 'RIGHT$(s$, n)', variant: 'CB' },
    'MID$':     { desc: 'Returns substring. MID$ as statement replaces characters in-place.', syntax: 'MID$(s$, start[, len])', variant: 'CB' },
    'POINT':    { desc: 'Returns color of text/low-res pixel.', syntax: 'POINT(x, y)', variant: 'CB' },
    'INKEY$':   { desc: 'Returns single key pressed without waiting (empty string if none).', syntax: 'INKEY$', variant: 'CB' },
    'MEM':      { desc: 'Returns number of bytes of free memory.', syntax: 'MEM', variant: 'CB' },
    'USR':      { desc: 'Call user machine language routine (0–9).', syntax: 'USR[n](arg)', variant: 'CB' },
    'DEFUSR':   { desc: 'Define address for USR function.', syntax: 'DEFUSR[n]=address', variant: 'CB' },

    // ── Extended Color BASIC ──
    'DEL':      { desc: 'Delete a range of BASIC lines.', syntax: 'DEL start-end', variant: 'ECB' },
    'EDIT':     { desc: 'Enter line editor for a BASIC line.', syntax: 'EDIT linenum', variant: 'ECB' },
    'TRON':     { desc: 'Turn on trace mode (prints line numbers).', syntax: 'TRON', variant: 'ECB' },
    'TROFF':    { desc: 'Turn off trace mode.', syntax: 'TROFF', variant: 'ECB' },
    'LET':      { desc: 'Explicit variable assignment (LET is optional).', syntax: 'LET var = expr', variant: 'ECB' },
    'LINE':     { desc: 'Draw a line in hi-res or low-res mode.', syntax: 'LINE (x1,y1)-(x2,y2)[,color[,B[F]]]', variant: 'ECB' },
    'PCLS':     { desc: 'Clear a graphics page. Optional color.', syntax: 'PCLS [color]', variant: 'ECB' },
    'PSET':     { desc: 'Plot a pixel in hi-res mode.', syntax: 'PSET (x,y)[,color]', variant: 'ECB' },
    'PRESET':   { desc: 'Clear a pixel in hi-res mode.', syntax: 'PRESET (x,y)[,color]', variant: 'ECB' },
    'SCREEN':   { desc: 'Set display mode (text/graphics) and color set.', syntax: 'SCREEN mode[,colorset]', variant: 'ECB' },
    'PCLEAR':   { desc: 'Reserve graphics pages.', syntax: 'PCLEAR n  (n=1..4)', variant: 'ECB' },
    'COLOR':    { desc: 'Set foreground and background colors.', syntax: 'COLOR fg[,bg]', variant: 'ECB' },
    'CIRCLE':   { desc: 'Draw a circle in hi-res mode.', syntax: 'CIRCLE (x,y),radius[,color[,start,end[,aspect]]]', variant: 'ECB' },
    'PAINT':    { desc: 'Flood-fill an area in hi-res mode.', syntax: 'PAINT (x,y)[,fillcolor[,bordercolor]]', variant: 'ECB' },
    'GET':      { desc: 'Capture a hi-res rectangle into a buffer.', syntax: 'GET (x1,y1)-(x2,y2),buffer', variant: 'ECB' },
    'PUT':      { desc: 'Paste a captured buffer to the screen.', syntax: 'PUT (x,y),buffer[,action]', variant: 'ECB' },
    'DRAW':     { desc: 'Execute a draw command string (turtle graphics).', syntax: 'DRAW "commands"', variant: 'ECB' },
    'PCOPY':    { desc: 'Copy one graphics page to another.', syntax: 'PCOPY src, dest', variant: 'ECB' },
    'PMODE':    { desc: 'Set hi-res graphics mode and page.', syntax: 'PMODE mode[,page]  (mode=0..4)', variant: 'ECB' },
    'PLAY':     { desc: 'Play a music command string.', syntax: 'PLAY "string"', variant: 'ECB' },
    'DLOAD':    { desc: 'Load a BASIC program from tape at a specific baud rate.', syntax: 'DLOAD ["name"][,Dn][,Bn]', variant: 'ECB' },
    'RENUM':    { desc: 'Renumber BASIC lines.', syntax: 'RENUM [new[,old[,step]]]', variant: 'ECB' },
    'ATN':      { desc: 'Returns arctangent in radians.', syntax: 'ATN(n)', variant: 'ECB' },
    'COS':      { desc: 'Returns cosine of angle in radians.', syntax: 'COS(n)', variant: 'ECB' },
    'TAN':      { desc: 'Returns tangent of angle in radians.', syntax: 'TAN(n)', variant: 'ECB' },
    'EXP':      { desc: 'Returns e raised to the power n.', syntax: 'EXP(n)', variant: 'ECB' },
    'FIX':      { desc: 'Truncates toward zero (no rounding).', syntax: 'FIX(n)', variant: 'ECB' },
    'LOG':      { desc: 'Returns natural logarithm.', syntax: 'LOG(n)', variant: 'ECB' },
    'POS':      { desc: 'Returns current cursor column position.', syntax: 'POS(0)', variant: 'ECB' },
    'SQR':      { desc: 'Returns square root.', syntax: 'SQR(n)', variant: 'ECB' },
    'HEX$':     { desc: 'Converts a number to its hexadecimal string.', syntax: 'HEX$(n)', variant: 'ECB' },
    'VARPTR':   { desc: 'Returns memory address of a variable.', syntax: 'VARPTR(var)', variant: 'ECB' },
    'INSTR':    { desc: 'Returns position of a substring within a string (0=not found).', syntax: 'INSTR([start,] s$, search$)', variant: 'ECB' },
    'TIMER':    { desc: 'Returns/sets the real-time clock value (60ths of a second).', syntax: 'TIMER  or  TIMER=n', variant: 'ECB' },
    'PPOINT':   { desc: 'Returns color attribute of a hi-res pixel.', syntax: 'PPOINT(x,y)', variant: 'ECB' },
    'STRING$':  { desc: 'Returns a string of n repeated characters.', syntax: 'STRING$(n, char$|code)', variant: 'ECB' },

    // ── Disk Extended Color BASIC ──
    'DIR':      { desc: 'Display disk directory.', syntax: 'DIR [":drive"]', variant: 'DECB' },
    'FIELD':    { desc: 'Assign string variables to a random file buffer.', syntax: 'FIELD #n, len AS var$[,len AS var$...]', variant: 'DECB' },
    'FILES':    { desc: 'Display disk directory (alias for DIR).', syntax: 'FILES [":drive"]', variant: 'DECB' },
    'KILL':     { desc: 'Delete a file from disk.', syntax: 'KILL "filename"', variant: 'DECB' },
    'LOAD':     { desc: 'Load a BASIC or machine language file from disk.', syntax: 'LOAD "filename"[,R]', variant: 'DECB' },
    'LSET':     { desc: 'Left-justify a string into a FIELD buffer variable.', syntax: 'LSET var$ = expr$', variant: 'DECB' },
    'MERGE':    { desc: 'Merge a disk BASIC file into current program.', syntax: 'MERGE "filename"', variant: 'DECB' },
    'RENAME':   { desc: 'Rename a file on disk.', syntax: 'RENAME "oldname","newname"', variant: 'DECB' },
    'RSET':     { desc: 'Right-justify a string into a FIELD buffer variable.', syntax: 'RSET var$ = expr$', variant: 'DECB' },
    'SAVE':     { desc: 'Save the BASIC program to disk.', syntax: 'SAVE "filename"[,A]', variant: 'DECB' },
    'WRITE':    { desc: 'Write comma-delimited data to a file.', syntax: 'WRITE #n, expr[, expr...]', variant: 'DECB' },
    'VERIFY':   { desc: 'Verify a saved disk file against memory.', syntax: 'VERIFY "filename"', variant: 'DECB' },
    'BACKUP':   { desc: 'Backup an entire disk.', syntax: 'BACKUP "src":"dest"', variant: 'DECB' },
    'COPY':     { desc: 'Copy a file from one disk to another.', syntax: 'COPY "src":"dest"', variant: 'DECB' },
    'CVN':      { desc: 'Convert MKN$ 5-byte string back to a floating point number.', syntax: 'CVN(s$)', variant: 'DECB' },
    'FREE':     { desc: 'Returns number of free granules on disk (drive 0 or specified).', syntax: 'FREE(n)', variant: 'DECB' },
    'LOC':      { desc: 'Returns current record position in a random file.', syntax: 'LOC(#n)', variant: 'DECB' },
    'LOF':      { desc: 'Returns number of records in a random file.', syntax: 'LOF(#n)', variant: 'DECB' },
    'MKN$':     { desc: 'Encodes a floating point number into a 5-byte string for FIELD storage.', syntax: 'MKN$(n)', variant: 'DECB' },

    // ── Super Extended Color BASIC (CoCo 3) ──
    'WIDTH':    { desc: 'Set text screen width (32 or 40 or 80 columns).', syntax: 'WIDTH n', variant: 'SECB' },
    'PALETTE':  { desc: 'Set a palette register color (composite or RGB).', syntax: 'PALETTE reg,color  or  PALETTE CMP  or  PALETTE RGB', variant: 'SECB' },
    'HSCREEN':  { desc: 'Set CoCo 3 hi-res graphics mode.', syntax: 'HSCREEN n  (0=off, 1=16color 256×192, 2=4color 320×192, 3=2color 640×192, 4=16color 640×192)', variant: 'SECB' },
    'LPOKE':    { desc: 'Write a byte to an extended (logical) memory address.', syntax: 'LPOKE address, value', variant: 'SECB' },
    'HCLS':     { desc: 'Clear the CoCo 3 hi-res graphics screen.', syntax: 'HCLS [color]', variant: 'SECB' },
    'HCOLOR':   { desc: 'Set foreground color for hi-res graphics.', syntax: 'HCOLOR n', variant: 'SECB' },
    'HPAINT':   { desc: 'Flood-fill area in CoCo 3 hi-res mode.', syntax: 'HPAINT (x,y)[,fillcolor[,bordercolor]]', variant: 'SECB' },
    'HCIRCLE':  { desc: 'Draw a circle in CoCo 3 hi-res mode.', syntax: 'HCIRCLE (x,y),r[,color[,start,end[,aspect]]]', variant: 'SECB' },
    'HLINE':    { desc: 'Draw a line in CoCo 3 hi-res mode.', syntax: 'HLINE (x1,y1)-(x2,y2)[,color[,B[F]]]', variant: 'SECB' },
    'HGET':     { desc: 'Capture a CoCo 3 hi-res rectangle into an HBUFF buffer.', syntax: 'HGET (x1,y1)-(x2,y2),buf[,action]', variant: 'SECB' },
    'HPUT':     { desc: 'Paste an HBUFF buffer to the CoCo 3 hi-res screen.', syntax: 'HPUT (x1,y1)-(x2,y2),buf[,action]', variant: 'SECB' },
    'HBUFF':    { desc: 'Allocate a buffer for HGET/HPUT operations.', syntax: 'HBUFF n,size', variant: 'SECB' },
    'HPRINT':   { desc: 'Print text to CoCo 3 hi-res graphics screen.', syntax: 'HPRINT (x,y),"text"[,color]', variant: 'SECB' },
    'LOCATE':   { desc: 'Position the cursor at a specific row and column.', syntax: 'LOCATE row,col', variant: 'SECB' },
    'HSTAT':    { desc: 'Returns status/size information about an HBUFF buffer.', syntax: 'HSTAT n', variant: 'SECB' },
    'HSET':     { desc: 'Plot a pixel in CoCo 3 hi-res mode.', syntax: 'HSET (x,y)[,color]', variant: 'SECB' },
    'HRESET':   { desc: 'Clear a pixel in CoCo 3 hi-res mode.', syntax: 'HRESET (x,y)[,color]', variant: 'SECB' },
    'HDRAW':    { desc: 'Execute a draw command string in CoCo 3 hi-res mode.', syntax: 'HDRAW "commands"', variant: 'SECB' },
    'ATTR':     { desc: 'Set text character attributes (color, blink, underline).', syntax: 'ATTR fg,bg[,blink[,underline]]', variant: 'SECB' },
    'LPEEK':    { desc: 'Read a byte from an extended (logical) memory address.', syntax: 'LPEEK(address)', variant: 'SECB' },
    'BUTTON':   { desc: 'Returns joystick button state (1=pressed).', syntax: 'BUTTON(n)  (0=left, 1=right, 2=left alt, 3=right alt)', variant: 'SECB' },
    'HPOINT':   { desc: 'Returns color of a pixel in CoCo 3 hi-res mode.', syntax: 'HPOINT(x,y)', variant: 'SECB' },
    'ERNO':     { desc: 'Returns the error number from the last error.', syntax: 'ERNO', variant: 'SECB' },
    'ERLIN':    { desc: 'Returns the line number where the last error occurred.', syntax: 'ERLIN', variant: 'SECB' },

    // ── BaTo6809 new structured control flow ──
    'DO':           { desc: 'Begin a DO/LOOP/UNTIL block loop.', syntax: 'DO\n  ...\nLOOP UNTIL condition', variant: 'BaTo6809' },
    'LOOP':         { desc: 'End of a DO loop; evaluates UNTIL exit condition.', syntax: 'DO\n  ...\nLOOP UNTIL condition', variant: 'BaTo6809' },
    'UNTIL':        { desc: 'Exit condition for DO/LOOP.', syntax: 'DO\n  ...\nLOOP UNTIL condition', variant: 'BaTo6809' },
    'WHILE':        { desc: 'Begin a WHILE/WEND loop; repeats while condition is true.', syntax: 'WHILE condition\n  ...\nWEND', variant: 'BaTo6809' },
    'WEND':         { desc: 'End of a WHILE loop.', syntax: 'WHILE condition\n  ...\nWEND', variant: 'BaTo6809' },
    'ELSEIF':       { desc: 'Additional condition branch in a block IF statement.', syntax: 'IF cond THEN\n  ...\nELSEIF cond2 THEN\n  ...\nENDIF', variant: 'BaTo6809' },
    'SELECT':       { desc: 'Begin a SELECT/CASE multi-branch statement.', syntax: 'SELECT CASE expr\n  CASE value\n  ...\nEND SELECT', variant: 'BaTo6809' },
    'CASE':         { desc: 'Branch label in a SELECT/CASE statement.', syntax: 'CASE value [TO value]', variant: 'BaTo6809' },
    'EXIT':         { desc: 'Exit from the current FOR, WHILE, or DO loop.', syntax: 'EXIT [FOR|WHILE|DO]', variant: 'BaTo6809' },
    // ── BaTo6809 new commands ──
    'GCLS':         { desc: 'Clear the graphics screen.', syntax: 'GCLS [color]', variant: 'BaTo6809' },
    'GCOPY':        { desc: 'Copy a rectangular area of the graphics screen.', syntax: 'GCOPY x1,y1,x2,y2,destx,desty', variant: 'BaTo6809' },
    'GMODE':        { desc: 'Set the graphics mode for BaTo6809 graphics commands.', syntax: 'GMODE n', variant: 'BaTo6809' },
    'GETJOYD':      { desc: 'Read joystick direction as a value (0–8).', syntax: 'GETJOYD(port)', variant: 'BaTo6809' },
    'PLAYFIELD':    { desc: 'Define the scrolling playfield (tile map) for the current page.', syntax: 'PLAYFIELD x,y,w,h', variant: 'BaTo6809' },
    'VIEW':         { desc: 'Set the visible viewport within the playfield.', syntax: 'VIEW x,y,w,h', variant: 'BaTo6809' },
    'SPRITE':       { desc: 'Display, move, or control a hardware/software sprite.', syntax: 'SPRITE n,x,y[,frame]', variant: 'BaTo6809' },
    'SPRITE_LOAD':  { desc: 'Load sprite data from a file into a sprite slot.', syntax: 'SPRITE_LOAD n,"filename"', variant: 'BaTo6809' },
    'SAMPLE':       { desc: 'Play a loaded audio sample.', syntax: 'SAMPLE n', variant: 'BaTo6809' },
    'SAMPLE_LOAD':  { desc: 'Load an audio sample from a file into a sample slot.', syntax: 'SAMPLE_LOAD n,"filename"', variant: 'BaTo6809' },
    'CONST':        { desc: 'Declare a named integer constant (compile-time).', syntax: 'CONST name = value', variant: 'BaTo6809' },
    'LOADM':        { desc: 'Load a machine language binary file from disk.', syntax: 'LOADM "filename"[,offset]', variant: 'BaTo6809' },
    'CPUSPEED':     { desc: 'Set the CoCo 3 CPU speed (0=1.79 MHz, 1=7.16 MHz).', syntax: 'CPUSPEED n', variant: 'BaTo6809' },
    'COPYBLOCKS':   { desc: 'Copy memory blocks between MMU pages.', syntax: 'COPYBLOCKS src,dst,count', variant: 'BaTo6809' },
    'COCOHARDWARE': { desc: 'Returns the CoCo hardware type (0=CoCo1/2, 1=CoCo3).', syntax: 'COCOHARDWARE()', variant: 'BaTo6809' },
    'TRIM$':        { desc: 'Remove leading and trailing spaces from a string.', syntax: 'TRIM$(s$)', variant: 'BaTo6809' },
    'LTRIM$':       { desc: 'Remove leading spaces from a string.', syntax: 'LTRIM$(s$)', variant: 'BaTo6809' },
    'RTRIM$':       { desc: 'Remove trailing spaces from a string.', syntax: 'RTRIM$(s$)', variant: 'BaTo6809' },

    // ── Standard MC-10 BASIC ──
    'PRINT@':   { desc: 'Print at a specific screen position (0–511).', syntax: 'PRINT@ pos, expr', variant: 'MC10' },
    'LPRINT':   { desc: 'Print to the printer.', syntax: 'LPRINT [expr[;|,] ...]', variant: 'MC10' },
    'CLOAD*':   { desc: 'Load a numeric array from cassette.', syntax: 'CLOAD* arrayname', variant: 'MC10' },
    'CSAVE*':   { desc: 'Save a numeric array to cassette.', syntax: 'CSAVE* arrayname', variant: 'MC10' },

    // ── MCX BASIC extensions ──
    'PCLS':     { desc: 'Clear a graphics page to background color.', syntax: 'PCLS [color]', variant: 'MCX' },
    'PMODE':    { desc: 'Set graphics mode and page. Mode 0=128×96 2-color, 1=128×96 4-color, 2=128×192 2-color.', syntax: 'PMODE mode, page', variant: 'MCX' },
    'PSET':     { desc: 'Set a pixel to foreground color.', syntax: 'PSET (x,y)[, color]', variant: 'MCX' },
    'PRESET':   { desc: 'Set a pixel to background color.', syntax: 'PRESET (x,y)[, color]', variant: 'MCX' },
    'PPOINT':   { desc: 'Read the color of a pixel on the graphics screen.', syntax: 'PPOINT(x, y)', variant: 'MCX' },
    'PCOPY':    { desc: 'Copy one graphics page to another.', syntax: 'PCOPY src, dst', variant: 'MCX' },
    'LINE':     { desc: 'Draw a line or box on the graphics screen.', syntax: 'LINE (x1,y1)-(x2,y2)[, color[, B[F]]]', variant: 'MCX' },
    'PAINT':    { desc: 'Flood-fill an area on the graphics screen.', syntax: 'PAINT (x,y)[, fillcolor[, bordercolor]]', variant: 'MCX' },
    'PLAY':     { desc: 'Play a musical note sequence. Notes A-G, octave On, tempo Tn, length Nn, pause Pn.', syntax: 'PLAY "string"', variant: 'MCX' },
    'OPEN':     { desc: 'Open a data file on the MCX32-SD card.', syntax: 'OPEN "mode", #n, "filename"', variant: 'MCX' },
    'FILES':    { desc: 'Allocate file control blocks for file I/O. Default 2, max 15.', syntax: 'FILES n', variant: 'MCX' },
    'SWAP':     { desc: 'Exchange the values of two variables.', syntax: 'SWAP var1, var2', variant: 'MCX' },
    'WAIT':     { desc: 'Pause execution for a number of milliseconds.', syntax: 'WAIT ms', variant: 'MCX' },
    'TIMER':    { desc: 'Read or set the system timer (increments ~60 times/sec, range 0–65535).', syntax: 'TIMER [= n]', variant: 'MCX' },
    'ERROR':    { desc: 'Simulate a BASIC error by number.', syntax: 'ERROR n', variant: 'MCX' },
    'ERRN':     { desc: 'Returns the error number from the last error.', syntax: 'ERRN', variant: 'MCX' },
    'ERRL':     { desc: 'Returns the line number where the last error occurred.', syntax: 'ERRL', variant: 'MCX' },
    'FIX':      { desc: 'Truncate a number toward zero (compare: INT truncates toward negative infinity).', syntax: 'FIX(n)', variant: 'MCX' },
    'HEX$':     { desc: 'Convert an integer to a hexadecimal string.', syntax: 'HEX$(n)', variant: 'MCX' },
    'INSTR':    { desc: 'Find the position of a substring within a string.', syntax: 'INSTR([start,] s$, search$)', variant: 'MCX' },
    'MAXVAL':   { desc: 'Returns the larger of two numeric values.', syntax: 'MAXVAL(a, b)', variant: 'MCX' },
    'MINVAL':   { desc: 'Returns the smaller of two numeric values.', syntax: 'MINVAL(a, b)', variant: 'MCX' },
    'MEMEND':   { desc: 'Returns the highest memory address in use by MCX BASIC.', syntax: 'MEMEND', variant: 'MCX' },
    'STRMEM':   { desc: 'Returns the amount of string space available.', syntax: 'STRMEM', variant: 'MCX' },
    'STRING$':  { desc: 'Build a string by repeating a character n times.', syntax: 'STRING$(n, char)', variant: 'MCX' },
};

// Variant labels
const VARIANT_LABEL = {
    'CB':       'Color BASIC (all CoCo)',
    'ECB':      'Extended Color BASIC (all CoCo)',
    'DECB':     'Disk Extended Color BASIC',
    'SECB':     'Super Extended Color BASIC (CoCo 3 only)',
    'MC10':     'MC-10 BASIC',
    'MCX':      'MCX BASIC (MC-10 extended)',
    'BaTo6809': 'BaTo6809 BASIC (CoCo enhanced)',
    'ugBASIC':  'ugBASIC (cross-platform retro)',
};

// ── ugBASIC keyword documentation ─────────────────────────────────────────
const UGBASIC_DOCS = {
    // Control flow
    'FOR':      { desc: 'Begin a FOR/NEXT loop.', syntax: 'FOR var = start TO end [STEP n]\n  ...\nNEXT [var]', variant: 'ugBASIC' },
    'TO':       { desc: 'Part of FOR loop range syntax.', syntax: 'FOR var = start TO end [STEP n]', variant: 'ugBASIC' },
    'STEP':     { desc: 'Step increment/decrement for a FOR loop.', syntax: 'FOR var = start TO end STEP n', variant: 'ugBASIC' },
    'NEXT':     { desc: 'End of a FOR/NEXT loop.', syntax: 'NEXT [var]', variant: 'ugBASIC' },
    'IF':       { desc: 'Conditional branch. Supports single-line and block forms.', syntax: 'IF condition THEN statement\n  or\nIF condition THEN\n  ...\nENDIF', variant: 'ugBASIC' },
    'THEN':     { desc: 'Part of IF/THEN conditional.', syntax: 'IF condition THEN statement', variant: 'ugBASIC' },
    'ELSE':     { desc: 'Alternative branch in IF/THEN/ELSE.', syntax: 'IF cond THEN\n  ...\nELSE\n  ...\nENDIF', variant: 'ugBASIC' },
    'ELSEIF':   { desc: 'Additional condition in a multi-branch block IF.', syntax: 'IF cond THEN\n  ...\nELSEIF cond2 THEN\n  ...\nENDIF', variant: 'ugBASIC' },
    'ENDIF':    { desc: 'End of a block IF statement.', syntax: 'IF cond THEN\n  ...\nENDIF', variant: 'ugBASIC' },
    'FI':       { desc: 'Alias for ENDIF.', syntax: 'IF cond THEN\n  ...\nFI', variant: 'ugBASIC' },
    'WHILE':    { desc: 'Begin a WHILE loop; repeats while condition is true.', syntax: 'WHILE condition\n  ...\nWEND', variant: 'ugBASIC' },
    'WEND':     { desc: 'End of a WHILE loop.', syntax: 'WHILE condition\n  ...\nWEND', variant: 'ugBASIC' },
    'DO':       { desc: 'Begin a DO/LOOP/UNTIL loop.', syntax: 'DO\n  ...\nLOOP UNTIL condition', variant: 'ugBASIC' },
    'LOOP':     { desc: 'End of a DO loop; evaluates UNTIL condition.', syntax: 'DO\n  ...\nLOOP UNTIL condition', variant: 'ugBASIC' },
    'UNTIL':    { desc: 'Exit condition for DO/LOOP.', syntax: 'DO\n  ...\nLOOP UNTIL condition', variant: 'ugBASIC' },
    'GOTO':     { desc: 'Jump unconditionally to a label or line number.', syntax: 'GOTO label', variant: 'ugBASIC' },
    'CGOTO':    { desc: 'Computed GOTO — jump to label at index in list.', syntax: 'CGOTO expr, label1, label2, ...', variant: 'ugBASIC' },
    'GOSUB':    { desc: 'Call a subroutine at a label.', syntax: 'GOSUB label', variant: 'ugBASIC' },
    'RETURN':   { desc: 'Return from a GOSUB subroutine.', syntax: 'RETURN', variant: 'ugBASIC' },
    'ON':       { desc: 'ON/GOTO or ON/GOSUB branch by index.', syntax: 'ON expr GOTO label1[,label2...]', variant: 'ugBASIC' },
    'END':      { desc: 'End the program.', syntax: 'END', variant: 'ugBASIC' },
    'STOP':     { desc: 'Stop execution.', syntax: 'STOP', variant: 'ugBASIC' },
    'RUN':      { desc: 'Run the program from the start.', syntax: 'RUN', variant: 'ugBASIC' },
    'WAIT':     { desc: 'Wait for a hardware register condition (polls until mask matches).', syntax: 'WAIT address, mask [, xormask]', variant: 'ugBASIC' },
    'HALT':     { desc: 'Halt all parallel tasks.', syntax: 'HALT', variant: 'ugBASIC' },
    'SUSPEND':  { desc: 'Suspend a specific task.', syntax: 'SUSPEND taskID', variant: 'ugBASIC' },
    'RESUME':   { desc: 'Resume a suspended task.', syntax: 'RESUME taskID', variant: 'ugBASIC' },
    'EXIT':     { desc: 'Exit from the current loop (FOR, WHILE, DO).', syntax: 'EXIT', variant: 'ugBASIC' },
    'EXITIF':   { desc: 'Exit from the current loop if condition is true.', syntax: 'EXITIF condition', variant: 'ugBASIC' },
    'PROC':     { desc: 'Define a named procedure.', syntax: 'PROC name\n  ...\nENDPROC', variant: 'ugBASIC' },
    'ENDPROC':  { desc: 'End of a PROC procedure definition.', syntax: 'PROC name\n  ...\nENDPROC', variant: 'ugBASIC' },
    'FUNCTION': { desc: 'Define a function that returns a value.', syntax: 'FUNCTION name(params) AS type\n  ...\nEND FUNCTION', variant: 'ugBASIC' },
    'CALL':     { desc: 'Call a named procedure.', syntax: 'CALL name[(args)]', variant: 'ugBASIC' },
    'SPAWN':    { desc: 'Launch a procedure as a new parallel task.', syntax: 'SPAWN name', variant: 'ugBASIC' },
    'KILL':     { desc: 'Kill (stop) a parallel task by ID.', syntax: 'KILL taskID', variant: 'ugBASIC' },
    'EVERY':    { desc: 'Call a procedure repeatedly every n timer ticks.', syntax: 'EVERY n CALL name', variant: 'ugBASIC' },
    'AFTER':    { desc: 'Call a procedure once after n timer ticks.', syntax: 'AFTER n CALL name', variant: 'ugBASIC' },
    'SELECT':   { desc: 'Begin a SELECT CASE multi-branch statement.', syntax: 'SELECT CASE expr\n  CASE value\n    ...\nENDSELECT', variant: 'ugBASIC' },
    'CASE':     { desc: 'Branch in a SELECT CASE statement.', syntax: 'CASE value [TO value]', variant: 'ugBASIC' },
    'ENDSELECT':{ desc: 'End of a SELECT CASE statement.', syntax: 'ENDSELECT', variant: 'ugBASIC' },
    'GAMELOOP': { desc: 'Begin the main game loop (repeats indefinitely until END).', syntax: 'GAMELOOP\n  ...\nENDGAMELOOP', variant: 'ugBASIC' },
    'YIELD':    { desc: 'Yield CPU time to other tasks in cooperative multitasking.', syntax: 'YIELD', variant: 'ugBASIC' },
    'FREEZE':   { desc: 'Freeze all background tasks.', syntax: 'FREEZE', variant: 'ugBASIC' },
    'UNFREEZE': { desc: 'Unfreeze all background tasks.', syntax: 'UNFREEZE', variant: 'ugBASIC' },
    // Declarations
    'DIM':      { desc: 'Declare a variable or array with an optional type.', syntax: 'DIM name AS type\nDIM name(size) AS type', variant: 'ugBASIC' },
    'VAR':      { desc: 'Declare a variable (alias for DIM).', syntax: 'VAR name AS type', variant: 'ugBASIC' },
    'CONST':    { desc: 'Declare a named compile-time constant.', syntax: 'CONST name = value', variant: 'ugBASIC' },
    'DEFINE':   { desc: 'Define a compile-time alias or value.', syntax: 'DEFINE name value', variant: 'ugBASIC' },
    'GLOBAL':   { desc: 'Declare a global variable accessible from all procedures.', syntax: 'GLOBAL name AS type', variant: 'ugBASIC' },
    // Types
    'BYTE':     { desc: 'Unsigned 8-bit integer type (0–255).', syntax: 'DIM x AS BYTE', variant: 'ugBASIC' },
    'SBYTE':    { desc: 'Signed 8-bit integer type (-128–127).', syntax: 'DIM x AS SBYTE', variant: 'ugBASIC' },
    'WORD':     { desc: 'Unsigned 16-bit integer type (0–65535).', syntax: 'DIM x AS WORD', variant: 'ugBASIC' },
    'DWORD':    { desc: 'Unsigned 32-bit double-word type.', syntax: 'DIM x AS DWORD', variant: 'ugBASIC' },
    'INTEGER':  { desc: 'Signed 16-bit integer type.', syntax: 'DIM x AS INTEGER', variant: 'ugBASIC' },
    'LONG':     { desc: 'Signed 32-bit integer type.', syntax: 'DIM x AS LONG', variant: 'ugBASIC' },
    'FLOAT':    { desc: 'Single-precision floating point type.', syntax: 'DIM x AS FLOAT', variant: 'ugBASIC' },
    // I/O
    'PRINT':    { desc: 'Output text or values to the screen.', syntax: 'PRINT [expr[;|,] ...]', variant: 'ugBASIC' },
    'INPUT':    { desc: 'Read input from the user.', syntax: 'INPUT ["prompt";] var', variant: 'ugBASIC' },
    'CLS':      { desc: 'Clear the text screen.', syntax: 'CLS', variant: 'ugBASIC' },
    'LOCATE':   { desc: 'Move the text cursor to a column/row position.', syntax: 'LOCATE col, row', variant: 'ugBASIC' },
    'REM':      { desc: 'Comment — rest of line is ignored.', syntax: 'REM comment  or  \' comment', variant: 'ugBASIC' },
    'DATA':     { desc: 'Store literal values for READ.', syntax: 'DATA val1, val2, ...', variant: 'ugBASIC' },
    'READ':     { desc: 'Read the next value from a DATA statement.', syntax: 'READ var[, var...]', variant: 'ugBASIC' },
    'RESTORE':  { desc: 'Reset DATA pointer to start or to a label.', syntax: 'RESTORE [label]', variant: 'ugBASIC' },
    'OPEN':     { desc: 'Open a file for I/O.', syntax: 'OPEN "filename" AS #n', variant: 'ugBASIC' },
    'CLOSE':    { desc: 'Close a file.', syntax: 'CLOSE #n', variant: 'ugBASIC' },
    // Memory access
    'POKE':     { desc: 'Write a byte to a memory address.', syntax: 'POKE address, value', variant: 'ugBASIC' },
    'PEEK':     { desc: 'Read a byte from a memory address.', syntax: 'PEEK(address)', variant: 'ugBASIC' },
    'POKEW':    { desc: 'Write a 16-bit word to a memory address.', syntax: 'POKEW address, value', variant: 'ugBASIC' },
    'PEEKW':    { desc: 'Read a 16-bit word from a memory address.', syntax: 'PEEKW(address)', variant: 'ugBASIC' },
    'POKED':    { desc: 'Write a 32-bit dword to a memory address.', syntax: 'POKED address, value', variant: 'ugBASIC' },
    'PEEKD':    { desc: 'Read a 32-bit dword from a memory address.', syntax: 'PEEKD(address)', variant: 'ugBASIC' },
    // Screen/graphics
    'HSCROLL':  { desc: 'Scroll a text line or the entire screen horizontally.', syntax: 'HSCROLL LEFT|RIGHT [OF row]', variant: 'ugBASIC' },
    'VSCROLL':  { desc: 'Scroll the screen vertically.', syntax: 'VSCROLL UP|DOWN', variant: 'ugBASIC' },
    'INK':      { desc: 'Set the foreground drawing/text color.', syntax: 'INK color', variant: 'ugBASIC' },
    'PAPER':    { desc: 'Set the background (paper) color.', syntax: 'PAPER color', variant: 'ugBASIC' },
    'PLOT':     { desc: 'Plot a pixel at (x,y).', syntax: 'PLOT x, y [, color]', variant: 'ugBASIC' },
    'LINE':     { desc: 'Draw a line from (x1,y1) to (x2,y2).', syntax: 'LINE x1, y1 TO x2, y2 [, color]', variant: 'ugBASIC' },
    'BOX':      { desc: 'Draw a rectangle outline.', syntax: 'BOX x1, y1 TO x2, y2 [, color]', variant: 'ugBASIC' },
    'CIRCLE':   { desc: 'Draw a circle.', syntax: 'CIRCLE x, y, r [, color]', variant: 'ugBASIC' },
    'FILL':     { desc: 'Flood-fill an area starting at (x,y).', syntax: 'FILL x, y [, color]', variant: 'ugBASIC' },
    'GR':       { desc: 'Set the graphics screen resolution/mode.', syntax: 'GR mode', variant: 'ugBASIC' },
    'TEXT':     { desc: 'Switch back to text mode (disables graphics).', syntax: 'TEXT', variant: 'ugBASIC' },
    'SPRITE':   { desc: 'Display or move a sprite.', syntax: 'SPRITE n AT x, y', variant: 'ugBASIC' },
    // Screen info
    'ROWS':     { desc: 'Returns number of text rows on the current screen.', syntax: 'ROWS', variant: 'ugBASIC' },
    'COLUMNS':  { desc: 'Returns number of text columns on the current screen.', syntax: 'COLUMNS', variant: 'ugBASIC' },
    'WIDTH':    { desc: 'Returns screen width in pixels.', syntax: 'WIDTH', variant: 'ugBASIC' },
    'HEIGHT':   { desc: 'Returns screen height in pixels.', syntax: 'HEIGHT', variant: 'ugBASIC' },
    // Math
    'ABS':      { desc: 'Returns absolute value.', syntax: 'ABS(n)', variant: 'ugBASIC' },
    'SGN':      { desc: 'Returns sign: -1, 0, or 1.', syntax: 'SGN(n)', variant: 'ugBASIC' },
    'INT':      { desc: 'Returns integer portion (floor toward negative infinity).', syntax: 'INT(n)', variant: 'ugBASIC' },
    'FIX':      { desc: 'Truncate toward zero (no rounding).', syntax: 'FIX(n)', variant: 'ugBASIC' },
    'SQR':      { desc: 'Returns square root.', syntax: 'SQR(n)', variant: 'ugBASIC' },
    'SIN':      { desc: 'Returns sine of angle in radians.', syntax: 'SIN(n)', variant: 'ugBASIC' },
    'COS':      { desc: 'Returns cosine of angle in radians.', syntax: 'COS(n)', variant: 'ugBASIC' },
    'ATN':      { desc: 'Returns arctangent in radians.', syntax: 'ATN(n)', variant: 'ugBASIC' },
    'TAN':      { desc: 'Returns tangent in radians.', syntax: 'TAN(n)', variant: 'ugBASIC' },
    'EXP':      { desc: 'Returns e raised to the power n.', syntax: 'EXP(n)', variant: 'ugBASIC' },
    'LOG':      { desc: 'Returns natural logarithm.', syntax: 'LOG(n)', variant: 'ugBASIC' },
    'RND':      { desc: 'Returns a pseudo-random number.', syntax: 'RND(n)', variant: 'ugBASIC' },
    'MAX':      { desc: 'Returns the larger of two values.', syntax: 'MAX(a, b)', variant: 'ugBASIC' },
    'MIN':      { desc: 'Returns the smaller of two values.', syntax: 'MIN(a, b)', variant: 'ugBASIC' },
    // String functions
    'LEN':      { desc: 'Returns the length of a string.', syntax: 'LEN(s)', variant: 'ugBASIC' },
    'LEFT':     { desc: 'Returns leftmost n characters.', syntax: 'LEFT(s, n)', variant: 'ugBASIC' },
    'RIGHT':    { desc: 'Returns rightmost n characters.', syntax: 'RIGHT(s, n)', variant: 'ugBASIC' },
    'MID':      { desc: 'Returns a substring.', syntax: 'MID(s, start [, len])', variant: 'ugBASIC' },
    'INSTR':    { desc: 'Returns position of substring (0=not found).', syntax: 'INSTR([start,] s, search)', variant: 'ugBASIC' },
    'STR':      { desc: 'Converts a number to a string.', syntax: 'STR(n)', variant: 'ugBASIC' },
    'VAL':      { desc: 'Converts a string to a number.', syntax: 'VAL(s)', variant: 'ugBASIC' },
    'CHR':      { desc: 'Returns character for a character code.', syntax: 'CHR(n)', variant: 'ugBASIC' },
    'ASC':      { desc: 'Returns character code of first character.', syntax: 'ASC(s)', variant: 'ugBASIC' },
    'HEX':      { desc: 'Converts integer to hexadecimal string.', syntax: 'HEX(n)', variant: 'ugBASIC' },
    // Input/device
    'INKEY':    { desc: 'Returns key pressed without waiting (empty if none).', syntax: 'INKEY()', variant: 'ugBASIC' },
    'TIMER':    { desc: 'Returns the current system timer value.', syntax: 'TIMER', variant: 'ugBASIC' },
    'JOYSTICK': { desc: 'Returns joystick axis value.', syntax: 'JOYSTICK(port, axis)', variant: 'ugBASIC' },
    'JOY':      { desc: 'Returns joystick direction bitmask.', syntax: 'JOY(port)', variant: 'ugBASIC' },
    'BUTTON':   { desc: 'Returns gamepad/joystick button state (1=pressed).', syntax: 'BUTTON(port, button)', variant: 'ugBASIC' },
    'KEYSTATE': { desc: 'Returns 1 if a specific key is currently held.', syntax: 'KEYSTATE(keycode)', variant: 'ugBASIC' },
    'SCANCODE': { desc: 'Returns the scancode of the last key pressed.', syntax: 'SCANCODE()', variant: 'ugBASIC' },
    // Constants
    'TRUE':     { desc: 'Boolean constant for true.', syntax: 'TRUE', variant: 'ugBASIC' },
    'FALSE':    { desc: 'Boolean constant for false.', syntax: 'FALSE', variant: 'ugBASIC' },
    'NULL':     { desc: 'Null/empty value constant.', syntax: 'NULL', variant: 'ugBASIC' },
};

// ── Parse address from token under cursor ─────────────────────────────────
// Handles: PEEK(1234), POKE 1234,val, EXEC 1234
// Returns integer or null
function extractAddressFromContext(document, position) {
    const line  = document.lineAt(position).text;
    const col   = position.character;

    // Scan backward from cursor to find which PEEK/POKE/EXEC call we're in
    const window = line.substring(0, col + 20).toUpperCase();

    // Match: PEEK(addr), LPEEK(addr)
    let m = window.match(/(?:L?PEEK)\((\d+|\&[HhOo][0-9A-Fa-f0-7]+)/);
    if (m) return parseBasicNumber(m[1]);

    // Match: POKE addr,  or  LPOKE addr,
    m = window.match(/L?POKE\s*(\d+|\&[HhOo][0-9A-Fa-f0-7]+)/);
    if (m) return parseBasicNumber(m[1]);

    // Match: EXEC addr
    m = window.match(/EXEC\s*(\d+|\&[HhOo][0-9A-Fa-f0-7]+)/);
    if (m) return parseBasicNumber(m[1]);

    // Is the cursor sitting directly on a number?
    const token = getWordAtPosition(line, col);
    if (token && /^(\d+|\&[HhOo][0-9A-Fa-f0-7]+)$/.test(token)) {
        return parseBasicNumber(token);
    }

    return null;
}

function parseBasicNumber(s) {
    s = s.toUpperCase();
    if (s.startsWith('&H')) return parseInt(s.slice(2), 16);
    if (s.startsWith('&O')) return parseInt(s.slice(2), 8);
    return parseInt(s, 10);
}

function getWordAtPosition(line, col) {
    const re = /(&[HhOo][0-9A-Fa-f0-7]+|\d+\.\d*|\d+|[A-Za-z_][A-Za-z0-9_$]*)/g;
    let m;
    while ((m = re.exec(line)) !== null) {
        if (m.index <= col && col <= m.index + m[0].length) {
            return m[0];
        }
    }
    return null;
}

// ── Build hover markdown ──────────────────────────────────────────────────
function buildAddressHover(entry) {
    const variants = entry.variants
        .map(v => VARIANT_LABEL[v] || v)
        .join(', ');

    const md = new vscode.MarkdownString();
    md.isTrusted = true;
    md.appendMarkdown(`### \`$${entry.address}\` — ${entry.label}\n\n`);
    md.appendMarkdown(`${entry.description}\n\n`);
    md.appendMarkdown(`**Decimal:** ${entry.address_dec}  |  **Hex:** $${entry.address}\n\n`);
    md.appendMarkdown(`**Available in:** ${variants}\n\n`);
    md.appendMarkdown(`*Source: Unravelled II / CoCo memory map*`);
    return new vscode.Hover(md);
}

function buildKeywordHover(keyword, docsTable) {
    docsTable = docsTable || KEYWORD_DOCS;
    const doc = docsTable[keyword.toUpperCase()];
    if (!doc) return null;

    const variantLabel = VARIANT_LABEL[doc.variant] || doc.variant;
    const langId = docsTable === UGBASIC_DOCS ? 'ugbasic' : 'coco-basic';
    const md = new vscode.MarkdownString();
    md.isTrusted = true;
    md.appendMarkdown(`### \`${keyword.toUpperCase()}\`\n\n`);
    md.appendMarkdown(`${doc.desc}\n\n`);
    md.appendCodeblock(doc.syntax, langId);
    md.appendMarkdown(`\n**Variant:** ${variantLabel}`);
    return new vscode.Hover(md);
}

// ── Hover provider ────────────────────────────────────────────────────────
const LANGUAGES     = ['coco-basic', 'color-basic', 'ecb2', 'mc10-basic', 'basto6809'];
const ASM_LANGUAGES = ['asm.6x09', 'asm6x09'];

function activate(context) {
    loadMemoryMap();
    loadAsmInstructions();

    // Assembly hover — mnemonic lookup in asm-instructions.json
    const asmProvider = vscode.languages.registerHoverProvider(ASM_LANGUAGES, {
        provideHover(document, position) {
            const range = document.getWordRangeAtPosition(position, /[A-Za-z][A-Za-z0-9]*/);
            if (!range) return null;
            const word = document.getText(range);
            return buildAsmHover(word);
        }
    });
    context.subscriptions.push(asmProvider);

    const provider = vscode.languages.registerHoverProvider(LANGUAGES, {
        provideHover(document, position) {
            const line  = document.lineAt(position).text;
            const col   = position.character;

            // 1. Try PEEK/POKE/EXEC address lookup
            const addr = extractAddressFromContext(document, position);
            if (addr !== null && memoryMap.has(addr)) {
                return buildAddressHover(memoryMap.get(addr));
            }

            // 2. Try keyword lookup
            const word = getWordAtPosition(line, col);
            if (word) {
                const hover = buildKeywordHover(word);
                if (hover) return hover;
                // Keyword run together with digits (e.g. SCREEN1,1 or POKE65497,0)
                const alphaPrefix = word.match(/^[A-Za-z]+/);
                if (alphaPrefix && alphaPrefix[0].length < word.length) {
                    const hover2 = buildKeywordHover(alphaPrefix[0]);
                    if (hover2) return hover2;
                }
            }

            return null;
        }
    });

    context.subscriptions.push(provider);

    // ugBASIC hover — uses UGBASIC_DOCS; also does PEEK/POKE address lookup for CoCo targets
    const ugbasicProvider = vscode.languages.registerHoverProvider('ugbasic', {
        provideHover(document, position) {
            const line = document.lineAt(position).text;
            const col  = position.character;

            // 1. Try PEEK/POKE/EXEC address lookup (for CoCo-targeted ugBASIC programs)
            const addr = extractAddressFromContext(document, position);
            if (addr !== null && memoryMap.has(addr)) {
                return buildAddressHover(memoryMap.get(addr));
            }

            // 2. Try ugBASIC keyword lookup
            const word = getWordAtPosition(line, col);
            if (word) {
                const hover = buildKeywordHover(word, UGBASIC_DOCS);
                if (hover) return hover;
                const alphaPrefix = word.match(/^[A-Za-z]+/);
                if (alphaPrefix && alphaPrefix[0].length < word.length) {
                    const hover2 = buildKeywordHover(alphaPrefix[0], UGBASIC_DOCS);
                    if (hover2) return hover2;
                }
            }
            return null;
        }
    });
    context.subscriptions.push(ugbasicProvider);
}

function deactivate() {}

module.exports = { activate, deactivate };

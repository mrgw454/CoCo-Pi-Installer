#!/usr/bin/env bash
set -euo pipefail

# ============================================================
#  CoCo BASIC Syntax Extension — Build & Install
#  Packages coco-basic-syntax as a .vsix and installs it
#  into VS Code.
#
#  Usage:
#    ./build-and-install.sh           # build + install
#    ./build-and-install.sh --build   # build only, no install
# ============================================================

INSTALL=true
[[ "${1:-}" == "--build" ]] && INSTALL=false

EXT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_JSON="$EXT_DIR/package.json"
LOCAL_BIN="$HOME/.local/bin"

# Derive expected .vsix name from package.json
NAME=$(python3 -c "import json; d=json.load(open('$PKG_JSON')); print(d['name'])")
VERSION=$(python3 -c "import json; d=json.load(open('$PKG_JSON')); print(d['version'])")
VSIX_NAME="${NAME}-${VERSION}.vsix"

# ------------------------------------------------------------
# 1. Pre-flight
# ------------------------------------------------------------
echo "=== CoCo BASIC Syntax Extension — Build & Install ==="
echo "Extension: $NAME  v$VERSION"
echo "Directory: $EXT_DIR"
echo ""

for f in extension.js package.json language-configuration.json \
          syntaxes/coco-basic.tmLanguage.json snippets/coco-basic.json \
          data/memory-map.json; do
    if [[ ! -f "$EXT_DIR/$f" ]]; then
        echo "[ERROR] Missing: $f"
        exit 1
    fi
done
echo "[OK] All required extension files present."
echo ""

# ------------------------------------------------------------
# 2. Check for vsce
# ------------------------------------------------------------
echo "=== Checking for vsce ==="

if command -v vsce >/dev/null 2>&1; then
    echo "[OK] vsce found at: $(command -v vsce)"
else
    echo "[WARN] vsce not found in PATH."
    read -r -p "Install vsce into \$HOME/.local now? [y/N] " ans
    if [[ "${ans,,}" == "y" ]]; then
        npm install -g @vscode/vsce --prefix "$HOME/.local"
        if [[ ":$PATH:" != *":$LOCAL_BIN:"* ]]; then
            export PATH="$LOCAL_BIN:$PATH"
        fi
        if ! command -v vsce >/dev/null 2>&1; then
            echo "[ERROR] vsce install failed."
            exit 1
        fi
    else
        echo "[ERROR] vsce is required. Aborting."
        exit 1
    fi
fi
echo ""

# ------------------------------------------------------------
# 3. Package
# ------------------------------------------------------------
echo "=== Packaging ==="
cd "$EXT_DIR"
vsce package --allow-missing-repository --allow-star-activation

if [[ ! -f "$VSIX_NAME" ]]; then
    echo "[ERROR] Expected $VSIX_NAME not found after packaging."
    exit 1
fi
echo "[OK] Created $VSIX_NAME"
echo ""

# ------------------------------------------------------------
# 4. Install
# ------------------------------------------------------------
if $INSTALL; then
    echo "=== Installing into VS Code ==="
    code --install-extension "$VSIX_NAME"
    echo "[OK] Installed. Reload VS Code to activate."
else
    echo "[--build only] Skipping install. VSIX is at: $EXT_DIR/$VSIX_NAME"
fi

echo ""
echo "=== Done. ==="

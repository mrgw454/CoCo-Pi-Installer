# CoCoPi Launcher VSIX Packaging

## Resolved `vsce 3.7.1` entry-point failure

On 2026-07-14, repackaging `cocopi-launcher` 1.1.1 with the locally installed
`@vscode/vsce` 3.7.1 failed even though `extension.js` existed and was declared
by both of these fields in `package.json`:

```json
"main": "./extension.js",
"files": ["extension.js"]
```

The failing command was:

```sh
vsce package --allow-missing-repository --allow-star-activation
```

`vsce` reported:

```text
ERROR  Extension entrypoint(s) missing. Make sure these files exist and are
included by your "files" field in 'package.json':
  extension/extension.js
```

An archive filename by itself was not proof of success. During recovery, an
older validated 1.1.0 VSIX envelope had to be updated and independently checked
to produce a safe 1.1.1 installation.

## Root cause and fix

This extension has no packaged Node dependencies. The `vsce` dependency-
discovery path produced an incorrect collected entry-point set in this source
layout. Disabling dependency discovery made `vsce 3.7.1` consistently include
the declared entry point:

```sh
vsce package \
    --no-dependencies \
    --allow-missing-repository \
    --allow-star-activation \
    --skip-license \
    --out "$VSIX_TMP"
```

Do not remove `--no-dependencies` unless a future extension version adds an
actual runtime dependency and the replacement packaging path is separately
proven.

## Required validation

`build-and-install-extension.sh` now treats packaging and installation as two
separate trust boundaries. It:

1. Derives the archive name from the manifest name and version.
2. Packages to a temporary VSIX with dependency discovery disabled.
3. Runs `unzip -tqq` to verify ZIP integrity.
4. Requires both `extension/package.json` and `extension/extension.js`.
5. Compares packaged `extension.js` byte-for-byte with the source.
6. Checks the packaged name, version, and `main` entry-point identity.
7. Runs `node --check` on the source JavaScript.
8. Replaces the final archive only after every check passes.
9. Installs with `code --install-extension ... --force` only after validation.

For a packaging-only test that does not change the installed VS Code extension:

```sh
COCOPI_VSCODE_EXTENSION_INSTALL=0 \
    bash "$HOME/scripts/launcher/vscode-extension/build-and-install-extension.sh"
```

For an isolated source-copy test, override the source directory as well:

```sh
COCOPI_VSCODE_EXTENSION_DIR=/path/to/test/vscode-extension \
COCOPI_VSCODE_EXTENSION_INSTALL=0 \
    bash /path/to/test/vscode-extension/build-and-install-extension.sh
```

The repaired live workflow successfully packaged, validated, and installed
`cocopi.cocopi-launcher` 1.1.1. The initial version-controlled fix is Launcher
commit `9a8442b` on `feature/xroar-ai-integration`.

## Maintainer note

`$HOME/scripts/launcher` is the live-first development source. This note belongs
beside the extension sources and should be harvested into
`unified/vscode-extension/` during the next normal Launcher repository update.

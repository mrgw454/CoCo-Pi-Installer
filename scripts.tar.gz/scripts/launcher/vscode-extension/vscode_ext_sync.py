#!/usr/bin/env python3
import argparse
import subprocess
import sys
import shutil
from pathlib import Path

# Resolve the actual VS Code CLI path (code.exe or code.cmd)
CODE = shutil.which("code")
if CODE is None:
    print("ERROR: 'code' command not found in PATH")
    sys.exit(1)

def run(cmd):
    """Run a command and return (stdout, stderr, exitcode)."""
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    out, err = proc.communicate()
    return out.strip(), err.strip(), proc.returncode

def list_extensions():
    out, err, code = run([CODE, "--list-extensions"])
    if code != 0:
        print("ERROR: Unable to list extensions:", err)
        sys.exit(1)
    return out.splitlines()

def export_extensions(path: Path):
    exts = list_extensions()
    path.write_text("\n".join(exts) + "\n", encoding="utf-8")
    print(f"Exported {len(exts)} extensions to {path}")

def import_extensions(path: Path, dry_run: bool = False):
    if not path.exists():
        print(f"ERROR: File not found: {path}")
        sys.exit(1)

    wanted = [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    installed = set(list_extensions())

    to_install = [ext for ext in wanted if ext not in installed]

    if not to_install:
        print("All extensions already installed. Nothing to do.")
        return

    if dry_run:
        print("Dry-run mode: the following extensions would be installed:")
        for ext in to_install:
            print(f"  → {ext}")
        return

    print(f"Installing {len(to_install)} missing extensions...")
    for ext in to_install:
        print(f"  → {ext}")
        out, err, code = run([CODE, "--install-extension", ext])
        if code != 0:
            print(f"    ERROR installing {ext}: {err}")
        else:
            print(f"    OK")

def main():
    parser = argparse.ArgumentParser(description="Export or import VS Code extensions.")
    parser.add_argument("--export", metavar="FILE", help="Export installed extensions to FILE")
    parser.add_argument("--import", dest="import_file", metavar="FILE", help="Install extensions from FILE")
    args = parser.parse_args()

    if args.export:
        export_extensions(Path(args.export))
    elif args.import_file:
        import_extensions(Path(args.import_file))
    else:
        print("No action specified. Use --export FILE or --import FILE.")
        sys.exit(1)

if __name__ == "__main__":
    main()

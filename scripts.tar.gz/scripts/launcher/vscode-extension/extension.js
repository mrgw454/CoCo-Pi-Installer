const vscode = require('vscode');
const path = require('path');
const os = require('os');
const childProcess = require('child_process');
const util = require('util');

const execFile = util.promisify(childProcess.execFile);
let agentStatus;
let launcherStatus;
let output;
let debugActive = false;

function workspacePath() {
    return vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
}

function pythonCommand() {
    return process.platform === 'win32' ? 'python' : 'python3';
}

function launcherRoot() {
    return path.join(os.homedir(), 'scripts', 'launcher');
}

async function agentTool(args) {
    const workspace = workspacePath();
    if (!workspace) throw new Error('No workspace folder open.');
    const tool = path.join(launcherRoot(), 'tools', 'xroar_agent_client.py');
    const result = await execFile(pythonCommand(), [tool, '--workspace', workspace, ...args],
        { cwd: workspace, timeout: 75000, maxBuffer: 4 * 1024 * 1024 });
    const line = result.stdout.trim().split(/\r?\n/).pop();
    const parsed = JSON.parse(line);
    if (parsed.error) throw new Error(parsed.error);
    return parsed;
}

function updateStatus(session) {
    if (!session) {
        agentStatus.text = '$(debug-disconnect) XRoar AI: none';
        agentStatus.tooltip = 'No workspace XRoar AI session found';
        return;
    }
    const mode = debugActive ? 'GDB active • observe only' : session.machine || 'starting';
    agentStatus.text = `$(radio-tower) XRoar AI: ${mode}`;
    agentStatus.tooltip = `PID ${session.pid} • ${session.endpoint} • ${session.session_id}`;
}

async function refreshStatus(showMessage = false) {
    try {
        const data = await agentTool(['status']);
        updateStatus(data.session);
        output.appendLine(`STATUS ${JSON.stringify(data.session)}`);
        if (showMessage) vscode.window.showInformationMessage(
            `XRoar AI: ${data.session.machine || 'starting'} PID ${data.session.pid} at ${data.session.endpoint}`);
        return data.session;
    } catch (error) {
        updateStatus(null);
        if (showMessage) vscode.window.showWarningMessage(`XRoar AI: ${error.message}`);
        return null;
    }
}

function requireObservationAvailable() {
    if (debugActive) {
        throw new Error('VS Code GDB owns execution. Capture/watch is disabled until debugging stops.');
    }
}

function activate(context) {
    output = vscode.window.createOutputChannel('CoCo-Pi XRoar AI');
    context.subscriptions.push(output);

    context.subscriptions.push(vscode.commands.registerCommand('cocopi.launcher', async () => {
        const folder = workspacePath();
        if (!folder) return vscode.window.showErrorMessage('No workspace folder open.');
        const task = new vscode.Task({ type: 'shell' }, vscode.TaskScope.Workspace,
            'Run Launcher Menu', 'cocopi', new vscode.ShellExecution(
                pythonCommand(), [path.join(launcherRoot(), 'launcher.py')], { cwd: folder }));
        vscode.tasks.executeTask(task);
    }));

    context.subscriptions.push(vscode.commands.registerCommand('cocopi.xroarStatus', () => refreshStatus(true)));

    context.subscriptions.push(vscode.commands.registerCommand('cocopi.xroarCapture', async () => {
        try {
            requireObservationAvailable();
            const folder = workspacePath();
            if (!folder) throw new Error('No workspace folder open.');
            const uri = await vscode.window.showSaveDialog({
                defaultUri: vscode.Uri.file(path.join(folder, '.vscode', 'xroar-capture.png')),
                filters: { PNG: ['png'] }
            });
            if (!uri) return;
            const data = await agentTool(['capture', '--output', uri.fsPath]);
            output.appendLine(`CAPTURE ${JSON.stringify(data)}`);
            vscode.window.showInformationMessage(`XRoar screen captured: ${uri.fsPath}`);
        } catch (error) { vscode.window.showErrorMessage(`XRoar capture: ${error.message}`); }
    }));

    context.subscriptions.push(vscode.commands.registerCommand('cocopi.xroarWatch', async () => {
        try {
            requireObservationAvailable();
            const folder = workspacePath();
            if (!folder) throw new Error('No workspace folder open.');
            const value = await vscode.window.showInputBox({ prompt: 'Watch duration in seconds (1–60)', value: '10' });
            if (value === undefined) return;
            const duration = Number(value);
            if (!Number.isFinite(duration) || duration < 1 || duration > 60) throw new Error('Duration must be 1–60 seconds.');
            const dir = path.join(folder, '.vscode', `xroar-watch-${Date.now()}`);
            const data = await vscode.window.withProgress({ location: vscode.ProgressLocation.Notification,
                title: 'Watching XRoar display', cancellable: false },
                () => agentTool(['watch', '--duration', String(duration), '--output-dir', dir]));
            output.appendLine(`WATCH ${JSON.stringify(data)}`);
            vscode.window.showInformationMessage(`XRoar watch saved ${data.count} changed frame(s): ${dir}`);
        } catch (error) { vscode.window.showErrorMessage(`XRoar watch: ${error.message}`); }
    }));

    context.subscriptions.push(vscode.commands.registerCommand('cocopi.xroarActivity', async () => {
        const session = await refreshStatus(false);
        if (!session) return vscode.window.showWarningMessage('No workspace XRoar AI session found.');
        const terminal = vscode.window.createTerminal({ name: 'XRoar AI Activity', shellPath: pythonCommand(),
            shellArgs: [path.join(launcherRoot(), 'tools', 'xroar_agent_console.py'), '--pid', String(session.pid)] });
        terminal.show();
    }));

    launcherStatus = vscode.window.createStatusBarItem(
        'cocopi.launcherStatus', vscode.StatusBarAlignment.Left, 101);
    launcherStatus.text = '$(rocket) Launcher';
    launcherStatus.command = 'cocopi.launcher';
    launcherStatus.tooltip = 'Run Launcher Menu';
    launcherStatus.show();
    context.subscriptions.push(launcherStatus);

    agentStatus = vscode.window.createStatusBarItem(
        'cocopi.xroarAgentStatus', vscode.StatusBarAlignment.Left, 100);
    agentStatus.command = 'cocopi.xroarStatus'; agentStatus.show(); context.subscriptions.push(agentStatus);
    updateStatus(null); refreshStatus(false);

    context.subscriptions.push(vscode.debug.onDidStartDebugSession(session => {
        debugActive = true; output.appendLine(`GDB START ${session.name}`); refreshStatus(false);
    }));
    context.subscriptions.push(vscode.debug.onDidTerminateDebugSession(session => {
        debugActive = false; output.appendLine(`GDB STOP ${session.name}`); refreshStatus(false);
    }));
}

function deactivate() {}
module.exports = { activate, deactivate };

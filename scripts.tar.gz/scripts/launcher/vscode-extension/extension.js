const vscode = require('vscode');
const path = require('path');
const os = require('os');

function activate(context) {
    let disposable = vscode.commands.registerCommand('cocopi.launcher', async () => {
        const folder = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;

        if (!folder) {
            vscode.window.showErrorMessage("No workspace folder open.");
            return;
        }

        // Cross‑platform Python
        const isWindows = process.platform === "win32";
        const python = isWindows ? "python" : "python3";

        // Cross‑platform HOME directory
        const launcherPath = path.join(
            os.homedir(),
            "scripts",
            "launcher",
            "launcher.py"
        );

        const task = new vscode.Task(
            { type: 'shell' },
            vscode.TaskScope.Workspace,
            'Run Launcher Menu',
            'cocopi',
            new vscode.ShellExecution(python, [launcherPath], { cwd: folder })
        );

        vscode.tasks.executeTask(task);
    });

    context.subscriptions.push(disposable);

    const button = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left);
    button.text = "$(rocket) Launcher";
    button.command = "cocopi.launcher";
    button.tooltip = "Run Launcher Menu";
    button.show();
    context.subscriptions.push(button);
}

function deactivate() {}

module.exports = {
    activate,
    deactivate
};

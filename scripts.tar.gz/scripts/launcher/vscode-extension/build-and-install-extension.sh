#!/usr/bin/env bash
set -euo pipefail

# ============================================================
#  CoCoPi VS Code Extension Builder
#  Deterministic packaging + installation workflow
#  Includes:
#    - vsce presence check
#    - optional local install of vsce
#    - validation of launcher + tasks.json files
#    - packaging + installation of the extension
# ============================================================

EXT_DIR="$HOME/scripts/launcher/vscode-extension"
VSIX_NAME="cocopi-launcher-1.0.0.vsix"
LOCAL_BIN="$HOME/.local/bin"

# ------------------------------------------------------------
# 1. Required file checks
# ------------------------------------------------------------
echo "=== Pre-flight validation ==="

LAUNCHER_JS="$EXT_DIR/extension.js"
LAUNCHER_JSON="$EXT_DIR/package.json"
TASKS_JSON="$HOME/.config/Code/User/tasks.json"

# These two files define the VS Code extension itself.
# If either is missing, packaging cannot proceed.
if [[ ! -f "$LAUNCHER_JS" ]]; then
    echo "[ERROR] Missing: $LAUNCHER_JS"
    echo "        This file defines the launcher command logic."
    exit 1
fi

if [[ ! -f "$LAUNCHER_JSON" ]]; then
    echo "[ERROR] Missing: $LAUNCHER_JSON"
    echo "        This file defines the VS Code extension metadata."
    exit 1
fi

echo "[OK] Extension files present."

# tasks.json is optional but recommended.
# It defines editor-side compile tasks (C, ASM, BASIC).
# The launcher extension does NOT replace tasks.json.
if [[ -f "$TASKS_JSON" ]]; then
    echo "[OK] tasks.json found at: $TASKS_JSON"
else
    echo "[WARN] No tasks.json found at: $TASKS_JSON"
    echo "       VS Code compile tasks will not be available."
    echo "       Launcher still works — tasks.json is editor-only."
fi

echo

# ------------------------------------------------------------
# 2. Check for vsce
# ------------------------------------------------------------
echo "=== Checking for vsce ==="

if command -v vsce >/dev/null 2>&1; then
    echo "[OK] vsce is installed at: $(command -v vsce)"
else
    echo "[WARN] vsce not found in PATH."

    read -p "Install vsce into \$HOME/.local now? [y/N] " ans
    if [[ "${ans,,}" == "y" ]]; then
        echo "[INFO] Installing vsce locally..."
        npm install -g @vscode/vsce --prefix "$HOME/.local"

        # Ensure PATH contains ~/.local/bin
        if [[ ":$PATH:" != *":$LOCAL_BIN:"* ]]; then
            echo "export PATH=\$HOME/.local/bin:\$PATH" >> "$HOME/.bashrc"
            export PATH="$HOME/.local/bin:$PATH"
            echo "[INFO] Added ~/.local/bin to PATH"
        fi

        if ! command -v vsce >/dev/null 2>&1; then
            echo "[ERROR] vsce installation failed."
            exit 1
        fi
    else
        echo "[ERROR] vsce is required. Aborting."
        exit 1
    fi
fi

echo

# ------------------------------------------------------------
# 3. Package the extension
# ------------------------------------------------------------
echo "=== Packaging extension ==="
cd "$EXT_DIR"

vsce package --allow-missing-repository --allow-star-activation

if [[ ! -f "$VSIX_NAME" ]]; then
    echo "[ERROR] Packaging failed: $VSIX_NAME not found."
    exit 1
fi

echo "[OK] Created $VSIX_NAME"
echo

# ------------------------------------------------------------
# 4. Install the extension into VS Code
# ------------------------------------------------------------
echo "=== Installing extension into VS Code ==="
code --install-extension "$VSIX_NAME"

echo "[OK] Extension installed."
echo
echo "=== Done. Reload VS Code to activate the extension. ==="

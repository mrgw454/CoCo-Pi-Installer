#!/usr/bin/env bash
set -euo pipefail

# ============================================================
#  CoCoPi VS Code Extension Builder
#  Deterministic packaging + installation workflow
#  Includes:
#    - vsce presence check
#    - optional local install of vsce
#    - validation of launcher + tasks.json files
#    - packaging + installation of the extension
# ============================================================

EXT_DIR="${COCOPI_VSCODE_EXTENSION_DIR:-$HOME/scripts/launcher/vscode-extension}"
LOCAL_BIN="$HOME/.local/bin"

# ------------------------------------------------------------
# 1. Required file checks
# ------------------------------------------------------------
echo "=== Pre-flight validation ==="

LAUNCHER_JS="$EXT_DIR/extension.js"
LAUNCHER_JSON="$EXT_DIR/package.json"
TASKS_JSON="$HOME/.config/Code/User/tasks.json"

# These two files define the VS Code extension itself.
# If either is missing, packaging cannot proceed.
if [[ ! -f "$LAUNCHER_JS" ]]; then
    echo "[ERROR] Missing: $LAUNCHER_JS"
    echo "        This file defines the launcher command logic."
    exit 1
fi

if [[ ! -f "$LAUNCHER_JSON" ]]; then
    echo "[ERROR] Missing: $LAUNCHER_JSON"
    echo "        This file defines the VS Code extension metadata."
    exit 1
fi

echo "[OK] Extension files present."

VSIX_NAME="$(node -e '
const manifest = require(process.argv[1]);
if (!manifest.name || !manifest.version) process.exit(1);
process.stdout.write(`${manifest.name}-${manifest.version}.vsix`);
' "$LAUNCHER_JSON")"
VSIX_PATH="$EXT_DIR/$VSIX_NAME"
VSIX_TMP="$EXT_DIR/.$VSIX_NAME.tmp.vsix"
trap 'rm -f "$VSIX_TMP"' EXIT

# tasks.json is optional but recommended.
# It defines editor-side compile tasks (C, ASM, BASIC).
# The launcher extension does NOT replace tasks.json.
if [[ -f "$TASKS_JSON" ]]; then
    echo "[OK] tasks.json found at: $TASKS_JSON"
else
    echo "[WARN] No tasks.json found at: $TASKS_JSON"
    echo "       VS Code compile tasks will not be available."
    echo "       Launcher still works — tasks.json is editor-only."
fi

echo

# ------------------------------------------------------------
# 2. Check for vsce
# ------------------------------------------------------------
echo "=== Checking for vsce ==="

if command -v vsce >/dev/null 2>&1; then
    echo "[OK] vsce is installed at: $(command -v vsce)"
else
    echo "[WARN] vsce not found in PATH."

    read -p "Install vsce into \$HOME/.local now? [y/N] " ans
    if [[ "${ans,,}" == "y" ]]; then
        echo "[INFO] Installing vsce locally..."
        npm install -g @vscode/vsce --prefix "$HOME/.local"

        # Ensure PATH contains ~/.local/bin
        if [[ ":$PATH:" != *":$LOCAL_BIN:"* ]]; then
            echo "export PATH=\$HOME/.local/bin:\$PATH" >> "$HOME/.bashrc"
            export PATH="$HOME/.local/bin:$PATH"
            echo "[INFO] Added ~/.local/bin to PATH"
        fi

        if ! command -v vsce >/dev/null 2>&1; then
            echo "[ERROR] vsce installation failed."
            exit 1
        fi
    else
        echo "[ERROR] vsce is required. Aborting."
        exit 1
    fi
fi

echo

# ------------------------------------------------------------
# 3. Package the extension
# ------------------------------------------------------------
echo "=== Packaging extension ==="
cd "$EXT_DIR"

rm -f "$VSIX_TMP"
vsce package \
    --no-dependencies \
    --allow-missing-repository \
    --allow-star-activation \
    --skip-license \
    --out "$VSIX_TMP"

if [[ ! -f "$VSIX_TMP" ]]; then
    echo "[ERROR] Packaging failed: temporary VSIX not found."
    exit 1
fi

echo "=== Validating package ==="
unzip -tqq "$VSIX_TMP"

for entry in extension/package.json extension/extension.js; do
    if ! unzip -Z1 "$VSIX_TMP" | grep -Fxq "$entry"; then
        echo "[ERROR] Packaged VSIX is missing required entry: $entry"
        exit 1
    fi
done

if ! cmp -s "$LAUNCHER_JS" <(unzip -p "$VSIX_TMP" extension/extension.js); then
    echo "[ERROR] Packaged extension.js does not match the source file."
    exit 1
fi

unzip -p "$VSIX_TMP" extension/package.json | node -e '
let raw = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", chunk => raw += chunk);
process.stdin.on("end", () => {
    const manifest = JSON.parse(raw);
    const expectedName = process.argv[1];
    const expectedVersion = process.argv[2];
    if (manifest.name !== expectedName || manifest.version !== expectedVersion ||
        manifest.main !== "./extension.js") process.exit(1);
});
' "$(node -p 'require(process.argv[1]).name' "$LAUNCHER_JSON")" \
  "$(node -p 'require(process.argv[1]).version' "$LAUNCHER_JSON")"

node --check "$LAUNCHER_JS"
mv -f "$VSIX_TMP" "$VSIX_PATH"

echo "[OK] Created and validated $VSIX_PATH"
echo

# ------------------------------------------------------------
# 4. Install the extension into VS Code
# ------------------------------------------------------------
echo "=== Installing extension into VS Code ==="
if [[ "${COCOPI_VSCODE_EXTENSION_INSTALL:-1}" == "1" ]]; then
    code --install-extension "$VSIX_PATH" --force
    echo "[OK] Extension installed."
else
    echo "[SKIP] Installation disabled by COCOPI_VSCODE_EXTENSION_INSTALL."
fi

echo
echo "=== Done. Reload VS Code to activate the extension. ==="

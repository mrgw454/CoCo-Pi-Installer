#!/usr/bin/env bash
# Linux wrapper for audit_all.py
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$SCRIPT_DIR/audit_all.py" "$@"

#!/usr/bin/env python3
import os
import sys
import json
import re
from pathlib import Path

# ============================================================
# COLOR CONSTANTS
# ============================================================

C_RESET = "\033[0m"
C_RED   = "\033[31m"
C_GRN   = "\033[32m"
C_YEL   = "\033[33m"
C_CYN   = "\033[36m"

# ============================================================
# SUMMARY COUNTERS
# ============================================================

COUNT_OK = 0
COUNT_MISSING = 0
COUNT_SKIPPED = 0
COUNT_WARN = 0

def mark_ok(msg):
    global COUNT_OK
    COUNT_OK += 1
    return f"{C_GRN}[OK]{C_RESET} {msg}"

def mark_missing(msg):
    global COUNT_MISSING
    COUNT_MISSING += 1
    return f"{C_RED}[MISSING]{C_RESET} {msg}"

def mark_skipped(msg):
    global COUNT_SKIPPED
    COUNT_SKIPPED += 1
    return f"{C_YEL}[SKIPPED]{C_RESET} {msg}"

def mark_warn(msg):
    global COUNT_WARN
    COUNT_WARN += 1
    return f"{C_YEL}[WARN]{C_RESET} {msg}"

# ============================================================
# PLATFORM DETECTION
# ============================================================

IS_WINDOWS = (os.name == "nt")
IS_LINUX = (os.name == "posix")

LIN_HOME = os.environ.get("HOME", "")

# Windows home (real or mounted)
if IS_LINUX:
    WIN_HOME = "/media/ron/OS/Users/Ron"
else:
    WIN_HOME = os.environ.get("USERPROFILE", "")

APPDATA = os.environ.get("APPDATA", "")

# ============================================================
# PATH TRANSLATION (MATCHES launcher.py)
# ============================================================

def translate_path_to_linux(p):
    if not isinstance(p, str):
        return p
    s = p.replace("\\", "/")
    win_home_norm = WIN_HOME.replace("\\", "/").lower()

    if "\\" in p or ":" in p:
        if s.lower().startswith("e:/media/share1"):
            return "/media/share1" + s[15:]
        if s.lower().startswith(win_home_norm):
            return LIN_HOME + s[len(win_home_norm):]
    return s

def translate_path_to_windows(p):
    if not isinstance(p, str):
        return p
    s = p.replace("\\", "/")
    lin_home_norm = LIN_HOME

    if s.startswith("/"):
        if s.lower().startswith("/media/share1"):
            return r"E:\media\share1" + s[13:].replace("/", "\\")
        if s.lower().startswith(lin_home_norm.lower()):
            return WIN_HOME + s[len(lin_home_norm):].replace("/", "\\")
    return s

def translate_path(p):
    return translate_path_to_windows(p) if IS_WINDOWS else translate_path_to_linux(p)

# ============================================================
# PLACEHOLDER EXPANSION
# ============================================================

def expand_home(p):
    if not isinstance(p, str):
        return p
    return (
        p.replace("{HOME}", LIN_HOME)
         .replace("{WINHOME}", WIN_HOME.replace("\\", "/"))
    )

def expand_vscode_placeholders(cmd):
    if not isinstance(cmd, str):
        return cmd
    out = cmd
    out = out.replace("${env:HOME}", LIN_HOME)
    out = out.replace("${env:USERPROFILE}", WIN_HOME)
    return out

# ============================================================
# PATH LOOKUP
# ============================================================

def find_in_path(cmd):
    hits = []
    for path_dir in os.environ.get("PATH", "").split(os.pathsep):
        candidate = Path(path_dir) / cmd
        if candidate.exists():
            hits.append(str(candidate))
    return hits

# ============================================================
# UTILITY SCRIPT RESOLUTION
# ============================================================

def resolve_utility(cmd, tools_dir):
    if cmd == "build_dsk":
        return tools_dir / "build_dsk.py"
    if cmd == "build_cassette":
        return tools_dir / "build_cassette.py"
    return None

# ============================================================
# pyDW NORMALIZATION
# ============================================================

def normalize_pydw(pydw):
    if not isinstance(pydw, dict):
        return {}
    out = dict(pydw)
    if "insert" in out:
        if isinstance(out["insert"], str):
            out["insert"] = [out["insert"]]
    if "disks" in out and isinstance(out["disks"], dict):
        out["disks"] = {str(k): v for k, v in out["disks"].items()}
    return out

def extract_pydw_paths(pydw):
    paths = []
    pydw = normalize_pydw(pydw)
    if "insert" in pydw:
        paths.extend(pydw["insert"])
    if "disks" in pydw:
        paths.extend(pydw["disks"].values())
    return paths

# ============================================================
# VALIDATE COMMAND (MODE B)
# ============================================================

def validate_command(cmd_raw, platform):
    if platform == "linux" and IS_WINDOWS:
        return mark_skipped("Run audit on Linux to validate this entry")
    if platform == "windows" and IS_LINUX:
        return mark_skipped("Run audit on Windows to validate this entry")

    if not cmd_raw:
        return mark_missing("No command")

    expanded = expand_vscode_placeholders(cmd_raw)
    expanded = expand_home(expanded)
    translated = translate_path(expanded)

    if os.path.isabs(translated):
        if os.path.exists(translated):
            return mark_ok(translated)
        else:
            return mark_missing(translated)

    hits = find_in_path(translated)
    if hits:
        return mark_ok(", ".join(hits))

    return mark_missing(f"{translated} (not in PATH)")

# ============================================================
# EXTRACT EXECUTABLE FROM COMMAND STRING
# ============================================================

def extract_executable(cmd_string):
    if not isinstance(cmd_string, str):
        return None
    expanded = expand_home(cmd_string)
    parts = expanded.split()
    if not parts:
        return None
    return parts[0]

# ============================================================
# AUDIT VS CODE TASKS
# ============================================================

def audit_vscode_tasks():
    print(f"\n{C_CYN}=== VS Code tasks.json Audit ==={C_RESET}\n")

    if IS_LINUX:
        tasks_path = Path(LIN_HOME) / ".config" / "Code" / "User" / "tasks.json"
    else:
        tasks_path = Path(APPDATA) / "Code" / "User" / "tasks.json"

    if not tasks_path.exists():
        print(mark_missing(f"tasks.json not found at: {tasks_path}"))
        return

    raw = tasks_path.read_text()

    cleaned = re.sub(r"//.*", "", raw)
    cleaned = re.sub(r"/\*.*?\*/", "", cleaned, flags=re.DOTALL)

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as err:
        print(mark_missing(f"JSON parse error at line {err.lineno}, column {err.colno}"))
        return

    tasks = data.get("tasks", [])

    for task in tasks:
        label = task.get("label", "<no label>")
        print(f"\nTask: {label}")

        linux_cfg = task.get("linux")
        win_cfg = task.get("windows")

        if linux_cfg:
            print(f"  Linux: {validate_command(linux_cfg.get('command'), 'linux')}")
        else:
            print(f"  Linux: {mark_missing('No linux entry')}")

        if win_cfg:
            print(f"  Windows: {validate_command(win_cfg.get('command'), 'windows')}")
        else:
            print(f"  Windows: {mark_missing('No windows entry')}")

    print(f"\n{C_CYN}=== VS Code Audit Complete ==={C_RESET}\n")

# ============================================================
# AUDIT LAUNCHER MENUS (PATCHED)
# ============================================================

def audit_launcher():
    print(f"\n{C_CYN}=== Launcher Menu Audit ==={C_RESET}\n")

    base_dir = Path(__file__).resolve().parent
    launcher_dir = base_dir
    config_dir = launcher_dir / "config"
    tools_dir = launcher_dir / "tools"

    if not config_dir.exists():
        print(mark_missing("No config directory found."))
        return

    for filename in sorted(config_dir.glob("*.json")):
        print(f"\n--- {filename.name} ---")
        try:
            data = json.load(open(filename, "r", encoding="utf-8"))
        except Exception as e:
            print(mark_missing(f"Cannot parse JSON: {e}"))
            continue

        for item in data.get("items", []):
            label = item.get("label", "<no label>")
            print(f"\nItem: {label}")

            raw_cmd = None

            if "platforms" in item:
                plat = "windows" if IS_WINDOWS else "linux"
                cfg = item["platforms"].get(plat, {})
                raw_cmd = cfg.get("command")
            else:
                emu = item.get("emulator")
                args = item.get("args", [])
                if emu == "xroar":
                    raw_cmd = "xroar"
                elif emu == "mame":
                    raw_cmd = "mame"
                elif emu == "trs80gp":
                    raw_cmd = "trs80gp"
                elif emu == "browser":
                    raw_cmd = args[0] if args else None
                elif emu == "utility":
                    raw_cmd = args[0] if args else None

            exe = extract_executable(raw_cmd)

            util = resolve_utility(exe, tools_dir)
            if util:
                if util.exists():
                    print(f"  {mark_ok(f'Utility script exists: {util}')}")
                else:
                    print(f"  {mark_missing(f'Utility script: {util}')}")
                continue

            if exe:
                platform = "windows" if IS_WINDOWS else "linux"
                print(f"  {validate_command(exe, platform)}")
            else:
                print(f"  {mark_warn('No command')}")

            pydw = item.get("pyDW")
            if pydw:
                print("  pyDW:")
                for p in extract_pydw_paths(pydw):
                    if "{DSK}" in p:
                        print(f"    {mark_warn(f'[PLACEHOLDER] {p}')}")
                        continue
                    translated = translate_path(expand_home(p))
                    if os.path.exists(translated):
                        print(f"    {mark_ok(translated)}")
                    else:
                        print(f"    {mark_missing(translated)}")

    print(f"\n{C_CYN}=== Launcher Audit Complete ==={C_RESET}\n")

# ============================================================
# SUMMARY
# ============================================================

def print_summary():
    print(f"{C_CYN}=== Summary ==={C_RESET}")
    print(f"{C_GRN}OK:      {COUNT_OK}{C_RESET}")
    print(f"{C_RED}MISSING: {COUNT_MISSING}{C_RESET}")
    print(f"{C_YEL}SKIPPED: {COUNT_SKIPPED}{C_RESET}")
    print(f"{C_YEL}WARN:    {COUNT_WARN}{C_RESET}")
    print()

# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    audit_launcher()
    audit_vscode_tasks()
    print_summary()

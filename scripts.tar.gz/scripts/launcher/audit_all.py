#!/usr/bin/env python3
"""
audit_all.py — CoCo Launcher configuration auditor

USAGE
-----
  Linux:    ./audit_all.sh          (or: python3 audit_all.py)
  Windows:  python audit_all.py     (or: pwsh -ExecutionPolicy Bypass -File audit_all.ps1)

No arguments or options — just run it from the launcher directory.
Paths are imported from launcher.py at runtime, so SHARE1 and emulator
locations are always in sync with the launcher itself.

WHAT IT CHECKS
--------------
  config/*.json (all menu items):
    - Emulator executable exists (xroar, mame, trs80gp resolved via PATH or absolute path)
    - File/directory args expanded from {SHARE1}/{HOME}/{WINHOME} exist on disk
    - pyDriveWire disk paths (insert / disks[n]) exist on disk
    - attract / attract_slideshow scan root directories exist
    - Hardcoded share1 or home paths that should use placeholders
    - Wrong-platform paths in linux/windows sub-blocks (e.g. C:\\ inside a linux block)
    - Identical linux/windows blocks that could be merged to top-level
    - Blocks that differ only in path prefix (could use {SHARE1}/{HOME}/{WINHOME})
    - utility items: verifies the referenced Python script exists
    - platforms.linux/windows command items: verifies executable (and -File script for PowerShell)
    - Malformed JSON

  VS Code tasks.json:
    - Each task's linux/windows command executable exists

  Version selector:
    - Versioned MAME/XRoar install directories exist
    - Active symlink (Linux) or junction (Windows) is set and points to a real target

OUTPUT TAGS
-----------
  [OK]      — file/executable/directory found
  [MISSING] — file/executable/directory not found; something needs fixing
  [WARN]    — style issue (hardcoded path, wrong-platform path, redundant block)
  [SKIPPED] — check not applicable on this platform (off-platform block)
  [INFO]    — informational note (runtime placeholder, no binary needed, etc.)

Runtime-only placeholders ({DSK}, {FILE}, {AUTOBOOT}, {AUTOTYPE}) are resolved
by the launcher at launch time and are skipped during existence checks.
"""
import os
import re
import sys
import json
from pathlib import Path

# ============================================================
# COLOR OUTPUT (works on Windows 10+/11 and Linux)
# ============================================================

def _ansi_supported():
    if os.name == "nt":
        # Enable VT processing on Windows if possible
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
            return True
        except Exception:
            return False
    return True

USE_COLOR = _ansi_supported() and sys.stdout.isatty()

def _c(code, text):
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text

def red(t):    return _c("31", t)
def green(t):  return _c("32", t)
def yellow(t): return _c("33", t)
def cyan(t):   return _c("36", t)
def bold(t):   return _c("1",  t)

# ============================================================
# COUNTERS
# ============================================================

_counts = {"ok": 0, "missing": 0, "warn": 0, "skipped": 0, "info": 0}

def _tag(color_fn, label, msg, counter_key):
    _counts[counter_key] += 1
    return f"  {color_fn(f'[{label}]')} {msg}"

def ok(msg):      return _tag(green,  "OK",      msg, "ok")
def missing(msg): return _tag(red,    "MISSING", msg, "missing")
def warn(msg):    return _tag(yellow, "WARN",    msg, "warn")
def skipped(msg): return _tag(yellow, "SKIPPED", msg, "skipped")
def info(msg):    return _tag(cyan,   "INFO",    msg, "info")

# ============================================================
# PLATFORM DETECTION
# ============================================================

IS_WINDOWS = (os.name == "nt")
IS_LINUX   = (os.name == "posix")

MOUNTED_WIN_HOME = os.environ.get(
    "COCOPI_WINDOWS_HOME", "/media/ron/OS/Users/Ron"
)
WIN_HOME = os.environ.get("USERPROFILE", "") if IS_WINDOWS else MOUNTED_WIN_HOME
LIN_HOME = os.environ.get("HOME", "") or (WIN_HOME.replace("\\", "/") if IS_WINDOWS else "")
APPDATA  = os.environ.get("APPDATA", "")

# Import SHARE1 config from launcher.py so there is a single place to edit.
# Falls back to defaults if launcher.py cannot be imported.
# Import configurable paths from launcher.py — single source of truth.
# Falls back to defaults only if launcher.py cannot be imported.
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from launcher import (
        SHARE1_LINUX, SHARE1_WINDOWS, SHARE1,
        XROAR_EXE, MAME_EXE, TRS80GP_EXE,
        MAME_EXE_LINUX, MAME_EXE_WINDOWS,
        XROAR_EXE_LINUX, XROAR_EXE_WINDOWS,
        MAME_VERSIONS_DIR_LINUX, XROAR_VERSIONS_DIR_LINUX,
        VCC_EXE, VCC_EXE_WINDOWS,
        OVCC_EXE, OVCC_EXE_LINUX,
        CLK_EXE, CLK_EXE_LINUX,
        LIN_HOME, WIN_HOME,
    )
except ImportError:
    SHARE1_LINUX   = "/media/share1"
    SHARE1_WINDOWS = "E:/media/share1"
    SHARE1         = SHARE1_WINDOWS if IS_WINDOWS else SHARE1_LINUX
    XROAR_EXE      = "xroar.exe"   if IS_WINDOWS else "xroar"
    MAME_EXE       = "mame.exe"    if IS_WINDOWS else "mame"
    TRS80GP_EXE    = "trs80gp.exe" if IS_WINDOWS else "trs80gp"
    MAME_EXE_LINUX    = "mame"
    MAME_EXE_WINDOWS  = str(Path(WIN_HOME) / "mame" / "mame.exe")
    XROAR_EXE_LINUX   = "xroar"
    XROAR_EXE_WINDOWS = str(Path(WIN_HOME) / "xroar" / "xroar.exe")
    MAME_VERSIONS_DIR_LINUX  = "/opt"
    XROAR_VERSIONS_DIR_LINUX = "/usr/local/bin"
    VCC_EXE_WINDOWS  = str(Path(WIN_HOME) / "VCC" / "VCC.exe")
    VCC_EXE          = VCC_EXE_WINDOWS if IS_WINDOWS else ""
    OVCC_EXE_LINUX   = str(Path(LIN_HOME) / ".ovcc" / "ovcc")
    OVCC_EXE         = "" if IS_WINDOWS else OVCC_EXE_LINUX
    CLK_EXE_LINUX    = str(Path(LIN_HOME) / "CLK" / "bin" / "clksignal")
    CLK_EXE          = "" if IS_WINDOWS else CLK_EXE_LINUX

# On Linux, launcher.py correctly leaves WIN_HOME empty because USERPROFILE is
# not part of the native runtime environment.  The auditor also inspects the
# mounted Windows installation, so restore that separate cross-OS view after
# importing the Launcher's canonical settings and recompute its executable
# paths from the mounted profile.
if IS_LINUX and not WIN_HOME:
    WIN_HOME = MOUNTED_WIN_HOME
    MAME_EXE_WINDOWS = str(Path(WIN_HOME) / "mame" / "mame.exe")
    XROAR_EXE_WINDOWS = str(Path(WIN_HOME) / "xroar" / "xroar.exe")
    VCC_EXE_WINDOWS = str(Path(WIN_HOME) / "VCC" / "VCC.exe")

# Known placeholders that are intentionally not real paths
_SKIP_PLACEHOLDERS = {"{DSK}", "{FILE}", "{AUTOBOOT}", "{AUTOTYPE}", "{SHARE1}",
                      "{HOME}", "{WINHOME}"}

# ============================================================
# PATH TRANSLATION (matches launcher.py)
# ============================================================

def _expand_home(p):
    if not isinstance(p, str):
        return p
    return (
        p.replace("{HOME}", LIN_HOME)
         .replace("{WINHOME}", WIN_HOME.replace("\\", "/"))
         .replace("{SHARE1}", SHARE1.replace("\\", "/"))
    )

def translate_path(p):
    if not isinstance(p, str):
        return p
    p = _expand_home(p)
    s = p.replace("\\", "/")
    lin_share1 = SHARE1_LINUX.lower()
    win_share1 = SHARE1_WINDOWS.replace("\\", "/").lower()
    if IS_WINDOWS:
        if s.startswith("/"):
            if s.lower().startswith(lin_share1):
                return SHARE1_WINDOWS.replace("/", "\\") + s[len(lin_share1):].replace("/", "\\")
            wh = WIN_HOME.replace("\\", "/")
            if s.lower().startswith(wh.lower()):
                return WIN_HOME + s[len(wh):].replace("/", "\\")
        return s
    else:
        if "\\" in p or (":" in p and re.match(r"^[A-Za-z]:", p)):
            if s.lower().startswith(win_share1):
                return SHARE1_LINUX + s[len(win_share1):]
            wh = WIN_HOME.replace("\\", "/").lower()
            if s.lower().startswith(wh):
                return LIN_HOME + s[len(wh):]
        return s

# ============================================================
# COMMAND RESOLUTION (PATH + PATHEXT on Windows)
# ============================================================

def resolve_command(cmd):
    """Return resolved executable path, or None if not found."""
    if not isinstance(cmd, str) or not cmd:
        return None
    candidate = os.path.expanduser(cmd)
    if os.path.sep in candidate or "/" in candidate:
        return os.path.abspath(candidate) if os.path.isfile(candidate) else None

    path_dirs = [p for p in os.environ.get("PATH", "").split(os.pathsep) if p]
    if IS_WINDOWS:
        pathext = os.environ.get("PATHEXT", ".COM;.EXE;.BAT;.CMD")
        exts = [e.strip() for e in pathext.split(";") if e.strip()]
        names = [cmd] + [cmd + e for e in exts if not cmd.lower().endswith(e.lower())]
        for d in path_dirs:
            for name in names:
                full = os.path.join(d, name)
                if os.path.isfile(full):
                    return os.path.abspath(full)
    else:
        for d in path_dirs:
            full = os.path.join(d, cmd)
            if os.path.isfile(full) and os.access(full, os.X_OK):
                return os.path.abspath(full)
    return None

# ============================================================
# PATH ISSUE DETECTORS
# ============================================================

_WIN_PATH_RE = re.compile(r"(?:^|(?<=[^{A-Za-z]))[A-Za-z]:[/\\]", re.IGNORECASE)

def _has_any_placeholder(s):
    return any(ph in s for ph in _SKIP_PLACEHOLDERS)

def _looks_like_path(s):
    """Heuristic: does this string look like a file path?"""
    if not isinstance(s, str) or not s:
        return False
    # Strings containing newline/carriage-return (actual or as \n/\r escape sequences)
    # are command strings (e.g. MAME -autoboot_command), not file paths.
    if "\n" in s or "\r" in s or "\\n" in s or "\\r" in s:
        return False
    return (
        s.startswith("/") or
        bool(_WIN_PATH_RE.search(s)) or
        (len(s) > 3 and ("/" in s or "\\" in s))
    )

def _hardcoded_share(s):
    """True if s contains a raw share1 path (not via placeholder)."""
    if not isinstance(s, str) or _has_any_placeholder(s):
        return False
    sl = s.replace("\\", "/").lower()
    lin = SHARE1_LINUX.lower()
    win = SHARE1_WINDOWS.replace("\\", "/").lower()
    return lin in sl or win in sl

def _hardcoded_home(s):
    """True if s contains a literal home directory path."""
    if not isinstance(s, str) or _has_any_placeholder(s):
        return False
    sl = s.replace("\\", "/").lower()
    if LIN_HOME and LIN_HOME != "/" and LIN_HOME.lower() in sl:
        return True
    if WIN_HOME:
        wh = WIN_HOME.replace("\\", "/").lower()
        if len(wh) > 3 and wh in sl:
            return True
    return False

def _win_path_in_linux_block(s):
    if not isinstance(s, str) or _has_any_placeholder(s):
        return False
    return bool(_WIN_PATH_RE.search(s))

def _linux_path_in_win_block(s):
    if not isinstance(s, str) or _has_any_placeholder(s):
        return False
    return s.startswith("/") and not s.startswith("//")

# ============================================================
# STRING / ARGS STYLE CHECKS
# ============================================================

_RUNTIME_PLACEHOLDERS = {"{DSK}", "{FILE}", "{AUTOBOOT}", "{AUTOTYPE}"}

def _check_string(s, block=None, ctx="", existence=True):
    """Yield (tag_fn, message) for style/path issues and existence checks in a single string."""
    if not isinstance(s, str) or not _looks_like_path(s):
        return

    prefix = f"{ctx}: " if ctx else ""

    if _hardcoded_share(s):
        yield warn, f"{prefix}hardcoded share1 path -> use {{SHARE1}}: {s!r}"
    elif _hardcoded_home(s):
        yield warn, f"{prefix}hardcoded home path -> use {{HOME}} or {{WINHOME}}: {s!r}"

    if block == "linux" and _win_path_in_linux_block(s):
        yield warn, f"{prefix}Windows-style path inside linux block: {s!r}"
    elif block == "windows" and _linux_path_in_win_block(s):
        yield warn, f"{prefix}Linux-style path inside windows block: {s!r}"

    # Existence check: skip runtime-only placeholders resolved at launch time
    if not existence or any(ph in s for ph in _RUNTIME_PLACEHOLDERS):
        return
    expanded = _expand_home(s)
    if re.search(r'\{[^}]+\}', expanded):
        return  # unresolved tokens remain — can't check
    translated = translate_path(expanded)
    if os.path.exists(translated):
        yield ok, f"{prefix}{translated}"
    elif os.path.splitext(os.path.basename(translated))[1]:
        # Has a file extension — a specific file was expected
        yield missing, f"{prefix}{translated}"
    else:
        # No extension — likely a directory browse hint; missing is expected in some setups
        yield warn, f"{prefix}directory not found: {translated}"

def check_args(args, block=None, existence=True):
    """Return list of output lines for issues found in an args list."""
    lines = []
    if not isinstance(args, list):
        return lines
    for val in args:
        for tag_fn, msg in _check_string(val, block, "arg", existence=existence):
            lines.append(tag_fn(msg))
    return lines

# ============================================================
# PYDRIVEWARE PATH CHECKS
# ============================================================

def _normalize_pydw(pydw):
    if not isinstance(pydw, dict):
        return {}
    out = dict(pydw)
    if "insert" in out and isinstance(out["insert"], str):
        out["insert"] = [out["insert"]]
    if "disks" in out and isinstance(out["disks"], dict):
        out["disks"] = {str(k): v for k, v in out["disks"].items()}
    return out

def check_pydw(pydw, block=None):
    """Return list of output lines for a pyDW block."""
    lines = []
    pydw = _normalize_pydw(pydw)
    entries = []
    if "insert" in pydw:
        entries += [(p, "insert") for p in pydw["insert"]]
    if "disks" in pydw:
        entries += [(v, f"disks[{k}]") for k, v in pydw["disks"].items()]

    if not entries:
        return lines

    for p, field in entries:
        if not isinstance(p, str):
            continue
        if "{DSK}" in p:
            lines.append(info(f"pyDW.{field}: {{DSK}} placeholder (resolved at build time)"))
            continue

        for tag_fn, msg in _check_string(p, block, f"pyDW.{field}"):
            lines.append(tag_fn(msg))

    return lines

# ============================================================
# BLOCK SIMILARITY  (identical / differ-only-in-prefix)
# ============================================================

def _normalise_for_compare(obj):
    """Replace share1 and home prefixes so we can compare blocks structurally."""
    s = json.dumps(obj, sort_keys=True)
    # normalise backslashes first
    s = s.replace("\\\\", "/").replace("\\", "/")
    sl = s.lower()

    # Replace known path prefixes with tokens
    sl = sl.replace(WIN_HOME.replace("\\", "/").lower(), "{WINHOME}")
    if LIN_HOME:
        sl = sl.replace(LIN_HOME.lower(), "{HOME}")
    sl = sl.replace(SHARE1_WINDOWS.replace("\\", "/").lower(), "{SHARE1}")
    sl = sl.replace(SHARE1_LINUX.lower(), "{SHARE1}")
    return sl

def compare_blocks(linux_block, win_block):
    """
    Returns:
      'identical'   — blocks are byte-for-byte the same
      'same_after_norm' — blocks are the same after normalising path prefixes
      'different'   — blocks genuinely differ
    """
    raw_l = json.dumps(linux_block, sort_keys=True)
    raw_w = json.dumps(win_block,   sort_keys=True)
    if raw_l == raw_w:
        return "identical"
    if _normalise_for_compare(linux_block) == _normalise_for_compare(win_block):
        return "same_after_norm"
    return "different"

# ============================================================
# EMULATOR EXECUTABLE CHECK
# ============================================================

BASE_DIR  = Path(__file__).resolve().parent
TOOLS_DIR = BASE_DIR / "tools"

# These are the exact same paths launcher.py will use at runtime.
_EMU_CMDS = {
    "xroar":   XROAR_EXE,
    "mame":    MAME_EXE,
    "trs80gp": TRS80GP_EXE,
    "vcc":     VCC_EXE,
    "ovcc":    OVCC_EXE,
    "clk":     CLK_EXE,
}

def check_emulator(emu, args, item_type=None):
    """Return an output line for the emulator executable."""
    # Type-based items with no binary to check
    if item_type == "system_action":
        return info("type: system_action (no binary check)")
    if item_type in ("attract", "attract_slideshow"):
        return info(f"type: {item_type} (no binary check)")

    if emu in ("browser", "attract", "attract_slideshow"):
        return info(f"emulator: {emu} (no binary check)")

    if emu == "utility":
        util_name = args[0] if args else None
        if util_name == "build_dsk":
            p = TOOLS_DIR / "build_dsk.py"
            return ok(str(p)) if p.exists() else missing(str(p))
        if util_name == "extract_dsk":
            p = TOOLS_DIR / "extract_dsk.py"
            return ok(str(p)) if p.exists() else missing(str(p))
        if util_name == "build_cassette":
            p = TOOLS_DIR / "build_cassette.py"
            return ok(str(p)) if p.exists() else missing(str(p))
        if util_name == "extract_cassette":
            p = TOOLS_DIR / "extract_cassette.py"
            return ok(str(p)) if p.exists() else missing(str(p))
        # General pattern: ["python3", "<script>"] or ["python", "<script>"]
        # launcher.py replaces these with sys.executable at runtime.
        if util_name in ("python3", "python", "python3.exe", "python.exe") and len(args) >= 2:
            interp = sys.executable
            script = translate_path(_expand_home(args[1]))
            if os.path.exists(script):
                return ok(f"utility: {interp} {script}")
            return missing(f"utility: script not found: {script}")
        return warn(f"utility: unrecognised action {util_name!r}")

    if emu is None:
        return warn("no emulator specified")

    cmd = _EMU_CMDS.get(emu, emu)
    resolved = resolve_command(cmd)
    if resolved:
        return ok(f"{emu}: {resolved}")
    # Absolute path → file genuinely missing; bare command name → not in PATH (may just not be installed)
    if os.sep in cmd or "/" in cmd:
        return missing(f"{emu}: '{cmd}' not found")
    return warn(f"{emu}: '{cmd}' not found in PATH")

# ============================================================
# PLATFORM COMMAND CHECK  (item["platforms"][plat]["command"])
# ============================================================

def _expand_vscode(s):
    """Expand VS Code ${env:VAR} placeholders."""
    if not isinstance(s, str):
        return s
    s = s.replace("${env:HOME}", LIN_HOME)
    s = s.replace("${env:USERPROFILE}", WIN_HOME)
    return s

_POWERSHELL_EXES = {"powershell", "powershell.exe", "pwsh", "pwsh.exe"}

def _extract_powershell_file_arg(cmd_str):
    """
    Extract the path from a -File argument in a powershell command.
    Handles both quoted and unquoted paths, forward and back slashes.
    """
    m = re.search(r'-[Ff]ile\s+"([^"]+)"', cmd_str)
    if m:
        return m.group(1)
    m = re.search(r'-[Ff]ile\s+(\S+)', cmd_str)
    if m:
        return m.group(1)
    return None

def check_platform_command(cmd_raw, plat_name):
    """
    Check a platforms.linux/windows command string.
    Verifies the executable exists, and for PowerShell commands also
    verifies that the -File script argument exists.
    """
    if not cmd_raw:
        return missing(f"platforms.{plat_name}: no command")

    # Expand placeholders and translate paths
    expanded = _expand_vscode(_expand_home(cmd_raw))
    translated = translate_path(expanded)
    # Strip surrounding quotes (e.g. bat files stored as "\"path\"")
    cleaned = translated.strip().strip('"').strip("'")
    exe = cleaned.split()[0] if cleaned.split() else ""
    exe_name = os.path.basename(exe).lower()

    # Resolve the executable
    if os.path.isabs(exe):
        exe_ok = os.path.exists(exe)
        exe_label = exe
    else:
        resolved = resolve_command(exe)
        exe_ok = resolved is not None
        exe_label = resolved if resolved else f"'{exe}' not in PATH"

    if not exe_ok:
        if os.path.isabs(exe):
            return missing(f"platforms.{plat_name}: {exe_label}")
        return warn(f"platforms.{plat_name}: {exe_label}")

    # For PowerShell commands, also verify the -File script exists
    if exe_name in _POWERSHELL_EXES:
        script_raw = _extract_powershell_file_arg(translated)
        if script_raw:
            script_path = translate_path(_expand_home(script_raw))
            if os.path.exists(script_path):
                return ok(f"platforms.{plat_name}: {exe_label} -File {script_path}")
            return missing(f"platforms.{plat_name}: -File script not found: {script_path}")
        # powershell found but no -File arg — just report the exe
        return ok(f"platforms.{plat_name}: {exe_label}")

    return ok(f"platforms.{plat_name}: {exe_label}")

# ============================================================
# AUDIT A SINGLE ITEM
# ============================================================

def audit_item(item):
    """
    Audit one menu item.  Returns list of output lines.
    Handles:
      - top-level emulator + args + pyDW
      - item["linux"] / item["windows"] sub-blocks
      - item["platforms"]["linux/windows"]["command"]
      - platform-hidden items (still audited)
      - utility items (build_dsk / build_cassette / extract_cassette / build_mount)
    """
    lines = []
    emu       = item.get("emulator")
    args      = item.get("args", [])
    item_type = item.get("type")

    # ---- platforms block ----
    if "platforms" in item:
        cur_plat   = "windows" if IS_WINDOWS else "linux"
        other_plat = "linux"   if IS_WINDOWS else "windows"
        cur_cfg    = item["platforms"].get(cur_plat,   {})
        other_cfg  = item["platforms"].get(other_plat, {})

        # Always report the off-platform entry
        if other_cfg.get("hidden"):
            lines.append(info(f"platforms.{other_plat}: hidden on this platform"))
        elif "command" in other_cfg:
            lines.append(skipped(f"platforms.{other_plat}: not current platform"))

        # Handle the current platform entry
        if cur_cfg.get("hidden"):
            lines.append(info(f"platforms.{cur_plat}: hidden on this platform"))
            return lines  # hidden here — nothing else to check

        if "command" in cur_cfg:
            lines.append(check_platform_command(cur_cfg["command"], cur_plat))
            return lines  # command override — no emulator/args block

        # No hidden flag, no command override: platforms block only marks
        # the other platform as hidden.  Fall through to emulator/args checks.

    # ---- top-level utility type (e.g. build_mount) ----
    top_util = item.get("utility")
    if top_util == "build_mount":
        p = TOOLS_DIR / "build_dsk.py"
        lines.append(ok(f"utility: build_mount → {p}") if p.exists() else missing(f"utility: build_mount → {p} not found"))
        if "pyDW" in item:
            lines.extend(check_pydw(item["pyDW"]))
        return lines

    # ---- emulator / type check ----
    lines.append(check_emulator(emu, args, item_type=item_type))

    # ---- vcc_ini / ovcc_ini template path ----
    for ini_field in ("vcc_ini", "ovcc_ini"):
        ini_raw = item.get(ini_field)
        if ini_raw:
            ini_expanded = translate_path(_expand_home(ini_raw))
            if os.path.exists(ini_expanded):
                lines.append(ok(f"{ini_field}: {ini_expanded}"))
            else:
                lines.append(missing(f"{ini_field}: {ini_expanded}"))

    # ---- attract/attract_slideshow: check scan root directory ----
    if item_type in ("attract", "attract_slideshow"):
        attract_cfg = item.get("attract", {})
        root = attract_cfg.get("root") if isinstance(attract_cfg, dict) else None
        if root:
            expanded = translate_path(_expand_home(root))
            if os.path.isdir(expanded):
                lines.append(ok(f"attract.root: {expanded}"))
            else:
                lines.append(missing(f"attract.root: {expanded}"))
        else:
            lines.append(warn("attract.root: missing from attract block"))

    # ---- top-level args style checks ----
    lines.extend(check_args(args))

    # ---- top-level pyDW ----
    if "pyDW" in item:
        lines.extend(check_pydw(item["pyDW"]))

    # ---- platform sub-blocks  item["linux"] / item["windows"] ----
    has_linux = "linux" in item
    has_windows = "windows" in item

    for block_name in ("linux", "windows"):
        blk = item.get(block_name)
        if not blk:
            continue

        if (block_name == "linux"   and IS_WINDOWS) or \
           (block_name == "windows" and IS_LINUX):
            skip_label = skipped(f"{block_name} block: not current platform - skipping file checks")
            # Still do style checks (path formats, wrong-platform paths) but no existence checks
            style_lines = check_args(blk.get("args", []), block=block_name, existence=False)
            if "pyDW" in blk:
                # Style-only for off-platform — no existence checks
                pydw_norm = _normalize_pydw(blk["pyDW"])
                for p in list(pydw_norm.get("insert", [])) + list(pydw_norm.get("disks", {}).values()):
                    for tag_fn, msg in _check_string(p, block_name, "pyDW", existence=False):
                        style_lines.append(tag_fn(msg))
            if style_lines:
                lines.append(skip_label)
                lines.extend(style_lines)
            else:
                lines.append(skipped(f"{block_name} block: not current platform"))
        else:
            lines.append(info(f"{block_name} block:"))
            lines.extend(check_args(blk.get("args", []), block=block_name))
            if "pyDW" in blk:
                lines.extend(check_pydw(blk["pyDW"], block=block_name))

    # ---- block similarity check ----
    if has_linux and has_windows:
        result = compare_blocks(item["linux"], item["windows"])
        if result == "identical":
            lines.append(warn("linux/windows blocks are identical -> merge to top-level"))
        elif result == "same_after_norm":
            lines.append(warn("linux/windows blocks differ only in path prefixes -> use {SHARE1}/{HOME}/{WINHOME} to unify"))

    return lines

# ============================================================
# AUDIT LAUNCHER CONFIG FILES
# ============================================================

def audit_launcher():
    print(bold(cyan("\n=== Launcher Config Audit ===")))

    config_dir = BASE_DIR / "config"
    if not config_dir.exists():
        print(missing("config/ directory not found"))
        return

    for filepath in sorted(config_dir.glob("*.json")):
        print(f"\n{bold(filepath.name)}")

        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            print(missing(f"JSON parse error: {e}"))
            continue
        except Exception as e:
            print(missing(f"Cannot read file: {e}"))
            continue

        items = data.get("items", [])
        if not items:
            print(info("  no items"))
            continue

        for item in items:
            label = item.get("label", "<no label>")
            print(f"\n  {bold(label)}")
            for line in audit_item(item):
                print(f"  {line}")

# ============================================================
# AUDIT VS CODE TASKS
# ============================================================

def audit_vscode_tasks():
    print(bold(cyan("\n=== VS Code tasks.json Audit ===")))

    if IS_LINUX:
        tasks_path = Path(LIN_HOME) / ".config" / "Code" / "User" / "tasks.json"
    else:
        tasks_path = Path(APPDATA) / "Code" / "User" / "tasks.json"

    if not tasks_path.exists():
        print(skipped(f"tasks.json not found: {tasks_path}"))
        return

    raw = tasks_path.read_text(encoding="utf-8")
    # Strip JS-style comments
    cleaned = re.sub(r"//[^\n]*", "", raw)
    cleaned = re.sub(r"/\*.*?\*/", "", cleaned, flags=re.DOTALL)

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        print(missing(f"JSON parse error: {e}"))
        return

    for task in data.get("tasks", []):
        label = task.get("label", "<no label>")
        print(f"\n  {bold(label)}")

        for plat in ("linux", "windows"):
            cfg = task.get(plat)
            if not cfg:
                print(f"  {missing(f'{plat}: no entry')}")
                continue
            if (plat == "linux" and IS_WINDOWS) or (plat == "windows" and IS_LINUX):
                print(f"  {skipped(f'{plat}: not current platform')}")
                continue
            print(f"  {check_platform_command(cfg.get('command', ''), plat)}")

# ============================================================
# AUDIT VERSION SELECTOR
# ============================================================

def audit_version_selector():
    print(bold(cyan("\n=== Version Selector Audit ===")))

    # Derive the same paths that version_selector.py uses
    mame_junction_win  = Path(MAME_EXE_WINDOWS).parent   # e.g. WIN_HOME/mame
    xroar_junction_win = Path(XROAR_EXE_WINDOWS).parent  # e.g. WIN_HOME/xroar
    mame_search_win    = mame_junction_win.parent
    xroar_search_win   = xroar_junction_win.parent
    mame_canonical_lin  = Path(MAME_VERSIONS_DIR_LINUX) / "mame"
    xroar_canonical_lin = Path(XROAR_VERSIONS_DIR_LINUX) / "xroar"

    if IS_WINDOWS:
        # --- Search directories ---
        print(f"\n  {bold('MAME')}")
        print(f"    Search dir:  {mame_search_win}")
        if mame_search_win.is_dir():
            versions = sorted(mame_search_win.glob("mame-*"))
            if versions:
                for v in versions:
                    print(f"    {ok(str(v.name))}")
            else:
                print(f"    {warn('No mame-* directories found')}")
        else:
            print(f"    {missing(f'Search dir does not exist: {mame_search_win}')}")

        print(f"    Active junction: {mame_junction_win}")
        if mame_junction_win.exists():
            target = mame_junction_win.resolve()
            print(f"    {ok(f'Junction exists -> {target}')}")
        else:
            print(f"    {warn('Active junction/dir does not exist (no version selected yet)')}")

        print(f"\n  {bold('XRoar')}")
        print(f"    Search dir:  {xroar_search_win}")
        if xroar_search_win.is_dir():
            versions = sorted(xroar_search_win.glob("xroar-*"))
            if versions:
                for v in versions:
                    print(f"    {ok(str(v.name))}")
            else:
                print(f"    {warn('No xroar-* directories found')}")
        else:
            print(f"    {missing(f'Search dir does not exist: {xroar_search_win}')}")

        print(f"    Active junction: {xroar_junction_win}")
        if xroar_junction_win.exists():
            target = xroar_junction_win.resolve()
            print(f"    {ok(f'Junction exists -> {target}')}")
        else:
            print(f"    {warn('Active junction/dir does not exist (no version selected yet)')}")

    else:
        # --- Linux ---
        print(f"\n  {bold('MAME')}")
        print(f"    Search dir:  {MAME_VERSIONS_DIR_LINUX}")
        if Path(MAME_VERSIONS_DIR_LINUX).is_dir():
            versions = sorted(Path(MAME_VERSIONS_DIR_LINUX).glob("mame-*"))
            if versions:
                for v in versions:
                    print(f"    {ok(str(v.name))}")
            else:
                print(f"    {warn('No mame-* directories found')}")
        else:
            print(f"    {missing(f'Search dir does not exist: {MAME_VERSIONS_DIR_LINUX}')}")

        print(f"    Canonical symlink: {mame_canonical_lin}")
        if mame_canonical_lin.is_symlink():
            target = mame_canonical_lin.resolve()
            print(f"    {ok(f'Symlink -> {target}')}")
        elif mame_canonical_lin.exists():
            print(f"    {warn(f'Exists but is not a symlink: {mame_canonical_lin}')}")
        else:
            print(f"    {warn('Canonical symlink does not exist (no version selected yet)')}")

        print(f"\n  {bold('XRoar')}")
        print(f"    Search dir:  {XROAR_VERSIONS_DIR_LINUX}")
        if Path(XROAR_VERSIONS_DIR_LINUX).is_dir():
            versions = sorted(Path(XROAR_VERSIONS_DIR_LINUX).glob("xroar-*"))
            if versions:
                for v in versions:
                    print(f"    {ok(str(v.name))}")
            else:
                print(f"    {warn('No xroar-* files found')}")
        else:
            print(f"    {missing(f'Search dir does not exist: {XROAR_VERSIONS_DIR_LINUX}')}")

        print(f"    Canonical symlink: {xroar_canonical_lin}")
        if xroar_canonical_lin.is_symlink():
            target = xroar_canonical_lin.resolve()
            print(f"    {ok(f'Symlink -> {target}')}")
        elif xroar_canonical_lin.exists():
            print(f"    {warn(f'Exists but is not a symlink: {xroar_canonical_lin}')}")
        else:
            print(f"    {warn('Canonical symlink does not exist (no version selected yet)')}")


# ============================================================
# EMULATOR CONFIG AUDIT  (mame.ini, xroar.conf)
# ============================================================

def _win_c_mount():
    """Return the Linux mount point for the Windows C: drive, derived from WIN_HOME.
    e.g. WIN_HOME=/media/ron/OS/Users/Ron → /media/ron/OS"""
    parts = Path(WIN_HOME).parts
    try:
        users_idx = next(i for i, p in enumerate(parts) if p.lower() == "users")
        return str(Path(*parts[:users_idx]))
    except StopIteration:
        return None

def _resolve_config_path(path):
    """Return the real Path to read for a config file.
    Handles Windows-style symlink targets (C:/...) accessed from Linux by
    translating the target to a Linux path via the known C: mount point."""
    path = Path(path)
    if not path.is_symlink():
        return path
    target = os.readlink(str(path))
    m = re.match(r'^[A-Za-z]:[/\\](.+)$', target)
    if not m:
        return path  # normal symlink, let Python resolve it
    rest = m.group(1).replace("\\", "/")
    mount = _win_c_mount()
    if mount:
        return Path(mount) / rest
    return path

def _expand_ini_vars(s, win_context=False):
    """Expand $HOME, %USERPROFILE%, and ~ as used inside emulator config files.
    win_context=True treats ~ as the Windows home dir (for parsing Windows config files)."""
    tilde_home = WIN_HOME.replace("\\", "/") if win_context else LIN_HOME
    s = (s.replace("$HOME", LIN_HOME)
          .replace("%USERPROFILE%", WIN_HOME.replace("\\", "/")))
    if s.startswith("~/") or s == "~":
        s = tilde_home + s[1:]
    return s

def _parse_mame_ini(path):
    """Parse mame.ini → dict of lowercase key: value (strips comments/blanks)."""
    result = {}
    try:
        for line in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(None, 1)
            if len(parts) == 2:
                result[parts[0].lower()] = parts[1].strip()
    except Exception:
        pass
    return result

def _parse_xroar_conf(path):
    """Parse xroar.conf → dict of top-level (non-indented) key: value.
    Stanza blocks (machine/cart definitions) are indented and skipped."""
    result = {}
    try:
        for line in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
            if not line.strip() or line.strip().startswith("#"):
                continue
            if line[0] in (" ", "\t"):
                continue  # inside a stanza block
            parts = line.strip().split(None, 1)
            if len(parts) == 2:
                result[parts[0].lower()] = parts[1].strip()
    except Exception:
        pass
    return result

def _split_rompath(val, sep):
    """Split a rompath string on sep.
    For colon separator, Windows drive-letter colons (C:/, E:/) are not treated as separators."""
    if sep == ";":
        return [p.strip() for p in val.split(";") if p.strip()]
    # Colon separator: walk the string so single-letter drive colons are kept intact
    result, current = [], []
    for i, c in enumerate(val):
        if c == ":":
            is_drive = (len(current) == 1 and current[0].isalpha()
                        and i + 1 < len(val) and val[i + 1] in "/\\")
            if is_drive:
                current.append(c)
            else:
                part = "".join(current).strip()
                if part:
                    result.append(part)
                current = []
        else:
            current.append(c)
    part = "".join(current).strip()
    if part:
        result.append(part)
    return result

def _translate_any_win_path(p):
    """Extend translate_path to also handle C:/ by mapping via _win_c_mount().
    Only C: (the OS drive) is mapped this way; other unrecognised drives are left unchanged."""
    translated = translate_path(p)
    if translated != p:
        return translated  # translate_path already handled it (e.g. E:/media/share1/...)
    m = re.match(r'^([Cc]):[/\\](.*)$', p)  # C: drive only
    if m:
        mount = _win_c_mount()
        if mount:
            return os.path.join(mount, m.group(2).replace("\\", "/"))
    return p  # unchanged — caller treats as INFO

def _print_rompath_entries(rompath_val, sep, win_context=False):
    """Print OK/MISSING/INFO for each entry in a rompath string."""
    for part in _split_rompath(rompath_val, sep):
        expanded = _expand_ini_vars(part, win_context=win_context)
        translated = _translate_any_win_path(expanded)
        if os.path.isabs(translated):
            if os.path.isdir(translated):
                print(f"        {ok(translated)}")
            else:
                print(f"        {missing(translated)}")
        elif re.match(r"^[A-Za-z]:[/\\]", expanded) and not IS_WINDOWS:
            print(f"        {info(f'Windows path (not checkable from Linux): {part!r}')}")
        else:
            print(f"        {info(f'relative path: {part!r} (resolved by emulator at runtime)')}")

def _audit_one_mame_config(cfg_path, label):
    print(f"\n    {bold(label)}")
    real = _resolve_config_path(cfg_path)
    if not real.exists():
        print(f"      {warn(f'not found: {cfg_path}')}")
        return
    note = f" → {real}" if real != Path(cfg_path) else ""
    print(f"      {ok(f'config: {cfg_path}{note}')}")
    win_context = WIN_HOME and str(cfg_path).startswith(WIN_HOME)
    ini = _parse_mame_ini(real)
    rompath_raw = ini.get("rompath", "")
    if rompath_raw:
        print(f"      rompath = {rompath_raw}")
        _print_rompath_entries(rompath_raw, ";", win_context=win_context)
    else:
        print(f"      {info('rompath not set in config (MAME uses built-in defaults)')}")

def _audit_one_xroar_config(cfg_path, label):
    print(f"\n    {bold(label)}")
    real = _resolve_config_path(cfg_path)
    if not real.exists():
        print(f"      {warn(f'not found: {cfg_path}')}")
        return
    note = f" → {real}" if real != Path(cfg_path) else ""
    print(f"      {ok(f'config: {cfg_path}{note}')}")
    win_context = WIN_HOME and str(cfg_path).startswith(WIN_HOME)
    conf = _parse_xroar_conf(real)
    rompath_raw = conf.get("rompath", "")
    if rompath_raw:
        sep = ":"  # XRoar always uses colon-separated rompath (drive-letter colons handled by _split_rompath)
        print(f"      rompath = {rompath_raw}")
        _print_rompath_entries(rompath_raw, sep, win_context=win_context)
    else:
        print(f"      {info('rompath not set — XRoar searches ~/.xroar/ by default')}")

def audit_emulator_configs():
    print(bold(cyan("\n=== Emulator Config Audit ===")))

    # --- MAME ---
    print(f"\n  {bold('MAME')}  (mame.ini)")
    lin_mame = Path(LIN_HOME) / ".mame" / "mame.ini"
    win_mame = Path(WIN_HOME) / "mame" / "mame.ini"
    if IS_LINUX:
        _audit_one_mame_config(lin_mame, "Linux")
        if Path(WIN_HOME).is_dir():
            _audit_one_mame_config(win_mame, "Windows (via mounted partition)")
    else:
        _audit_one_mame_config(win_mame, "Windows")

    # --- XRoar ---
    print(f"\n  {bold('XRoar')}  (xroar.conf)")
    lin_xroar = Path(LIN_HOME) / ".xroar" / "xroar.conf"
    win_xroar = Path(WIN_HOME) / "AppData" / "Local" / "XRoar" / "xroar.conf"
    if IS_LINUX:
        _audit_one_xroar_config(lin_xroar, "Linux")
        if Path(WIN_HOME).is_dir():
            _audit_one_xroar_config(win_xroar, "Windows (via mounted partition)")
    else:
        _audit_one_xroar_config(win_xroar, "Windows")

    # --- trs80gp ---
    print(f"\n  {bold('trs80gp')}")
    print(f"    {info('no config file — configured entirely via command-line options')}")


# ============================================================
# AUDIT GIT INFO
# ============================================================

def audit_git_info():
    import subprocess
    print(bold(cyan("\n=== git_info.txt Audit ===")))

    git_info_file = BASE_DIR / "git_info.txt"

    if not git_info_file.exists():
        print(f"  {missing('git_info.txt not found — launcher will not display a version')}")
        return

    content = git_info_file.read_text(encoding="utf-8").strip()
    if not re.match(r'^[0-9a-f]{7,}\s+\d{4}-\d{2}-\d{2}$', content):
        print(f"  {warn(f'git_info.txt has unexpected format: {content!r}')}")
        return

    print(f"  {ok(f'git_info.txt: {content}')}")

    # On Linux, if the CoCo-Pi-Launcher repo is present, check for staleness
    if not IS_LINUX:
        return

    launcher_repo = Path(LIN_HOME) / "source-CoCo-Pi" / "CoCo-Pi-Launcher"
    if not (launcher_repo / ".git").exists():
        print(f"  {info('CoCo-Pi-Launcher repo not present — cannot check for staleness')}")
        return

    try:
        result = subprocess.run(
            ["git", "-C", str(launcher_repo), "log", "-1", "--format=%h %ad", "--date=short"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0 or not result.stdout.strip():
            print(f"  {warn('Could not read repo HEAD to check staleness')}")
            return
        repo_head = result.stdout.strip()
        if content == repo_head:
            print(f"  {ok(f'up to date with repo HEAD ({repo_head})')}")
        else:
            print(f"  {warn(f'stale — repo HEAD is {repo_head!r}, git_info.txt has {content!r}')}")
            print(f"  {info('To fix, run one of:')}")
            print(f"  {info('  cd ~/source-CoCo-Pi/CoCo-Pi-Launcher && bash dev/CoCo-Pi-Launcher-repo-update.sh')}")
            print(f"  {info('  cd ~/source-CoCo-Pi/CoCo-Pi-Installer && bash dev/CoCo-Pi-Installer-repo-update.sh')}")
    except Exception as e:
        print(f"  {warn(f'Could not check repo HEAD: {e}')}")


# ============================================================
# SUMMARY
# ============================================================

def print_summary():
    print(bold(cyan("\n=== Summary ===")))
    total = sum(_counts.values())
    n_ok      = _counts["ok"]
    n_missing = _counts["missing"]
    n_warn    = _counts["warn"]
    n_skipped = _counts["skipped"]
    n_info    = _counts["info"]
    print(f"  {green(  f'OK:      {n_ok}'     )}")
    print(f"  {red(    f'MISSING: {n_missing}')}")
    print(f"  {yellow( f'WARN:    {n_warn}'   )}")
    print(f"  {yellow( f'SKIPPED: {n_skipped}')}")
    print(f"  {cyan(   f'INFO:    {n_info}'   )}")
    print(f"  Total:   {total}")
    print()

# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    audit_launcher()
    audit_vscode_tasks()
    audit_version_selector()
    audit_emulator_configs()
    audit_git_info()
    print_summary()

#!/usr/bin/env python3
import os
import sys
import json
import curses
import subprocess
import shlex
import socket
import platform
from pathlib import Path

# ---------------- Platform detection ----------------

IS_WINDOWS = (os.name == "nt")
IS_LINUX = (os.name == "posix" and platform.system() == "Linux")

# ---------------- User home directories ----------------

WIN_HOME = os.environ.get("USERPROFILE", "")
LIN_HOME = os.environ.get("HOME", "")

# ---------------- Base paths ----------------

BASE_DIR = Path(__file__).resolve().parent
CONFIG_DIR = BASE_DIR / "config"

if IS_WINDOWS:
    XROAR_EXE = os.path.join(WIN_HOME, "xroar", "xroar.exe")
    MAME_EXE = os.path.join(WIN_HOME, "mame", "mame.exe")
    TRS80GP_EXE = os.path.join(WIN_HOME, "trs80gp", "trs80gp.exe")

    PYDWCLI = os.path.join(WIN_HOME, "pyDriveWire", "pyDwCli.bat")
    PYDW_URL = "http://localhost:6800"
    PYDW_PIDFILE = os.path.join(WIN_HOME, "pyDriveWire-logs", "pyDW.pid")

    ROMPATH = os.path.join(WIN_HOME, "roms")

    XROAR_OPT = os.path.join(WIN_HOME, "xroar", ".optional_xroar_parameters.txt")
    MAME_OPT = os.path.join(WIN_HOME, "mame", ".optional_mame_parameters.txt")
    TRS80GP_OPT = os.path.join(WIN_HOME, "trs80gp", ".optional_trs80gp_parameters.txt")

    FUJINET_EXE = os.path.join(
        WIN_HOME, "msys64", "home", "Ron",
        "source", "fujinet-pc-CoCo", "build", "dist", "fujinet.exe"
    )

else:
    XROAR_EXE = "xroar"
    MAME_EXE = "mame"
    TRS80GP_EXE = "trs80gp"

    PYDWCLI = os.path.join(LIN_HOME, "pyDriveWire", "pyDwCli")
    PYDW_URL = "http://localhost:6800"
    PYDW_PIDFILE = "/tmp/pyDriveWire.pid"

    ROMPATH = "/media/share1/roms"

    XROAR_OPT = os.path.join(LIN_HOME, ".xroar", ".optional_xroar_parameters.txt")
    MAME_OPT = os.path.join(LIN_HOME, ".mame", ".optional_mame_parameters.txt")
    TRS80GP_OPT = os.path.join(LIN_HOME, ".trs80gp", ".optional_trs80gp_parameters.txt")

    FUJINET_EXE = os.path.join(
        LIN_HOME, "source", "fujinet-pc-CoCo", "build", "dist", "fujinet"
    )

TOOLS_DIR = BASE_DIR / "tools"

# ---------------- Optional parameter files ----------------

def load_optional_params(path):
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            line = f.readline().strip()
            return line.split()
    except Exception:
        return []

XROAR_PARAMS = load_optional_params(XROAR_OPT)
MAME_PARAMS = load_optional_params(MAME_OPT)
TRS80GP_PARAMS = load_optional_params(TRS80GP_OPT)

# ---------------- Placeholder expansion ----------------

def expand_home_placeholders(p):
    if not isinstance(p, str):
        return p
    return (
        p.replace("{HOME}", LIN_HOME)
         .replace("{WINHOME}", WIN_HOME.replace("\\", "/"))
    )

def expand_placeholders_in_item(item):
    # Expand args (no translation, just {HOME}/{WINHOME})
    if "args" in item:
        item["args"] = [expand_home_placeholders(a) for a in item["args"]]

    # Expand platform-specific commands (no translation, just {HOME}/{WINHOME})
    if "platforms" in item:
        for plat, cfg in item["platforms"].items():
            if "command" in cfg:
                cfg["command"] = expand_home_placeholders(cfg["command"])

    # Expand pyDW
    if "pyDW" in item:
        p = item["pyDW"]
        if "insert" in p:
            if isinstance(p["insert"], str):
                p["insert"] = [expand_home_placeholders(p["insert"])]
            else:
                p["insert"] = [expand_home_placeholders(x) for x in p["insert"]]
        if "disks" in p:
            p["disks"] = {k: expand_home_placeholders(v) for k, v in p["disks"].items()}

# ---------------- Path translation (only for known path fields) ----------------

def translate_path_to_linux(p: str) -> str:
    if not isinstance(p, str):
        return p
    p = expand_home_placeholders(p)
    s = p.replace("\\", "/")

    # Only treat as Windows-style if it has a drive or backslashes
    if "\\" in p or ":" in p:
        win_home_norm = WIN_HOME.replace("\\", "/").lower()

        if s.lower().startswith("e:/media/share1"):
            return "/media/share1" + s[15:]

        if s.lower().startswith(win_home_norm):
            return LIN_HOME + s[len(win_home_norm):]

    return s

def translate_path_to_windows(p: str) -> str:
    if not isinstance(p, str):
        return p
    p = expand_home_placeholders(p)
    s = p.replace("\\", "/")

    lin_home_norm = LIN_HOME

    # Only treat as Linux-style if it starts with a slash
    if s.startswith("/"):
        if s.lower().startswith("/media/share1"):
            return r"E:\media\share1" + s[13:].replace("/", "\\")

        if s.lower().startswith(lin_home_norm.lower()):
            return WIN_HOME + s[len(lin_home_norm):].replace("/", "\\")

    return s

def translate_path(p: str) -> str:
    p = expand_home_placeholders(p)
    return translate_path_to_windows(p) if IS_WINDOWS else translate_path_to_linux(p)

def translate_args(args):
    # Args are emulator options / literals; do NOT translate them.
    return list(args)

def translate_pydw(pydw):
    if not isinstance(pydw, dict):
        return pydw
    out = dict(pydw)
    if "insert" in out:
        ins = out["insert"]
        if isinstance(ins, str):
            out["insert"] = [translate_path(ins)]
        else:
            out["insert"] = [translate_path(x) for x in ins]
    if "disks" in out and isinstance(out["disks"], dict):
        out["disks"] = {str(k): translate_path(v) for k, v in out["disks"].items()}
    return out

# ---------------- Load menu ----------------

def load_menu():
    categories = []
    if not CONFIG_DIR.exists():
        return categories

    for filename in sorted(os.listdir(CONFIG_DIR)):
        if not filename.lower().endswith(".json"):
            continue
        path = CONFIG_DIR / filename
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            continue

        title = data.get("title", filename)
        items = data.get("items", [])
        final_items = []

        for it in items:
            # Skip hidden items for this platform
            if "platforms" in it:
                plat = "windows" if IS_WINDOWS else "linux"
                plat_cfg = it["platforms"].get(plat, {})
                if plat_cfg.get("hidden", False):
                    continue

            expand_placeholders_in_item(it)
            it["args"] = translate_args(it.get("args", []))

            if "pyDW" in it:
                it["pyDW"] = translate_pydw(it["pyDW"])

            final_items.append(it)

        categories.append({"title": title, "items": final_items})

    return categories

# ---------------- pyDriveWire helpers ----------------

def run_pydw(args):
    cmd = [PYDWCLI, PYDW_URL] + args
    try:
        subprocess.call(cmd)
    except FileNotFoundError:
        pass

def pydw_set_server_mode(server, mode):
    if server is None or mode is None:
        return
    run_pydw(["dw", "server", str(server), str(mode)])

def pydw_mount_disk_slot(slot, path):
    if path:
        run_pydw(["dw", "disk", "insert", str(slot), path])

def pydw_eject_slot(slot):
    run_pydw(["dw", "disk", "eject", str(slot)])

def pydw_eject_slots(slots):
    for s in slots:
        pydw_eject_slot(s)

def validate_pydw_paths(pydw):
    missing = []
    planned = []
    if not pydw:
        return missing, planned
    if "insert" in pydw:
        slot = int(pydw.get("slot", 0))
        for path in pydw["insert"]:
            planned.append((slot, path))
            if not os.path.exists(path):
                missing.append(path)
    if "disks" in pydw:
        for s, path in pydw["disks"].items():
            slot = int(s)
            planned.append((slot, path))
            if not os.path.exists(path):
                missing.append(path)
    return missing, planned

def pydw_pre_launch(pydw):
    if not pydw:
        return
    if pydw.get("server") is not None and pydw.get("mode") is not None:
        pydw_set_server_mode(pydw["server"], pydw["mode"])
    missing, _ = validate_pydw_paths(pydw)
    if missing:
        print("pyDriveWire: missing DSK files:")
        for m in missing:
            print(" ", m)
        return
    if "insert" in pydw:
        slot = int(pydw.get("slot", 0))
        pydw_eject_slot(slot)
        for path in pydw["insert"]:
            pydw_mount_disk_slot(slot, path)
        return
    if "disks" in pydw:
        slots = sorted(int(s) for s in pydw["disks"].keys())
        pydw_eject_slots(slots)
        for s, path in pydw["disks"].items():
            pydw_mount_disk_slot(int(s), path)

def pydw_post_launch(pydw):
    if not pydw:
        return
    if pydw.get("eject"):
        if "insert" in pydw:
            slot = int(pydw.get("slot", 0))
            pydw_eject_slot(slot)
        elif "disks" in pydw:
            slots = sorted(int(s) for s in pydw["disks"].keys())
            pydw_eject_slots(slots)
    if pydw.get("server") is not None and pydw.get("restoreMode") is not None:
        pydw_set_server_mode(pydw["server"], pydw["restoreMode"])

# ---------------- pyDriveWire runtime status ----------------

def check_pid_running(pid):
    if IS_WINDOWS:
        try:
            result = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}"],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True
            )
            return str(pid) in result.stdout
        except Exception:
            return False
    else:
        try:
            result = subprocess.run(
                ["ps", "-p", str(pid)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return result.returncode == 0
        except Exception:
            return False

def check_http_alive():
    try:
        with socket.create_connection(("localhost", 6800), timeout=0.2):
            return True
    except OSError:
        return False

def check_pydw_api():
    try:
        result = subprocess.run(
            [PYDWCLI, PYDW_URL, "dw", "disk", "list"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=0.3
        )
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        return False
    except Exception:
        return False

def get_pydw_status_lines():
    lines = []
    if not os.path.exists(PYDW_PIDFILE):
        lines.append("pyDriveWire: not running")
    else:
        try:
            with open(PYDW_PIDFILE, "r", encoding="utf-8") as f:
                pid_str = f.read().strip()
        except Exception:
            pid_str = ""

        if not pid_str.isdigit():
            lines.append("pyDriveWire: PID file invalid")
        else:
            pid = int(pid_str)
            if check_pid_running(pid):
                lines.append(f"pyDriveWire: running (PID {pid})")
            else:
                lines.append("pyDriveWire: stale PID (not running)")

    if check_http_alive():
        lines.append("pyDW HTTP: OK")
    else:
        lines.append("pyDW HTTP: unreachable")

    if check_pydw_api():
        lines.append("pyDW API: OK")
    else:
        lines.append("pyDW API: offline")

    lines.append("------------------------------")
    return lines

# ---------------- FujiNet-PC runtime status ----------------

def check_fujinet_running():
    if IS_WINDOWS:
        try:
            result = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq fujinet.exe"],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True
            )
            return "fujinet.exe" in result.stdout.lower()
        except Exception:
            return False
    else:
        try:
            result = subprocess.run(
                ["pgrep", "-f", "fujinet"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            return result.returncode == 0
        except Exception:
            return False

def get_fujinet_status_lines():
    lines = []
    if check_fujinet_running():
        lines.append("FujiNet-PC: running")
    else:
        lines.append("FujiNet-PC: not running")
    return lines

# ---------------- TNFS runtime status ----------------

def check_tnfs_running():
    try:
        result = subprocess.run(
            ["pgrep", "-f", "tnfsd"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return result.returncode == 0
    except Exception:
        return False

def get_tnfs_status_lines():
    lines = []

    if IS_WINDOWS:
        # Windows: standalone tnfsd.exe installed by installer
        try:
            result = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq tnfsd.exe"],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True
            )
            if "tnfsd.exe" in result.stdout.lower():
                lines.append("TNFS Server: running")
            else:
                lines.append("TNFS Server: not running")
        except Exception:
            lines.append("TNFS Server: status unknown")
        return lines

    # Linux: tnfsd is a separate daemon
    try:
        result = subprocess.run(
            ["pgrep", "-f", "tnfsd"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        if result.returncode == 0:
            pid = subprocess.check_output(["pgrep", "-f", "tnfsd"]).decode().strip().split("\n")[0]
            lines.append(f"TNFS Server: running (PID {pid})")
        else:
            lines.append("TNFS Server: not running")
    except Exception:
        lines.append("TNFS Server: status unknown")

    return lines

# ---------------- Command building ----------------

def build_command(item):
    expand_placeholders_in_item(item)

    # Platform-specific command override (already correct per platform)
    if "platforms" in item:
        plat = "windows" if IS_WINDOWS else "linux"
        plat_cfg = item["platforms"].get(plat)
        if plat_cfg and "command" in plat_cfg:
            cmd = expand_home_placeholders(plat_cfg["command"])
            return shlex.split(cmd)

    emu = item.get("emulator")
    machine = item.get("machine")
    args = item.get("args", [])

    if emu == "xroar":
        return [XROAR_EXE, "-default-machine", machine] + args + XROAR_PARAMS

    elif emu == "mame":
        return [MAME_EXE, machine, "-rompath", ROMPATH] + args + MAME_PARAMS

    elif emu == "trs80gp":
        return [TRS80GP_EXE, f"-{machine}"] + TRS80GP_PARAMS + args

    elif emu == "browser":
        return args[:]

    elif emu == "utility":
        if args and args[0] == "build_dsk":
            return [sys.executable, str(TOOLS_DIR / "build_dsk.py")]
        if args and args[0] == "build_cassette":
            return [sys.executable, str(TOOLS_DIR / "build_cassette.py")]
        return args[:]

    return ["echo", "unknown emulator type"]

def command_to_string(cmd):
    return " ".join(shlex.quote(str(c)) for c in cmd)

# ---------------- Safe {DSK} substitution ----------------

def substitute_dsk_in_pydw(pydw, dsk_path):
    if not pydw:
        return pydw

    out = json.loads(json.dumps(pydw))

    if "insert" in out:
        out["insert"] = [
            str(path).replace("{DSK}", str(dsk_path))
            for path in out["insert"]
        ]

    if "disks" in out:
        out["disks"] = {
            slot: str(path).replace("{DSK}", str(dsk_path))
            for slot, path in out["disks"].items()
        }

    return out

# ---------------- pyDW preview/status helpers ----------------

def build_pydw_preview_lines(pydw):
    lines = []

    if not pydw:
        lines.append("pyDW: none")
        return lines

    missing, planned = validate_pydw_paths(pydw)

    if pydw.get("server") is not None and pydw.get("mode") is not None:
        lines.append(f"pyDW: server {pydw['server']} mode {pydw['mode']}")
    else:
        lines.append("pyDW: server unchanged")

    if planned:
        for slot, path in planned:
            tag = "MISSING" if path in missing else "OK"
            lines.append(f"  slot {slot}: {path} [{tag}]")
    else:
        lines.append("  no disks configured")

    if pydw.get("eject"):
        lines.append("  eject after exit: yes")
    else:
        lines.append("  eject after exit: no")

    return lines

# ---------------- UI drawing ----------------

def draw_ui(stdscr, categories, cat_index, item_index, preview_cmd, pydw_lines, status_lines):
    stdscr.clear()
    max_y, max_x = stdscr.getmaxyx()

    curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
    curses.init_pair(2, curses.COLOR_BLACK, curses.COLOR_GREEN)

    stdscr.border()

    stdscr.attron(curses.color_pair(1))
    stdscr.addstr(0, 2, " CoCo Launcher ")
    stdscr.attroff(curses.color_pair(1))

    y = 1
    for line in status_lines:
        if y >= max_y - 1:
            break
        stdscr.addstr(y, 2, line[:max_x - 4])
        y += 1

    cwd_line = f"Current folder: {Path.cwd()}"
    if y < max_y - 1:
        stdscr.addstr(y, 2, cwd_line[:max_x - 4])
        y += 1

    if y < max_y - 1:
        stdscr.addstr(y, 2, "")
        y += 1

    status_block_height = y
    left_w = max_x // 3

    preview_h = min(2 + len(pydw_lines), max_y // 2)
    list_h = max_y - preview_h - 3

    if status_block_height < max_y - 1:
        stdscr.attron(curses.color_pair(1))
        stdscr.addstr(status_block_height, 2, "Categories")
        stdscr.addstr(status_block_height, left_w + 3, "Items")
        stdscr.attroff(curses.color_pair(1))

    start_list_y = status_block_height + 1
    for i, cat in enumerate(categories):
        row = start_list_y + i
        if row >= list_h:
            break
        label = cat["title"]
        if i == cat_index:
            stdscr.attron(curses.color_pair(2))
            stdscr.addstr(row, 2, label[:left_w - 3])
            stdscr.attroff(curses.color_pair(2))
        else:
            stdscr.addstr(row, 2, label[:left_w - 3])

    items = categories[cat_index]["items"]
    for i, item in enumerate(items):
        row = start_list_y + i
        if row >= list_h:
            break
        label = item.get("label", "")
        if i == item_index:
            stdscr.attron(curses.color_pair(2))
            stdscr.addstr(row, left_w + 3, label[:max_x - left_w - 4])
            stdscr.attroff(curses.color_pair(2))
        else:
            stdscr.addstr(row, left_w + 3, label[:max_x - left_w - 4])

    start_y = list_h + 1
    if start_y < max_y - 2:
        stdscr.attron(curses.color_pair(1))
        stdscr.addstr(start_y, 2, "Command Preview:")
        stdscr.attroff(curses.color_pair(1))

        if start_y + 1 < max_y - 1:
            safe_cmd = preview_cmd.replace("\n", " ⏎ ")
            stdscr.addstr(start_y + 1, 2, safe_cmd[:max_x - 4])

        if start_y + 2 < max_y - 1:
            stdscr.attron(curses.color_pair(1))
            stdscr.addstr(start_y + 2, 2, "pyDriveWire:")
            stdscr.attroff(curses.color_pair(1))

            line_y = start_y + 3
            for line in pydw_lines:
                if line_y >= max_y - 1:
                    break
                stdscr.addstr(line_y, 2, line[:max_x - 4])
                line_y += 1

    stdscr.refresh()

# ---------------- Main loop ----------------

def main(stdscr):
    curses.curs_set(0)
    curses.start_color()
    curses.mousemask(curses.ALL_MOUSE_EVENTS | curses.REPORT_MOUSE_POSITION)
    curses.mouseinterval(200)
    stdscr.keypad(True)

    categories = load_menu()
    if not categories:
        stdscr.addstr(0, 0, "No JSON menus found.")
        stdscr.getch()
        return

    cat_index = 0
    item_index = 0

    items = categories[0]["items"]
    current_item = items[0] if items else {}

    preview_cmd = command_to_string(build_command(current_item)) if items else ""
    pydw_lines = build_pydw_preview_lines(current_item.get("pyDW"))

    # --- INITIAL STATUS (only once) ---
    status_lines = (
        get_pydw_status_lines()
        + get_fujinet_status_lines()
        + get_tnfs_status_lines()
    )

    # Helper to launch an item
    def launch_item(item):
        nonlocal status_lines, stdscr
        cmd_list = build_command(item)
        cmd_str = command_to_string(cmd_list)
        pydw = item.get("pyDW")

        is_windows_style_dsk = (item.get("utility") == "build_dsk")
        is_linux_style_dsk = (
            item.get("emulator") == "utility"
            and item.get("args") == ["build_dsk"]
        )

        if is_windows_style_dsk or is_linux_style_dsk:
            dsk_builder = [sys.executable, str(TOOLS_DIR / "build_dsk.py")]
            subprocess.call(dsk_builder)

            project = Path.cwd()
            dsk_path = project / f"{project.name}.dsk"

            cmd_list = [str(c).replace("{DSK}", str(dsk_path)) for c in cmd_list]

            if pydw:
                pydw = substitute_dsk_in_pydw(pydw, dsk_path)
                pydw = translate_pydw(pydw)
                item["pyDW"] = pydw

            cmd_str = command_to_string(cmd_list)

        curses.endwin()
        print("\nLaunching:")
        print(cmd_str)
        print()

        pydw_pre_launch(pydw)
        try:
            subprocess.call(cmd_list)
        finally:
            pydw_post_launch(pydw)

        # --- REFRESH STATUS ONLY AFTER ACTION ---
        status_lines = (
            get_pydw_status_lines()
            + get_fujinet_status_lines()
            + get_tnfs_status_lines()
        )

        input("\nPress Enter to return to launcher...")
        stdscr = curses.initscr()
        curses.curs_set(0)
        curses.start_color()
        stdscr.keypad(True)

    # ---------------- MAIN LOOP ----------------
    while True:

        # --- NO STATUS UPDATES HERE ---
        # Navigation is now instant.

        draw_ui(
            stdscr, categories, cat_index, item_index,
            preview_cmd, pydw_lines, status_lines
        )

        key = stdscr.getch()

        if key in (ord('q'), ord('Q'), 27, curses.KEY_F10, 24):
            break

        if key == curses.KEY_UP:
            item_index = max(0, item_index - 1)

        elif key == curses.KEY_DOWN:
            items = categories[cat_index]["items"]
            if items:
                item_index = min(len(items) - 1, item_index + 1)

        elif key == curses.KEY_LEFT:
            cat_index = max(0, cat_index - 1)
            item_index = 0

        elif key == curses.KEY_RIGHT:
            cat_index = min(len(categories) - 1, cat_index + 1)
            item_index = 0

        elif key in (curses.KEY_ENTER, 10, 13):
            items = categories[cat_index]["items"]
            if items:
                launch_item(items[item_index])

        elif key == curses.KEY_MOUSE:
            try:
                _, mx, my, _, bstate = curses.getmouse()
            except curses.error:
                continue

            max_y, max_x = stdscr.getmaxyx()
            left_w = max_x // 3

            # Recompute status_block_height exactly like draw_ui does
            y = 1
            for _ in status_lines:
                if y >= max_y - 1:
                    break
                y += 1
            if y < max_y - 1:
                y += 1
            if y < max_y - 1:
                y += 1

            status_block_height = y
            preview_h = min(2 + len(pydw_lines), max_y // 2)
            list_h = max_y - preview_h - 3
            start_list_y = status_block_height + 1

            # Category click
            if start_list_y <= my < list_h and 2 <= mx <= left_w - 3:
                i = my - start_list_y
                if 0 <= i < len(categories):
                    cat_index = i
                    item_index = 0
                    items = categories[cat_index]["items"]
                    if items:
                        current_item = items[item_index]
                        preview_cmd = command_to_string(build_command(current_item))
                        pydw_lines = build_pydw_preview_lines(current_item.get("pyDW"))
                    else:
                        preview_cmd = ""
                        pydw_lines = ["pyDW: none"]

            # Item click
            elif start_list_y <= my < list_h and mx >= left_w + 3:
                i = my - start_list_y
                items = categories[cat_index]["items"]
                if items and 0 <= i < len(items):
                    item_index = i
                    current_item = items[item_index]
                    preview_cmd = command_to_string(build_command(current_item))
                    pydw_lines = build_pydw_preview_lines(current_item.get("pyDW"))

                    # Double-click launches
                    if bstate & getattr(curses, "BUTTON1_DOUBLE_CLICKED", 0):
                        launch_item(current_item)

        # Update preview (not status)
        items = categories[cat_index]["items"]
        if items:
            current_item = items[item_index]
            preview_cmd = command_to_string(build_command(current_item))
            pydw_lines = build_pydw_preview_lines(current_item.get("pyDW"))
        else:
            preview_cmd = ""
            pydw_lines = ["pyDW: none"]

if __name__ == "__main__":
    print(f"\nCurrent project folder: {Path.cwd()}\n")
    curses.wrapper(main)

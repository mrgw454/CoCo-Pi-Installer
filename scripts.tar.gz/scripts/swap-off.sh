#!/bin/bash

sudo /etc/init.d/dphys-swapfile stop
sudo cp /etc/dphys-swapfile.original.20230601 /etc/dphys-swapfile

sudo /etc/init.d/dphys-swapfile start
sudo /etc/init.d/dphys-swapfile status

swapon -s


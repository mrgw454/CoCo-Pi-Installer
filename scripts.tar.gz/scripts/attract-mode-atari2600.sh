#!/bin/bash

# loop over Atari 2600 console games and run them for 120 seconds each

ATARI2600PARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_atari2600.txt`
export ATARI2600PARMS=$ATARI2600PARMSFILE

shopt -s extglob

for f in `ls $1/*.*`

do

     clear

     echo file = "$f"
     echo

     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     echo
     sleep 2

     if [[ $f == *.bin ]]; then

                echo BIN
		mame a2600 -cart "$f" -seconds_to_run 120 $ATARI2600PARMS

     fi


     if [[ $f == *.car ]]; then

                echo CAR
		mame a2600 -cart "$f" -seconds_to_run 120 $ATARI2600PARMS

     fi


     if [[ $f == *.rom ]]; then

                echo ROM
		mame a2600 -cart "$f" -seconds_to_run 120 $ATARI2600PARMS

     fi


# capture MAME ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi


done

sleep 2

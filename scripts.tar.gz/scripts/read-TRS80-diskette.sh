# replace filename as needed
./gw read --ecyl 39 --single-sided /media/share1/FredHD_BOOT_LS-DOS_6.3.1.scp

<#
.SYNOPSIS
    Pulls the latest CoCo-Pi Launcher from GitHub and deploys it to Windows.
.DESCRIPTION
    Works on: native Windows 11, QEMU/KVM Windows 11 guest, g814fp laptop.
    Auto-detects the repo whether run from inside the repo or from %USERPROFILE%\scripts\.
    Run with -DryRun to preview changes without writing any files.
.EXAMPLE
    .\sync-launcher-from-git.ps1
    .\sync-launcher-from-git.ps1 -DryRun
#>
param(
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"

# Auto-detect repo root — works when run from inside the repo (bootstrap) or
# from %USERPROFILE%\scripts\ after being deployed there.
$_candidate = (Resolve-Path "$PSScriptRoot\..\..\").Path
if (Test-Path "$_candidate\unified") {
    $RepoRoot = $_candidate
} elseif (Test-Path "$env:USERPROFILE\source\CoCo-Pi-Launcher\unified") {
    $RepoRoot = "$env:USERPROFILE\source\CoCo-Pi-Launcher"
} elseif (Test-Path "$env:USERPROFILE\source-CoCo-Pi\CoCo-Pi-Launcher\unified") {
    $RepoRoot = "$env:USERPROFILE\source-CoCo-Pi\CoCo-Pi-Launcher"
} else {
    throw "Cannot find repo. Clone it to %USERPROFILE%\source\CoCo-Pi-Launcher or set `$RepoRoot manually."
}
$UserHome = $env:USERPROFILE
$Scripts  = "$UserHome\scripts"
$Launcher = "$Scripts\launcher"
$AppData  = "$UserHome\AppData\Roaming\Code\User"

$modeTag = if ($DryRun) { " [DRY-RUN]" } else { "" }
Write-Host "=== CoCo-Pi Launcher Sync from Git$modeTag ===" -ForegroundColor Cyan
Write-Host "Repo:     $RepoRoot"
Write-Host "Launcher: $Launcher"

# -------------------------------------------------------
# Git pull
# -------------------------------------------------------
Write-Host "`n--- git pull ---" -ForegroundColor Cyan
Push-Location $RepoRoot
git pull
if ($LASTEXITCODE -ne 0) { throw "git pull failed (exit $LASTEXITCODE)" }
$gitInfo = git log -1 --format="%h %ad" --date=short
Pop-Location

# Write git_info.txt to launcher dir so launcher.py can display commit/date
if (!$DryRun) {
    $null = New-Item -ItemType Directory -Force -Path $Launcher
    $gitInfo | Set-Content -Encoding UTF8 "$Launcher\git_info.txt"
    Write-Host "  [git_info] $gitInfo"
}

# -------------------------------------------------------
# Helpers
# -------------------------------------------------------
$script:countNew       = 0
$script:countUpdated   = 0
$script:countIdentical = 0

function Deploy-File {
    param([string]$Src, [string]$Dst)

    if (!(Test-Path $Src)) {
        Write-Warning "  MISSING: $Src"
        return
    }

    if (Test-Path $Dst) {
        $srcHash = (Get-FileHash $Src -Algorithm SHA256).Hash
        $dstHash = (Get-FileHash $Dst -Algorithm SHA256).Hash
        if ($srcHash -eq $dstHash) {
            Write-Host "  [=] $(Split-Path $Dst -Leaf)"
            $script:countIdentical++
            return
        }
        $tag   = "UPDATED"
        $color = "Yellow"
        $script:countUpdated++
    } else {
        $tag   = "NEW"
        $color = "Green"
        $script:countNew++
    }

    Write-Host "  [$tag] $Dst" -ForegroundColor $color
    if (!$DryRun) {
        $null = New-Item -ItemType Directory -Force -Path (Split-Path $Dst)
        Copy-Item -Force $Src $Dst
    }
}

function Deploy-Dir {
    param(
        [string]$Src,
        [string]$Dst,
        [string[]]$ExcludeFiles = @()
    )

    if (!(Test-Path $Src)) {
        Write-Warning "  MISSING dir: $Src"
        return
    }

    Write-Host "  [DIR] $(Split-Path $Src -Leaf)  ->  $Dst"

    # /MIR  = mirror (add new, update changed, remove extras)
    # /XF   = exclude specific files from the mirror (used for Windows supplements)
    # /L    = list-only (dry-run)
    # /NJH /NJS /NP /NDL = suppress noisy robocopy output
    $xf = if ($ExcludeFiles.Count -gt 0) { @('/XF') + $ExcludeFiles } else { @() }

    if ($DryRun) {
        robocopy $Src $Dst /MIR /L /NJH /NJS /NP /NDL @xf `
            | Where-Object { $_ -match '\S' } `
            | ForEach-Object { Write-Host "    $_" }
    } else {
        robocopy $Src $Dst /MIR /NJH /NJS /NP /NDL @xf `
            | Where-Object { $_ -match '\S' } `
            | ForEach-Object { Write-Host "    $_" }
        # robocopy exit codes 0-7 = success; 8+ = errors
        if ($LASTEXITCODE -ge 8) { throw "robocopy failed (exit $LASTEXITCODE)" }
    }
}

# -------------------------------------------------------
# unified/ -> scripts\launcher\
# -------------------------------------------------------
Write-Host "`n--- Unified launcher ---" -ForegroundColor Cyan
Deploy-File "$RepoRoot\unified\launcher.py"          "$Launcher\launcher.py"
Deploy-File "$RepoRoot\unified\audit_all.py"         "$Launcher\audit_all.py"
Deploy-File "$RepoRoot\unified\audit_all.ps1"        "$Launcher\audit_all.ps1"
Deploy-File "$RepoRoot\unified\version_selector.py"  "$Launcher\version_selector.py"
Deploy-Dir  "$RepoRoot\unified\config"               "$Launcher\config"
Deploy-Dir  "$RepoRoot\unified\tools"                "$Launcher\tools"
Deploy-Dir  "$RepoRoot\unified\assets"               "$Launcher\assets"
Deploy-Dir  "$RepoRoot\unified\vscode-extension"     "$Launcher\vscode-extension" -ExcludeFiles @("build-and-install-extension.ps1")
Deploy-Dir  "$RepoRoot\unified\maintenance"          "$Launcher\maintenance"
Deploy-Dir  "$RepoRoot\unified\.vscode"              "$Launcher\.vscode"
Deploy-Dir  "$RepoRoot\unified\templates"            "$Launcher\templates"

# -------------------------------------------------------
# windows/scripts/launcher/ supplements -> scripts\launcher\
# -------------------------------------------------------
Write-Host "`n--- Windows launcher supplements ---" -ForegroundColor Cyan
Deploy-File "$RepoRoot\windows\scripts\launcher\create-launcher-shortcut.ps1" `
            "$Launcher\create-launcher-shortcut.ps1"
Deploy-File "$RepoRoot\windows\scripts\launcher\vscode-extension\build-and-install-extension.ps1" `
            "$Launcher\vscode-extension\build-and-install-extension.ps1"

# -------------------------------------------------------
# windows/scripts/ -> scripts\
# -------------------------------------------------------
Write-Host "`n--- Windows scripts ---" -ForegroundColor Cyan
$winScripts = @(
    "start-tnfsd.ps1",
    "stop-tnfsd.ps1",
    "status-tnfsd.ps1",
    "start-FujiNet-server-CoCo-Becker.ps1",
    "stop-FujiNet-server-CoCo-Becker.ps1",
    "status-FujiNet-server-CoCo-Becker.ps1",
    "renumBASIC.bat",
    "cmoc.cmd",
    "compile-BASIC-mc10.bat",
    "build-BasTo6809.cmd",
    "Install-basic-renumber.ps1",
    "install-cygwin.bat",
    "Install-pyDriveWire.ps1",
    "install-tnfsd.ps1",
    "msys2-hybrid-env-rebuilder.ps1",
    "sync-launcher-from-git.ps1"   # copies itself so future updates land in $Scripts
)
foreach ($s in $winScripts) {
    Deploy-File "$RepoRoot\windows\scripts\$s" "$Scripts\$s"
}

# -------------------------------------------------------
# windows/source/msys2/ -> msys64\home\<user>\source\
# -------------------------------------------------------
Write-Host "`n--- MSYS2 build scripts ---" -ForegroundColor Cyan
$msys2Source = "$UserHome\msys64\home\$env:USERNAME\source"
$msys2Scripts = Get-ChildItem "$RepoRoot\windows\source\msys2" -File -ErrorAction SilentlyContinue
if ($msys2Scripts) {
    foreach ($f in $msys2Scripts) {
        Deploy-File $f.FullName "$msys2Source\$($f.Name)"
    }
} else {
    Write-Host "  (no msys2 source scripts found in repo)"
}

# -------------------------------------------------------
# windows/m6809-gdb/ -> %USERPROFILE%\xroar\
# -------------------------------------------------------
Write-Host "`n--- m6809-gdb debugger ---" -ForegroundColor Cyan
$GdbExe = "$RepoRoot\windows\m6809-gdb\m6809-gdb.exe"
if (Test-Path $GdbExe) {
    $XroarDir = "$UserHome\xroar"
    if (-not (Test-Path $XroarDir)) { New-Item -ItemType Directory -Force -Path $XroarDir | Out-Null }
    Deploy-File $GdbExe "$XroarDir\m6809-gdb.exe"
} else {
    Write-Host "  (m6809-gdb.exe not found in repo)"
}

# -------------------------------------------------------
# tasks.json -> VS Code user settings
# -------------------------------------------------------
Write-Host "`n--- VS Code tasks.json ---" -ForegroundColor Cyan
Deploy-File "$RepoRoot\windows\AppData\Roaming\Code\User\tasks.json" `
            "$AppData\tasks.json"

# -------------------------------------------------------
# VS Code extension install
# -------------------------------------------------------
Write-Host "`n--- VS Code extension ---" -ForegroundColor Cyan
$vsixDir = "$Launcher\vscode-extension\coco-basic-syntax"
$vsixFiles = Get-ChildItem $vsixDir -Filter "*.vsix" -ErrorAction SilentlyContinue
if ($vsixFiles) {
    $latestVsix = ($vsixFiles | Sort-Object Name | Select-Object -Last 1).FullName
    if ($DryRun) {
        Write-Host "  [dry-run] would install: $(Split-Path $latestVsix -Leaf)"
    } else {
        $codeCmd = Get-Command code -ErrorAction SilentlyContinue
        if ($codeCmd) {
            code --install-extension $latestVsix 2>&1 | ForEach-Object { Write-Host "  $_" }
        } else {
            Write-Warning "  'code' not in PATH — skipping extension install"
        }
    }
} else {
    Write-Warning "  No .vsix found in $vsixDir"
}

# -------------------------------------------------------
# Summary
# -------------------------------------------------------
Write-Host "`n--- Summary ---"
Write-Host "  New:       $($script:countNew)"
Write-Host "  Updated:   $($script:countUpdated)"
Write-Host "  Identical: $($script:countIdentical)"
Write-Host "`n=== Done.$modeTag ===" -ForegroundColor Green

#!/bin/bash

export WATCOM="$HOME/source/open-watcom-v2/build"
export PATH="$WATCOM/binbuild:$PATH"

# Watcom include and lib paths
export INCLUDE="$WATCOM/h"
export LIB="$WATCOM/lib386"

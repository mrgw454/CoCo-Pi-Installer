killall -9 fujinet
kill -9 `pgrep -f netsiohub`

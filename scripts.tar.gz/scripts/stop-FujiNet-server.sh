#!/bin/bash

killall fujinet
sleep 2
killall -9 fujinet 2>/dev/null
kill `pgrep -f netsiohub` 2>/dev/null
sleep 1
kill -9 `pgrep -f netsiohub` 2>/dev/null

#lsof -i :8000
#kill -9 <process ID>

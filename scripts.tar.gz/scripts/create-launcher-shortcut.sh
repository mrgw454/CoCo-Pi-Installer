#!/usr/bin/env bash

set -euo pipefail

DESKTOP_FILE="$HOME/Desktop/CoCo Launcher.desktop"
LAUNCHER_PATH="$HOME/scripts/launcher/launcher.py"
ICON_PATH="$HOME/scripts/launcher/assets/CoCo-Pi-Launcher.ico"

# The exact .desktop content we want to enforce
read -r -d '' DESKTOP_CONTENT <<EOF
[Desktop Entry]
Type=Application
Name=CoCo Launcher
Comment=Unified CoCo emulator launcher
Exec=xterm -fa "Hot CoCo with T" -fs 16 -geometry 100x30 -bg "#003300" -fg "#00FF00" -e python3 "$LAUNCHER_PATH"
Icon=$ICON_PATH
Terminal=false
Categories=Utility;
EOF

# Create Desktop directory if missing
mkdir -p "$HOME/Desktop"

# If file doesn't exist, create it
if [[ ! -f "$DESKTOP_FILE" ]]; then
    echo "Creating launcher..."
    printf "%s\n" "$DESKTOP_CONTENT" > "$DESKTOP_FILE"
else
    # If file exists but differs, repair it
    if ! diff -q <(echo "$DESKTOP_CONTENT") "$DESKTOP_FILE" >/dev/null; then
        echo "Repairing launcher..."
        printf "%s\n" "$DESKTOP_CONTENT" > "$DESKTOP_FILE"
    else
        echo "Launcher already correct."
    fi
fi

# Ensure it is executable
chmod +x "$DESKTOP_FILE"

echo "Done."

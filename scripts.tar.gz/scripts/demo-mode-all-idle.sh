#!/bin/bash

cd $HOME/.atari800
$HOME/.atari800/atari800-DOS.sh &
sleep 6

cd $HOME/.coleco
$HOME/.coleco/colem -home $HOME/.coleco -adam &
sleep 6

cd $HOME/.xroar
$HOME/.xroar/coco2bh-decb-xroar.sh &
sleep 6

cd $HOME/.mame
$HOME/.mame/mc-10-20k.sh &
sleep 6

cd $HOME/.mame
$HOME/.mame/ti994a_32memtest.sh &
sleep 6

cd $HOME/.vice
$HOME/.vice/vice-c64.sh &
sleep 6

cd $HOME/.vice
$HOME/.vice/vice-c128.sh &
sleep 6

cd $HOME/.mame
$HOME/.mame/dragon64plus.sh &
sleep 6

cd $HOME/.sdltrs
$HOME/.sdltrs/trs80-model4-DOS.sh &
sleep 6

cd $HOME/virtualt-linux64-v1.7
$HOME/virtualt-linux64-v1.7/virtualt &
sleep 6

cd $HOME
/opt/openMSX/bin/openmsx &
sleep 6

cd $HOME/.ovcc
$HOME/.ovcc/coco3-hdbdos-6309-nitros9-OVCC.sh &
sleep 6

cd $HOME/.xtrs
$HOME/.xtrs/xtrs-m4.sh &
sleep 6

cd $HOME

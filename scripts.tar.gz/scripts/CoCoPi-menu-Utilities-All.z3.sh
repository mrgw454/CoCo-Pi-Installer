#!/bin/bash
clear
export COCOPI_MENU_CALLER="/home/ron/scripts/CoCoPi-menu-Utilities-All.z3.sh"
TITLE="$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)"

CHOICE=$(zenity --list \
  --title="$TITLE" \
  --width=700 --height=500 \
  --column="Option" --column="Description" \
  "1" "System Status" \
  "2" "Start     pyDriveWire server" \
  "3" "Stop      pyDriveWire server" \
  "4" "Edit      pyDriveWire configuration" \
  "5" "Restart   Drivewire 4" \
  "6" "Stop      Drivewire 4" \
  "7" "Start     lwwire (Use option 9 prior to running)" \
  "8" "Stop      lwwire" \
  "9" "Edit      lwwire configuration" \
  "10" "Start     emceed file server (MC-10)" \
  "11" "Stop      emceed file server (MC-10)" \
  "12" "Start     tcpser (modem emulator)" \
  "13" "Stop      tcpser (modem emulator)" \
  "14" "Edit      tcpser (modem emulator) script" \
  "15" "Mount     DSK image in Drivewire" \
  "16" "Mount     DSK image in pyDriveWire" \
  "17" "Mount     DSK image in MAME" \
  "18" "Mount     DSK image in XRoar" \
  "19" "Mount     CASSETTE image in XRoar" \
  "20" "Mount     BIN image in XRoar" \
  "21" "Mount     ROM image in MAME" \
  "22" "Mount     ROM image in XRoar" \
  "23" "Show      all saved mount files" \
  "24" "Clear     all saved mount files" \
  "25" "Select    default YA-DOS HDD image" \
  "26" "Select    MAME version" \
  "27" "Select    XRoar version" \
  "28" "Edit      optional MAME parameters (CAUTION)" \
  "29" "Edit      optional XRoar parameters (CAUTION)" \
  "30" "Edit      WiFi configuration" \
  "31" "Edit      pyDriveWire configuration" \
  "32" "Adjust    RPi audio volume" \
  "33" "Test      Bluetooth/USB Game Controller" \
  "34" "Run       Raspi-Config Script" \
  "35" "Edit      /boot/config.txt (DANGEROUS)" \
  "36" "Sync      Cloud Services" \
  "37" "Show      Existing Bluetooth Pairing(s)" \
  "38" "Backup    Existing Bluetooth Pairing(s)" \
  "39" "Restore   Bluetooth Pairing(s) from Archive" \
  "40" "Show      Existing Emulator Configuration File(s)" \
  "41" "Backup    Existing Emulator Configuration File(s)" \
  "42" "Restore   Emulator Configuration File(s) from Archive" \
  "43" "Backup    RPi to alternate SD card" \
  "44" "Download  ROM images to /media/share1/roms" \
  "45" "Download  Latest Fuzix Nightly image" \
  "46" "Download  Latest NitrOS9 EOU image" \
  "47" "Download  Latest UltimateSDC image" \
  "48" "Update    CoCo-Pi from git repo" \
  "49" "Run       CoCo-Pi fix script" \
  "50" "Install   MAME  package file" \
  "51" "Install   XRoar package file" \
  "52" "Load      HDB-DOS via Cassette Cable" \
  "53" "Start     X-Windows Desktop" \
  "54" "Stop      X-Windows Desktop" \
  "55" "Edit      RVPN config" \
  "56" "Start     RVPN network daemon" \
  "57" "Stop      RVPN network daemon" \
  "58" "View      RVPN network log" \
  "59" "Show      RVPN network status" \
  "60" "Reboot    Raspberry Pi" \
  "61" "Shutdown  Raspberry Pi" \
  "62" "Return to Main Menu"
)

case $CHOICE in
  "1") status.sh && CoCoPi-menu-Utilities.sh;;
  "2") $HOME/pyDriveWire/start_pyDW.sh && CoCoPi-menu-Utilities.sh;;
  "3") $HOME/pyDriveWire/stop_pyDW.sh && CoCoPi-menu-Utilities.sh;;
  "4") nano $HOME/.pydrivewirerc && CoCoPi-menu-Utilities.sh;;
  "5") $HOME/DriveWire4/restartDW4.sh && CoCoPi-menu-Utilities.sh;;
  "6") $HOME/DriveWire4/stopDW4.sh && CoCoPi-menu-Utilities.sh;;
  "7") $HOME/lwwire/startlwwire.sh && CoCoPi-menu-Utilities.sh;;
  "8") $HOME/lwwire/stoplwwire.sh && CoCoPi-menu-Utilities.sh;;
  "9") $HOME/lwwire/edit-tcpserv.sh && CoCoPi-menu-Utilities.sh;;
  "10") $HOME/emceed/start_emceed.sh && CoCoPi-menu-Utilities.sh;;
  "11") $HOME/emceed/stop_emceed.sh && CoCoPi-menu-Utilities.sh;;
  "12") $HOME/tcpser/start_tcpser.sh && CoCoPi-menu-Utilities.sh;;
  "13") $HOME/tcpser/stop_tcpser.sh && CoCoPi-menu-Utilities.sh;;
  "14") nano $HOME/tcpser/start_tcpser.sh && CoCoPi-menu-Utilities.sh;;
  "15") mountDWfile.sh 0 0 && CoCoPi-menu-Utilities.sh;;
  "16") mountpyDWfile.sh 0 0 && CoCoPi-menu-Utilities.sh;;
  "17") mountFloppy.sh /media/share1/ && CoCoPi-menu-Utilities.sh;;
  "18") mountXRoarFloppy.sh /media/share1/ && CoCoPi-menu-Utilities.sh;;
  "19") mountXRoarCassette.sh /media/share1/cassette/ && CoCoPi-menu-Utilities.sh;;
  "20") mountXRoarBin.sh /media/share1/ && CoCoPi-menu-Utilities.sh;;
  "21") mountROM.sh /media/share1/ && CoCoPi-menu-Utilities.sh;;
  "22") mountXRoarROM.sh /media/share1/roms/ && CoCoPi-menu-Utilities.sh;;
  "23") mountShow.sh && CoCoPi-menu-Utilities.sh;;
  "24") mountClear.sh && CoCoPi-menu-Utilities.sh;;
  "25") select-hdd.sh && CoCoPi-menu-Utilities.sh;;
  "26") select-emu.sh && CoCoPi-menu-Utilities.sh;;
  "27") select-xroar.sh && CoCoPi-menu-Utilities.sh;;
  "28") editMAMEparms.sh && CoCoPi-menu-Utilities.sh;;
  "29") editXROARparms.sh && CoCoPi-menu-Utilities.sh;;
  "30") editWiFi.sh && CoCoPi-menu-Utilities.sh;;
  "31") editpyDWconfig.sh && CoCoPi-menu-Utilities.sh;;
  "32") adjustVol.sh && CoCoPi-menu-Utilities.sh ;;
  "33") test-controller.sh && CoCoPi-menu-Utilities.sh;;
  "34") runRaspiConfig.sh && CoCoPi-menu-Utilities.sh;;
  "35") editConfig-txt.sh && CoCoPi-menu-Utilities.sh;;
  "36") CoCoPi-menu-rclone.z3.sh;;
  "37") showBluetoothPairings.sh && CoCoPi-menu-Utilities.sh;;
  "38") backupBluetoothPairings.sh && CoCoPi-menu-Utilities.sh;;
  "39") restoreBluetoothPairings.sh && CoCoPi-menu-Utilities.sh;;
  "40") showEMUConfigs.sh && CoCoPi-menu-Utilities.sh;;
  "41") backupEMUConfigs.sh && CoCoPi-menu-Utilities.sh;;
  "42") restoreEMUConfigs.sh && CoCoPi-menu-Utilities.sh;;
  "43") backupSD.sh && CoCoPi-menu-Utilities.sh;;
  "44") downloadROMs.sh && CoCoPi-menu-Utilities.sh;;
  "45") downloadFuzixNightly.sh && CoCoPi-menu-Utilities.sh;;
  "46") downloadNitrOS9EOU.sh && CoCoPi-menu-Utilities.sh;;
  "47") downloadUltimateSDC.sh && CoCoPi-menu-Utilities.sh;;
  "48") updateCoCo-Pi.sh && CoCoPi-menu-Utilities.sh;;
  "49") fix-cocopi.sh && CoCoPi-menu-Utilities.sh;;
  "50") installMAMEpackage.sh && CoCoPi-menu-Utilities.sh;;
  "51") installXRoarpackage.sh && CoCoPi-menu-Utilities.sh;;
  "52") cloadm-hdbdos.sh && CoCoPi-menu-Utilities.sh;;
  "53") start-desktop.sh && CoCoPi-menu-Utilities.sh;;
  "54") stop-desktop.sh && CoCoPi-menu-Utilities.sh;;
  "55") editRVPN.sh && CoCoPi-menu-Utilities.sh;;
  "56") $HOME/rvpn/startRVPN.sh && CoCoPi-menu-Utilities.sh;;
  "57") $HOME/rvpn/stopRVPN.sh && CoCoPi-menu-Utilities.sh;;
  "58") viewRVPN-log.sh && CoCoPi-menu-Utilities.sh;;
  "59") statusRVPN.sh && CoCoPi-menu-Utilities.sh;;
  "60") rebootRPi.sh;;
  "61") shutdownRPi.sh;;
  "62") menu;;
  "*") echo "Quitting...";;
  *) echo "Quitting...";;
esac

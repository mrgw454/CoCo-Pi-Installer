import os
import sys
import re
import shutil

HOME = os.path.expanduser("~")
SEARCH_DIRS = [
    "scripts",
    ".mame",
    ".xroar",
    ".trs80gp",
    ".ovcc"
]

TARGET_STRING = "os.path.expanduser("~")"
SHELL_REPLACEMENT = "$HOME"
PYTHON_REPLACEMENT = 'os.path.expanduser("~")'

def is_shell_script(path):
    return path.endswith(".sh")

def is_python_script(path):
    return path.endswith(".py")

def scan_and_patch(patch_mode=False):
    flagged = []
    for subdir in SEARCH_DIRS:
        full_path = os.path.join(HOME, subdir)
        for root, _, files in os.walk(full_path):
            for fname in files:
                if fname.endswith(".sh") or fname.endswith(".py"):
                    path = os.path.join(root, fname)
                    with open(path, "r") as f:
                        lines = f.readlines()

                    modified = False
                    new_lines = []
                    for line in lines:
                        if TARGET_STRING in line:
                            modified = True
                            if patch_mode:
                                if is_shell_script(path):
                                    line = line.replace(TARGET_STRING, SHELL_REPLACEMENT)
                                elif is_python_script(path):
                                    line = line.replace(TARGET_STRING, PYTHON_REPLACEMENT)
                        new_lines.append(line)

                    if modified:
                        flagged.append(path)
                        if patch_mode:
                            shutil.copy2(path, path + ".bak")
                            with open(path, "w") as f:
                                f.writelines(new_lines)
    return flagged
def print_results(flagged, patch_mode):
    if not flagged:
        print("✅ No hardcoded os.path.expanduser("~") paths found.")
        return

    mode = "Patched" if patch_mode else "Dry-run"
    print(f"\n🔍 {mode}: Found {len(flagged)} scripts with hardcoded os.path.expanduser("~") paths:\n")
    for path in flagged:
        print(f"📄 {path}")
        if patch_mode:
            print(f"   ✔️ Patched and backed up to {path}.bak")
        print()

if __name__ == "__main__":
    patch_mode = "--patch" in sys.argv
    results = scan_and_patch(patch_mode=patch_mode)
    print_results(results, patch_mode)

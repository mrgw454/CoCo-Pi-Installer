#!/bin/bash
echo
clear
echo
echo 4 - 10PRINTcoco.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/10PRINTcoco.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/10PRINTcoco.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5 - 10PRINT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/10PRINT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/10PRINT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 18 - 3DLABY1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/3DLABY1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/3DLABY1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 19 - 3DLABY.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/3DLABY.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/3DLABY.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 54 - 3DMCHASE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/3DMCHASE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/3DMCHASE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 58 - 3X3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/3X3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/3X3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 63 - 64Maze2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/64Maze2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/64Maze2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 64 - 64Maze3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/64Maze3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/64Maze3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 65 - 64Maze4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/64Maze4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/64Maze4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 66 - 64Maze5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/64Maze5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/64Maze5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 67 - 64Maze.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/64Maze.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/64Maze.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 68 - 64X48GF1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/64X48GF1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/64X48GF1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 72 - 6KEYS4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/6KEYS4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/6KEYS4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 73 - 6KEYS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/6KEYS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/6KEYS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 80 - ABM1.2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ABM1.2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ABM1.2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 83 - ABM4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ABM4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ABM4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 84 - ABM5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ABM5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ABM5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 85 - ABM6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ABM6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ABM6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 86 - ABM.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ABM.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ABM.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 87 - ACEY1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ACEY1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ACEY1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 88 - ACEY2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ACEY2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ACEY2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 89 - ACEY3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ACEY3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ACEY3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 90 - ACEY.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ACEY.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ACEY.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 118 - ADVENTR20.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR20.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR20.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 119 - ADVENTR21.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR21.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR21.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 120 - ADVENTR22.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR22.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR22.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 121 - ADVENTR23.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR23.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR23.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 122 - ADVENTR24.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR24.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR24.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 123 - ADVENTR25.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR25.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR25.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 124 - ADVENTR26.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR26.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR26.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 125 - ADVENTR27.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR27.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR27.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 126 - ADVENTR28.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR28.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR28.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 127 - ADVENTR29.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR29.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR29.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 129 - ADVENTR30.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR30.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR30.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 130 - ADVENTR31.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR31.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR31.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 131 - ADVENTR32.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR32.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR32.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 132 - ADVENTR33.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR33.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR33.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 133 - ADVENTR34.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR34.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR34.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 134 - ADVENTR35.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR35.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR35.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 135 - ADVENTR36.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR36.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR36.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 136 - ADVENTR37.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR37.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR37.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 137 - ADVENTR38.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR38.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR38.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 138 - ADVENTR39.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR39.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR39.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 140 - ADVENTR40.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR40.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR40.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 141 - ADVENTR41.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR41.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR41.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 142 - ADVENTR42.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR42.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR42.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 143 - ADVENTR43.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR43.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR43.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 144 - ADVENTR44.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR44.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR44.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 145 - ADVENTR45.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR45.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR45.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 146 - ADVENTR46.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR46.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR46.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 147 - ADVENTR47.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR47.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR47.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 154 - ADVENTR6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 164 - ADVENTR.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ADVENTR.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 185 - AERIEN2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AERIEN2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AERIEN2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 186 - AERIEN3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AERIEN3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AERIEN3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 187 - AERIENLongListing.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AERIENLongListing.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AERIENLongListing.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 188 - AERIEN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AERIEN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AERIEN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 191 - AEROJAM4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AEROJAM4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AEROJAM4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 192 - AEROJAM5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AEROJAM5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AEROJAM5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 202 - AINVADER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AINVADER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AINVADER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 203 - AINVADER3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AINVADER3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AINVADER3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 204 - AINVADER4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AINVADER4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AINVADER4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 244 - ALERT0_1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT0_1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT0_1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 245 - ALERT0_2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT0_2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT0_2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 246 - ALERT0_3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT0_3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT0_3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 247 - ALERT0_4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT0_4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT0_4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 248 - ALERT0_5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT0_5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT0_5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 249 - ALERT0_6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT0_6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT0_6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 250 - ALERT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALERT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 253 - ALIEN1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 255 - ALIEN3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 256 - ALIEN4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 257 - ALIEN5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 258 - ALIEN6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 259 - ALIEN7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 260 - ALIEN8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIEN8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 262 - ALIENS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIENS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALIENS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 268 - ALPHAFOR10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 269 - ALPHAFOR11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 270 - ALPHAFOR12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 271 - ALPHAFOR13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 272 - ALPHAFOR14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 273 - ALPHAFOR2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 274 - ALPHAFOR3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 275 - ALPHAFOR4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 276 - ALPHAFOR5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 277 - ALPHAFOR6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 278 - ALPHAFOR7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 280 - ALPHAFOR9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 284 - ALPHAFOR.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAFOR.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 285 - ALPHAPAC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAPAC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHAPAC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 286 - ALPHA_RED.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHA_RED.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHA_RED.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 288 - ALPHA.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHA.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ALPHA.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 293 - AMAZING2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AMAZING2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AMAZING2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 294 - AMAZING3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AMAZING3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AMAZING3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 295 - AMAZING4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AMAZING4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AMAZING4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 296 - AMAZINGspecial.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AMAZINGspecial.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AMAZINGspecial.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 297 - AMAZING.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AMAZING.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AMAZING.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 299 - AMFOOTB1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AMFOOTB1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AMFOOTB1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 324 - APSHAIchars.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/APSHAIchars.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/APSHAIchars.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 325 - APSHAIED.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/APSHAIED.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/APSHAIED.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 337 - AREA51_10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AREA51_10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AREA51_10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 338 - AREA51_11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AREA51_11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AREA51_11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 347 - AREA51_9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AREA51_9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AREA51_9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 348 - AREA51UK.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AREA51UK.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AREA51UK.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 349 - AREA51_VZ.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AREA51_VZ.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AREA51_VZ.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 368 - ArgonMaze.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ArgonMaze.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ArgonMaze.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 370 - AROID1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AROID1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AROID1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 374 - ASCIITEST.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ASCIITEST.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ASCIITEST.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 375 - ASMOVIAN7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ASMOVIAN7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ASMOVIAN7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 376 - ASSIGN45_2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ASSIGN45_2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ASSIGN45_2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 381 - AST64.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AST64.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AST64.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 382 - ASTER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 384 - ASTEROID.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTEROID.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTEROID.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 385 - ASTEROLD.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTEROLD.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTEROLD.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 386 - ASTERROID2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTERROID2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTERROID2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 387 - ASTERROID3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTERROID3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTERROID3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 388 - ASTERROID4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTERROID4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTERROID4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 389 - ASTERROID.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTERROID.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTERROID.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 390 - ASTER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 396 - ASTSTORM.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTSTORM.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ASTSTORM.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 397 - ast.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ast.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ast.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 398 - ATANARJ2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ATANARJ2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ATANARJ2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 399 - ATANARJ3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ATANARJ3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ATANARJ3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 406 - ATLBALN3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ATLBALN3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ATLBALN3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 407 - ATLBALN4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ATLBALN4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ATLBALN4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 408 - ATTACK2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ATTACK2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ATTACK2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 410 - ATTHEPOST.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ATTHEPOST.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ATTHEPOST.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 411 - AUSFLAG2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AUSFLAG2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AUSFLAG2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 412 - AUSFLAG.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AUSFLAG.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AUSFLAG.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 413 - AUSMAP2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AUSMAP2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AUSMAP2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 414 - AUSMAP.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AUSMAP.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AUSMAP.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 416 - AUTOSOL2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AUTOSOL2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AUTOSOL2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 417 - AUTOSOL3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AUTOSOL3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AUTOSOL3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 423 - AZMOVIAN5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AZMOVIAN5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AZMOVIAN5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 424 - AZMOVIAN6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/AZMOVIAN6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/AZMOVIAN6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 425 - BACCARAT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BACCARAT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BACCARAT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 427 - BACH.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BACH.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BACH.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 428 - BACH.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BACH.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BACH.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 431 - BALL2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BALL2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BALL2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 434 - BALL.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BALL.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BALL.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 437 - BALSTAR1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BALSTAR1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BALSTAR1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 438 - BALSTAR2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BALSTAR2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BALSTAR2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 439 - BALSTAR3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BALSTAR3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BALSTAR3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 440 - BANDIT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BANDIT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BANDIT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 441 - BANDITOLD.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BANDITOLD.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BANDITOLD.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 442 - BANDIT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BANDIT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BANDIT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 452 - BARREL1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BARREL1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BARREL1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 457 - BASCHESS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BASCHESS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BASCHESS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 466 - BASEINV1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BASEINV1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BASEINV1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 467 - BASERACE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BASERACE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BASERACE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 468 - BASE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BASE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BASE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 470 - BATLBOTS10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 471 - BATLBOTS3_Old.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS3_Old.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS3_Old.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 472 - BATLBOTS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 473 - BATLBOTS4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 474 - BATLBOTS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 475 - BATLBOTS6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 476 - BATLBOTS7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 477 - BATLBOTS8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 478 - BATLBOTS9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BATLBOTS9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 484 - BAZOOKA1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BAZOOKA1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BAZOOKA1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 485 - BAZOOKA2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BAZOOKA2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BAZOOKA2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 486 - BAZOOKA.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BAZOOKA.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BAZOOKA.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 504 - BERZERK12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 506 - BERZERK14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 507 - BERZERK15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 508 - BERZERK16.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK16.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK16.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 509 - BERZERK17.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK17.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK17.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 510 - BERZERK18.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK18.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK18.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 511 - BERZERK19.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK19.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK19.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 512 - BERZERK20.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK20.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK20.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 513 - BERZERK21.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK21.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK21.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 514 - BERZERK22.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK22.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK22.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 515 - BERZERK23.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK23.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK23.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 523 - BERZERK30.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK30.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK30.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 532 - BERZERK.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BERZERK.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 535 - BFKlondike.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BFKlondike.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BFKlondike.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 536 - BGAMMON10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BGAMMON10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BGAMMON10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 537 - BGAMMON11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BGAMMON11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BGAMMON11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 538 - BGAMMON12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BGAMMON12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BGAMMON12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 546 - BGAMMON9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BGAMMON9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BGAMMON9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 565 - BIGPRINT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGPRINT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGPRINT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 574 - BIGRED1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 575 - BIGRED2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 576 - BIGRED3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 577 - BIGRED4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 578 - BIGRED5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 579 - BIGRED6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 580 - BIGRED7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BIGRED7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 584 - BINROOM2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BINROOM2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BINROOM2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 596 - BLACKJACK.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BLACKJACK.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BLACKJACK.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 598 - BLAKHOLE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BLAKHOLE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BLAKHOLE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 599 - BLANDER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BLANDER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BLANDER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 600 - BLANDER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BLANDER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BLANDER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 603 - BLITZ.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BLITZ.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BLITZ.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 609 - BLKJCK1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BLKJCK1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BLKJCK1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 610 - BLKJCK2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BLKJCK2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BLKJCK2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 612 - BLOCKOUT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BLOCKOUT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BLOCKOUT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 616 - BOARDER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BOARDER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BOARDER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 624 - BOBO2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BOBO2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BOBO2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 625 - BOBO3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BOBO3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BOBO3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 626 - BOBO.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BOBO.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BOBO.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 629 - BOMBRUN2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 630 - BOMBRUN3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 631 - BOMBRUN4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 632 - BOMBRUN5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 633 - BOMBRUN6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 634 - BOMBRUN7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 635 - BOMBRUN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BOMBRUN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 644 - BORER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BORER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BORER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 646 - BOULDER1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BOULDER1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BOULDER1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 656 - BOXING2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BOXING2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BOXING2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 662 - BRICKOUT3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BRICKOUT3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BRICKOUT3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 663 - BRICKOUT4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BRICKOUT4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BRICKOUT4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 664 - BRICKOUT5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BRICKOUT5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BRICKOUT5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 665 - BRICKOUT6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BRICKOUT6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BRICKOUT6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 667 - BRICKS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BRICKS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BRICKS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 668 - BRICKS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BRICKS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BRICKS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 669 - brickwall2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/brickwall2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/brickwall2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 672 - BSHIP_12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BSHIP_12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BSHIP_12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 676 - BULLS1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BULLS1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BULLS1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 677 - BULLS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BULLS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BULLS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 712 - BUSTERS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 713 - BUSTERS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 714 - BUSTERS4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 715 - BUSTERS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 716 - BUSTERS6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 717 - BUSTERS7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 718 - BUSTERS8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 719 - BUSTERS9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 724 - BUSTERS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/BUSTERS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 729 - C5P9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/C5P9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/C5P9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 731 - CADANZA.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CADANZA.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CADANZA.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 732 - CADNZAMC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CADNZAMC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CADNZAMC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 733 - CADNZAMC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CADNZAMC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CADNZAMC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 736 - CAMP.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAMP.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAMP.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 737 - CAMP.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAMP.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAMP.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 738 - CANFLAG.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CANFLAG.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CANFLAG.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 744 - cannons.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/cannons.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/cannons.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 745 - CAPTCHEM2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAPTCHEM2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAPTCHEM2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 746 - CAPTCHEM3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAPTCHEM3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAPTCHEM3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 747 - CAPTCHEM.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAPTCHEM.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAPTCHEM.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 748 - CAPTURE0.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAPTURE0.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAPTURE0.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 749 - CAPTURE1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAPTURE1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAPTURE1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 750 - CAPTURE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAPTURE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAPTURE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 752 - CAR3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 753 - CAR4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 754 - CAR5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 755 - CAR6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 756 - CAR7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 757 - CAR8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 758 - CARDS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CARDS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CARDS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 765 - CARNEW10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CARNEW10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CARNEW10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 766 - CARNEW11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CARNEW11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CARNEW11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 767 - CARNEW12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CARNEW12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CARNEW12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 768 - CARNEW13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CARNEW13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CARNEW13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 769 - CARNEW9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CARNEW9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CARNEW9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 770 - CARTEST.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CARTEST.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CARTEST.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 771 - CAR.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAR.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 789 - CASTLDRA.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CASTLDRA.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CASTLDRA.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 790 - CASTLE1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CASTLE1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CASTLE1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 803 - CASTLE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CASTLE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CASTLE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 811 - CAVERAID2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 812 - CAVERAID3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 813 - CAVERAID4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 814 - CAVERAID5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 815 - CAVERAID6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 816 - CAVERAID7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 817 - CAVERAID8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERAID8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 819 - CAVERN1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERN1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERN1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 821 - CAVERN3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERN3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERN3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 822 - CAVERN4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERN4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERN4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 823 - CAVERN5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERN5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERN5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 824 - CAVERN6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERN6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERN6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 825 - CAVERN7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERN7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVERN7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 831 - CAVES1_2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVES1_2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVES1_2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 856 - CAVEWALL.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVEWALL.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVEWALL.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 861 - CAVMARS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVMARS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVMARS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 862 - CAVMARS6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVMARS6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CAVMARS6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 879 - CENTIPEDE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CENTIPEDE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CENTIPEDE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 880 - CENTIPEDE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CENTIPEDE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CENTIPEDE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 881 - CENTIPEDE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CENTIPEDE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CENTIPEDE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 882 - CENTIPEDE5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CENTIPEDE5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CENTIPEDE5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 888 - CENTIPEDE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CENTIPEDE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CENTIPEDE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 894 - CHARGEN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHARGEN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHARGEN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 895 - CharlieSounds.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CharlieSounds.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CharlieSounds.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 896 - CHASE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHASE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHASE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 897 - CHASE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHASE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHASE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 898 - CHASE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHASE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHASE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 899 - CHASE5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHASE5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHASE5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 900 - CHASE6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHASE6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHASE6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 901 - CHASE7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHASE7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHASE7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 915 - CHATEAUTI99.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHATEAUTI99.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHATEAUTI99.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 932 - CHESS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHESS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHESS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 933 - CHESS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHESS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHESS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 934 - CHESSB2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHESSB2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHESSB2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 945 - CHOMP.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHOMP.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHOMP.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 946 - CHOPPER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHOPPER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHOPPER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 947 - CHOPPER3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHOPPER3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHOPPER3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 948 - CHOPPER4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHOPPER4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHOPPER4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 949 - CHOPPER5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHOPPER5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHOPPER5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 951 - CHOPPER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CHOPPER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CHOPPER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 961 - CIA1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CIA1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CIA1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 962 - CIA2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CIA2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CIA2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 963 - CIA3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CIA3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CIA3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 964 - CIA4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CIA4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CIA4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 965 - CIA5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CIA5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CIA5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 966 - CIA6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CIA6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CIA6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 970 - CIRCLE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CIRCLE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CIRCLE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 976 - CITYBOMB2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CITYBOMB2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CITYBOMB2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 977 - CITYBOMB.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CITYBOMB.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CITYBOMB.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 984 - CLICK_SOUND.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CLICK_SOUND.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CLICK_SOUND.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 990 - CLOSEOUT4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CLOSEOUT4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CLOSEOUT4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 991 - CLOSEOUT5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CLOSEOUT5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CLOSEOUT5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 992 - CLOSEOUT6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CLOSEOUT6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CLOSEOUT6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 993 - CLOSEOUT7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CLOSEOUT7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CLOSEOUT7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 994 - CLOSEOUT8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CLOSEOUT8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CLOSEOUT8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 995 - CLOSEOUT9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CLOSEOUT9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CLOSEOUT9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 998 - CLRPATH2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CLRPATH2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CLRPATH2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 999 - CLRPATH3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CLRPATH3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CLRPATH3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1000 - CLRPATH4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CLRPATH4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CLRPATH4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1001 - CLRPATH5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CLRPATH5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CLRPATH5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1019 - COCOCRAWL18.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COCOCRAWL18.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COCOCRAWL18.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1022 - COCODND.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COCODND.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COCODND.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1029 - COCOFLIPULL.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COCOFLIPULL.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COCOFLIPULL.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1051 - cocoOVERTAKE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/cocoOVERTAKE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/cocoOVERTAKE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1058 - COCOSNAKE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COCOSNAKE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COCOSNAKE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1083 - COLMIND.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLMIND.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLMIND.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1086 - COLORIC2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLORIC2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLORIC2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1087 - COLORIC3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLORIC3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLORIC3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1088 - COLORIC4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLORIC4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLORIC4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1090 - COLOROID2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1091 - COLOROID3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1092 - COLOROID4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1093 - COLOROID5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1094 - COLOROID6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1095 - COLOROID7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1096 - COLOROID8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1097 - COLOROID9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLOROID9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1099 - COLORTST.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLORTST.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLORTST.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1111 - ColossaldataDeprecated.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ColossaldataDeprecated.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ColossaldataDeprecated.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1112 - Colossaldata.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/Colossaldata.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/Colossaldata.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1115 - COLUMNS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLUMNS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLUMNS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1116 - COLUMNS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLUMNS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLUMNS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1122 - COLUMNS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COLUMNS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COLUMNS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1125 - COMBOT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COMBOT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COMBOT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1126 - COMBOT3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/COMBOT3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/COMBOT3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1130 - CONCENTR2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CONCENTR2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CONCENTR2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1131 - CONCENTR3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CONCENTR3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CONCENTR3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1134 - CONNECT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CONNECT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CONNECT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1143 - CONVOY1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CONVOY1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CONVOY1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1150 - CORPSES2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CORPSES2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CORPSES2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1151 - CORPSES3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CORPSES3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CORPSES3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1185 - CRAWL2_Old.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL2_Old.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL2_Old.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1186 - CRAWL2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1187 - CRAWL3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1190 - CRAWL6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1191 - CRAWL7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1192 - CRAWL8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1193 - CRAWL9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAWL9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1198 - CRAZY8S2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAZY8S2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAZY8S2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1199 - CRAZY8S.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAZY8S.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CRAZY8S.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1200 - CREATION.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CREATION.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CREATION.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1208 - CROPS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CROPS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CROPS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1240 - CSS1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1241 - CSS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1242 - CSS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1243 - CSS4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1244 - CSS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1245 - CSS6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1246 - CSS7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1247 - CSS8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CSS8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1271 - CUPBALL2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CUPBALL2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CUPBALL2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1272 - CUPBALL3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CUPBALL3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CUPBALL3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1273 - CUPBALL4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CUPBALL4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CUPBALL4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1274 - CUPBALL5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CUPBALL5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CUPBALL5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1276 - CUPID.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/CUPID.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/CUPID.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1284 - Curve2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/Curve2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/Curve2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1285 - Curve3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/Curve3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/Curve3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1286 - Curve4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/Curve4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/Curve4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1287 - Curve.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/Curve.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/Curve.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1290 - DALEKS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DALEKS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DALEKS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1291 - DANTE1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DANTE1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DANTE1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1292 - DANTE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DANTE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DANTE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1302 - DASH10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1303 - DASH11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1318 - DASH4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1319 - DASH5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1320 - DASH6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1321 - DASH7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1322 - DASH8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1323 - DASH9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DASH9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1333 - D-CHIRP.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/D-CHIRP.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/D-CHIRP.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1336 - DEADSTIK.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEADSTIK.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEADSTIK.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1340 - DECOY2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DECOY2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DECOY2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1341 - DECOY3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DECOY3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DECOY3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1342 - DECOY4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DECOY4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DECOY4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1343 - DECOY5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DECOY5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DECOY5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1347 - DEEPSCAN1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEEPSCAN1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEEPSCAN1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1348 - DEEPSCAN2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEEPSCAN2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEEPSCAN2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1349 - DEEPSCAN3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEEPSCAN3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEEPSCAN3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1350 - DEEPSCAN4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEEPSCAN4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEEPSCAN4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1351 - DEEPSCAN5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEEPSCAN5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEEPSCAN5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1358 - DEFCON1_10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1359 - DEFCON1_11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1360 - DEFCON1_12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1361 - DEFCON1_13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1362 - DEFCON1_14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1365 - DEFCON1_17.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_17.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_17.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1366 - DEFCON1_2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1_2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1374 - DEFCON1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFCON1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1375 - DefectorCalc.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DefectorCalc.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DefectorCalc.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1380 - DEFENDER5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFENDER5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFENDER5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1381 - DEFENDER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFENDER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFENDER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1384 - DEFENSE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFENSE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFENSE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1385 - DEFENSE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFENSE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFENSE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1386 - DEFENSE5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFENSE5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEFENSE5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1416 - DEUTCHLN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEUTCHLN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEUTCHLN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1417 - DEVIL1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEVIL1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEVIL1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1419 - DEV-TRI1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DEV-TRI1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DEV-TRI1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1423 - DHUNT1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DHUNT1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DHUNT1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1424 - DHUNT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DHUNT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DHUNT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1425 - DHUNTD.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DHUNTD.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DHUNTD.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1429 - DICEWARS10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1430 - DICEWARS11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1431 - DICEWARS12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1432 - DICEWARS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1433 - DICEWARS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1434 - DICEWARS4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1435 - DICEWARS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1436 - DICEWARS6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1437 - DICEWARS7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1438 - DICEWARS8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1439 - DICEWARS9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1441 - DICEWARStest.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARStest.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARStest.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1442 - DICEWARS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DICEWARS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1447 - DIGDUG0.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGDUG0.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGDUG0.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1453 - DIGDUG2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGDUG2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGDUG2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1462 - DIGDUG.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGDUG.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGDUG.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1464 - DIGGER3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGGER3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGGER3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1465 - DIGGER4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGGER4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGGER4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1466 - DIGGER5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGGER5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGGER5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1467 - DIGGER6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGGER6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DIGGER6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1504 - DND1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DND1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DND1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1506 - DND2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DND2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DND2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1512 - DOCTOR3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DOCTOR3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DOCTOR3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1513 - DOCTOR4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DOCTOR4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DOCTOR4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1514 - DOCTOR5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DOCTOR5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DOCTOR5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1515 - DOCTOR6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DOCTOR6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DOCTOR6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1520 - DODGE1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGE1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGE1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1521 - DODGE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1522 - DODGE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1523 - DODGE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1524 - DODGE5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGE5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGE5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1526 - DODGEM10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1527 - DODGEM11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1528 - DODGEM12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1529 - DODGEM1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1530 - DODGEM2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1531 - DODGEM3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1532 - DODGEM4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1533 - DODGEM5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1534 - DODGEM6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1535 - DODGEM7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1536 - DODGEM8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1537 - DODGEM9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGEM9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1538 - DODGE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DODGE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1572 - DOMINO10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DOMINO10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DOMINO10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1578 - DOMINO6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DOMINO6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DOMINO6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1579 - DOMINO7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DOMINO7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DOMINO7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1580 - DOMINO8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DOMINO8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DOMINO8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1581 - DOMINO9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DOMINO9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DOMINO9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1586 - DOTS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DOTS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DOTS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1587 - DRAC2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAC2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAC2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1588 - DRAC3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAC3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAC3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1602 - DRAGONFE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAGONFE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAGONFE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1605 - DRAUGHTS0.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS0.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS0.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1606 - DRAUGHTS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1607 - DRAUGHTS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1608 - DRAUGHTS4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1609 - DRAUGHTS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1610 - DRAUGHTS6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1611 - DRAUGHTS7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DRAUGHTS7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1613 - DrawPok.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DrawPok.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DrawPok.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1615 - DREIDEL2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DREIDEL2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DREIDEL2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1616 - DREIDEL3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DREIDEL3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DREIDEL3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1629 - DROPTITLE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/DROPTITLE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/DROPTITLE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1697 - ELEVATOR10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1698 - ELEVATOR11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1699 - ELEVATOR12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1700 - ELEVATOR13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1701 - ELEVATOR14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1702 - ELEVATOR15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1703 - ELEVATOR16.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR16.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR16.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1704 - ELEVATOR17.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR17.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR17.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1705 - ELEVATOR18.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR18.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR18.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1706 - ELEVATOR19.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR19.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR19.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1712 - ELEVATOR6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1713 - ELEVATOR7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1714 - ELEVATOR8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1715 - ELEVATOR9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATOR9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1719 - ELEVATORcompiler19.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATORcompiler19.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ELEVATORcompiler19.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1741 - EMPIRE0.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/EMPIRE0.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/EMPIRE0.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1751 - EMPIRE1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/EMPIRE1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/EMPIRE1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1764 - ENGINEER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ENGINEER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ENGINEER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1765 - ENGINEER3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ENGINEER3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ENGINEER3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1774 - ENTERPRISE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ENTERPRISE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ENTERPRISE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1776 - ENTERPRISE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ENTERPRISE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ENTERPRISE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1784 - EUCHRE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/EUCHRE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/EUCHRE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1786 - Euphoria.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/Euphoria.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/Euphoria.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1787 - EXPCALC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/EXPCALC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/EXPCALC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1793 - F1_1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/F1_1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/F1_1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1796 - FARFAL4K_MC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFAL4K_MC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFAL4K_MC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1797 - FARFAL8K.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFAL8K.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFAL8K.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1798 - FARFALL2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1799 - FARFALL4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1800 - FARFALL5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1801 - FARFALL6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1802 - FARFALL7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1803 - FARFALL8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1804 - FARFALL9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1805 - FARFALL_old.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL_old.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALL_old.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1806 - FARFALLSilent.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALLSilent.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FARFALLSilent.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1839 - FELIX.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FELIX.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FELIX.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1840 - FESQUEST5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FESQUEST5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FESQUEST5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1841 - FESQUEST6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FESQUEST6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FESQUEST6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1844 - FESTTREK3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FESTTREK3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FESTTREK3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1845 - FESTTREK4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FESTTREK4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FESTTREK4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1852 - FIGHTER1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FIGHTER1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FIGHTER1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1867 - FINANCE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FINANCE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FINANCE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1872 - FIREWORK1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FIREWORK1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FIREWORK1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1873 - FIREWORK2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FIREWORK2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FIREWORK2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1874 - FIREWORK.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FIREWORK.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FIREWORK.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1876 - FISHIN2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FISHIN2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FISHIN2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1877 - FISHIN3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FISHIN3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FISHIN3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1878 - FISHIN4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FISHIN4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FISHIN4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1879 - FISHIN5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FISHIN5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FISHIN5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1884 - FISH.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FISH.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FISH.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1893 - FLAPPY1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLAPPY1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLAPPY1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1894 - FLAPPY2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLAPPY2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLAPPY2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1895 - FLAPPY3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLAPPY3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLAPPY3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1896 - FLAPPY4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLAPPY4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLAPPY4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1897 - FLAPPY5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLAPPY5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLAPPY5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1913 - FLIPULL10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1914 - FLIPULL11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1915 - FLIPULL12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1916 - FLIPULL13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1917 - FLIPULL14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1918 - FLIPULL15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1919 - FLIPULL2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1921 - FLIPULL4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1926 - FLIPULL9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULL9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1927 - FLIPULLAlice.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULLAlice.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLIPULLAlice.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1928 - FLOOD2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLOOD2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLOOD2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1929 - FLOOD.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLOOD.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLOOD.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1931 - FLTSIM2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLTSIM2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLTSIM2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1932 - FLTSIM3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLTSIM3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLTSIM3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1933 - FLTSIM4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLTSIM4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLTSIM4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1936 - FLYCATCH3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLYCATCH3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLYCATCH3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1937 - FLYCATCH4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FLYCATCH4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FLYCATCH4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1942 - FORMULA1_1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1943 - FORMULA1_2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1944 - FORMULA1_3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1945 - FORMULA1_4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1946 - FORMULA1_5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1947 - FORMULA1_6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1948 - FORMULA1_7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1949 - FORMULA1_8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FORMULA1_8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1950 - FOUR2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FOUR2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FOUR2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1952 - FOUR.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FOUR.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FOUR.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1968 - FREECELL7compiler.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FREECELL7compiler.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FREECELL7compiler.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1970 - FREECELL8compiler.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FREECELL8compiler.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FREECELL8compiler.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1971 - FREECELL9compiler.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FREECELL9compiler.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FREECELL9compiler.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1974 - FRENCH.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FRENCH.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FRENCH.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1975 - FRENCH.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FRENCH.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FRENCH.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1986 - FROG1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FROG1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FROG1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1989 - FROG2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FROG2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FROG2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1990 - FROG3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FROG3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FROG3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1991 - FROG4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FROG4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FROG4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1992 - FROG5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FROG5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FROG5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1993 - FROG6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FROG6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FROG6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 1998 - FROGS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FROGS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FROGS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2001 - FRUITFLY2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FRUITFLY2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FRUITFLY2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2002 - FRUITFLY.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FRUITFLY.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FRUITFLY.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2007 - FURTRADE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FURTRADE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FURTRADE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2008 - FURTRADE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FURTRADE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FURTRADE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2009 - FURTRADE5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FURTRADE5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FURTRADE5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2010 - FURTRADE6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FURTRADE6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FURTRADE6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2021 - FWHEELLIGHTS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/FWHEELLIGHTS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/FWHEELLIGHTS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2023 - G2048_4KMC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/G2048_4KMC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/G2048_4KMC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2040 - GALSTART.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GALSTART.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GALSTART.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2056 - GAME2048_1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2057 - GAME2048_2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2058 - GAME2048_3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2059 - GAME2048_4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2060 - GAME2048_5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2061 - GAME2048_6Deprecated.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_6Deprecated.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_6Deprecated.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2062 - GAME2048_6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2063 - GAME2048_7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GAME2048_7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2069 - GAMMON3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GAMMON3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GAMMON3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2072 - GANYMEDE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GANYMEDE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GANYMEDE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2080 - GANYMEDE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GANYMEDE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GANYMEDE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2083 - GARDEN1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2084 - GARDEN2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2085 - GARDEN4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2086 - GARDEN5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2088 - GARDEN7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2089 - GARDEN8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2090 - GARDEN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GARDEN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2106 - GBUSTERS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GBUSTERS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GBUSTERS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2107 - GBUSTERS6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GBUSTERS6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GBUSTERS6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2108 - GBUSTERS7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GBUSTERS7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GBUSTERS7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2109 - GBUSTERS8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GBUSTERS8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GBUSTERS8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2121 - GERMAN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GERMAN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GERMAN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2126 - GIGABONX.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GIGABONX.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GIGABONX.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2127 - GMCHESS0.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GMCHESS0.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GMCHESS0.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2128 - GMCHESS1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GMCHESS1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GMCHESS1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2129 - GMCHESS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GMCHESS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GMCHESS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2130 - GOBLIN2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOBLIN2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOBLIN2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2131 - GOBLIN3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOBLIN3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOBLIN3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2133 - GOBLIN4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOBLIN4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOBLIN4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2134 - GOBLIN5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOBLIN5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOBLIN5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2138 - GOFISH2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOFISH2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOFISH2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2139 - GOFISH3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOFISH3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOFISH3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2140 - GOFISH4K.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOFISH4K.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOFISH4K.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2141 - GOFISH4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOFISH4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOFISH4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2142 - GOFISH.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOFISH.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOFISH.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2147 - GOLDHUNT10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2148 - GOLDHUNT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2149 - GOLDHUNT3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2150 - GOLDHUNT4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2151 - GOLDHUNT5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2152 - GOLDHUNT6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2153 - GOLDHUNT7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2154 - GOLDHUNT8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2155 - GOLDHUNT9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2156 - GOLDHUNT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOLDHUNT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2161 - GOMOKU1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOMOKU1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOMOKU1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2169 - GOTCHA2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOTCHA2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOTCHA2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2170 - GOTCHA3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOTCHA3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOTCHA3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2171 - GOTCHA4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOTCHA4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOTCHA4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2172 - GOTCHA5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOTCHA5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOTCHA5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2173 - GOTCHA.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GOTCHA.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GOTCHA.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2174 - GO.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GO.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GO.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2175 - GRAFDEMO.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAFDEMO.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAFDEMO.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2188 - GRAIL10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2189 - GRAIL11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2190 - GRAIL12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2192 - GRAIL14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2193 - GRAIL15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2194 - GRAIL16.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL16.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL16.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2195 - GRAIL17.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL17.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL17.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2196 - GRAIL17WRM.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL17WRM.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL17WRM.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2197 - GRAIL18.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL18.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL18.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2198 - GRAIL19.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL19.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL19.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2199 - GRAIL1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2200 - GRAIL20.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL20.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL20.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2201 - GRAIL21.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL21.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL21.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2202 - GRAIL22.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL22.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL22.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2203 - GRAIL23.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL23.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL23.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2204 - GRAIL24.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL24.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL24.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2205 - GRAIL25.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL25.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL25.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2206 - GRAIL26.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL26.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL26.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2207 - GRAIL27.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL27.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL27.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2208 - GRAIL28.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL28.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL28.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2209 - GRAIL29.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL29.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL29.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2210 - GRAIL2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2211 - GRAIL30.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL30.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL30.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2212 - GRAIL31.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL31.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL31.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2215 - GRAIL3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2216 - GRAIL4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2217 - GRAIL5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2218 - GRAIL6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2219 - GRAIL7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2220 - GRAIL8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2221 - GRAIL9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAIL9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2225 - GRAPHICDEMO.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAPHICDEMO.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAPHICDEMO.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2228 - GRAPHIC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAPHIC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRAPHIC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2229 - GREENTHI2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GREENTHI2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GREENTHI2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2234 - GREENTHI.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GREENTHI.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GREENTHI.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2235 - GREEN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GREEN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GREEN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2236 - GREEN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GREEN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GREEN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2248 - GRINCH.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GRINCH.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GRINCH.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2253 - GUNDAM3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GUNDAM3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GUNDAM3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2254 - GUNDAM4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GUNDAM4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GUNDAM4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2259 - GUPPY0.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/GUPPY0.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/GUPPY0.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2277 - HAMURABI4K.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HAMURABI4K.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HAMURABI4K.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2284 - HAMURABI.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HAMURABI.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HAMURABI.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2286 - HANUKKAH.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HANUKKAH.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HANUKKAH.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2287 - HAPPYFACE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HAPPYFACE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HAPPYFACE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2296 - HAUNTED.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HAUNTED.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HAUNTED.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2300 - HEIANKYO2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HEIANKYO2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HEIANKYO2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2301 - HEIANKYO3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HEIANKYO3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HEIANKYO3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2302 - HEIANKYO4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HEIANKYO4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HEIANKYO4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2303 - HEIANKYO5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HEIANKYO5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HEIANKYO5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2304 - HEIANKYO6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HEIANKYO6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HEIANKYO6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2305 - HEIANKYO.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HEIANKYO.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HEIANKYO.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2306 - HERDER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HERDER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HERDER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2307 - HERDER3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HERDER3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HERDER3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2308 - HERDER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HERDER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HERDER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2309 - HEXAGON2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HEXAGON2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HEXAGON2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2310 - HEXAGON.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HEXAGON.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HEXAGON.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2313 - HEX.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HEX.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HEX.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2314 - HFOREST2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HFOREST2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HFOREST2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2315 - HFOREST3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HFOREST3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HFOREST3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2316 - HFOREST.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HFOREST.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HFOREST.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2318 - HHOUSE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HHOUSE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HHOUSE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2319 - HHOUSE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HHOUSE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HHOUSE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2320 - HHOUSE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HHOUSE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HHOUSE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2323 - HIGHSCORE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HIGHSCORE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HIGHSCORE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2325 - HIPPO2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HIPPO2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HIPPO2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2326 - HIPPO3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HIPPO3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HIPPO3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2327 - HIPPO4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HIPPO4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HIPPO4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2328 - HIPPO5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HIPPO5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HIPPO5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2329 - HIPPO6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HIPPO6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HIPPO6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2331 - HIPPO.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HIPPO.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HIPPO.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2336 - HIRES_SET&RESET.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HIRES_SET&RESET.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HIRES_SET&RESET.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2340 - HIRES_SOUND.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HIRES_SOUND.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HIRES_SOUND.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2343 - HITMISS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HITMISS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HITMISS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2344 - HLANDER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HLANDER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HLANDER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2349 - HOCKEY2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HOCKEY2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HOCKEY2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2350 - HOCKEY3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HOCKEY3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HOCKEY3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2351 - HOCKEY4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HOCKEY4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HOCKEY4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2354 - HOCKEY.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HOCKEY.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HOCKEY.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2395 - HRACE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HRACE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HRACE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2399 - HTOAD3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HTOAD3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HTOAD3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2403 - HUNTER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/HUNTER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/HUNTER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2413 - ICHING1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ICHING1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ICHING1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2414 - ICHING2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ICHING2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ICHING2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2422 - IndieTheme.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/IndieTheme.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/IndieTheme.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2424 - INKEY.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/INKEY.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/INKEY.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2437 - INN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/INN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/INN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2438 - INPUT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/INPUT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/INPUT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2439 - INPUT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/INPUT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/INPUT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2444 - INSTRUCT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/INSTRUCT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/INSTRUCT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2481 - ISOLA.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ISOLA.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ISOLA.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2484 - JACK.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JACK.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JACK.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2490 - JETPAC2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JETPAC2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JETPAC2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2491 - JETPAC3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JETPAC3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JETPAC3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2492 - JETPAC4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JETPAC4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JETPAC4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2493 - JETPAC5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JETPAC5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JETPAC5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2494 - JETPAC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JETPAC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JETPAC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2497 - JEWELED2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JEWELED2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JEWELED2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2498 - JEWELED3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JEWELED3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JEWELED3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2499 - JEWELED4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JEWELED4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JEWELED4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2500 - JEWELED.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JEWELED.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JEWELED.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2505 - JEWELS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JEWELS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JEWELS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2508 - JIMVADER1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2509 - JIMVADER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2510 - JIMVADER3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2511 - JIMVADER4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2512 - JIMVADER5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2513 - JIMVADER_MC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER_MC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER_MC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2514 - JIMVADER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JIMVADER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2516 - JOUST.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JOUST.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JOUST.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2518 - JTITLE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JTITLE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JTITLE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2521 - JUMPJACK0.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JUMPJACK0.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JUMPJACK0.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2522 - JUMPJACK1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JUMPJACK1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JUMPJACK1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2524 - JUMPJACK3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JUMPJACK3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JUMPJACK3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2525 - JUMPJACK4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/JUMPJACK4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/JUMPJACK4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2526 - jumpship.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/jumpship.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/jumpship.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2539 - KALSCOPE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KALSCOPE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KALSCOPE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2540 - KALSCOPE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KALSCOPE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KALSCOPE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2542 - keyiinput.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/keyiinput.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/keyiinput.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2544 - KEYTEST2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KEYTEST2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KEYTEST2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2545 - keytest.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/keytest.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/keytest.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2547 - KILLER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2548 - KILLER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2549 - KILLTOM10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2550 - KILLTOM11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2551 - KILLTOM12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2552 - KILLTOM13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2554 - KILLTOM3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2555 - KILLTOM4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2556 - KILLTOM5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2557 - KILLTOM6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2558 - KILLTOM7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2559 - KILLTOM8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2560 - KILLTOM9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOM9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2561 - KILLTOMcompiler13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOMcompiler13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KILLTOMcompiler13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2577 - KINGS10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KINGS10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KINGS10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2583 - KINGS6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KINGS6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KINGS6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2584 - KINGS7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KINGS7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KINGS7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2585 - KINGS8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KINGS8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KINGS8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2586 - KINGS9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KINGS9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KINGS9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2589 - KLINGON1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KLINGON1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KLINGON1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2590 - KLINGON.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KLINGON.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KLINGON.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2603 - KNIGHTS10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2604 - KNIGHTS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2605 - KNIGHTS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2606 - KNIGHTS4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2607 - KNIGHTS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2608 - KNIGHTS6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2609 - KNIGHTS7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2610 - KNIGHTS8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2611 - KNIGHTS9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2613 - KNIGHTS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KNIGHTS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2615 - KONG1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KONG1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KONG1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2616 - KONG2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KONG2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KONG2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2617 - KONG3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KONG3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KONG3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2618 - KONG4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KONG4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KONG4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2620 - KONGSTART.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KONGSTART.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KONGSTART.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2621 - KONG_WHOLE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KONG_WHOLE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KONG_WHOLE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2626 - KORPS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KORPS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KORPS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2633 - KUIPER10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KUIPER10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KUIPER10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2634 - KUIPER1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KUIPER1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KUIPER1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2635 - KUIPER8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KUIPER8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KUIPER8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2636 - KUIPER9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KUIPER9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KUIPER9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2637 - KUIPER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KUIPER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KUIPER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2638 - KURSK10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2639 - KURSK11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2640 - KURSK12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2641 - KURSK13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2642 - KURSK14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2643 - KURSK15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2644 - KURSK16.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK16.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK16.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2645 - KURSK17.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK17.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK17.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2653 - KURSK9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2654 - KURSK.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KURSK.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2655 - KUTENK.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/KUTENK.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/KUTENK.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2665 - LANDER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LANDER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LANDER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2666 - LANDER4K_MC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LANDER4K_MC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LANDER4K_MC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2667 - LANDER4K.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LANDER4K.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LANDER4K.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2669 - LANDER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LANDER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LANDER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2678 - LEM2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LEM2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LEM2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2679 - LEMMINGS1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LEMMINGS1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LEMMINGS1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2690 - LETTER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LETTER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LETTER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2691 - LETTERD.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LETTERD.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LETTERD.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2707 - LIFE10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2709 - LIFE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2711 - LIFE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2712 - LIFE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2716 - LIFE8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2718 - LIFE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2719 - LIFE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LIFE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2725 - linedrawSG4Simplified3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/linedrawSG4Simplified3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/linedrawSG4Simplified3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2728 - linelist.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/linelist.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/linelist.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2736 - LITTLEBR1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LITTLEBR1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LITTLEBR1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2737 - LITTLEBR2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LITTLEBR2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LITTLEBR2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2738 - LITTLEBR3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LITTLEBR3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LITTLEBR3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2739 - LITTLEBR4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LITTLEBR4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LITTLEBR4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2740 - LITTLEBR5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LITTLEBR5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LITTLEBR5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2755 - LODERUN18.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN18.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN18.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2756 - LODERUN19.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN19.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN19.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2757 - LODERUN20.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN20.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN20.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2758 - LODERUN21.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN21.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN21.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2759 - LODERUN22.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN22.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN22.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2760 - LODERUN23.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN23.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN23.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2761 - LODERUN24.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN24.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN24.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2762 - LODERUN25.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN25.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN25.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2763 - LODERUN26.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN26.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN26.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2764 - LODERUN28.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN28.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN28.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2776 - LODERUN6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LODERUN6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2780 - loderunneroriginal.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/loderunneroriginal.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/loderunneroriginal.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2802 - LUMPIES4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LUMPIES4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LUMPIES4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2803 - LUMPIES5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LUMPIES5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LUMPIES5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2804 - LUMPIES6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LUMPIES6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LUMPIES6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2805 - LUMPIES7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LUMPIES7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LUMPIES7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2806 - LUMPIES8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LUMPIES8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LUMPIES8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2811 - LUNLAND.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/LUNLAND.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/LUNLAND.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2824 - MAHJONG10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2825 - MAHJONG11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2826 - MAHJONG12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2827 - MAHJONG14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2828 - MAHJONG15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2829 - MAHJONG16.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG16.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG16.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2830 - MAHJONG17.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG17.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG17.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2831 - MAHJONG18.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG18.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG18.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2832 - MAHJONG19.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG19.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG19.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2833 - MAHJONG20.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG20.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG20.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2834 - MAHJONG2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2835 - MAHJONG3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2836 - MAHJONG4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2837 - MAHJONG5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2838 - MAHJONG6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2839 - MAHJONG7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2840 - MAHJONG8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2841 - MAHJONG9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2844 - MAHJONG.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAHJONG.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2852 - MANDEL2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MANDEL2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MANDEL2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2854 - MANDEL4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MANDEL4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MANDEL4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2855 - MANDEL5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MANDEL5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MANDEL5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2856 - MANDELBR.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MANDELBR.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MANDELBR.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2867 - map4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/map4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/map4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2875 - MAP.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAP.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAP.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2876 - MARIO.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MARIO.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MARIO.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2880 - MARRUD.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MARRUD.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MARRUD.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2881 - MARS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MARS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MARS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2889 - master.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/master.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/master.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2890 - MASTER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MASTER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MASTER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2896 - MATRIX.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MATRIX.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MATRIX.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2901 - MATTELFB14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MATTELFB14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MATTELFB14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2902 - MATTELFB15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MATTELFB15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MATTELFB15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2903 - MATTELFB16.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MATTELFB16.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MATTELFB16.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2919 - MAZERACE1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAZERACE1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAZERACE1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2920 - MAZERACE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAZERACE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAZERACE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2921 - MAZERACE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MAZERACE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MAZERACE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2937 - MC100020481.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MC100020481.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MC100020481.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2938 - MC10002048_2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MC10002048_2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MC10002048_2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2939 - MC10002048_3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MC10002048_3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MC10002048_3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2940 - MC10002048_4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MC10002048_4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MC10002048_4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2941 - MC10002048_5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MC10002048_5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MC10002048_5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2944 - MCBOMB.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCBOMB.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCBOMB.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2957 - MCJOUST10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2958 - MCJOUST11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2959 - MCJOUST12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2960 - MCJOUST13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2961 - MCJOUST14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2962 - MCJOUST15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2963 - MCJOUST2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2964 - MCJOUST3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2965 - MCJOUST4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2966 - MCJOUST5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2967 - MCJOUST6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2968 - MCJOUST7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2969 - MCJOUST8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2970 - MCJOUST9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCJOUST9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2973 - MCMINE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCMINE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCMINE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2974 - mcmine.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/mcmine.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/mcmine.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2975 - MCMINE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCMINE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCMINE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2978 - MCTETRIS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCTETRIS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCTETRIS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2979 - MCTETRIS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCTETRIS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCTETRIS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2980 - MCTETRIS4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCTETRIS4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCTETRIS4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2981 - MCTETRIS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCTETRIS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCTETRIS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2986 - MCVADERS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MCVADERS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MCVADERS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2994 - MEANIES3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MEANIES3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MEANIES3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2995 - MEANIES4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MEANIES4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MEANIES4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2996 - MEANIES5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MEANIES5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MEANIES5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2997 - MEANIES6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MEANIES6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MEANIES6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 2998 - MEANIES7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MEANIES7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MEANIES7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3008 - METEOR2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/METEOR2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/METEOR2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3009 - METEOR3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/METEOR3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/METEOR3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3010 - METEOR4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/METEOR4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/METEOR4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3011 - METEOR5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/METEOR5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/METEOR5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3017 - METEORS1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/METEORS1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/METEORS1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3018 - METEORS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/METEORS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/METEORS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3019 - METEORS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/METEORS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/METEORS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3020 - METEORS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/METEORS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/METEORS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3025 - METRIC2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/METRIC2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/METRIC2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3027 - MICROBES2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3028 - MICROBES3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3029 - MICROBES4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3030 - MICROBES5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3031 - MICROBES6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3032 - MICROBES7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3033 - MICROBES.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MICROBES.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3039 - MILLI0.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLI0.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLI0.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3043 - MILLI2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLI2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLI2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3044 - MILLI3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLI3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLI3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3045 - MILLI4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLI4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLI4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3053 - MILLIPED1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLIPED1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLIPED1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3054 - MILLIPED2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLIPED2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLIPED2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3055 - MILLIPED3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLIPED3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLIPED3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3056 - MILLIPED4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLIPED4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLIPED4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3057 - MILLIPED5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLIPED5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MILLIPED5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3087 - MINER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3088 - MINES.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINES.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINES.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3090 - MINIDUNG1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIDUNG1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIDUNG1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3092 - MINIDUNG3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIDUNG3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIDUNG3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3093 - MINIDUNG4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIDUNG4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIDUNG4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3094 - MINIDUNG5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIDUNG5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIDUNG5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3095 - MINIDUNG.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIDUNG.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIDUNG.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3097 - MINIPAC_10LINER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC_10LINER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC_10LINER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3098 - MINIPAC2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3099 - MINIPAC3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3100 - MINIPAC4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3101 - MINIPAC5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3102 - MINIPAC6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3103 - MINIPAC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINIPAC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3112 - MINITAUR2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINITAUR2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINITAUR2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3113 - MINITAUR3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINITAUR3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINITAUR3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3114 - MINITAUR4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINITAUR4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINITAUR4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3115 - MINITAUR5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINITAUR5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINITAUR5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3116 - MINITAUR6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MINITAUR6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MINITAUR6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3130 - MISSION3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MISSION3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MISSION3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3131 - MISSION4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MISSION4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MISSION4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3132 - MISSION5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MISSION5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MISSION5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3133 - MISSION6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MISSION6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MISSION6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3134 - MISSION7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MISSION7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MISSION7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3136 - Missle.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/Missle.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/Missle.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3137 - MMAZE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MMAZE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MMAZE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3138 - mmind.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/mmind.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/mmind.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3141 - MNOPLY4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MNOPLY4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MNOPLY4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3142 - MNOPLY5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MNOPLY5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MNOPLY5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3143 - MNOPLY6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MNOPLY6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MNOPLY6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3146 - MOCKUP.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOCKUP.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOCKUP.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3159 - MONSTER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3161 - MONSTER4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3162 - MONSTER5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3163 - MONSTER6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3164 - MONSTER7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3165 - MONSTER8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3166 - MONSTER9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MONSTER9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3175 - MOONFX1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3176 - MOONFX2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3177 - MOONFX3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3178 - MOONFX4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3179 - MOONFX5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3180 - MOONFX6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3181 - MOONFX7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3182 - MOONFX8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONFX8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3184 - MOONL.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONL.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONL.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3190 - MOONTST.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONTST.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOONTST.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3195 - MORLOCK4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MORLOCK4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MORLOCK4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3196 - MORLOCK5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MORLOCK5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MORLOCK5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3197 - MORLOCK6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MORLOCK6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MORLOCK6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3220 - MOUSE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3221 - MOUSE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3222 - MOUSE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3223 - MOUSE5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3224 - MOUSE6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3225 - MOUSE7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3229 - MOUSE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MOUSE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3248 - MSEARCH.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MSEARCH.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MSEARCH.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3249 - MTFUJI1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3250 - MTFUJI2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3251 - MTFUJI3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3252 - MTFUJI4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3253 - MTFUJI5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3254 - MTFUJI6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3255 - MTFUJI7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJI7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3256 - MTFUJIcompiler7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJIcompiler7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MTFUJIcompiler7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3261 - MUMMY.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/MUMMY.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/MUMMY.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3281 - NBLITZ2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NBLITZ2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NBLITZ2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3282 - NBLITZ3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NBLITZ3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NBLITZ3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3283 - NBLITZ4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NBLITZ4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NBLITZ4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3284 - NBLITZ5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NBLITZ5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NBLITZ5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3285 - NBLITZ6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NBLITZ6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NBLITZ6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3286 - NBLITZ7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NBLITZ7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NBLITZ7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3301 - NEWMAHJ2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NEWMAHJ2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NEWMAHJ2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3302 - NEWMAHJ3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NEWMAHJ3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NEWMAHJ3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3303 - NEWMAHJ4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NEWMAHJ4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NEWMAHJ4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3314 - NEWPOKER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NEWPOKER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NEWPOKER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3315 - NEWPOKER3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NEWPOKER3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NEWPOKER3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3316 - NEWPOKER4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NEWPOKER4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NEWPOKER4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3319 - NewSudoku.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NewSudoku.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NewSudoku.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3322 - NFLIGHT3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NFLIGHT3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NFLIGHT3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3334 - NINJA2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NINJA2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NINJA2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3335 - NINJA3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NINJA3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NINJA3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3337 - nmahjong.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/nmahjong.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/nmahjong.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3340 - nolist.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/nolist.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/nolist.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3365 - NOSTROMO2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NOSTROMO2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NOSTROMO2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3367 - NOSTROMO4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NOSTROMO4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NOSTROMO4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3369 - NOSTROMO6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NOSTROMO6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NOSTROMO6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3370 - NOSTROMO7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NOSTROMO7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NOSTROMO7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3371 - NOSTROMO8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NOSTROMO8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NOSTROMO8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3376 - NOTETEST2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NOTETEST2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NOTETEST2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3377 - NOTETEST3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NOTETEST3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NOTETEST3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3378 - NOTETEST.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NOTETEST.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NOTETEST.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3385 - NUKEWAR4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NUKEWAR4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NUKEWAR4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3394 - NYAN1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NYAN1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NYAN1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3395 - NYAN2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NYAN2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NYAN2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3396 - NYAN3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NYAN3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NYAN3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3397 - NYAN4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NYAN4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NYAN4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3398 - NYAN5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/NYAN5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/NYAN5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3400 - ODE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ODE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ODE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3401 - ODE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ODE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ODE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3404 - OLDMAID2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OLDMAID2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OLDMAID2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3405 - OLDMAID3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OLDMAID3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OLDMAID3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3412 - ONEROOM5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ONEROOM5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ONEROOM5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3413 - ONEROOM6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ONEROOM6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ONEROOM6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3415 - ONO2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ONO2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ONO2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3416 - ONO3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ONO3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ONO3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3429 - ORANGE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ORANGE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ORANGE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3431 - ORBIT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ORBIT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ORBIT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3453 - OURANOS10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3454 - OURANOS1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3455 - OURANOS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3456 - OURANOS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3458 - OURANOS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3459 - OURANOS6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3460 - OURANOS7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3461 - OURANOS8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3462 - OURANOS9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OURANOS9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3463 - OUTHOUSEGerman.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OUTHOUSEGerman.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OUTHOUSEGerman.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3464 - OUTHOUSE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OUTHOUSE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OUTHOUSE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3465 - OVERTAKE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OVERTAKE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OVERTAKE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3466 - OVERTAKE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OVERTAKE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OVERTAKE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3467 - OVERTAKE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OVERTAKE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OVERTAKE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3468 - OVERTAKE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/OVERTAKE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/OVERTAKE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3476 - PAC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PAC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PAC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3477 - PA-DUTCH.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PA-DUTCH.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PA-DUTCH.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3479 - PAINTDUL3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PAINTDUL3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PAINTDUL3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3480 - PAINT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PAINT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PAINT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3481 - panzerschreck.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/panzerschreck.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/panzerschreck.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3484 - PARAVIA10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PARAVIA10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PARAVIA10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3485 - PARAVIA11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PARAVIA11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PARAVIA11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3486 - PARAVIA12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PARAVIA12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PARAVIA12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3487 - PARAVIA13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PARAVIA13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PARAVIA13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3488 - PARAVIA14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PARAVIA14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PARAVIA14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3495 - PARAVIA9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PARAVIA9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PARAVIA9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3499 - PATTERN1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PATTERN1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PATTERN1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3500 - PEEPER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PEEPER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PEEPER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3501 - Peeper.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/Peeper.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/Peeper.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3502 - PEG.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PEG.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PEG.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3504 - PENDU2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENDU2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENDU2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3507 - PENDU.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENDU.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENDU.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3508 - PENGO2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3509 - PENGO3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3510 - PENGO4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3513 - PENGO7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3514 - PENGO8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3515 - PENGO9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3516 - PENGO.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGO.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3517 - PENGUINO1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3518 - PENGUINO2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3519 - PENGUINO3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3520 - PENGUINO4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3521 - PENGUINO6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3522 - PENGUINO7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3523 - PENGUINO_Fast.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO_Fast.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO_Fast.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3524 - PENGUINO_Original.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO_Original.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO_Original.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3525 - PENGUINO_Special.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO_Special.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PENGUINO_Special.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3538 - PICS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PICS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PICS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3539 - PIGS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIGS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIGS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3543 - PINBALLcompile.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PINBALLcompile.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PINBALLcompile.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3544 - PINBALL.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PINBALL.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PINBALL.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3546 - PIPES10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3547 - PIPES11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3548 - PIPES14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3549 - PIPES15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3550 - PIPES16.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES16.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES16.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3551 - PIPES17.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES17.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES17.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3552 - PIPES18.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES18.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES18.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3553 - PIPES19.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES19.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES19.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3554 - PIPES20.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES20.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES20.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3555 - PIPES21.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES21.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES21.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3556 - PIPES22.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES22.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES22.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3557 - PIPES23.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES23.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES23.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3561 - PIPES5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3562 - PIPES6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3566 - PIPESAlice.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPESAlice.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPESAlice.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3567 - PIPES_COCO_OLD.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES_COCO_OLD.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PIPES_COCO_OLD.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3607 - PLAY2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PLAY2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PLAY2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3612 - PLAYBACK.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PLAYBACK.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PLAYBACK.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3618 - PLUM.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PLUM.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PLUM.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3619 - PLUNKIT1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PLUNKIT1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PLUNKIT1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3620 - PLUNKIT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PLUNKIT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PLUNKIT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3621 - PLUNKIT3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PLUNKIT3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PLUNKIT3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3634 - POET.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/POET.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/POET.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3637 - POKER1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/POKER1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/POKER1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3643 - POLAR.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/POLAR.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/POLAR.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3644 - POLYBIUS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/POLYBIUS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/POLYBIUS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3665 - POS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/POS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/POS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3666 - PRESTAVBA2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PRESTAVBA2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PRESTAVBA2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3667 - PRESTAVBA3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PRESTAVBA3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PRESTAVBA3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3668 - PRESTAVBA4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PRESTAVBA4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PRESTAVBA4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3669 - PRESTAVBA5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PRESTAVBA5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PRESTAVBA5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3670 - PRESTAVBA6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PRESTAVBA6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PRESTAVBA6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3674 - printercheck.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/printercheck.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/printercheck.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3675 - PRINTLEADINGZEROS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PRINTLEADINGZEROS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PRINTLEADINGZEROS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3677 - PRINTUSING2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PRINTUSING2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PRINTUSING2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3678 - PRINTUSING3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PRINTUSING3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PRINTUSING3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3681 - PROVINCE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PROVINCE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PROVINCE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3689 - PUZZLE2048_7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PUZZLE2048_7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PUZZLE2048_7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3690 - PYRAMID10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3691 - PYRAMID2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3692 - PYRAMID3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3693 - PYRAMID4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3694 - PYRAMID5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3695 - PYRAMID6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3696 - PYRAMID7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3697 - PYRAMID8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3698 - PYRAMID9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3701 - PYRAMID.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PYRAMID.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3702 - PYTHON.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/PYTHON.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/PYTHON.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3703 - QBERT10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3704 - QBERT11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3705 - QBERT12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3706 - QBERT13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3707 - QBERT14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3708 - QBERT15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3709 - QBERT16.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT16.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT16.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3710 - QBERT17.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT17.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT17.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3711 - QBERT18.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT18.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT18.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3715 - QBERT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3716 - QBERT3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3717 - QBERT4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3718 - QBERT5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3720 - QBERT7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3721 - QBERT8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3722 - QBERT9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QBERT9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3729 - QIX3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3730 - QIX4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3731 - QIX5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3732 - QIX6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3733 - QIX7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3734 - QIX8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3735 - QIX9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3736 - QIXNEW.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QIXNEW.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QIXNEW.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3737 - QIX.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QIX.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3739 - QUATRAIN2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QUATRAIN2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QUATRAIN2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3740 - QUATRAIN3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QUATRAIN3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QUATRAIN3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3745 - QUEBEC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QUEBEC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QUEBEC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3751 - QUEST2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QUEST2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QUEST2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3754 - QUIX1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIX1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIX1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3755 - QUIX2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIX2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIX2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3756 - QUIX6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIX6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIX6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3757 - QUIX.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIX.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIX.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3758 - QUIZNITE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIZNITE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIZNITE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3759 - QUIZNITE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIZNITE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIZNITE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3761 - QUIZNITE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIZNITE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/QUIZNITE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3762 - r29mocks.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/r29mocks.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/r29mocks.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3764 - RACEDRIV2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RACEDRIV2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RACEDRIV2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3768 - RAID2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAID2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAID2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3780 - RAIDER1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIDER1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIDER1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3809 - RAIL0.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL0.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL0.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3810 - RAIL10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3811 - RAIL11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3812 - RAIL12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3813 - RAIL1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3814 - RAIL2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3815 - RAIL3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3819 - RAIL4K.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL4K.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL4K.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3821 - RAIL7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAIL7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3825 - RAINMAZE1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAINMAZE1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAINMAZE1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3826 - RAINMAZE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAINMAZE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAINMAZE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3831 - RANDLIST.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RANDLIST.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RANDLIST.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3836 - RANGER1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RANGER1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RANGER1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3846 - RAT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3850 - RATOLD.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RATOLD.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RATOLD.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3855 - RAT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RAT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RAT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3856 - RBOMBER1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RBOMBER1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RBOMBER1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3857 - RBOMBER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RBOMBER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RBOMBER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3858 - RBOMBER3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RBOMBER3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RBOMBER3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3859 - RBOMBER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RBOMBER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RBOMBER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3875 - REDALERT1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/REDALERT1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/REDALERT1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3876 - REDALERT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/REDALERT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/REDALERT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3877 - REDGREEN2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/REDGREEN2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/REDGREEN2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3878 - REDGREEN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/REDGREEN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/REDGREEN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3881 - RENEGADE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RENEGADE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RENEGADE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3892 - RESTORE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RESTORE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RESTORE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3893 - REVERSE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/REVERSE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/REVERSE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3894 - REVERSE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/REVERSE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/REVERSE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3906 - RIGHTJUSTIFYNUM.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RIGHTJUSTIFYNUM.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RIGHTJUSTIFYNUM.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3907 - RISK1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3908 - RISK2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3909 - RISK3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3910 - RISK4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3911 - RISK5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3912 - RISK6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3913 - RISK7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3914 - RISK8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3916 - RISK.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RISK.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3920 - ROADRACE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3921 - ROADRACE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3922 - ROADRACE5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3923 - ROADRACE6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3924 - ROADRACE7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3925 - ROADRACE8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3926 - ROADRACE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROADRACE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3929 - ROBOTNIM1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROBOTNIM1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROBOTNIM1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3935 - ROBOTR29_2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROBOTR29_2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROBOTR29_2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3936 - ROBOTR29_3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROBOTR29_3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROBOTR29_3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3937 - ROBOTR29_4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROBOTR29_4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROBOTR29_4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3938 - ROBOTR29_5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROBOTR29_5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROBOTR29_5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3943 - ROCKET1_3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROCKET1_3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROCKET1_3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3944 - ROCKET1_4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROCKET1_4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROCKET1_4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3945 - ROCKET1_5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROCKET1_5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROCKET1_5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3957 - ROMP9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROMP9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROMP9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3958 - ROMP_old.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROMP_old.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROMP_old.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3961 - RonDelvauxDemoDiscovery.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RonDelvauxDemoDiscovery.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RonDelvauxDemoDiscovery.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3966 - ROOMS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROOMS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROOMS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3967 - roomstuff.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/roomstuff.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/roomstuff.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3981 - ROULVZ2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROULVZ2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROULVZ2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3982 - ROULVZ3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROULVZ3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROULVZ3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3983 - ROULVZ4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROULVZ4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROULVZ4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3984 - ROULVZ.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROULVZ.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROULVZ.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3985 - ROVER10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3986 - ROVER11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3989 - ROVER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3990 - ROVER3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3991 - ROVER4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3992 - ROVER5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3993 - ROVER6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3994 - ROVER7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3995 - ROVER8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3996 - ROVER9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3997 - ROVER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ROVER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3998 - RROID10mcx.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID10mcx.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID10mcx.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 3999 - RROID10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4000 - RROID11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4001 - RROID12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4002 - RROID13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4003 - RROID14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4004 - RROID15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4007 - RROID2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4008 - RROID3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4009 - RROID4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4010 - RROID5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4011 - RROID6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4012 - RROID7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4013 - RROID8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4014 - RROID9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4015 - RROID.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RROID.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4021 - RRUNNER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RRUNNER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RRUNNER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4029 - RUBIK3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RUBIK3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RUBIK3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4030 - RUBIK4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RUBIK4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RUBIK4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4031 - RUBIK5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RUBIK5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RUBIK5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4033 - RUDOLF.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/RUDOLF.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/RUDOLF.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4036 - SABOT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SABOT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SABOT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4046 - SABOT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SABOT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SABOT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4047 - SADFACE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SADFACE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SADFACE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4050 - SAINTS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SAINTS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SAINTS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4051 - SAINTS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SAINTS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SAINTS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4055 - SANTA.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SANTA.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SANTA.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4059 - SAVESPOK.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SAVESPOK.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SAVESPOK.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4066 - SCEPTRE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCEPTRE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCEPTRE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4067 - SCORE1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCORE1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCORE1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4068 - SCRABBLE10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4069 - SCRABBLE11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4070 - SCRABBLE12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4071 - SCRABBLE13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4072 - SCRABBLE14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4073 - SCRABBLE15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4074 - SCRABBLE16.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE16.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE16.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4075 - SCRABBLE17.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE17.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE17.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4076 - SCRABBLE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4078 - SCRABBLE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4080 - SCRABBLE6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4082 - SCRABBLE8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4083 - SCRABBLE9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLE9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4085 - SCRABBLEhelp.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLEhelp.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRABBLEhelp.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4108 - SCRAMBLE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4116 - SCRAMBLE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4117 - SCRAMBLE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4120 - SCRAMBLE7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4121 - SCRAMBLE8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4122 - SCRAMBLE9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4124 - SCRAMBLE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SCRAMBLE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4156 - SEAQUEST1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SEAQUEST1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SEAQUEST1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4157 - SEAWAR1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SEAWAR1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SEAWAR1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4158 - SEAWAR2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SEAWAR2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SEAWAR2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4159 - SEAWAR3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SEAWAR3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SEAWAR3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4160 - SEAWAR.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SEAWAR.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SEAWAR.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4161 - SENTINEL1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SENTINEL1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SENTINEL1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4162 - SENTINEL2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SENTINEL2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SENTINEL2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4163 - SENTINEL3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SENTINEL3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SENTINEL3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4164 - SENTINEL4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SENTINEL4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SENTINEL4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4165 - SENTINEL.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SENTINEL.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SENTINEL.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4167 - SG6GRAPHICS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SG6GRAPHICS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SG6GRAPHICS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4170 - SG6_UTILS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SG6_UTILS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SG6_UTILS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4171 - SG6_UTILS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SG6_UTILS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SG6_UTILS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4189 - SHEBOYGN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SHEBOYGN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SHEBOYGN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4190 - SHEEPDOG2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SHEEPDOG2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SHEEPDOG2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4198 - SHERLOCK5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SHERLOCK5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SHERLOCK5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4202 - SHIFT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SHIFT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SHIFT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4207 - SHOOTOUT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SHOOTOUT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SHOOTOUT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4227 - SHUFFLE1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SHUFFLE1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SHUFFLE1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4228 - SHUFFLE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SHUFFLE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SHUFFLE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4254 - SKIDROW2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SKIDROW2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SKIDROW2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4256 - SKIER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SKIER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SKIER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4257 - SKIER3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SKIER3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SKIER3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4258 - SKIER4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SKIER4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SKIER4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4259 - SKIER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SKIER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SKIER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4275 - SLALOM.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SLALOM.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SLALOM.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4283 - SLIDER4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SLIDER4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SLIDER4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4284 - SLIDER5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SLIDER5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SLIDER5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4299 - SNAKE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4300 - SNAKE5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKE5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKE5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4301 - SNAKE6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKE6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKE6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4302 - SNAKEBIT10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4303 - SNAKEBIT11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4304 - SNAKEBIT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4306 - SNAKEBIT4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4307 - SNAKEBIT5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4308 - SNAKEBIT6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4309 - SNAKEBIT7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4310 - SNAKEBIT8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4311 - SNAKEBIT9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4312 - SNAKEBIT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNAKEBIT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4314 - SNIPER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNIPER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNIPER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4318 - SNOWTREE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNOWTREE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNOWTREE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4319 - SNOWTREE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SNOWTREE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SNOWTREE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4320 - SOCCER1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOCCER1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOCCER1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4324 - SOKOBAN1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4325 - SOKOBAN2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4326 - SOKOBAN3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4327 - SOKOBAN4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4328 - SOKOBAN5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4329 - SOKOBAN6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4330 - SOKOBAN7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4331 - SOKOBAN8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4332 - SOKOBAN9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4333 - SOKOBAN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOKOBAN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4344 - SOLCHESS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOLCHESS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOLCHESS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4348 - SOLITAIRE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOLITAIRE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOLITAIRE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4349 - SOLITAIRE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOLITAIRE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOLITAIRE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4369 - SOUNDS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SOUNDS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SOUNDS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4374 - SPACEDUL1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEDUL1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEDUL1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4384 - SPACETRK8_2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACETRK8_2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACETRK8_2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4385 - SPACETRK8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACETRK8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACETRK8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4386 - SPACETRK9_2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACETRK9_2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACETRK9_2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4387 - SPACETRK9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACETRK9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACETRK9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4390 - SPACEWALL3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWALL3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWALL3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4391 - SPACEWALL4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWALL4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWALL4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4392 - SPACEWALL5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWALL5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWALL5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4393 - SPACEWALL6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWALL6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWALL6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4394 - SPACEWALL7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWALL7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWALL7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4395 - SPACEWALL8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWALL8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWALL8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4396 - SPACEWAL.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWAL.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACEWAL.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4405 - SPACSLAL2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACSLAL2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACSLAL2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4406 - SPACSLAL3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACSLAL3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACSLAL3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4407 - SPACSLAL4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACSLAL4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPACSLAL4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4411 - SPANISH.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPANISH.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPANISH.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4412 - sparkle.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/sparkle.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/sparkle.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4413 - SPCTAXI1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPCTAXI1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPCTAXI1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4417 - SPCWAR10linerORIGINAL.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPCWAR10linerORIGINAL.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPCWAR10linerORIGINAL.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4418 - SPCWAR10liner.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPCWAR10liner.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPCWAR10liner.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4419 - SPCWAR4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPCWAR4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPCWAR4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4423 - SPEEDTST.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPEEDTST.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPEEDTST.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4428 - SPHINX3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPHINX3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPHINX3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4429 - SPHINX4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPHINX4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPHINX4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4430 - SPHINX5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPHINX5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPHINX5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4432 - SPIDER3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPIDER3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPIDER3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4434 - SPIRAL.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPIRAL.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPIRAL.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4436 - SPRINGER1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SPRINGER1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SPRINGER1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4439 - sprkle.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/sprkle.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/sprkle.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4441 - SQUARE10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4442 - SQUARE11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4444 - SQUARE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4445 - SQUARE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4446 - SQUARE5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4447 - SQUARE6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4448 - SQUARE7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4449 - SQUARE8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4450 - SQUARE9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4451 - SQUARE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SQUARE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4468 - STARFIND.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/STARFIND.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/STARFIND.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4477 - STARMAP3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/STARMAP3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/STARMAP3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4478 - STARMAP4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/STARMAP4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/STARMAP4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4479 - STARMAP5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/STARMAP5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/STARMAP5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4480 - STARMAP6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/STARMAP6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/STARMAP6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4500 - STARTREK2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/STARTREK2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/STARTREK2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4505 - star.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/star.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/star.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4514 - STELLEMP4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/STELLEMP4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/STELLEMP4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4532 - STRATEGY.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/STRATEGY.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/STRATEGY.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4533 - STRENCH0.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/STRENCH0.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/STRENCH0.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4536 - STTR1_1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/STTR1_1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/STTR1_1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4537 - STTR1_2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/STTR1_2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/STTR1_2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4538 - SUBHUNT2_1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUBHUNT2_1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUBHUNT2_1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4539 - SUBHUNT2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUBHUNT2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUBHUNT2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4540 - SUBHUNT3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUBHUNT3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUBHUNT3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4541 - SUBHUNT.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUBHUNT.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUBHUNT.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4543 - SUBSRCH.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUBSRCH.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUBSRCH.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4557 - SUDOKGEN3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKGEN3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKGEN3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4567 - SUDOKU3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKU3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKU3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4570 - SUDOKU6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKU6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKU6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4574 - SUDOKUB2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKUB2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKUB2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4575 - SUDOKUB3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKUB3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKUB3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4576 - SUDOKUB.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKUB.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKUB.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4583 - SUDOKU.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKU.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUDOKU.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4587 - SUNRISE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUNRISE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUNRISE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4588 - SUNRISE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUNRISE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUNRISE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4589 - SUNRISE5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SUNRISE5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SUNRISE5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4603 - SWEEPER1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPER1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPER1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4604 - SWEEPER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4605 - SWEEPER3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPER3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPER3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4606 - SWEEPER4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPER4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPER4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4607 - SWEEPER5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPER5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPER5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4608 - SWEEPER6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPER6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPER6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4609 - SWEEPERHard.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPERHard.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPERHard.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4610 - SWEEPERLongVersion.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPERLongVersion.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWEEPERLongVersion.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4612 - sweepSPY.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/sweepSPY.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/sweepSPY.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4614 - SWELFOOP2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWELFOOP2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWELFOOP2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4615 - SWELFOOP3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWELFOOP3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWELFOOP3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4616 - SWELFOOP4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWELFOOP4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWELFOOP4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4617 - SWELFOOP5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWELFOOP5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWELFOOP5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4618 - SWELFOOP6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWELFOOP6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWELFOOP6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4619 - SWELFOOP7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWELFOOP7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWELFOOP7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4623 - swellfoop9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/swellfoop9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/swellfoop9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4624 - SWITCH2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWITCH2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWITCH2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4625 - SWITCH3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWITCH3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWITCH3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4626 - SWITCH5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWITCH5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWITCH5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4627 - SWITCH6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWITCH6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWITCH6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4631 - SWORDMAN2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SWORDMAN2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SWORDMAN2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4638 - SYLLOGY.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/SYLLOGY.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/SYLLOGY.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4652 - TAIPAN2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TAIPAN2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TAIPAN2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4653 - TAIPAN3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TAIPAN3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TAIPAN3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4654 - TAIPAN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TAIPAN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TAIPAN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4655 - TANK10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4656 - TANK11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4657 - TANK2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4658 - TANK3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4659 - TANK4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4660 - TANK5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4661 - TANK6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4662 - TANK7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4663 - TANK8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4664 - TANK9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4665 - TANKB.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANKB.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANKB.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4666 - TANKCAP2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANKCAP2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANKCAP2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4667 - TANKCAP3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANKCAP3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANKCAP3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4668 - TANKCAP4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANKCAP4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANKCAP4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4669 - TANKCAP5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANKCAP5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANKCAP5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4670 - TANKCAP.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANKCAP.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANKCAP.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4671 - TANK.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANK.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4672 - TANNEN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TANNEN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TANNEN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4673 - TARDIS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TARDIS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TARDIS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4676 - TAXI.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TAXI.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TAXI.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4678 - TBIRD2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TBIRD2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TBIRD2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4679 - TBIRD3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TBIRD3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TBIRD3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4680 - TBIRD4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TBIRD4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TBIRD4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4721 - TESTCARDS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TESTCARDS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TESTCARDS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4728 - TETRIS10Liner4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TETRIS10Liner4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TETRIS10Liner4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4730 - TETRIS1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TETRIS1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TETRIS1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4731 - TETRIS4K_MC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TETRIS4K_MC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TETRIS4K_MC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4732 - TETRIS4K.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TETRIS4K.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TETRIS4K.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4761 - TIMBER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4762 - TIMBER3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4763 - TIMBER4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4764 - TIMBER5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4765 - TIMBER6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4766 - TIMBER7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4767 - TIMBER8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4768 - TIMBER9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4769 - TIMBER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMBER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4770 - TIMEBOMB2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMEBOMB2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMEBOMB2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4771 - TIMEBOMB3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMEBOMB3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMEBOMB3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4772 - TIMEBOMB.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMEBOMB.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMEBOMB.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4775 - TIMEMACH6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMEMACH6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMEMACH6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4776 - TIMEMACH7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMEMACH7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMEMACH7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4777 - TIMEMACHcoco.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMEMACHcoco.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TIMEMACHcoco.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4788 - TITLETEST.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TITLETEST.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TITLETEST.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4813 - TOMB2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TOMB2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TOMB2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4814 - TOMB3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TOMB3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TOMB3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4829 - TOUCHDN.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TOUCHDN.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TOUCHDN.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4830 - TOUPPER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TOUPPER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TOUPPER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4831 - TOURIST2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TOURIST2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TOURIST2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4836 - TOWER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TOWER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TOWER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4837 - town.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/town.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/town.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4840 - TRADE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRADE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRADE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4841 - TRADE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRADE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRADE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4843 - TRAINS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRAINS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRAINS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4852 - TRAVELER5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRAVELER5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRAVELER5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4853 - TRAVELER6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRAVELER6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRAVELER6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4854 - TRAVELER7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRAVELER7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRAVELER7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4860 - TREASURE4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TREASURE4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TREASURE4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4863 - TREBUCHET10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4865 - TREBUCHET3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4866 - TREBUCHET4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4867 - TREBUCHET5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4868 - TREBUCHET6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4869 - TREBUCHET7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4870 - TREBUCHET8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4871 - TREBUCHET9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TREBUCHET9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4886 - TRENCHFIR0.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRENCHFIR0.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRENCHFIR0.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4887 - TRENCHFIR2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRENCHFIR2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRENCHFIR2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4888 - TRENCHFIR3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRENCHFIR3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRENCHFIR3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4889 - TRIG1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRIG1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRIG1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4890 - TRIG1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRIG1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRIG1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4891 - TRIG2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRIG2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRIG2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4892 - TRIG2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRIG2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRIG2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4896 - TRON3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRON3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRON3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4897 - TRON4K.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TRON4K.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TRON4K.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4903 - TUGAWAR.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUGAWAR.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUGAWAR.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4905 - Tune.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/Tune.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/Tune.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4906 - TUNE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4908 - TUNNELS10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4909 - TUNNELS11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4910 - TUNNELS12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4911 - TUNNELS13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4913 - TUNNELS15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4914 - TUNNELS16.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS16.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS16.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4915 - TUNNELS17.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS17.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS17.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4916 - TUNNELS18.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS18.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS18.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4917 - TUNNELS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4918 - TUNNELS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4919 - TUNNELS4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4920 - TUNNELS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4921 - TUNNELS6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4922 - TUNNELS7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4923 - TUNNELS8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4924 - TUNNELS9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUNNELS9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4928 - TURKEY2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TURKEY2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TURKEY2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4929 - TURKEY3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TURKEY3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TURKEY3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4930 - TURKEY4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TURKEY4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TURKEY4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4931 - TURKEY.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TURKEY.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TURKEY.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4932 - TURTLE1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TURTLE1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TURTLE1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4938 - TUTTUT10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4939 - TUTTUT11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4940 - TUTTUT12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4941 - TUTTUT13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4946 - TUTTUT6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4947 - TUTTUT7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4948 - TUTTUT8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4949 - TUTTUT9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/TUTTUT9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 4985 - UNCLETAY9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/UNCLETAY9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/UNCLETAY9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5004 - UNITS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/UNITS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/UNITS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5005 - UPWEGO2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/UPWEGO2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/UPWEGO2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5006 - UPWEGO.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/UPWEGO.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/UPWEGO.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5007 - USFLAG.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/USFLAG.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/USFLAG.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5009 - VADER2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VADER2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VADER2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5010 - VADER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VADER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VADER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5011 - VAISSEAU2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VAISSEAU2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VAISSEAU2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5013 - VALENTINE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VALENTINE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VALENTINE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5014 - VALHALLA2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VALHALLA2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VALHALLA2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5034 - VALLEYDRAW.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VALLEYDRAW.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VALLEYDRAW.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5047 - VESPOZIA11.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA11.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA11.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5048 - VESPOZIA12.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA12.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA12.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5049 - VESPOZIA13.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA13.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA13.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5050 - VESPOZIA14.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA14.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA14.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5051 - VESPOZIA15.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA15.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA15.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5056 - VESPOZIA6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5057 - VESPOZIA7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5058 - VESPOZIA8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5059 - VESPOZIA9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/VESPOZIA9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5068 - vmc10.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/vmc10.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/vmc10.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5102 - WAR3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WAR3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WAR3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5103 - WARBIRDS1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5104 - WARBIRDS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5105 - WARBIRDS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5106 - WARBIRDS4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5107 - WARBIRDS5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5108 - WARBIRDS6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5109 - WARBIRDS7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5110 - WARBIRDS8.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS8.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS8.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5111 - WARBIRDS9.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS9.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WARBIRDS9.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5113 - WARLORDS3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WARLORDS3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WARLORDS3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5114 - WARLORDS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WARLORDS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WARLORDS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5125 - WEATHER.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WEATHER.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WEATHER.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5130 - WEREWOLFOld.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WEREWOLFOld.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WEREWOLFOld.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5151 - WITCHING2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WITCHING2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WITCHING2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5152 - WITCHING3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WITCHING3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WITCHING3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5153 - WITCHING4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WITCHING4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WITCHING4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5181 - WORDWRAP2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAP2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAP2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5182 - WORDWRAP3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAP3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAP3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5183 - WORDWRAP4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAP4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAP4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5184 - WORDWRAP5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAP5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAP5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5185 - WORDWRAP6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAP6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAP6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5186 - WORDWRAPcoco.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAPcoco.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAPcoco.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5187 - WORDWRAP.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAP.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WORDWRAP.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5210 - WPTEST.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WPTEST.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WPTEST.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5211 - WRDMUSIC.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WRDMUSIC.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WRDMUSIC.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5216 - WUMPUS2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WUMPUS2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WUMPUS2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5217 - WUMPUS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WUMPUS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WUMPUS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5218 - WW.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/WW.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/WW.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5222 - XMAS2019_10-Liner2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/XMAS2019_10-Liner2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/XMAS2019_10-Liner2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5223 - XMAS2019_10-Liner.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/XMAS2019_10-Liner.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/XMAS2019_10-Liner.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5224 - XMAS2019_2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/XMAS2019_2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/XMAS2019_2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5225 - XMAS2019_3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/XMAS2019_3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/XMAS2019_3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5227 - XMAS2019.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/XMAS2019.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/XMAS2019.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5230 - XMAS.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/XMAS.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/XMAS.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5240 - XRALLY1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5241 - XRALLY2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5242 - XRALLY3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5243 - XRALLY4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5244 - XRALLY5.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY5.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY5.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5245 - XRALLY6.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY6.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY6.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5246 - XRALLY7.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY7.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/XRALLY7.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5252 - YAHTZEE1.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/YAHTZEE1.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/YAHTZEE1.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5253 - YAHTZEE2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/YAHTZEE2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/YAHTZEE2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5254 - YAHTZEE3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/YAHTZEE3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/YAHTZEE3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5255 - YAHTZEE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/YAHTZEE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/YAHTZEE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5258 - ZECTOR2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ZECTOR2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ZECTOR2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5259 - ZECTOR3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ZECTOR3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ZECTOR3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5260 - ZECTOR4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ZECTOR4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ZECTOR4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5271 - ZOMBIES2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ZOMBIES2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ZOMBIES2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5272 - ZOMBIES3.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ZOMBIES3.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ZOMBIES3.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5273 - ZOMBIES4.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ZOMBIES4.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ZOMBIES4.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5274 - ZOMBIES.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ZOMBIES.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ZOMBIES.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5275 - ZOMBIE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ZOMBIE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ZOMBIE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5278 - ZXLIFE.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ZXLIFE.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ZXLIFE.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5279 - ZYMON2.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ZYMON2.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ZYMON2.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5280 - ZYMONDeprecated.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ZYMONDeprecated.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ZYMONDeprecated.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear
echo 5281 - ZYMON.wav
echo
echo Make sure to type CLOADM on MC-10 and ...
read -p "Press any key to continue... " -n1 -s
echo
echo Playing /media/share1/source/MC-10/BASIC/JIMG/compiled/ZYMON.wav ...
echo
omxplayer -p -o hdmi /media/share1/source/MC-10/BASIC/JIMG/compiled/ZYMON.wav
echo
echo Now type EXEC on the MC-10.
read -p "Press any key to continue... " -n1 -s
echo
echo
clear

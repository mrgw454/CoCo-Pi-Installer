#!/bin/bash

# unmount all samba share connections
sudo umount -a -t cifs

#sudo du -hs * | sort -rh | head -5
find . -xdev -mindepth 2 -maxdepth 2 -type d  -exec du -hs {} + | sort -rh | head -10

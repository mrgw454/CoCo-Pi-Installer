#!/bin/bash

if [ ! -d $HOME/source/coco-shelf/build-frobio ]; then
	echo
	echo $HOME/source/coco-shelf/build-frobio folder missing!
	echo
	echo Please make sure to install coco-shelf project prior to using this script.  Aborting.
	echo
	exit 1
fi

# start local instance of Lemma server for use with CoCoIO network cartridge
cd $HOME/source/coco-shelf/build-frobio

IPADDR=$(hostname  -I | cut -f1 -d' ')
echo Local IP address is: $IPADDR
echo

echo Use [CTRL-C] to stop Lemma server.
echo
echo

make run-lemma LAN=$IPADDR DHCP=1 &


#!/usr/bin/env bash
set -euo pipefail

echo "=== Updating CoCo-Pi Launcher Repo (Unified Linux-side) ==="

# ------------------------------------------------------------
# Canonical repo location (Linux is authoritative)
# ------------------------------------------------------------
EXPECTED_ROOT="$HOME/source-CoCo-Pi/CoCo-Pi-Launcher"
REPO_ROOT="$(pwd)"

echo "Repo root: $REPO_ROOT"
echo "Expected:  $EXPECTED_ROOT"

if [[ "$REPO_ROOT" != "$EXPECTED_ROOT" ]]; then
    echo "[ERROR] This script must be run from:"
    echo "        $EXPECTED_ROOT"
    exit 1
fi

# ------------------------------------------------------------
# Linux live system paths
# ------------------------------------------------------------
LIN_LAUNCHER="$HOME/scripts/launcher"
LIN_TASKS="$HOME/.config/Code/User/tasks.json"
LIN_SCRIPTS_DIR="$HOME/scripts"
LIN_PYDW_DIR="$HOME/pyDriveWire"
LIN_BUILD_DIR="$HOME/source"

# Linux runtime scripts
LIN_SCRIPTS=(
    "start-FujiNet-server-CoCo-Becker.sh"
    "stop-FujiNet-server.sh"
    "status-FujiNet-server-CoCo-Becker.sh"
    "start-tnfs-server.sh"
    "stop-tnfs-server.sh"
    "status-tnfs-server.sh"
    "renumBASIC.sh"
    "compile-BASIC-mc10.sh"
    "build-BasTo6809.sh"
    "makeWAV-mc10.sh"
    "sync-launcher-from-git.sh"
    "setup-apt-packages.sh"
    "setup-bashrc.sh"
    "setup-share1.sh"
    "setup-system.sh"
    "setup-github-ssh.sh"
)

# Linux build scripts
LIN_BUILD_SCRIPTS=(
    "make-ugBasic-beta.sh"
    "make-mc10-tools.sh"
    "make-coco-tools.sh"
    "make-python3-pyenv.sh"
    "make-pyDriveWire-python3.sh"
    "make-fujinet-pc-CoCo.sh"
    "make-BASIC-To-6809-arm64.sh"
    "make-BASIC-To-6809.sh"
    "make-binutils-gdb.sh"
    "make-mc6809.sh"
    "make-QB64pe.sh"
    "make-basic_renumber.sh"
    "make-lwtools-unofficial.sh"
    "make-CMOC.sh"
    "make-mc6801-tools.sh"
    "make-mame.sh"
    "make-ugBasic.sh"
    "make-mcbasic.sh"
    "make-all-ugBasic-targets-beta.sh"
    "make-all-ugBasic-targets.sh"
    "make-trs80gp.sh"
    "make-xroar.sh"
    "make-toolshed.sh"
    "make-toolshed-code.sh"
    "make-tnfsd.sh"
    "make-bin2cas.sh"
    "make-tasm6801.sh"
    "make-cas2wav.sh"
    "make-asm6809.sh"
    "make-lwtools.sh"
    "make-DriveWire.sh"
    "make-rust.sh"
)

# pyDriveWire scripts
PYDW_SCRIPTS=(
    "start_pyDW.sh"
    "stop_pyDW.sh"
    "status_pyDW.sh"
)

# ------------------------------------------------------------
# Detect WSL vs Native Linux for Windows path mapping
# ------------------------------------------------------------
IS_WSL=false
if grep -qiE "(microsoft|wsl)" /proc/version 2>/dev/null; then
    IS_WSL=true
fi

if $IS_WSL; then
    _win_users=$(ls -d /mnt/c/Users/*/ 2>/dev/null | grep -iv "public\|default\|all.users")
    WIN_HOME=$(echo "$_win_users" | head -1 | sed 's:/$::')
else
    _win_users=$(ls -d /media/"$USER"/OS/Users/*/ 2>/dev/null | grep -iv "public\|default\|all.users")
    WIN_HOME=$(echo "$_win_users" | head -1 | sed 's:/$::')
fi
WIN_USER=$(basename "$WIN_HOME")

WIN_SCRIPTS="$WIN_HOME/scripts"
WIN_LAUNCHER="$WIN_SCRIPTS/launcher"
WIN_TASKS="$WIN_HOME/AppData/Roaming/Code/User/tasks.json"

# Toolchain directories (CoCo/MC-10/Dragon only)
WIN_TOOLCHAINS=(
    "BASIC-to-6809"
    "asm6809"
    "cas2wav"
    "lwtools"
    "ToolShed"
    "tnfsd"
    "ugBasic"
)

# Lifecycle scripts used by launcher menus
WIN_LIFECYCLE=(
    "start-tnfsd.ps1"
    "stop-tnfsd.ps1"
    "status-tnfsd.ps1"
    "start-FujiNet-server-CoCo-Becker.ps1"
    "stop-FujiNet-server-CoCo-Becker.ps1"
    "status-FujiNet-server-CoCo-Becker.ps1"
)

# VS Code task dependencies
WIN_VSCODE=(
    "renumBASIC.bat"
    "cmoc.cmd"
    "compile-BASIC-mc10.bat"
    "build-BasTo6809.cmd"
)

# Windows utility scripts
WIN_UTILITY=(
    "Install-basic-renumber.ps1"
    "install-cygwin.bat"
    "Install-pyDriveWire.ps1"
    "install-tnfsd.ps1"
    "msys2-hybrid-env-rebuilder.ps1"
    "sync-launcher-from-git.ps1"
)

# MSYS2 and Cygwin build script locations
MSYS_SOURCE="$WIN_HOME/msys64/home/$WIN_USER/source"
CYG_SOURCE="$WIN_HOME/cygwin64/home/$WIN_USER/source"

MSYS_SCRIPTS=(
    "make-asm6809.sh"
    "make-BASIC-To-6809.sh"
    "make-cas2wav.sh"
    "make-fujinet-pc-CoCo-msys2.sh"
    "make-lwtools.sh"
    "make-mcbasic.sh"
    "make-tnfsd-msys2.sh"
    "make-toolshed.sh"
    "make-ugBasic.sh"
    "make-xroar.sh"
    "make-ovcc-msys2.sh"
    "make-binutils-gdb-msys2.sh"
    "useroptions.mak"
)

CYG_SCRIPTS=(
    "make-CMOC.sh"
    "make-lwtools.sh"
)

# ------------------------------------------------------------
# Ensure repo structure exists
# ------------------------------------------------------------
mkdir -p unified/{config,tools,assets,vscode-extension,maintenance}
mkdir -p linux/scripts/launcher/maintenance
mkdir -p linux/pyDriveWire
mkdir -p linux/.config/Code/User
mkdir -p linux/source
mkdir -p windows/scripts/launcher/maintenance
mkdir -p windows/AppData/Roaming/Code/User
mkdir -p windows/source/{msys2,cygwin}

for d in "${WIN_TOOLCHAINS[@]}"; do
    mkdir -p "windows/$d"
done

# ------------------------------------------------------------
# Unified launcher
# ------------------------------------------------------------
echo "Copying unified launcher files..."

cp "$LIN_LAUNCHER/launcher.py" unified/
cp "$LIN_LAUNCHER/audit_all.py" unified/
cp "$LIN_LAUNCHER/audit_all.ps1" unified/
cp "$LIN_LAUNCHER/audit_all.sh" unified/
cp "$LIN_LAUNCHER/version_selector.py" unified/

rsync -av --delete "$LIN_LAUNCHER/config/" unified/config/
rsync -av --delete "$LIN_LAUNCHER/tools/" unified/tools/
rsync -av --delete "$LIN_LAUNCHER/assets/" unified/assets/
rsync -av --delete "$LIN_LAUNCHER/vscode-extension/" unified/vscode-extension/
rsync -av --delete "$LIN_LAUNCHER/maintenance/" unified/maintenance/
[[ -d "$LIN_LAUNCHER/.vscode" ]] && rsync -av --delete "$LIN_LAUNCHER/.vscode/" unified/.vscode/
[[ -d "$LIN_LAUNCHER/templates" ]] && rsync -av --delete "$LIN_LAUNCHER/templates/" unified/templates/

# ------------------------------------------------------------
# Linux-side harvesting
# ------------------------------------------------------------
echo "Copying Linux launcher wrapper files..."
cp "$LIN_LAUNCHER/create-launcher-shortcut.sh" linux/scripts/launcher/
cp "$LIN_LAUNCHER/audit_all.py" linux/scripts/launcher/
cp "$LIN_LAUNCHER/audit_all.ps1" linux/scripts/launcher/
cp "$LIN_LAUNCHER/audit_all.sh" linux/scripts/launcher/
cp "$LIN_LAUNCHER/version_selector.py" linux/scripts/launcher/

echo "Copying Linux maintenance scripts..."
rsync -av --delete "$LIN_LAUNCHER/maintenance/" linux/scripts/launcher/maintenance/

echo "Copying Linux runtime scripts..."
for s in "${LIN_SCRIPTS[@]}"; do
    [[ -f "$LIN_SCRIPTS_DIR/$s" ]] && cp "$LIN_SCRIPTS_DIR/$s" linux/scripts/
done

echo "Copying Linux build scripts..."
for s in "${LIN_BUILD_SCRIPTS[@]}"; do
    [[ -f "$LIN_BUILD_DIR/$s" ]] && cp "$LIN_BUILD_DIR/$s" linux/source/
done

echo "Copying Linux pyDriveWire scripts..."
for s in "${PYDW_SCRIPTS[@]}"; do
    [[ -f "$LIN_PYDW_DIR/$s" ]] && cp "$LIN_PYDW_DIR/$s" linux/pyDriveWire/
done

cp "$LIN_TASKS" linux/.config/Code/User/tasks.json

# ------------------------------------------------------------
# Windows-side harvesting
# ------------------------------------------------------------
echo "Copying Windows launcher files..."
cp "$WIN_LAUNCHER/launcher.py" windows/scripts/launcher/
cp "$WIN_LAUNCHER/audit_all.py" windows/scripts/launcher/
cp "$WIN_LAUNCHER/audit_all.ps1" windows/scripts/launcher/
cp "$WIN_LAUNCHER/create-launcher-shortcut.ps1" windows/scripts/launcher/
cp "$WIN_LAUNCHER/version_selector.py" windows/scripts/launcher/

rsync -av --delete "$WIN_LAUNCHER/config/" windows/scripts/launcher/config/
rsync -av --delete "$WIN_LAUNCHER/tools/" windows/scripts/launcher/tools/
rsync -av --delete "$WIN_LAUNCHER/assets/" windows/scripts/launcher/assets/
rsync -av --delete "$WIN_LAUNCHER/vscode-extension/" windows/scripts/launcher/vscode-extension/
rsync -av --delete "$WIN_LAUNCHER/maintenance/" windows/scripts/launcher/maintenance/

cp "$WIN_TASKS" windows/AppData/Roaming/Code/User/tasks.json

echo "Copying Windows lifecycle scripts..."
for s in "${WIN_LIFECYCLE[@]}"; do
    [[ -f "$WIN_SCRIPTS/$s" ]] && cp "$WIN_SCRIPTS/$s" windows/scripts/
done

echo "Copying Windows VS Code task dependencies..."
for s in "${WIN_VSCODE[@]}"; do
    [[ -f "$WIN_SCRIPTS/$s" ]] && cp "$WIN_SCRIPTS/$s" windows/scripts/
done

echo "Copying Windows toolchains..."
for d in "${WIN_TOOLCHAINS[@]}"; do
    [[ -d "$WIN_HOME/$d" ]] && rsync -av --delete "$WIN_HOME/$d/" "windows/$d/"
done

echo "Copying m6809-gdb debugger..."
mkdir -p windows/m6809-gdb
if [[ -f "$WIN_HOME/xroar/m6809-gdb.exe" ]]; then
    _gdb_size=$(stat -c%s "$WIN_HOME/xroar/m6809-gdb.exe")
    if (( _gdb_size >= 1048576 )); then
        cp "$WIN_HOME/xroar/m6809-gdb.exe" windows/m6809-gdb/
        echo "  Copied m6809-gdb.exe (${_gdb_size} bytes)"
    else
        echo "  WARNING: m6809-gdb.exe is only ${_gdb_size} bytes — looks like a libtool stub, skipping"
    fi
fi
for _dll in "$WIN_HOME/xroar/"lib*.dll; do
    [[ -f "$_dll" ]] && cp "$_dll" windows/m6809-gdb/ && echo "  Copied $(basename "$_dll")"
done

echo "Copying MSYS2 build scripts..."
for s in "${MSYS_SCRIPTS[@]}"; do
    [[ -f "$MSYS_SOURCE/$s" ]] && cp "$MSYS_SOURCE/$s" windows/source/msys2/
done
[[ -f "$WIN_HOME/msys64/hybrid-packages.txt" ]] && cp "$WIN_HOME/msys64/hybrid-packages.txt" windows/source/msys2/

echo "Copying Cygwin build scripts..."
for s in "${CYG_SCRIPTS[@]}"; do
    [[ -f "$CYG_SOURCE/$s" ]] && cp "$CYG_SOURCE/$s" windows/source/cygwin/
done

echo "Copying Windows utility scripts..."
for s in "${WIN_UTILITY[@]}"; do
    [[ -f "$WIN_SCRIPTS/$s" ]] && cp "$WIN_SCRIPTS/$s" windows/scripts/
done

# Update git_info.txt so the launcher displays the correct commit/date on this machine
git log -1 --format="%h %ad" --date=short > "$LIN_LAUNCHER/git_info.txt"
echo "Updated git_info.txt: $(cat "$LIN_LAUNCHER/git_info.txt")"

echo "=== Unified repo update complete. Review changes and commit. ==="

k#!/usr/bin/env bash
set -euo pipefail

echo "=== Updating CoCo-Pi Launcher Repo ==="

REPO_ROOT="$(pwd)"
echo "Repo root: $REPO_ROOT"

# ------------------------------------------------------------
# Define live system paths
# ------------------------------------------------------------
LIN_LAUNCHER="$HOME/scripts/launcher"
LIN_TASKS="$HOME/.config/Code/User/tasks.json"

WIN_HOME="/media/ron/OS/Users/Ron"
WIN_LAUNCHER="$WIN_HOME/scripts/launcher"
WIN_TASKS="$WIN_HOME/AppData/Roaming/Code/User/tasks.json"

# ------------------------------------------------------------
# Ensure repo structure exists
# ------------------------------------------------------------
mkdir -p unified/config
mkdir -p unified/tools
mkdir -p unified/assets
mkdir -p unified/vscode-extension

mkdir -p linux/scripts/launcher
mkdir -p linux/.config/Code/User

mkdir -p windows/scripts/launcher
mkdir -p windows/AppData/Roaming/Code/User

# ------------------------------------------------------------
# Copy unified launcher files
# ------------------------------------------------------------
echo "Copying unified launcher files..."

cp "$LIN_LAUNCHER/launcher.py" unified/
cp "$LIN_LAUNCHER/audit_all.py" unified/
cp "$LIN_LAUNCHER/audit_all.ps1" unified/

rsync -av --delete "$LIN_LAUNCHER/config/" unified/config/
rsync -av --delete "$LIN_LAUNCHER/tools/" unified/tools/
rsync -av --delete "$LIN_LAUNCHER/assets/" unified/assets/
rsync -av --delete "$LIN_LAUNCHER/vscode-extension/" unified/vscode-extension/

# ------------------------------------------------------------
# Copy Linux-specific files
# ------------------------------------------------------------
echo "Copying Linux-specific files..."

cp "$LIN_LAUNCHER/create-launcher-shortcut.sh" linux/scripts/launcher/
cp "$LIN_LAUNCHER/audit_all.py" linux/scripts/launcher/
cp "$LIN_LAUNCHER/audit_all.ps1" linux/scripts/launcher/

cp "$LIN_TASKS" linux/.config/Code/User/tasks.json

# ------------------------------------------------------------
# Copy Windows-specific files
# ------------------------------------------------------------
echo "Copying Windows-specific files..."

cp "$WIN_LAUNCHER/create-launcher-shortcut.ps1" windows/scripts/launcher/
cp "$WIN_LAUNCHER/audit_all.py" windows/scripts/launcher/
cp "$WIN_LAUNCHER/audit_all.ps1" windows/scripts/launcher/

cp "$WIN_TASKS" windows/AppData/Roaming/Code/User/tasks.json

echo "=== Repo update complete. Review changes and commit. ==="


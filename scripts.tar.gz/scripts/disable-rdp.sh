#!/bin/bash

# remove pi user for remote desktop access
#sudo gpasswd -d pi video
#sudo gpasswd -d pi render

# add pi user for normal console access
sudo usermod -a -G video pi
sudo usermod -a -G render pi

sudo reboot


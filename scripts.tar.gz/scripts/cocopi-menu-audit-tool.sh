#!/bin/bash
# cocopi-menu-audit-tool.sh

AUDIT_SCRIPT="$HOME/scripts/cocopi-menu-audit-tool.py"
PYTHON_VERSION="3.11.2"

# Ensure pyenv is initialized and Python version is available
if command -v pyenv >/dev/null 2>&1; then
  eval "$(pyenv init -)"
  pyenv shell "$PYTHON_VERSION"
else
  echo "❌ pyenv is not installed or not in PATH."
  exit 1
fi

if [[ ! -f "$AUDIT_SCRIPT" ]]; then
  echo "❌ Audit tool not found at $AUDIT_SCRIPT"
  exit 1
fi

function show_help() {
  echo "Usage: $0 [--dry-run | --patch | --help]"
  echo ""
  echo "Options:"
  echo "  --dry-run   Run audit and show suggested patches (default)"
  echo "  --patch     Apply suggested changes and create .bak backups"
  echo "  --help      Show this help message"
}

case "$1" in
  --dry-run|"")
    echo "🔍 Running dry-run audit of emulator scripts using Python $PYTHON_VERSION..."
    pyenv exec python "$AUDIT_SCRIPT"
    ;;
  --patch)
    echo "🛠️  Applying patches to emulator scripts using Python $PYTHON_VERSION..."
    pyenv exec python "$AUDIT_SCRIPT" --patch
    ;;
  --help|-h)
    show_help
    ;;
  *)
    echo "❌ Unknown option: $1"
    show_help
    exit 1
    ;;
esac

#!/bin/bash

# loop over ColecoVision/ADAM games and run them for 120 seconds each

shopt -s extglob

for run in {1..100}
do

f=$(shuf -ezn 1 $1* | xargs -0 -n1 echo)

     clear

     echo file = "$f"
     echo

     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     echo
     sleep 2

     if [[ $f == *.dsk ]]; then

                echo DSK
		timelimit -t120 colem -home $HOME/.coleco -adam -sgm "$f"

     fi


     if [[ $f == *.rom ]]; then

                echo ROM
		timelimit -t120 colem -home $HOME/.coleco -adam -sgm "$f"

     fi


# capture ERRORLEVEL

if [ $? -eq 0 ]
then
        echo
else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi


done

sleep 2

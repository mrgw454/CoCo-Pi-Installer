#!/bin/bash

# loop over ColecoVision/ADAM games and run them for 120 seconds each

shopt -s extglob
shopt -s nocasematch

cd $HOME/ColEm

for run in {1..100}
do

#f=$(shuf -ezn 1 $1/*.* | xargs -0 -n1 echo)
f=$(find "$1" -type f -print0 | shuf -z | xargs -0 -n1 echo 2>/dev/null | head -n 1)

     clear

     echo file = "$f"
     echo

     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     echo
     sleep 2

     if [[ $f == *.dsk ]]; then

                echo DSK
		timelimit -t120 ./colem -adam -sgm "$f"

     fi


     if [[ $f == *.rom ]]; then

                echo ROM
		timelimit -t120 ./colem -adam -sgm "$f"

     fi


done

sleep 2

#!/bin/bash

echo "Stopping FujiNet-PC (openMSX / MSX)..."

killall -9 fujinet 2>/dev/null

# Legacy MSX builds sometimes spawn helper processes
kill -9 $(pgrep -f netsiohub) 2>/dev/null

echo "Stopped."

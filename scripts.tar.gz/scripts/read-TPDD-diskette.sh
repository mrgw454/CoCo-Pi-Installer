./gw read --ecyl 79 --single-sided --rate 125 --revs 1 yourfilenamehere.scp


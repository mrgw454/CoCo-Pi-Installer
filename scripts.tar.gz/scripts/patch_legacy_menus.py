import os
import re
import sys
import shutil
from pathlib import Path

HOME = os.path.expanduser("~")
SEARCH_DIRS = ["scripts", ".mame", ".xroar", ".trs80gp", ".ovcc"]
MENU_PATTERN = re.compile(r'^CoCoPi-menu.*\.sh$')
EXCLUDE_SUFFIX = ".z3.sh"
EXPORT_LINE = 'export COCOPI_MENU_CALLER="${BASH_SOURCE[0]}"\n'

def needs_injection(lines):
    return not any("COCOPI_MENU_CALLER" in line for line in lines)

def inject_export(lines):
    for i, line in enumerate(lines):
        if line.startswith("#!/bin/bash") or line.strip() == "clear":
            return lines[:i+1] + [EXPORT_LINE] + lines[i+1:]
    return [EXPORT_LINE] + lines

def patch_menus(patch_mode=False):
    flagged = []
    for subdir in SEARCH_DIRS:
        full_path = os.path.join(HOME, subdir)
        for root, _, files in os.walk(full_path):
            for fname in files:
                if MENU_PATTERN.match(fname) and not fname.endswith(EXCLUDE_SUFFIX):
                    path = os.path.join(root, fname)
                    with open(path, "r") as f:
                        lines = f.readlines()
                    if needs_injection(lines):
                        flagged.append(path)
                        if patch_mode:
                            shutil.copy2(path, path + ".bak")
                            new_lines = inject_export(lines)
                            with open(path, "w") as f:
                                f.writelines(new_lines)
    return flagged

def print_results(flagged, patch_mode):
    if not flagged:
        print("✅ All legacy menu scripts already set COCOPI_MENU_CALLER.")
        return
    mode = "Patched" if patch_mode else "Dry-run"
    print(f"\n🔧 {mode}: Found {len(flagged)} legacy menu scripts missing COCOPI_MENU_CALLER:\n")
    for path in flagged:
        print(f"📄 {path}")
        if patch_mode:
            print(f"   ✔️ Patched and backed up to {path}.bak")
        print()

if __name__ == "__main__":
    patch_mode = "--patch" in sys.argv
    results = patch_menus(patch_mode=patch_mode)
    print_results(results, patch_mode)

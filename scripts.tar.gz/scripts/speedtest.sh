curl -s https://raw.githubusercontent.com/sivel/speedtest-cli/master/speedtest.py | python -


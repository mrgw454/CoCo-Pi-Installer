#!/bin/bash

# Full path to the BASIC file from VS Code
SRC="$1"

# Extract filename and base name
BASENAME=$(basename "$SRC")
BASE="${BASENAME%.*}"

# Compiler directory
COMP_DIR="$HOME/source/BASIC-To-6809/Source_Code"

# Destination directory (project folder)
DEST_DIR=$(dirname "$SRC")

# Clean old temp files in compiler directory
rm -f "$COMP_DIR"/*.asm \
      "$COMP_DIR"/*.bin \
      "$COMP_DIR"/BasicTokenized*.bin \
      "$COMP_DIR"/SamplesUsed.txt \
      "$COMP_DIR"/BASIC_Text.bas

# Copy BASIC file into compiler directory
cp "$SRC" "$COMP_DIR/$BASENAME"

# Run the BASIC-To-6809 wrapper
cd "$COMP_DIR"
./BasTo6809 -V4 -ascii "$BASENAME"

# Assemble the generated ASM file
ASM_FILE="$BASE.asm"
BIN_FILE="$BASE.bin"

lwasm --6809 --decb -o "$BIN_FILE" "$ASM_FILE"

# Copy the final .bin back to the project folder
cp "$BIN_FILE" "$DEST_DIR/"

# Cleanup compiler directory
rm -f "$COMP_DIR/$BASENAME" \
      "$COMP_DIR/$ASM_FILE" \
      "$COMP_DIR/$BIN_FILE" \
      "$COMP_DIR"/BasicTokenized*.bin \
      "$COMP_DIR"/SamplesUsed.txt \
      "$COMP_DIR"/BASIC_Text.bas

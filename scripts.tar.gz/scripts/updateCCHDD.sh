#!/bin/bash

# script to update CCHDD repository from github repo
if [ -d $HOME/source/CCHDD ]
then
    echo git repo exists.  Updating...
    echo
    cd $HOME/source/CCHDD
    git pull
    echo
else
    echo git repo does not exist.  Cloning and updating...
    echo
    cd $HOME/source
    git clone https://github.com/mrgw454/CCHDD.git
    echo
fi


# unzip CCHDD image into proper folder
unzip -o "$HOME/source/CCHDD/YA-DOS HDD Image (2020-04-24).zip" -d /media/share1/EMU/VHD

# check for existing symlink
if [ -f /media/share1/EMU/VHD/HDD.DSK ]
then
    echo symlink already exists.
    echo
else
    echo symlink does not exist.  Creating...
    echo
    ln -s /media/share1/EMU/VHD/DECBVHD.DSK /media/share1/EMU/VHD/HDD.DSK
    echo
fi

cd $HOME/.mame

echo -e
echo -e
read -p "Press any key to continue... " -n1 -s
echo -e

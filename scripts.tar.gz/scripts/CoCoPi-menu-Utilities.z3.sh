#!/bin/bash
clear
export COCOPI_MENU_CALLER="/home/ron/scripts/CoCoPi-menu-Utilities.z3.sh"
TITLE="$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)"

CHOICE=$(zenity --list \
  --title="$TITLE" \
  --width=700 --height=500 \
  --column="Option" --column="Description" \
  "1" "System Status" \
  "2" "CoCoPi    Administration Menu" \
  "3" "CoCoPi    Downloads Menu" \
  "4" "CoCoPi    Drive Emulation Menu" \
  "5" "CoCoPi    Mount Media Menu" \
  "6" "CoCoPi    RVPN Menu" \
  "7" "Reboot    Raspberry Pi" \
  "8" "Shutdown  Raspberry Pi" \
  "9" "Return to Main Menu"
)

case $CHOICE in
  "1") status.sh && CoCoPi-menu-Utilities.sh;;
  "2") CoCoPi-menu-Utilities-Administration.z3.sh;;
  "3") CoCoPi-menu-Utilities-Downloads.z3.sh;;
  "4") CoCoPi-menu-Utilities-DriveEmu.z3.sh;;
  "5") CoCoPi-menu-Utilities-MountMedia.z3.sh;;
  "6") CoCoPi-menu-Utilities-RVPN.z3.sh;;
  "7") rebootRPi.sh;;
  "8") shutdownRPi.sh;;
  "9") menu;;
  "*") echo "Quitting...";;
  *) echo "Quitting...";;
esac

sudo nano /etc/wpa_supplicant/wpa_supplicant.conf

cd $HOME/.mame
 

#!/bin/bash

# convert Apple IIx disk format from WOZ to PO

shopt -s globstar
shopt -s extglob
shopt -s nocasematch


if [ -f convert-errors.txt ]; then
	rm convert-errors.txt
fi

for f in "$PWD"/**/*
do

    fullfilename="$f"
    filename=$(basename "$fullfilename")
    fname="${filename%.*}"
    filesize=$(stat -c%s "$fullfilename")
    filepath=$(dirname "$f")
    parentname="$(basename "$(dirname "$filepath")")"
    fujipath=$(echo $filepath | cut -d'/' -f4-)

#echo fullfilename $fullfilenmae
#echo filename $filename
#echo fname $fname
#echo filesize $filesize
#echo filepath $filepath
#echo parentname $parentname
#echo $fujipath

	if [[ $f == *.WOZ ]]; then


		echo $HOME/source/woz2dsk/woz2dsk --format ProDOS "$f" "$filepath/$fname.po"
		$HOME/source/woz2dsk/woz2dsk --format ProDOS "$f" "$filepath/$fname.po"

		java -jar $HOME/AppleCommander/ac.jar -i "$filepath/$fname.po" > "$fname.output"
		filesize=$(stat -c%s "$fname.output")

		if [ $filesize -eq 0 ]; then
			echo "$fname" did not convert successfully.  Deleting "$fname.po" file.
        		rm "$filepath/$fname.po"
			echo "$f" >> convert-errors.txt
			echo
		else
			echo "$fname" converted successfully.
			cp --parents "$filepath/$fname.po" "/media/share1/FUJINET-APPLE"
        		rm "$filepath/$fname.po"
			echo
		fi

       		rm "$fname.output"

		echo
		echo

	fi

done

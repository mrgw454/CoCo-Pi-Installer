echo -e "CoCo\e[91m/\e[93m/\e[34m/\e[39mPi"

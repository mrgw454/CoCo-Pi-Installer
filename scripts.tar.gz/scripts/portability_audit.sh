#!/bin/bash
# portability_audit.sh

AUDIT_SCRIPT="$HOME/scripts/portability_audit.py"
PYTHON_VERSION="3.11.2"

if ! command -v pyenv >/dev/null 2>&1; then
  echo "❌ pyenv is not installed or not in PATH."
  exit 1
fi

eval "$(pyenv init -)"
eval "$(pyenv virtualenv-init - 2>/dev/null || true)"

if ! pyenv versions --bare | grep -q "^${PYTHON_VERSION}$"; then
  echo "📦 Installing Python $PYTHON_VERSION via pyenv..."
  pyenv install "$PYTHON_VERSION"
fi

pyenv shell "$PYTHON_VERSION"

if [[ ! -f "$AUDIT_SCRIPT" ]]; then
  echo "❌ Portability audit script not found at $AUDIT_SCRIPT"
  exit 1
fi

function show_help() {
  echo "Usage: $0 [--dry-run | --patch | --help]"
  echo ""
  echo "Options:"
  echo "  --dry-run   Show scripts with hardcoded $HOME paths (default)"
  echo "  --patch     Replace with \$HOME or os.path.expanduser(\"~\") and create .bak backups"
  echo "  --help      Show this help message"
}

case "$1" in
  --dry-run|"")
    echo "🔍 Running portability dry-run audit using Python $PYTHON_VERSION..."
    pyenv exec python "$AUDIT_SCRIPT"
    ;;
  --patch)
    echo "🛠️  Patching hardcoded paths using Python $PYTHON_VERSION..."
    pyenv exec python "$AUDIT_SCRIPT" --patch
    ;;
  --help|-h)
    show_help
    ;;
  *)
    echo "❌ Unknown option: $1"
    show_help
    exit 1
    ;;
esac

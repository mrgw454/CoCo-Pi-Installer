!#/bin/bash

find . -type f -exec bash -c 'hexdump -n4 "$1" | grep -q "^0000000 0000 0000"' Anything {} \; -exec printf "Would delete: %s\n" {} \;
find . -type f -exec bash -c 'hexdump -n4 "$1" | grep -q "^0000000 0000 0000"' Anything {} \; -delete;

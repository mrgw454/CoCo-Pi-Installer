#!/bin/bash

# Function to recursively find files and shuffle them
find_and_shuffle() {
  local dir="$1"

  # Find all files in the current directory and its subdirectories
  find "$dir" -type f -print0 | 
  # Shuffle the list of files
  shuf -z |
  # Read each file and print its name
  while IFS= read -r -d $'\0' file; do
    echo "$file"
    # Perform operations on the file here, e.g.,
    # cat "$file"
  done
}

# Get the directory from the user or use the current directory as default
directory="${1:-.}"

# Call the function to find and shuffle files
find_and_shuffle "$directory"

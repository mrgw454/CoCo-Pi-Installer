clear

echo "The following Atari video modes are available:"
echo

# set the prompt used by select, replacing "#?"
PS3="
Please select one to use as the default or 'stop' to cancel:"

# allow the user to choose a file
select filename in $HOME/.atari800/.optional_atari800_parameters-*

do
    # leave the loop if the user says 'stop'
    if [[ "$REPLY" == stop ]]; then break; fi

    # complain if no file was selected, and loop to ask again
    if [[ "$filename" == "" ]]
    then
        echo "'$REPLY' is not a valid number"
        continue
    fi

    # now we can use the selected file
    rm $HOME/.atari800/.optional_atari800_parameters.txt
    ln -s "$filename" $HOME/.atari800/.optional_atari800_parameters.txt
    echo 
    echo "$filename" is now the default Atari video mode.
    echo
    read -p "Press any key to continue... " -n1 -s
    # it'll ask for another unless we leave the loop
    break
done

cd $HOME/.atari800


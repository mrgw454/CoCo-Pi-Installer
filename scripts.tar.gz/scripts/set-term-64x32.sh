echo Setting terminal for ANSI emulation
export TERM=ansi
echo Setting terminal for 64 x 32 size
stty rows 32 cols 64
echo -e
echo Run 'tack' to perform terminal testing.
echo -e


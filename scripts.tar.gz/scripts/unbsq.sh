#!/bin/bash

# get name of script and place it into a variable
scriptname=`basename "$0"`

rubyscript=$HOME/source/unbinscii/unbinscii.rb


if [ $# -eq 0 ]; then
    echo "No arguments supplied"

    echo -e
    echo -e "Example syntax:"
    echo -e
    echo -e "./$scriptname <filename.bsq>"
    echo -e
    exit 1
fi

ruby $rubyscript "$1"

echo -e



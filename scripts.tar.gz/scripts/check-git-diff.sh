git diff --name-only master origin/yados-0.4c | more


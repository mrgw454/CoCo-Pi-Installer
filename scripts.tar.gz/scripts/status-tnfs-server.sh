#!/bin/bash
PIDFILE="/tmp/tnfsd.pid"

if [ ! -f "$PIDFILE" ]; then
    echo "TNFS server is not running."
    exit 1
fi

PID=$(cat "$PIDFILE")

if ps -p "$PID" >/dev/null 2>&1; then
    echo "TNFS server is running (PID $PID)"
else
    echo "PID file exists but process is not running."
fi

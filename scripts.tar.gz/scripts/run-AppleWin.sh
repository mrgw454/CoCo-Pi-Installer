#!/bin/bash
set -e

###############################################################################
# AppleWin + FujiNet Configuration Notes
#
# To use FujiNet-PC inside AppleWin, configure the emulator as follows:
#
#   Machine type:
#       APPLE2ENHANCED
#
#   Slot configuration:
#       Slot 5  →  SPoverSLIP (SmartPort over SLIP)
#       Slot 6  →  Empty
#
#   Network settings:
#       IP Address: 0.0.0.0
#       Port:       1985
#       Timeout:    10
#
# FujiNet-PC (AppleWin build) must be running BEFORE launching AppleWin.
#
# Once AppleWin is running, the FujiNet device will appear as a SmartPort
# device on slot 5, and disk/network operations will route through the
# FujiNet-PC server.
###############################################################################

APPLEWIN_BIN="$HOME/source/AppleWin-FujiNetWIFI/build/sa2"

if [ ! -f "$APPLEWIN_BIN" ]; then
    echo "ERROR: AppleWin binary not found:"
    echo "  $APPLEWIN_BIN"
    echo "Did you build AppleWin-FujiNetWIFI?"
    exit 1
fi

echo "Launching AppleWin..."
"$APPLEWIN_BIN" &

#!/bin/bash
clear
export COCOPI_MENU_CALLER="$HOME/scripts/CoCoPi-menu-MC10-XRoar.z3.sh"
TITLE="$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)"

CHOICE=$(zenity --list \
  --title="$TITLE" \
  --width=700 --height=500 \
  --column="Option" --column="Description" \
  "1" "TRS-80 Micro Color Computer   4K" \
  "2" "TRS-80 Micro Color Computer  20K" \
  "3" "TRS-80 Micro Color Computer  32K" \
  "4" "TRS-80 Micro Color Computer 128K (MCX Basic)" \
  "5" "Return to Main Menu"
)

case $CHOICE in
  "1") $HOME/.xroar/mc-10-4k-xroar.sh;;
  "2") $HOME/.xroar/mc-10-20k-xroar.sh;;
  "3") $HOME/.xroar/mc-10-32k-xroar.sh;;
  "4") $HOME/.xroar/mc-10-128k-xroar.sh;;
  "5") menu;;
  "*") echo "Quitting...";;
  *) echo "Quitting...";;
esac

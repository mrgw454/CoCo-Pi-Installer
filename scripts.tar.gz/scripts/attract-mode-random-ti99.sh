# select 200 random TI-99/4a cartridges and run them for 120 seconds each

MAMEPARMSFILE=`cat $HOME/.mame/.optional_mame_parameters_ti99.txt`
export MAMEPARMS=$MAMEPARMSFILE

shopt -s extglob
shopt -s nocasematch

for run in {1..200}
do

#file=$(shuf -ezn 1 /media/share1/software/ti99_cart/* | xargs -0 -n1 echo)
file=$(find "$1" -type f -print0 | shuf -z | xargs -0 -n1 echo 2>/dev/null | head -n 1)

     clear
     echo
     echo
     echo
     echo
     echo
     echo
     echo
     echo

     echo "Random cartridge $run"
     echo "file = $file"
     echo
     echo "Press [CTRL][C] to BREAK out of ATTRACT mode."
     echo
     echo "Press [F10] to toggle the no throttle option (helps speed things up)."
     sleep 2
     mame ti99_4a ${file//+(*\/|.*)} -ioport peb -ioport:peb:slot4 samsmem -ioport:peb:slot5 tirs232 -ioport:peb:slot7 tifdc -seconds_to_run 120 -autoboot_delay 2 -autoboot_command '\n2' $MAMEPARMS

done

cd $HOME/.mame


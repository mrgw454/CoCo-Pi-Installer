#!/bin/bash
clear
export COCOPI_MENU_CALLER="$HOME/scripts/CoCoPi-menu-Dragon.z3.sh"
TITLE="$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)"

CHOICE=$(zenity --list \
  --title="$TITLE" \
  --width=700 --height=500 \
  --column="Option" --column="Description" \
  "1" "Dragon 32" \
  "2" "Dragon 64" \
  "3" "Dragon 64 Plus" \
  "4" "Dragon 128 (Beta)" \
  "7" "Return to Main Menu"
)

case $CHOICE in
  "1") dragon32.sh;;
  "2") dragon64.sh;;
  "3") dragon64plus.sh;;
  "4") dragon128.sh;;
  "7") menu;;
  "*") echo "Quitting...";;
  *) echo "Quitting...";;
esac

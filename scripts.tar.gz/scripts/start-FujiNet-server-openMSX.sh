#!/bin/bash

# Start FujiNet-PC for openMSX (legacy MSX build)

cd $HOME/source/fujinet-pc-openMSX/build/dist
./fujinet &

cd $HOME/source

echo
echo "FujiNet-PC (openMSX / MSX) started."
echo

ps auwx | grep fujinet | grep -v grep

echo
exit

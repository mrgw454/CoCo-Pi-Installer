#!/usr/bin/env bash
# setup-bashrc.sh
# Appends CoCo-Pi Launcher environment settings to ~/.bashrc.
#
# Adds a clearly marked block that sets up:
#   - PATH entries for scripts, launcher, pyenv, and compilers
#   - pyenv initialization
#   - launcher() shell function (run from anywhere)
#   - Auto-launch launcher on local console (TERM=linux)
#   - fastfetch on SSH/desktop login
#   - WSL-specific tweaks
#
# Idempotent — skips if the block already exists.
# Re-running is safe.
#
# Usage:
#   bash setup-bashrc.sh

set -euo pipefail

BASHRC="$HOME/.bashrc"
MARKER_START="# START of CoCo-Pi modifications"
MARKER_END="# END of CoCo-Pi modifications"

echo "=============================================================="
echo " CoCo-Pi Launcher — .bashrc setup"
echo "=============================================================="
echo

# -------------------------------------------------------
# Check if the block already exists
# -------------------------------------------------------
if grep -qF "$MARKER_START" "$BASHRC"; then
    echo "CoCo-Pi block already present in $BASHRC — skipping."
    echo
    echo "To update it, remove the block between:"
    echo "  $MARKER_START"
    echo "  $MARKER_END"
    echo "...and re-run this script."
    exit 0
fi

# -------------------------------------------------------
# Detect environment for default settings
# -------------------------------------------------------
systemtype=$(dpkg --print-architecture 2>/dev/null || echo "unknown")

# Detect Raspberry Pi model label for rpi-model.txt
TITLE="unknown"
if [ -f /proc/device-tree/model ]; then
    RPI=$(cat /proc/device-tree/model | cut -c14-16)
    case "$RPI" in
        "500") TITLE="RPi500" ;;
        "5 M") TITLE="RPi5"   ;;
        "400") TITLE="RPi400" ;;
        "4 M") TITLE="RPi4"   ;;
        "3 M") TITLE="RPi3"   ;;
    esac
else
    TITLE=$(lscpu 2>/dev/null | grep 'Model name' | cut -f2 -d':' | awk '{$1=$1}1' || echo "unknown")
fi

echo "$TITLE" > "$HOME/rpi-model.txt"
echo "Detected platform: $TITLE"

# -------------------------------------------------------
# Append the CoCo-Pi block to .bashrc
# -------------------------------------------------------
cat >> "$BASHRC" <<'BASHRC_BLOCK'


# START of CoCo-Pi modifications
# Added by setup-bashrc.sh — CoCo-Pi Launcher

# Detect platform and write rpi-model.txt
_cocopitype=$(dpkg --print-architecture 2>/dev/null || echo "unknown")
if [ -f /proc/device-tree/model ]; then
    _cocorpi=$(cat /proc/device-tree/model | cut -c14-16)
    case "$_cocorpi" in
        "500") echo "RPi500" > "$HOME/rpi-model.txt" ;;
        "5 M") echo "RPi5"   > "$HOME/rpi-model.txt" ;;
        "400") echo "RPi400" > "$HOME/rpi-model.txt" ;;
        "4 M") echo "RPi4"   > "$HOME/rpi-model.txt" ;;
        "3 M") echo "RPi3"   > "$HOME/rpi-model.txt" ;;
    esac
else
    lscpu 2>/dev/null | grep 'Model name' | cut -f2 -d':' | awk '{$1=$1}1' > "$HOME/rpi-model.txt" || true
fi

# Fix for dialog/ncurses display in PuTTY
export NCURSES_NO_UTF8_ACS=1

# Fix for screen permission issue
export SCREENDIR="$HOME/.screen"

# PATH — scripts, launcher, local tools
PATH="$HOME/.local/bin:$PATH:$HOME/scripts:$HOME/scripts/launcher"

# CC6303 compiler (if installed)
if [ -d /opt/cc68/bin ]; then
    export PATH="/opt/cc68/bin:$PATH"
fi

# pyenv
export PYENV_ROOT="$HOME/.pyenv"
if [ -d "$PYENV_ROOT/bin" ]; then
    export PATH="$PYENV_ROOT/bin:$PATH"
    eval "$(pyenv init -)"
fi

export ACLOCAL_PATH=/usr/share/aclocal

# Run the launcher from anywhere in a shell
launcher() {
    python3 "$HOME/scripts/launcher/launcher.py" "$@"
}

# Auto-launch on local console (not over SSH or in desktop terminal)
if [ "$TERM" = "linux" ]; then
    cd "$HOME"
    launcher
else
    echo
    neofetch 2>/dev/null || fastfetch 2>/dev/null || true
fi

# WSL-specific settings
if uname -a | grep -qi "WSL"; then
    export DONT_PROMPT_WSL_INSTALL=Y
    echo
    echo "Use RIGHT mouse button or [SHIFT][CTRL][V] to paste inside this terminal."
    echo
    echo "Current terminal size: $COLUMNS columns, $LINES lines."
    echo
    PS1="[${WSL_DISTRO_NAME:-WSL}] ${PS1:-}"
fi

# END of CoCo-Pi modifications
BASHRC_BLOCK

echo "CoCo-Pi block appended to $BASHRC"
echo

# -------------------------------------------------------
# Source the updated .bashrc so PATH is available immediately
# (only works if this script is sourced; harmless otherwise)
# -------------------------------------------------------
# shellcheck disable=SC1090
source "$BASHRC" 2>/dev/null || true

echo "=============================================================="
echo " Done. Open a new terminal (or log out and back in) to apply."
echo "=============================================================="
echo

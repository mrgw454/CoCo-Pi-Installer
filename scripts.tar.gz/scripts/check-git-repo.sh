#!/bin/bash

shopt -s globstar
shopt -s extglob
shopt -s nocasematch

currentDIR=$PWD

RED='\033[0;31m'
RED_BOLD='\033[1;31m'
GREEN='\033[0;32m'
GREEN_BOLD='\033[1;32m'
YELLOW='\033[0;33m'
YELLOW_BOLD='\033[1;33m'
BLUE='\033[34m'
BLUE_BOLD='\033[1;34m'
NC='\033[0m' # no color


for d in *; do

	if [ -d "$d" ]; then

		cd "$d"

		# if .git folder exists, get repo info
		if [ -d ".git" ]; then

			giturl=$(git config --get remote.origin.url)

			git remote update > /dev/null
			git status | grep "Your branch"

			if [[ `git status --porcelain` ]]; then
				# Changes
				echo -e "$d - ${GREEN_BOLD}$giturl repo has been updated.${NC}"
				#git status --porcelain
				echo
			else
				# No changes
				echo -e "$d - ${BLUE_BOLD}$giturl repo has NOT been updated.${NC}"
				echo
			fi

		fi

	fi

	cd $currentDIR

done

shopt -u nocaseglob
shopt -u globstar
shopt -u nocasematch

echo Done!

sudo systemctl stop pulseaudio
sudo systemctl disable pulseaudio
sudo systemctl status pulseaudio.service


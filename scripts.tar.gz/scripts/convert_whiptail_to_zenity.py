import os
import re
from pathlib import Path

SOURCE_DIR = os.path.expanduser("~/.mame")
DEST_DIR = os.path.expanduser("~/scripts")
FILE_PATTERN = re.compile(r"^CoCoPi.*\.sh$")
MAIN_MENU = "CoCoPi-menu.z3.sh"

converted_scripts = set()

def extract_menu_block(lines):
    menu_block = []
    in_menu = False
    for line in lines:
        if not in_menu and re.search(r'RETVAL=\s*\$?\(.*whiptail', line):
            in_menu = True
        if in_menu:
            menu_block.append(line)
            if re.search(r'3>&1\s+1>&2\s+2>&3\s*\)', line):
                break
    return menu_block

def extract_case_block(lines):
    case_block = []
    in_case = False
    for line in lines:
        if not in_case and re.match(r'\s*case\s+\$RETVAL\s+in', line):
            in_case = True
        if in_case:
            case_block.append(line)
            if re.match(r'\s*esac', line):
                break
    return case_block

def parse_menu_options(menu_lines):
    options = []
    for line in menu_lines:
        match = re.match(r'\s*"(\d+)"\s+"(.+?)"\s*\\?', line)
        if match:
            options.append((match.group(1), match.group(2)))
    return options

def detect_convertible_scripts():
    for fname in os.listdir(SOURCE_DIR):
        if FILE_PATTERN.match(fname):
            path = os.path.join(SOURCE_DIR, fname)
            with open(path, "r") as f:
                lines = f.readlines()
            menu_block = extract_menu_block(lines)
            case_block = extract_case_block(lines)
            if menu_block and case_block:
                base = Path(fname).stem
                converted_scripts.add(base)
    print(f"Detected {len(converted_scripts)} convertible menu scripts.")

def build_zenity_script(title_expr, options, logic, caller_path):
    zenity_block = [
        "#!/bin/bash",
        "clear",
        f'export COCOPI_MENU_CALLER="$HOME/scripts/{MAIN_MENU}"',
        f'TITLE="{title_expr}"',
        "",
        "CHOICE=$(zenity --list \\",
        '  --title="$TITLE" \\',
        '  --width=700 --height=500 \\',
        '  --column="Option" --column="Description" \\'
    ]
    for opt, desc in options:
        zenity_block.append(f'  "{opt}" "{desc}" \\')
    zenity_block[-1] = zenity_block[-1].rstrip(" \\")
    zenity_block.append(")")

    case_block = ["", "case $CHOICE in"]
    for opt, cmd in logic:
        case_block.append(f'  "{opt}") {cmd};;')
    case_block.append('  "*") echo "Quitting...";;')
    case_block.append("esac")

    return "\n".join(zenity_block + case_block) + "\n"

def parse_case_logic(case_lines):
    logic = []
    for line in case_lines:
        match = re.match(r'\s*(\d+)\)\s+(.*?);;', line)
        if match:
            tag = match.group(1)
            cmd = match.group(2).strip()
            if cmd == "menu":
                cmd = '"$COCOPI_MENU_CALLER"'
            elif cmd.endswith(".sh") and not cmd.endswith(".z3.sh"):
                base = Path(cmd).stem
                if base in converted_scripts:
                    cmd = f"{base}.z3.sh"
            logic.append((tag, cmd))
        elif re.match(r'\s*\*\)', line):
            logic.append(("*", 'echo "Quitting..."'))
    return logic

def convert_file(filepath):
    with open(filepath, "r") as f:
        lines = f.readlines()

    menu_block = extract_menu_block(lines)
    case_block = extract_case_block(lines)

    if not menu_block or not case_block:
        print("    ⚠️ Skipping: No valid whiptail menu found.")
        return None

    title_expr = '$(cat $HOME/cocopi-release.txt) $(cat $HOME/rpi-model.txt)'
    options = parse_menu_options(menu_block)
    logic = parse_case_logic(case_block)

    base_name = Path(filepath).stem
    dest_filename = base_name + ".z3.sh"
    dest_path = os.path.join(DEST_DIR, dest_filename)
    zenity_script = build_zenity_script(title_expr, options, logic, dest_path)

    with open(dest_path, "w") as f:
        f.write(zenity_script)
    os.chmod(dest_path, 0o755)
    return dest_path

def main():
    os.makedirs(DEST_DIR, exist_ok=True)
    detect_convertible_scripts()
    converted = []
    for fname in os.listdir(SOURCE_DIR):
        if FILE_PATTERN.match(fname):
            src_path = os.path.join(SOURCE_DIR, fname)
            print(f"Scanning: {src_path}")
            result = convert_file(src_path)
            if result:
                print(f"  → Converted: {result}")
                converted.append(result)
    print(f"\nConverted {len(converted)} scripts.")

if __name__ == "__main__":
    main()

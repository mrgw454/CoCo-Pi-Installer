#!/bin/bash

# Start FujiNet bridge
cd $HOME/source/fujinet-emulator-bridge/fujinet-bridge
python3 -m netsiohub &

# Start FujiNet-PC for Altirra (ATARI platform)

cd $HOME/source/fujinet-pc-Altirra/build/dist
./fujinet &

cd $HOME/source

echo
echo "FujiNet-PC (Altirra) started."
echo

ps auwx | grep fujinet | grep -v grep
ps auwx | grep netsiohub | grep -v grep

echo
exit

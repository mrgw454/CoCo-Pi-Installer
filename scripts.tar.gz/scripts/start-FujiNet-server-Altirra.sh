#!/bin/bash

# https://forums.atariage.com/topic/380800-fujinet-and-altirra/page/1/
# https://forums.atariage.com/topic/380800-fujinet-and-altirra/page/2/
# make sure python3 is the default prior to running this

#pyenv shell system
# ... or ...
#PATH=`echo $PATH | tr ':' '\n' | sed '/pyenv/d' | tr '\n' ':' | sed -r 's/:$/\n/'`

# start FujiNet bridge
cd $HOME/source/fujinet-emulator-bridge/fujinet-bridge
python3 -m netsiohub &

# start FujiNet PC
cd $HOME/source/fujinet-pc-Altirra/build/dist
./run-fujinet &

cd $HOME/source

echo
echo

ps auwx | grep fuji
ps auwx | grep netsiohub

echo
echo

google-chrome http://localhost:8000 &


# make sure all attached drive media is removed and drives are set to OFF
# make sure OS acceleration Fast Boot is disabled

cd $HOME/.wine/drive_c/Altirra
wine $HOME/.wine/drive_c/Altirra/Altirra64.exe /gdi &

exit

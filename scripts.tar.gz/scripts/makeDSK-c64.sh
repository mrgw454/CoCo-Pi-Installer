#!/bin/bash

# rename files to be all lowercase
#/home/ron/rename-to-lowercase.sh

# convert ASCII basic file to C64 BASIC code
#petcat -w2 -o program.prg -- program.bas

# create new disk image
#cc1541 -n fntools fntools.d64

# add program to disk image
#cc1541 -f adaptcnf -w adaptcnf.prg fntools.d64 
#cc1541 -f getssid -w getssid.prg fntools.d64 
#cc1541 -f getwifi -w getwifi.prg fntools.d64 
#cc1541 -f mntdev -w mntdev.prg fntools.d64 
#cc1541 -f mnthost -w mnthost.prg fntools.d64 
#cc1541 -f opendir -w opendir.prg fntools.d64 
#cc1541 -f scannet -w scannet.prg fntools.d64 
#cc1541 -f setssid -w setssid.prg fntools.d64 


# case insensitive
#shopt -s nocaseglob


# convert contents of BASIC files to lowercase
for f in *.BAS; do

	filename=$(basename -- "$f")
	extension="${filename##*.}"
	shortname="${filename%.*}"
	lshortname=$(echo $shortname | tr A-Z a-z)
	
	tr '[:upper:]' '[:lower:]' < "$f" > "$lshortname.bas"

done



# get name of current folder and place it into a variable
floppy=`basename "$PWD"`
lfloppy=$(echo $floppy | tr A-Z a-z)

cc1541 -n "$lfloppy" "$floppy.d64"



for f in *.bas; do

	filename=$(basename -- "$f")
	extension="${filename##*.}"
	shortname="${filename%.*}"

	petcat -w2 -o "$shortname.prg" -- "$f"

done



for f in *.prg; do

	filename=$(basename -- "$f")
	extension="${filename##*.}"
	shortname="${filename%.*}"

	# Copy all PRG files to DSK image
	if [[ $f == *.prg ]]; then

		cc1541 -v -f "$shortname" -w "$shortname.prg" "$floppy.d64" 

	fi

done

sudo iw wlan0 get power_save
sudo iwconfig wlan0 power off
sudo iwconfig

# Edit power settings for WiFi module  (Edimax EW-7811Un)
# sudo nano /etc/modprobe.d/8192cu.conf


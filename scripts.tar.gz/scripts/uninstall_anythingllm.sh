#!/bin/bash

# Define paths based on your locate output
APP_IMAGE="$HOME/AnythingLLMDesktop.AppImage"
DESKTOP_FILE="$HOME/.local/share/applications/anythingllm.desktop"
CONFIG_DIR="$HOME/.config/anythingllm-desktop"
APPARMOR_FILE="/etc/apparmor.d/anythingllmdesktop"

echo "Starting AnythingLLM cleanup for Debian 13..."

# 1. Remove AppImage
if [ -f "$APP_IMAGE" ]; then
    echo "Removing AppImage..."
    rm "$APP_IMAGE" || echo "Error: Could not remove $APP_IMAGE"
else
    echo "AppImage not found, skipping."
fi

# 2. Remove Desktop Shortcut (Menu Item)
if [ -f "$DESKTOP_FILE" ]; then
    echo "Removing menu entry..."
    rm "$DESKTOP_FILE" || echo "Error: Could not remove $DESKTOP_FILE"
    
    # Refresh the desktop database to force menu update
    if command -v update-desktop-database >/dev/null 2>&1; then
        update-desktop-database ~/.local/share/applications
    fi
else
    echo "Menu entry not found, skipping."
fi

# 3. Wipe Configuration and Cache (Crucial for document importer issues)
if [ -d "$CONFIG_DIR" ]; then
    echo "Wiping local data and cache..."
    rm -rf "$CONFIG_DIR" || echo "Error: Could not remove $CONFIG_DIR"
else
    echo "Config directory not found, skipping."
fi

# 4. Remove AppArmor Profile (Requires sudo)
if [ -f "$APPARMOR_FILE" ]; then
    echo "Found AppArmor profile. Requesting sudo to remove it..."
    sudo rm "$APPARMOR_FILE" && echo "AppArmor profile removed." || echo "Error: Failed to remove AppArmor profile."
fi

echo "---------------------------------------"
echo "Cleanup complete. AnythingLLM is removed."

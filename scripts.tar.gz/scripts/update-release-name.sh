find $HOME/.mame -type f -print0 | xargs -0 sed -i 's|Tandy Assembly Edition|Tandy Assembly 2018 Edition|g'

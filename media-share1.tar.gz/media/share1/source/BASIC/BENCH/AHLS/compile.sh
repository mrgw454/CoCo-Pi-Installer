ugbc.coco -O dsk bench.bas -o TEST.dsk
decb copy -0 -a -r bench2.bas TEST.dsk,BENCH2.BAS


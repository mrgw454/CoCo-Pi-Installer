#include <stdio.h>
#include <stdlib.h>

void main(void)
{
  printf("Hello, World!\n");
}

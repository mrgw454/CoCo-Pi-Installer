#include "/opt/cc68/include/mc10/stdio.h"
#include "/opt/cc68/include/stdint.h"
#include "/opt/cc68/include/string.h"
int main()
{
   // printf() displays the string inside quotation
   printf("Hello, World!");
   return 0;
}

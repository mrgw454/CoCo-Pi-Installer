SHIFT SCROLL-LOCK		Paste text into MAME

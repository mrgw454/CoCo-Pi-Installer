au BufRead,BufNewFile *.asm set filetype=asm6809

#!/bin/bash

sudo apt -y remove geany geany-common

sudo apt -y install mc glances
sudo apt -y install neofetch

# for xroar
sudo apt -y install git build-essential python3 libsdl2-dev libsdl2-ttf-dev libfontconfig-dev libpulse-dev qtbase5-dev qtbase5-dev-tools qtchooser qt5-qmake
sudo apt -y install build-essential libsndfile1-dev libgtk2.0-dev libgtkglext1-dev libasound2-dev ddd

sudo apt -y install mercurial
sudo apt -y install libfuse-dev
sudo apt -y install bison
sudo apt -y install flex
sudo apt -y install libgtk-3-dev
sudo apt -y install pyenv
sudo apt -y install build-essential libssl-dev zlib1g-dev libbz2-dev libreadline-dev libsqlite3-dev llvm libncurses5-dev libncursesw5-dev xz-utils tk-dev libffi-dev liblzma-dev python3-openssl git
sudo apt -y install pyenv
sudo apt -y install screen
sudo apt -y install nodejs
sudo apt -y install texinfo

sudo apt -y install intltool
sudo apt -y install samba samba-common-bin smbclient cifs-utils
sudo apt -y install xxd
sudo apt -y install gcc libncurses5-dev libffi-dev libgl1-mesa-dev libx11-dev libxext-dev libxrender-dev libxrandr-dev libxpm-dev libtinfo5 libgpm-dev
sudo apt -y install subversion
sudo apt -y install libsdl1.2-dev
sudo apt -y install libao-dev
sudo apt -y install meld
sudo apt -y install debuild
sudo apt -y install devscripts
sudo apt -y install xterm-terminal-emulator
sudo apt -y install xterm
sudo apt -y install markdown
sudo apt -y install cpanminus
sudo apt -y install libglew-dev
sudo apt -y install libcurl-dev
sudo apt -y install libcurl
sudo apt -y install pkg-config
sudo apt -y install libcurl4-openssl-dev
sudo apt -y install libswt-gtk-3-java

# for gcc6809
sudo apt install libgmp-dev libmpfr-dev libmpc-dev markdown mercurial subversion bison texinfo

# for VGMPlay
sudo apt -y install make gcc zlib1g-dev libao-dev libdbus-1-dev

# for VGMPlay and lzsa
sudo apt -y install clang

sudo apt -y install screenfetch

# for flashfloppy and greaseweazle
sudo apt -y install git gcc-arm-none-eabi python3-pip srecord stm32flash zip unzip wget python3-intelhex python3-crcmod

# for pyDriveWire
sudo apt -y install build-essential libssl-dev zlib1g-dev libbz2-dev libreadline-dev libsqlite3-dev llvm libncurses5-dev libncursesw5-dev xz-utils tk-dev libffi-dev liblzma-dev python3-openssl git

# for DriveWire4
sudo apt -y install openjdk-17-jdk

# for Tormod Voldens repo
sudo apt install add-apt-repository
sudo apt install software-properties-common
sudo add-apt -repository ppa:tormodvolden/m6809
sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys 627ABB1E29CC8356AD0800EB4B1E287796DD5C9A

sudo apt autoremove

echo
echo Done!
echo

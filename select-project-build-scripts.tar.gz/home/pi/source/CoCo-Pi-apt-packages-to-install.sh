#!/bin/bash

systemtype=$(dpkg --print-architecture)
echo architecture = $systemtype

if [[ $systemtype =~ amdxx ]];then

	# install drivers for nVidia
	sudo apt -y install linux-headers-amd64

		## Add "contrib", "non-free" and "non-free-firmware" components to /etc/apt/sources.list, for example:
		## Debian Bookworm
		#deb http://deb.debian.org/debian/ bookworm main contrib non-free non-free-firmware
		#sudo apt update

	sudo apt-add-repository contrib non-free -y
	#sudo apt-add-repository contrib non-free-firmware -y
	sudo apt update

	#sudo apt -y install nvidia-driver firmware-misc-nonfree
	#sudo apt -y install nvidia-detect

	# install Google Chrome
	sudo apt -y install software-properties-common apt-transport-https ca-certificates curl
	sudo apt -y install google-chrome-stable

	sudo apt -y install apt-transport-https ca-certificates curl software-properties-common wget fonts-liberation libu2f-udev libvulkan1
	sudo apt -y install openssh-client
	sudo apt -y install network-manager-openvpn-gnome openvpn

	# install file managers
	sudo apt -y install mc
	sudo apt -y install doublecmd-gtk

	# install samba
	sudo apt -y install smbclient cifs-utils

	# hardware statitics utilities
	sudo apt -y install neofetch
	sudo apt -y install glances
	sudo apt -y install atop dstat sysstat nmon nvtop psensor lm-sensors hardinfo smartmontools gsmartcontrol nvme-cli baobab lshw-gtk libusb-1.0-0-dev libudev-dev pulseview net-tools


	# install archivers
	sudo apt -y install p7zip
	sudo apt -y install unrar
	sudo apt -y install rar

	# media player
	sudo apt -y install vlc

	# par utilities
	sudo apt -y install par2repair
	sudo apt -y install par2

	# additional fonts
	sudo apt-add-repository contrib non-free -y
	sudo apt -y install ttf-mscorefonts-installer

	# putty
	sudo apt -y install putty putty-tools

	# required for building Java programs
	sudo apt -y install ant

	# install flatpak
	sudo apt -y install flatpak
	flatpak remote-add --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo

	# for older openvpn client 2.4.12
	sudo apt -y install liblz4-dev
	sudo apt -y install libssl-dev liblzo2-dev libpam0g-dev

	# misc
	sudo apt -y install mlocate tigervnc-viewer minicom npm unionfs-fuse

	# qBittorrent
	cmake qttools5-dev libqt5svg5-dev extra-cmake-modules

	# mount SD card images and ARM virtualization
	#kpartx qemu-arm-static systemd-container

	# for gsplus
	sudo apt -y install re2c libsdl2-dev libsdl2-image-dev libfreetype6-dev libpcap0.8-dev

	# for gsport
	sudo apt -y install gcc-multilib
	sudo apt -y install g++-multilib
	sudo apt -y install re2c libsdl2-dev libsdl2-image-dev libfreetype6-dev libpcap0.8-devudo gcc-multilib g++-multilib libx11-dev:i386 libxext-dev:i386 libpcap-dev:i386

	# require for h19term
	sudo apt -y install python3-serial python3-pip python3-dev python3-setuptools python3-pyaudio

	# for Visual Studio Code
	# add repository for Visual Studio Code
	sudo apt -y install wget gpg
	wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > packages.microsoft.gpg
	sudo install -D -o root -g root -m 644 packages.microsoft.gpg /etc/apt/keyrings/packages.microsoft.gpg
	sudo sh -c 'echo "deb [arch=amd64,arm64,armhf signed-by=/etc/apt/keyrings/packages.microsoft.gpg] https://packages.microsoft.com/repos/code stable main" > /etc/apt/sources.list.d/vscode.list'
	rm -f packages.microsoft.gpg
	sudo apt -y install apt-transport-https
	sudo apt update
	sudo apt -y install code

	# for dolphin emulator
	sudo apt -y install build-essential git cmake ffmpeg libavcodec-dev libavformat-dev libavutil-dev libswscale-dev libevdev-dev libusb-1.0-0-dev libxrandr-dev libxi-dev libpangocairo-1.0-0 qt6-base-private-dev libqt6svg6-dev libbluetooth-dev libasound2-dev libpulse-dev libgl1-mesa-dev libcurl4-openssl-dev

	# required for building certain Java projects
	sudo apt -y install maven default-jdk

	exit

	# for VirtualBox
	curl -fsSL https://www.virtualbox.org/download/oracle_vbox_2016.asc|sudo gpg --dearmor -o /etc/apt/trusted.gpg.d/vbox.gpg
	curl -fsSL https://www.virtualbox.org/download/oracle_vbox.asc|sudo gpg --dearmor -o /etc/apt/trusted.gpg.d/oracle_vbox.gpg
	echo "deb [arch=amd64] http://download.virtualbox.org/virtualbox/debian $(lsb_release -cs) contrib" | sudo tee /etc/apt/sources.list.d/virtualbox.list
	sudo apt update
	sudo apt install virtualbox-6.1
	wget https://download.virtualbox.org/virtualbox/6.1.48/Oracle_VM_VirtualBox_Extension_Pack-6.1.48.vbox-extpack

	# for KVM QEMU
	sudo apt -y install qemu-kvm libvirt-daemon-system libvirt-daemon virtinst bridge-utils libosinfo-bin virt-manager
	sudo apt -y install vim libguestfs-tools libosinfo-bin  qemu-system virt-manager

	userid=$(whoami)
	sudo usermod -a -G libvirt $userid

	sudo systemctl status libvirtd
	sudo systemctl enable --now libvirtd

	lsmod | grep -i kvm
	sudo virsh net-start default
	sudo virsh net-autostart default
	sudo virsh net-list --all
	sudo modprobe vhost_net
	ip address

	wget https://www.spice-space.org/download/windows/spice-guest-tools/spice-guest-tools-latest.exe
	wget https://github.com/winfsp/winfsp/releases/download/v2.0/winfsp-2.0.23075.msi
	wget https://fedorapeople.org/groups/virt/virtio-win/direct-downloads/archive-virtio/virtio-win-0.1.240-1/virtio-win-guest-tools.exe

fi

sudo apt -y remove geany geany-common

sudo apt -y autoremove

sudo apt -y install mc glances
sudo apt -y install neofetch
sudo apt -y install net-tools
sudo apt -y install dos2unix

# for xroar
sudo apt -y install git build-essential python3 libsdl2-dev libsdl2-ttf-dev libfontconfig-dev libpulse-dev qtbase5-dev qtbase5-dev-tools qtchooser qt5-qmake
sudo apt -y install build-essential libsndfile1-dev libgtk2.0-dev libgtkglext1-dev libasound2-dev ddd

sudo apt -y install mercurial
sudo apt -y install libfuse-dev
sudo apt -y install bison
sudo apt -y install flex
sudo apt -y install libgtk-3-dev
sudo apt -y install build-essential libssl-dev zlib1g-dev libbz2-dev libreadline-dev libsqlite3-dev llvm libncurses5-dev libncursesw5-dev xz-utils tk-dev libffi-dev liblzma-dev python3-openssl git
sudo apt -y install screen
sudo apt -y install nodejs
sudo apt -y install texinfo
sudo apt -y install intltool

# for samba
sudo apt -y install samba samba-common-bin smbclient cifs-utils

echo
echo

userid=$(whoami)

echo Please make sure to enter a password for user - $userid
echo This password is for samba and should be set to match the login password entered at first power-up set up.
echo
sudo smbpasswd -a $userid

sudo apt -y install xxd
sudo apt -y install gcc libncurses5-dev libffi-dev libgl1-mesa-dev libx11-dev libxext-dev libxrender-dev libxrandr-dev libxpm-dev libtinfo5 libgpm-dev
sudo apt -y install subversion
sudo apt -y install libsdl1.2-dev
sudo apt -y install libao-dev
sudo apt -y install meld
sudo apt -y install devscripts
sudo apt -y install xterm
sudo apt -y install markdown
sudo apt -y install cpanminus
sudo apt -y install libglew-dev
sudo apt -y install pkg-config
sudo apt -y install libcurl4-openssl-dev
sudo apt -y install libswt-gtk-3-java

# for gcc6809
sudo apt -y install libgmp-dev libmpfr-dev libmpc-dev markdown mercurial subversion bison texinfo

# for VGMPlay
sudo apt -y install make gcc zlib1g-dev libao-dev libdbus-1-dev

# for VGMPlay and lzsa
sudo apt -y install clang

sudo apt -y install screenfetch

# for flashfloppy and greaseweazle
sudo apt -y install git gcc-arm-none-eabi python3-pip srecord stm32flash zip unzip wget python3-intelhex python3-crcmod

# for pyDriveWire
sudo apt -y install build-essential libssl-dev zlib1g-dev libbz2-dev libreadline-dev libsqlite3-dev llvm libncurses5-dev libncursesw5-dev xz-utils tk-dev libffi-dev liblzma-dev python3-openssl git

# for DriveWire4
sudo apt -y install openjdk-17-jdk ant

# remove uneeded packages
sudo apt -y autoremove


echo
echo
echo Please reboot as soon as possible so all updates can be applied.  Thank you.
echo
read -p "Press any key to continue... " -n1 -s

echo
echo Done!
echo

#!/bin/bash

sudo apt remove geany geany-common

sudo apt install mc glances
sudo apt install neofetch

# for xroar
sudo apt install git build-essential python3 libsdl2-dev libsdl2-ttf-dev libfontconfig-dev libpulse-dev qtbase5-dev qtbase5-dev-tools qtchooser qt5-qmake
sudo apt install build-essential libsndfile1-dev libgtk2.0-dev libgtkglext1-dev libasound2-dev ddd

sudo apt install mercurial
sudo apt install libfuse-dev
sudo apt install bison
sudo apt install flex
sudo apt install libgtk-3-dev
sudo apt install pyenv
sudo apt install build-essential libssl-dev zlib1g-dev libbz2-dev libreadline-dev libsqlite3-dev llvm libncurses5-dev libncursesw5-dev xz-utils tk-dev libffi-dev liblzma-dev python3-openssl git
sudo apt install pyenv
sudo apt install screen
sudo apt install nodejs
sudo apt install texinfo

sudo apt install intltool
sudo apt install samba samba-common-bin smbclient cifs-utils
sudo apt install xxd
sudo apt install gcc libncurses5-dev libffi-dev libgl1-mesa-dev libx11-dev libxext-dev libxrender-dev libxrandr-dev libxpm-dev libtinfo5 libgpm-dev
sudo apt install subversion
sudo apt install libsdl1.2-dev
sudo apt install libao-dev
sudo apt install meld
sudo apt install debuild
sudo apt install devscripts
sudo apt install xterm-terminal-emulator
sudo apt install xterm
sudo apt install markdown
sudo apt install cpanminus
sudo apt install libglew-dev
sudo apt install libcurl-dev
sudo apt install libcurl
sudo apt install pkg-config
sudo apt-get install libcurl4-openssl-dev
sudo apt-get install libswt-gtk-3-java

# for VGMPlay
sudo apt install make gcc zlib1g-dev libao-dev libdbus-1-dev

# for VGMPlay and lzsa
sudo apt install clang

sudo apt install screenfetch

# for flashfloppy and greaseweazle
sudo apt -y install git gcc-arm-none-eabi python3-pip srecord stm32flash zip unzip wget python3-intelhex python3-crcmod

# for pyDriveWire
sudo apt install build-essential libssl-dev zlib1g-dev libbz2-dev libreadline-dev libsqlite3-dev llvm libncurses5-dev libncursesw5-dev xz-utils tk-dev libffi-dev liblzma-dev python3-openssl git

# for DriveWire4
sudo apt install openjdk-17-jdk

# for Tormod Voldens repo
sudo apt install add-apt-repository
sudo apt install software-properties-common
sudo add-apt-repository ppa:tormodvolden/m6809
sudo apt-key adv --keyserver keyserver.ubuntu.com   --recv-keys 627ABB1E29CC8356AD0800EB4B1E287796DD5C9A

echo
echo Done!
echo

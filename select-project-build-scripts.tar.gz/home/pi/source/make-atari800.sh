#!/bin/bash

cd $HOME/source

# if a previous atari800 folder exists, move into a date-time named folder

if [ -d "atari800" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "atari800" "atari800-$foldername"

        echo -e Archiving existing cc65 folder ["atari800"] into backup folder ["atari800-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/atari800/atari800
git clone https://github.com/atari800/atari800.git

cd atari800

GITREV=`git rev-parse --short HEAD`

./autogen.sh
./configure
make

if [ -f src/atari800 ]; then
	echo sudo cp src/atari800 /usr/local/bin/atari800-$GITREV
else
	echo atari800 binary not found!
	echo
fi
cd ..

echo
echo Done!


#!/bin/bash

cd $HOME/source

# if a previous eoslib folder exists, move into a date-time named folder
if [ -d "eoslib" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "eoslib" "eoslib-$foldername"

        echo -e Archiving existing eoslib folder ["eoslib"] into backup folder ["eoslib-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/tschak909/eoslib
git clone https://github.com/tschak909/eoslib.git

cd $HOME/source/eoslib
make

cd ..



cd $HOME/source

# if a previous smartkeyslib folder exists, move into a date-time named folder
if [ -d "smartkeyslib" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "smartkeyslib" "smartkeyslib-$foldername"

        echo -e Archiving existing smartkeyslib folder ["smartkeyslib"] into backup folder ["smartkeyslib-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/tschak909/smartkeyslib
git clone https://github.com/tschak909/smartkeyslib.git

cd $HOME/source/smartkeyslib
make

cd ..


# add Coleco Adam support libraries to z88dk - if it exists
if [ -d $HOME/source/z88dk ]; then


	# add eoslib support
	if [ -f $HOME/source/eoslib/eos.lib ]; then
        	ln -s $HOME/source/eoslib/eos.lib $HOME/source/z88dk/lib/clibs/eos.lib
	fi

	if [ -f $HOME/source/eoslib/src/eos.h ]; then
        	ln -s /source/eoslib/src/eos.h  $HOME/source/z88dk/include/eos.h
	fi


	# add smartkeyslib support
	if [ -f $HOME/source/smartkeyslib/smartkeys.lib ]; then
        	ln -s $HOME/source/smartkeyslib/smartkeys.lib  $HOME/source/z88dk/lib/clibs/smartkeys.lib
	fi

	if [ -f $HOME/source/smartkeyslib/src/smartkeys.h ]; then
        	ln -s $HOME/source/smartkeyslib/src/smartkeys.h  $HOME/source/z88dk/include/smartkeys.h
	fi

fi

echo Done!
echo

#!/bin/bash

# install prereqisites
#sudo apt install libglew-dev libcurl4-openssl-dev

cd $HOME/source

# if a previous vice folder exists, move into a date-time named folder

if [ -d "vice" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "vice" "vice-$foldername"

        echo -e Archiving existing vice folder ["vice"] into backup folder ["vice-$foldername"]
        echo -e
        echo -e
fi

# https://sourceforge.net/p/vice-emu/code/HEAD/tree/
svn checkout https://svn.code.sf.net/p/vice-emu/code/trunk vice-emu-code vice

cd vice/trunk/vice

./configure
make

echo
echo Done!


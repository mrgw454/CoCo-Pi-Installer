#!/bin/bash

cd $HOME/source

# if a previous ip65 folder exists, move into a date-time named folder

if [ -d "ip65" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "ip65" "ip65-$foldername"

        echo -e Archiving existing ip65 folder ["ip65"] into backup folder ["ip65-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/cc65/ip65
git clone https://github.com/cc65/ip65.git

cd ip65

# fix apps/Makefile
echo Fixing apps/Makefile...
echo
sed -i 's!AC ?= ac.jar!AC ?= ~/source/AppleCommander/ac-cli.jar!' apps/Makefile
if [ $? -eq 0 ]
then
  echo "Successfully modified apps/Makefile"
else
  echo "Failure to modifiy apps/Makefile" >&2
  echo
fi
echo
echo Fixing of apps/Makefile file complete.
#read -p "Press any key to continue... " -n1 -s
echo
echo

make

cd ..

echo
echo Done!


#!/bin/bash

# install prerequisites
#sudo apt-get install build-essential libncurses5-dev zlib1g-dev

cd $HOME/source

# if a previous AtariSIO folder exists, move into a date-time named folder

if [ -d "AtariSIO" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "AtariSIO" "AtariSIO-$foldername"

        echo -e Archiving existing cc65 folder ["AtariSIO"] into backup folder ["AtariSIO-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/HiassofT/AtariSIO/tree/master
git clone https://github.com/HiassofT/AtariSIO.git

cd AtariSIO

# https://github.com/HiassofT/AtariSIO/blob/master/README.RPi
#make tools DEFAULT_DEVICE=/dev/ttyUSB0
#sudo make rpi-install
sudo make tools-install

cd ..

echo
echo Done!

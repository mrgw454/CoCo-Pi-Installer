#!/bin/bash

cd $HOME/source

# if a previous AppleCommander folder exists, move into a date-time named folder

if [ -d "AppleCommander" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "AppleCommander" "AppleCommander-$foldername"

        echo -e Archiving existing cc65 folder ["AppleCommander"] into backup folder ["AppleCommander-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/AppleCommander/AppleCommander
git clone https://github.com/AppleCommander/AppleCommander.git

if [ -f app/gui-swt-linux-aarch64/build/libs/AppleCommander-linux-aarch64-1.9.1-SNAPSHOT.jar ]; then
	echo jar file exists!
	echo
else
	echo jar file does NOT exist!
	echo
fi

architecture=$(uname -m)
echo $architecture

cd AppleCommander
./gradlew clean build
./gradlew test

if [ -f app/gui-swt-linux-aarch64/build/libs/AppleCommander-linux-aarch64-1.9.1-SNAPSHOT.jar ]; then
	echo jar file exists!
	echo
	ln -s $HOME/source/AppleCommander/app/gui-swt-linux-aarch64/build/libs/AppleCommander-linux-aarch64-1.9.1-SNAPSHOT.jar $HOME/source/AppleCommander/ac.jar
	ln -s $HOME/source/AppleCommander/app/cli-ac/build/libs/AppleCommander-ac-1.9.1-SNAPSHOT.jar $HOME/source/AppleCommander/ac-cli.jar
else
	echo jar file does NOT exist!
	echo
fi

cd ..

echo
echo Done!


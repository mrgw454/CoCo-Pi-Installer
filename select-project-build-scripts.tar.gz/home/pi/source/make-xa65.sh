#!/bin/bash

# add these to your .bashrc file
# add path for xa65 compiler
#export PATH=/home/pi/source/xa65/xa:$PATH

cd $HOME/source

# if a previous xa65 folder exists, move into a date-time named folder

if [ -d "xa65" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "xa65" "xa65-$foldername"

        echo -e Archiving existing xa65 folder ["xa65"] into backup folder ["xa65-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/fachat/xa65
git clone https://github.com/fachat/xa65.git

cd xa65/xa

make

cd $HOME/source

echo
echo Done!

#!/bin/bash

# install prerequisites
#sudo apt install ddd

# install pyenv - if needed

# check if .pyenv home folder exists
if [ ! -d $HOME/.pyenv ]; then
        echo ~/.pyenv folder does not exist.  Installing pyenv...
        echo
        echo git clone https://github.com/pyenv/pyenv.git ~/.pyenv
        git clone https://github.com/pyenv/pyenv.git ~/.pyenv
else
        echo ~/.pyenv folder exists.  Skipping...
        echo
fi

# check if pyenv entires exist in .bashrc file
if grep -q PYENV_ROOT $HOME/.bashrc; then
        echo pyenv entries found in $HOME/.bashrc .  Skipping...
        echo
else
        echo pyenv entries not found in $HOME/.bashrc .  Adding...
        echo

cat >/tmp/np <<EOF
# pyenv setup
export PYENV_ROOT="$HOME/.pyenv"
command -v pyenv >/dev/null || export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init -)"
EOF

        cat /tmp/np >> ~/.bashrc
        source ~/.bashrc
        rm /tmp/np
        echo
        echo
fi

# check if correct version of python2 is installed for pyenv
if [ -d $HOME/.pyenv/versions/pypy2.7-7.3.11 ]; then
        echo correct verion of python2 exists in ~/.pyenv/versions folder.  Skipping...
        echo
else
        echo correct verion of python2 does not exist in ~/.pyenv/versions folder.  Installing...
        echo
        pyenv install pypy2.7-7.3.11
        echo
        echo
        source $HOME/.bashrc

fi

echo
echo


source $HOME/.bashrc
pyenv local pypy2.7-7.3.11


cd $HOME/source

# if a previous binutils-gdb-git folder exists, move into a date-time named folder

if [ -d "binutils-gdb-git" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "binutils-gdb-git" "binutils-gdb-git-$foldername"

        echo -e Archiving existing binutils-gdb-git folder ["binutils-gdb-git"] into backup folder ["binutils-gdb-git-$foldername"]
        echo -e
        echo -e
fi

# https://www.6809.org.uk/dragon/m6809-gdb.shtml
git clone -b m6809-7.6 https://www.6809.org.uk/git/binutils-gdb.git binutils-gdb-git

cd binutils-gdb-git

GITREV=`git rev-parse --short HEAD`

./autogen.sh
./configure --target=m6809 --disable-werror
make
sudo make install

cd ..

echo
echo Done!


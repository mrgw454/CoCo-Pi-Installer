#!/bin/bash

# add prerequisites
#sudo apt install cpanminus
#cpanm App::Prove File::Path CPU::Z80::Assembler Object::Tiny::RW List::Uniq

# make sure this is in your .bashrc file
# add z88dk library
#export PATH=${PATH}:${HOME}/source/z88dk/bin
#export ZCCCFG=${HOME}/source/z88dk/lib/config
#eval $(perl -I ~/perl5/lib/perl5/ -Mlocal::lib)

cd $HOME/source

# if a previous z88dk folder exists, move into a date-time named folder

if [ -d "z88dk" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "z88dk" "z88dk-$foldername"

        echo -e Archiving existing z88dk folder ["z88dk"] into backup folder ["z88dk-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/z88dk/z88dk
git clone --recursive https://github.com/z88dk/z88dk.git

cd z88dk
git submodule update --init --recursive

export BUILD_SDCC=1
export BUILD_SDCC_HTTP=1
chmod 777 build.sh
./build.sh


# add Coleco Adam support libraries to z88dk - if it exists

# add eoslib support
if [ -f $HOME/source/eoslib/eos.lib ];
	ln -s $HOME/source/eoslib/eos.lib ../z88dk/lib/clibs/eos.lib
fi

if [ -f $HOME/source/eoslib/src/eos.h ];
	ln -s /source/eoslib/src/eos.h ../z88dk/include/eos.h
fi


# add smartkeyslib support
if [ -f $HOME/source/smartkeyslib/smartkeys.lib ];
	ln -s $HOME/source/smartkeyslib/smartkeys.lib ../z88dk/lib/clibs/smartkeys.lib
fi

if [ -f $HOME/source/smartkeyslib/src/smartkeys.h ];
	ln -s $HOME/source/smartkeyslib/src/smartkeys.h ../z88dk/include/smartkeys.h
fi

cd ..

echo Done!
echo

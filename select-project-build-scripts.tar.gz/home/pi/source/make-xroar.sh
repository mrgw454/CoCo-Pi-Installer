#!/bin/bash

cd $HOME/source

# if a previous xroar-git folder exists, move into a date-time named folder

if [ -d "xroar-git" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "xroar-git" "xroar-git-$foldername"

        echo -e Archiving existing xroar-git folder ["xroar-git"] into backup folder ["xroar-git-$foldername"]
        echo -e
        echo -e
fi

# https://www.6809.org.uk/xroar/
git clone https://www.6809.org.uk/git/xroar.git xroar-git

cd xroar-git

GITREV=`git rev-parse --short HEAD`

./autogen.sh
./configure
make

if [ -f src/xroar ]; then
	sudo cp src/xroar /usr/local/bin/xroar-git-$GITREV
else
	echo xroar binary not found!
	echo
fi
cd ..

# run the select emulator script to confirm which version of XRoar to use as default
select-xroar.sh

echo
echo Done!


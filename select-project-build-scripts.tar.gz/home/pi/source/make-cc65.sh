#!/bin/bash

# add these to your .bashrc file
# add path for cc65 compiler
#export PATH=/home/pi/source/cc65/bin:$PATH


cd $HOME/source

# if a previous cc65 folder exists, move into a date-time named folder

if [ -d "cc65" ]; then

        foldername=$(date +%Y-%m-%d_%H.%M.%S)

        mv "cc65" "cc65-$foldername"

        echo -e Archiving existing cc65 folder ["cc65"] into backup folder ["cc65-$foldername"]
        echo -e
        echo -e
fi

# https://github.com/cc65/cc65
git clone https://github.com/cc65/cc65.git

cd cc65

make

cd ..

echo
echo Done!


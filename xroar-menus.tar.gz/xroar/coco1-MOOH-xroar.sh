#!/bin/bash

cd $HOME/.xroar

XROARPARMSFILE=`cat $HOME/.xroar/.optional_xroar_parameters.txt`
export XROARPARMS=$XROARPARMSFILE

clear

    # link to proper sdcard.img
    rm sdcard.img
    ln -s sdcard-dualboot-co42.img sdcard.img

#    xroar -default-machine cocous -cart mooh -cart-rom sdbdos-eprom8-all-v1.rom -ao-fragments 1
#    xroar -default-machine cocous -cart mooh -cart-rom sdbdos-eprom8-all-v1.rom -load-sd $HOME/.xroar/sdcard.img $XROARPARMS
#   xroar -default-machine cocous -cart mooh -cart-rom sdbdos-eprom8-all-v1.rom $XROARPARMS

#   xroar -default-machine cocous -extbas extbas10.rom -cart mooh -cart-rom ~/source/sdboot/bootrom/eprom8.rom -load-sd ./sdcard.img $XROARPARMS
    xroar -default-machine cocous -extbas extbas10.rom -cart mooh -cart-rom ~/source/sdboot/bootrom/eprom8.rom -cart mpi -mpi-load-cart 0=mooh -mpi-load-cart 3=rsdos -mpi-slot 0 -load-sd ./sdcard.img $XROARPARMS

# capture XRoar ERRORLEVEL

if [ $? -eq 0 ]
then
        echo

else
        echo
        echo "Please make note of message above when requesting help."
        echo
        read -p  "Press any key to continue." -n1 -s
fi

#cd $HOME/.mame
#CoCoPi-menu-Coco2-XRoar.sh

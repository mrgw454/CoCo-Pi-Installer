xroar -c $HOME/.xroar/xroar.conf -default-machine coco2bus -type "PRINT \"HELLO\"\n\PRINT \"HELLO AGAIN\"\n"


clear

cd $HOME/.ovcc

if [ -e $HOME/.ovcc/ini/coco3-decb-OVCC.ini ]
then
    cp $HOME/.ovcc/ini/coco3-decb-OVCC.ini $HOME/.ovcc/Vcc.ini
    $HOME/.ovcc/ovcc

        # capture OVCC ERRORLEVEL
        if [ $? -ne 139 ]
        then
                echo
        else
                echo
                echo "Please make note of message above when requesting help."
                echo
                read -p  "Press any key to continue." -n1 -s
        fi

else

    echo "OVCC ini file is missing for this configuation..  Aborting."
	echo
    	read -p  "Press any key to continue." -n1 -s
    	echo

fi

cd $HOME/.mame
CoCoPi-menu-Coco3-OVCC.sh








clear

$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk eject 0
$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk insert 0 /media/share1/DW4/GORDON/PLATO/plato.dsk

cd $HOME/.ovcc

if [ -e $HOME/.ovcc/ini/coco3-hdbdos-pyDW-PLATO-OVCC.ini ]
then
    cp $HOME/.ovcc/ini/coco3-hdbdos-pyDW-PLATO-OVCC.ini $HOME/.ovcc/Vcc.ini
    $HOME/.ovcc/ovcc

	# capture OVCC ERRORLEVEL
	if [ $? -ne 139 ]
	then
        	echo
	else
        	echo
        	echo "Please make note of message above when requesting help."
        	echo
        	read -p  "Press any key to continue." -n1 -s
	fi

else

    echo "OVCC ini file is missing for this configuation..  Aborting."
        echo
        read -p  "Press any key to continue." -n1 -s
        echo

fi

$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk eject 0

cd $HOME/.mame
CoCoPi-menu-Coco3-OVCC.sh

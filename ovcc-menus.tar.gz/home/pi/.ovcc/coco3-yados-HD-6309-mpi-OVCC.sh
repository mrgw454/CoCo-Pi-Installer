clear

# make sure BECKER port is ENABLED for pyDriveWire access to work correctly
# make sure cart autostart is DISABLED for YADOS to work correctly

$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw server hdbdos false

$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk eject 0
$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk insert 0 /media/share1/DW4/AUTOEXEC/AUTOEXEC.DSK
$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk insert 1 /media/share1/DW4/YADOS/yados.dsk

clear

cd $HOME/.ovcc

if [ -e $HOME/.ovcc/ini/coco3-yados-HD-6309-mpi-OVCC.ini ]
then
    cp $HOME/.ovcc/ini/coco3-yados-HD-6309-mpi-OVCC.ini $HOME/.ovcc/Vcc.ini
    $HOME/.ovcc/ovcc

        # capture OVCC ERRORLEVEL
        if [ $? -ne 139 ]
        then
                echo
        else
                echo
                echo "Please make note of message above when requesting help."
                echo
                read -p  "Press any key to continue." -n1 -s
        fi

else

    echo "OVCC ini file is missing for this configuation..  Aborting."
        echo
        read -p  "Press any key to continue." -n1 -s
        echo
fi

$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk eject 0
$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw server hdbdos true

cd $HOME/.mame
CoCoPi-menu-Coco3-OVCC.sh

clear

# make sure BECKER port is ENABLED for pyDriveWire access to work correctly

$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw server hdbdos 0

$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk eject 0
$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk eject 1

$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk insert 0 /media/share1/DW4/GORDON/FUZIX/boot.dsk
$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk insert 1 /media/share1/DW4/GORDON/FUZIX/fuzixfs.dsk

cd $HOME/.ovcc

if [ -e $HOME/.ovcc/ini/coco3-Fuzix-pyDW-OVCC.ini ]
then
    cp $HOME/.ovcc/ini/coco3-Fuzix-pyDW-OVCC.ini $HOME/.ovcc/Vcc.ini
    $HOME/.ovcc/ovcc

        # capture OVCC ERRORLEVEL
        if [ $? -ne 139 ]
        then
                echo
        else
                echo
                echo "Please make note of message above when requesting help."
                echo
                read -p  "Press any key to continue." -n1 -s
        fi

else

    echo "OVCC ini file is missing for this configuation..  Aborting."
        echo
        read -p  "Press any key to continue." -n1 -s
        echo
fi

$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk eject 0
$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw disk eject 1

$HOME/pyDriveWire/pyDwCli http://localhost:6800 dw server hdbdos true

cd $HOME/.mame
CoCoPi-menu-Coco3-OVCC.sh

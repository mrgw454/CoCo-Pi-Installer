clear

# make sure BECKER port is ENABLED for pyDriveWire access to work correctly

cd $HOME/.ovcc

if [ -e $HOME/.ovcc/ini/coco3-hdbdos-6309-nitros9-OVCC.ini ]
then
    cp $HOME/.ovcc/ini/coco3-hdbdos-6309-nitros9-OVCC.ini $HOME/.ovcc/Vcc.ini
    $HOME/.ovcc/ovcc

        # capture OVCC ERRORLEVEL
        if [ $? -ne 139 ]
        then
                echo
        else
                echo
                echo "Please make note of message above when requesting help."
                echo
                read -p  "Press any key to continue." -n1 -s
        fi

else

    echo "OVCC ini file is missing for this configuation..  Aborting."
        echo
        read -p  "Press any key to continue." -n1 -s
        echo
fi

cd $HOME/.mame
CoCoPi-menu-Coco3-OVCC.sh

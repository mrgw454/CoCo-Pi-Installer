#!/bin/bash

wine "c:\program files (x86)\trstools\trstools.exe" "$1"

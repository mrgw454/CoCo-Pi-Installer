#!/bin/bash

trs80gp -m4p -mem 128 -frehd -frehd_dir /home/ron/source/trs80-sd/output -frehd_patch -frehd_menu


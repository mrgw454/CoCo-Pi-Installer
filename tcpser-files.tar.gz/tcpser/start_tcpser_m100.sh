export NEWT_COLORS='
root=black,black
border=black,black
window=black,black
shadow=black,black
title=brightgreen,black
button=white,black
actbutton=black,white
checkbox=back,black
actcheckbox=black,black
entry=green,black
label=white,black
listbox=green,black
actlistbox=black,green
textbox=white,black
acttextbox=black,white
helpline=black
roottext=black
disentry=black,black
compactbutton=black,black
actsellistbox=black,green
sellistbox=green,black
'

clear

echo
echo
echo
echo
echo
echo
echo
echo
echo
echo

echo -e "Start modem emulator (tcpser)." > msg.txt
echo -e "More information about tcpser can be found here (https://github.com/FozzTexx/tcpser)." >> msg.txt
echo -e >> msg.txt
echo -e "This script should be run from a separate console." >> msg.txt
echo -e >> msg.txt

whiptail --title "Modem Emulator (tcpser)" --textbox msg.txt 0 0
rm msg.txt

cd $HOME/tcpser

# various command line options are listed below.  Only uncomment one at a time.

# This one works with a TRS-80 Model 100 using it's 25 pin serial port.  Set TERM80 (or other terminal program) baud rate to match what is being used here.

#The TELCOM application to communicate with that serial console session. TELCOM uses a set-up command, "Stat," to configure the speed and communications settings for a terminal session. Stat configures the connection based on a five-character string that uses single characters to define:

#The baud rate (1 = 75, 2 = 110, 3 = 300, 4 = 600, 5 = 1200, 6 = 2400, 7 = 4800, 8 = 9600, 9 = 19200);
#The size of the bit words of data sent over the connection (7 or 8 bit);
#The parity bit used for error checking (E for even, O for odd, N for none, I for ignore);
#The number of stop bits (1 or 2);
#And whether XON/XOFF is enabled (E) or disabled (D).
#So, for example, to configure TELCOM on the Model 100 for my goal speed of 19,200 baud, using 8 bit words, no parity, 1 stop bit, and disabled XON/XOFF, the setup string would be:

#Stat 98N1D

tcpser -l 7 -i "e1 &k0 &c1 &r1 &s0" -I -s 1200 -tSs -v 6551 -d /dev/ttyUSB0

cd $HOME/tcpser

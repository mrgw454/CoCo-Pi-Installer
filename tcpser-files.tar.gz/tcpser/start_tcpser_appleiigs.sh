export NEWT_COLORS='
root=black,black
border=black,black
window=black,black
shadow=black,black
title=brightgreen,black
button=white,black
actbutton=black,white
checkbox=back,black
actcheckbox=black,black
entry=green,black
label=white,black
listbox=green,black
actlistbox=black,green
textbox=white,black
acttextbox=black,white
helpline=black
roottext=black
disentry=black,black
compactbutton=black,black
actsellistbox=black,green
sellistbox=green,black
'

clear

echo
echo
echo
echo
echo
echo
echo
echo
echo
echo

echo -e "Start modem emulator (tcpser)." > msg.txt
echo -e "More information about tcpser can be found here (https://github.com/FozzTexx/tcpser)." >> msg.txt
echo -e >> msg.txt
echo -e "This script should be run from a separate console." >> msg.txt
echo -e >> msg.txt

whiptail --title "Modem Emulator (tcpser)" --textbox msg.txt 0 0
rm msg.txt

cd $HOME/tcpser

# various command line options are listed below.  Only uncomment one at a time.

# This one works with an Apple IIgs the buil-in modem port on the back of the unit.  Set ProTerm (or other terminal program) baud rate to match what is being used here.
#tcpser -i "e1 k0 s0=1" -l 4 -v 6551 -s 2400 -p 6809 -tSs -d /dev/ttyUSB1

# This one works with an Apple IIgs the buil-in modem port on the back of the unit.  Set ProTerm (or other terminal program) baud rate to match what is being used here.
tcpser -i "e1 k0 s0=1" -l 4 -v 2023 -s 2400 -p 6502 -tSs

cd $HOME/tcpser

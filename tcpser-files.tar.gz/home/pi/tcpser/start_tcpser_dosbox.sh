export NEWT_COLORS='
root=black,black
border=black,black
window=black,black
shadow=black,black
title=brightgreen,black
button=white,black
actbutton=black,white
checkbox=back,black
actcheckbox=black,black
entry=green,black
label=white,black
listbox=green,black
actlistbox=black,green
textbox=white,black
acttextbox=black,white
helpline=black
roottext=black
disentry=black,black
compactbutton=black,black
actsellistbox=black,green
sellistbox=green,black
'

clear

echo
echo
echo
echo
echo
echo
echo
echo
echo
echo

echo -e "Start modem emulator (tcpser)." > msg.txt
echo -e "More information about tcpser can be found here (https://github.com/FozzTexx/tcpser)." >> msg.txt
echo -e >> msg.txt
echo -e "When using with DOSBOX, please make sure to change the serial port settings" >> msg.txt
echo -e "to:  serial1 = modem listenport:6809" >> msg.txt
echo -e >> msg.txt
echo -e "This script should be run from a separate console." >> msg.txt
echo -e >> msg.txt

whiptail --title "Modem Emulator (tcpser)" --textbox msg.txt 0 0
rm msg.txt

cd $HOME/tcpser

# various command line options are listed below.  Only uncomment one at a time.

# This one works with MAME (emulation) and TI's using a PEB RS232 card.  Set TERM80 (or other terminal program) baud rate to match what is being used here.
tcpser -i "e1 k0 s0=1" -l 4 -v 10000 -s 1200 -p 6809 -tSs

cd $HOME/tcpser

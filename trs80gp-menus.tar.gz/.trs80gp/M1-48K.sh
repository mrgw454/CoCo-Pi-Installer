trs80gp -m1 -mem 48k -d1 /media/share1/TRS80/Al\ Wallace/ST20221226.DSK

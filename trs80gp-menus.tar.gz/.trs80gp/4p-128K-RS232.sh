trs80gp -m4p -mem 128 -d1 /media/share1/TRS80/Terminal/OmniTerm\ Plus\ v4.11\ \(1985\)\(Lindbergh\ Systems\)\[DSK\]/otp411.dsk -r localhost:25232

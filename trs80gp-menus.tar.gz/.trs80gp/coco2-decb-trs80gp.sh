#!/bin/bash

cd $HOME/.trs80gp

TRS80GPPARMSFILE=`cat $HOME/.trs80gp/.optional_trs80gp_parameters.txt`
export TRS80GPPARMS=$TRS80GPPARMSFILE

clear

if [ -z "$1" ]
then
	/usr/local/bin/trs80gp -mc $TRS80GPPARMS
else
	/usr/local/bin/trs80gp -mc $TRS80GPPARMS -d0 "$1"
fi


# capture trs80gp ERRORLEVEL

if [ $? -eq 0 ]
then
	echo

else
	echo
	echo "Please make note of message above when requesting help."
	echo
	read -p  "Press any key to continue." -n1 -s
fi

cd $HOME/.mame
CoCoPi-menu-Coco2-trs80gp.sh

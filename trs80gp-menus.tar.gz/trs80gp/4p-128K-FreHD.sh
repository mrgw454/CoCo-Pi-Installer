trs80gp -m4p -mem 128 -frehd_dir /media/share1/TRS80/FreHD/SD
